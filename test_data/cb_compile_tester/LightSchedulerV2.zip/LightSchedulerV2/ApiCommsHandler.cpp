#include "Arduino.h"
#include "ApiCommsHandler.h"

// ---------------- ApiCommand ---------------------
ApiCommand::ApiCommand()
{
	_type = command_invalid;
}
ApiCommand::ApiCommand(String data)
{
	char typeChar = data.charAt(0);
	String payload = data.substring(1);
	Payload[0] = _getValue(payload, '-', 0);
	Payload[1] = _getValue(payload, '-', 1);
	Payload[2] = _getValue(payload, '-', 2);
	Payload[3] = _getValue(payload, '-', 3);
	Payload[4] = _getValue(payload, '-', 4);
	
	// Determine command type
	_type = command_invalid;
	switch(typeChar)
	{
		case 'g':
			if(Payload[0].toInt() == 0) // No (valid) parameters -> Dimensions
			{
				_type = command_get_dimensions;
			}
			else if(Payload[1].toInt() > 0)	// Channel and Point specified -> Point
			{
				_type = command_get_point;
			}
			break;
		case 's':	// Set
			if(Payload[0].toInt() != 0 && Payload[1].toInt() != 0) // Channel and Point specified -> Point
			{
				_type = command_set_point;
			}
			break;
		case 'c':	// Clear
			if(Payload[0].toInt() == 0) // No (valid) parameters -> All
			{
				_type = command_clear_all;
			}
			else	// Channel specified -> Channel
			{
				_type = command_clear_channel;
			}
			break;
		case 'u':	// Update
			_type = command_update;
	}
}

ApiCommandType ApiCommand::GetType()
{
	return _type;
}

String ApiCommand::_getValue(String data, char separator, int index) // Thanks Alvarolb (http://stackoverflow.com/a/14824108)
{
	int found = 0;
	int strIndex[] = {0, -1};
	int maxIndex = data.length() - 1;
	for(int i = 0; i <= maxIndex && found <= index; i++)
	{
		if(data.charAt(i) == separator || i == maxIndex)
		{
			found++;
			strIndex[0] = strIndex[1] + 1;
			strIndex[1] = (i == maxIndex) ? i + 1 : i;
		}
	}
	return found > index ? data.substring(strIndex[0], strIndex[1]) : "";
}

// ---------------- ApiCommsHandler ---------------------

ApiCommsHandler::ApiCommsHandler(HardwareSerial &print)
{
	printer = &print; //operate on the adress of print
}

ApiCommand ApiCommsHandler::ReadCommand()
{
	ApiCommand noCommand = ApiCommand();
	if(Serial.available() == 0)
	{
		return noCommand;
	}
	char inChar; // Where to store the character read
	byte index = 0; // Index into array; where to store the character
	char commandData[20]; // Buffer for recieved data
	if(Serial.available() > 0) // Don't read unless you know there is data
	{
		long start = millis();
		while(millis() < start + 1000)	// 1 second timout
		{
			if(Serial.available() > 0)
			{
				if(index < 19) // One less than the size of the array
				{
					inChar = Serial.read(); // Read a character
					commandData[index] = inChar; // Store it
					index++; // Increment where to write next
					commandData[index] = '\0'; // Null terminate the string
					if(inChar == '!')
					{
						return ApiCommand(String(commandData));
					}
				}
				else // Invalid data, return nothing
				{
					return noCommand;
				}
			}
		}
	}
}

void ApiCommsHandler::SendPoint(int channel, int index, int hours, int minutes, int intensity) 
{
	Serial.print(channel);
	Serial.print("-");
	Serial.print(index);
	Serial.print("-");
	Serial.print(hours);
	Serial.print("-");
	Serial.print(minutes);
	Serial.print("-");
	Serial.print(intensity);
	Serial.print("!");	
}

void ApiCommsHandler::SendDimensions(int channels, int points) 
{
	Serial.print(channels);
	Serial.print("-");
	Serial.print(points);
	Serial.print("!");	
}

void ApiCommsHandler::SendAck()
{
	Serial.print("x!");
}
