#include "Arduino.h"
#include <avr/eeprom.h>
#include "ChannelManager.h"
#include <NewEEPROM.h>

// ---------------- Point ------------------------
Point::Point()
{
	_minutes = 0;
	_intensity = 0;
}

// Initialize Point with given values
Point::Point(byte h, byte m, float intensity)
{
	_minutes = (60 * (int)h) + m;
	_intensity = intensity;
}

long Point::GetTimeSeconds()
{
	return _minutes * 60;
}

byte Point::GetHours()
{
	return (byte)(_minutes / 60);
}

byte Point::GetMinutes()
{
	return (byte)(_minutes % 60);
}

float Point::GetIntensity()
{
	return _intensity;
}

byte Point::GetIntensityInt()
{
	return (byte)((float) 255 * _intensity);
}

byte Point::GetIntensityPercent()
{
	return (byte)(100 * _intensity);
}

bool Point::IsValid()
{
	return _minutes >= 0 && _minutes < 60 * 24 && _intensity >= 0 && _intensity <= 1;
}

void Point::PrintPoint()
{
	Serial.print("Point: ");
	Serial.print(GetHours());
	Serial.print("-");
	Serial.print(GetMinutes());
	Serial.print("-");
	Serial.print(GetIntensityPercent());
	if(IsValid()) {
		Serial.println(" VALID");
	} else {
		Serial.println(" NOT VALID");
	}
}

// -------------- Storage Manager ----------------
StorageManager::StorageManager()
{
}

StorageManager::StorageManager(int offset, int channelsize)
{
	_offset = offset;
	_channelSize = channelsize;
}

int StorageManager::GetMaxChannelSize()
{
	return _channelSize;
}

Point StorageManager::Read(int channel, int index)
{
	int channelOffset = (channel-1) * _channelSize;
	int pointOffset = (index - 1) * 3;
	int addr = _offset + channelOffset + pointOffset;
	//byte h = EEPROM.read(addr);
	//byte m = EEPROM.read(addr+1);
	//byte value = EEPROM.read(addr+2);
	byte h = eeprom_read_byte((byte *) addr);
	byte m = eeprom_read_byte((byte *) (addr+1));
	byte value = eeprom_read_byte((byte *) (addr+2));
	return Point((int)h, (int)m, (float)value / 100);
}

void StorageManager::Write(int channel, int index, Point p)
{
	int channelOffset = (channel-1) * _channelSize;
	int pointOffset = (index - 1) * 3;
	int addr = _offset + channelOffset + pointOffset;
	//EEPROM.write(addr, p.GetHours());
	//EEPROM.write((addr + 1), p.GetMinutes());
	//EEPROM.write((addr + 2), p.GetIntensityPercent());
        p.PrintPoint();
	eeprom_write_byte((unsigned char *) addr, p.GetHours());
	eeprom_write_byte((unsigned char *) (addr + 1), p.GetMinutes());
	eeprom_write_byte((unsigned char *) (addr + 2), p.GetIntensityPercent());
}

// ---------------------- Point List -----------------------
List::List() {}

List::List(int channelNr, StorageManager* m)
{
	_maxLength = m->GetMaxChannelSize();
	_length = 0;
	_currentPosition = 1;
	_channelNr = channelNr;
	_storage = m;
}

Point List::GetPrevious()
{
	return _previous;
}

Point List::GetNext()
{
	return _next;
}

Point List::GetPoint(int index)
{
	return _storage->Read(_channelNr, index);
}

int List::GetLength()
{
	return _length;
}

void List::UpdateChannelLength()
{
	_length = 0;
	Point _c;
	Point _n;
	for(_length; _length < _maxLength; _length++)
	{
		// End of channel has been reached if:
		_c = _storage->Read(_channelNr, _length + 1);
		if(!_c.IsValid() || _length == _maxLength)	
		{
			// Current point is invalid (can only happen at the first one) or Max length of channel has been reached
			return;
		}
		_n = _storage->Read(_channelNr, _length + 2);
		if(!_n.IsValid() || _n.GetTimeSeconds() <= _c.GetTimeSeconds())
		{
			// Next point is invalid or earlier than current point (different kind of invalid)
			return;
		}
	}
}

void List::MoveForward()
{
	int nextPosition = 1;
	if(_currentPosition < _length - 1)
	{
		_currentPosition++;
		nextPosition = _currentPosition + 1;
	}
	else if(_currentPosition == _length - 1)
	{
		_currentPosition++;
		nextPosition = 1;
	}
	else if(_currentPosition == _length)
	{
		_currentPosition = 1;
		nextPosition = _currentPosition + 1;
	}
	_previous = _storage->Read(_channelNr, _currentPosition);
	_next =  _storage->Read(_channelNr, nextPosition);
}

void List::Add(Point p)
{
	if(_length == 0)
	{
		_previous = p;
		_next = p;
		_currentPosition = 1;
		_length = 1;
	}
	else
	{
		_previous = p;
		_currentPosition++;
		_length++;
	}
	Set(_currentPosition, p);
}

void List::Set(int index, Point p)
{
	_storage->Write(_channelNr, index, p);
}

void List::FindPosition(long time)
{
	if(_length <= 1) return;
	while(true)
	{
		if (_previous.GetTimeSeconds() <= time && _next.GetTimeSeconds() > time)
		{
			// Between 'this' point and 'next'
			break;
		}
		else if (_previous.GetTimeSeconds() <= time && _next.GetTimeSeconds() < _previous.GetTimeSeconds())
		{
			// Between 'this' point and 'next', currently before midnight and 'next' beeing after midnight
			break;
		}
		else if (_previous.GetTimeSeconds() > time && _next.GetTimeSeconds() > time && _previous.GetTimeSeconds() > _next.GetTimeSeconds())
		{
			// Between 'this' point and 'next', currently after midnight and 'this' point being before midnight
			break;
		}
		else
		{
			// Better luck next time
			MoveForward();
		}
	}
}

// ------------------- Channel ---------------------------

Channel::Channel() {}

// Initialize channel w. no points
Channel::Channel(int pin, int channelNr, FadeMode fadeMode, StorageManager* m)
{
	_pin = pin;
	_lightValue = 0;
	_fadeMode = fadeMode;
	_schedule = List(channelNr, m);
}

int Channel::GetPin()
{
	return _pin;
}

// Add Point to first available position (wrapper function)
void Channel::AddPoint(int h, int m, float intensity)
{
	_schedule.Add(Point(h, m, intensity));
}

void Channel::SetPoint(int index, int h, int m, float intensity)
{
	_schedule.Set(index, Point(h, m, intensity));
}

void Channel::ClearPoint(int index)
{
	_schedule.Set(index, Point());
}

Point Channel::GetPoint(int index)
{
	return _schedule.GetPoint(index);
}

void Channel::GoToCurrentPosition(long time)
{
	_schedule.FindPosition(time);
}

int Channel::GetLightIntensityInt(long time)
{
	UpdateCurrentLightValue(time);
	return _lightValue;
}

float Channel::CorrectForFadeMode(float intensity)
{
	switch(_fadeMode)
	{
		case fademode_exponential:
			return intensity * intensity;
		default:
			return intensity;
	}
}

void Channel::UpdateData()
{
	_schedule.UpdateChannelLength();
}

int Channel::GetLength()
{
	return _schedule.GetLength();
}

void Channel::UpdateCurrentLightValue(long time)
{
	GoToCurrentPosition(time);
	long timeDiff = 0;
	long prevPointTime = _schedule.GetPrevious().GetTimeSeconds();
	float prevPointIntensity = _schedule.GetPrevious().GetIntensity();
	long nextPointTime = _schedule.GetNext().GetTimeSeconds();
	float nextPointIntensity = _schedule.GetNext().GetIntensity();

	if(prevPointTime > nextPointTime)   // Midnight rollover
	{
		timeDiff = (nextPointTime + 24 * 60 * 60) - prevPointTime;
	}
	else
	{
		timeDiff = nextPointTime - prevPointTime;
	}

	long progress = 0;
	if(time > prevPointTime)   // Currently before midnight
	{
		progress = time - prevPointTime;
	}
	else     // Currently after midnight
	{
		progress = (time + 24 * 60 * 60) - prevPointTime;
	}
	float intensityDiff = nextPointIntensity - prevPointIntensity;	// Difference in light intesity between points
	float intensity = prevPointIntensity + (progress * (intensityDiff / timeDiff)); // Current intensity
	_lightValue = 255 * CorrectForFadeMode(intensity);		// Light value
}