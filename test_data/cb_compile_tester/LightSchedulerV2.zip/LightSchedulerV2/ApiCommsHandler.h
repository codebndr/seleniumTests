#include "Arduino.h"

enum ApiCommandType {
	command_get_dimensions,
	command_get_point,
	command_set_point,
	command_clear_all,
	command_clear_channel,
	command_update,
	command_invalid
};

class ApiCommand {
	public:
		ApiCommand();
		ApiCommand(String data);
		ApiCommandType GetType();
		String Payload[5];
	private:
		String _getValue(String data, char separator, int index);
		ApiCommandType _type;
};

class ApiCommsHandler {
  public:
    //pass a reference to a Print object
    ApiCommsHandler(HardwareSerial &print);
    ApiCommand ReadCommand();
	void SendPoint(int channel, int index, int hours, int minutes, int intensity);
	void SendDimensions(int channels, int points); 
	void SendAck();
  private:
    HardwareSerial* printer;
};
