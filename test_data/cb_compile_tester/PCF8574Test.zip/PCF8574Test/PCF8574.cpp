#include "PCF8574.h"
#include <Wire.h>

PCF8574::PCF8574(int address){
  _address = address;
  _data = 0xFF;
}

unsigned char PCF8574::getData(){
   return _data;
}

void PCF8574::setPinValue(byte pin){
  if (pin >=0 && pin <= 7 ){
    unsigned char pinValue = 1;
    pinValue <<= pin;
    _data = _data | pinValue;
  }
}

void PCF8574::unsetPinValue(byte pin){
  if (pin >=0 && pin <= 7 ){
    unsigned char pinValue = 1;
    pinValue <<= pin;
    _data = _data & (~pinValue) ;
  }
}
