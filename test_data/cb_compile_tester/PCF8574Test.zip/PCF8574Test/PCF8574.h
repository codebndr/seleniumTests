#ifndef PCF8574_h
#define PCF8574_h
#include <Arduino.h>

class PCF8574{
  public:
    PCF8574(int address);
    unsigned char getData();
    void setPinValue(byte pin);
    void unsetPinValue(byte pin);

  private:
    unsigned char _data;
    unsigned int _address;
};

#endif