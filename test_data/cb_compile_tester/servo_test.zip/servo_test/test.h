#include <Servo.h>

class test
{
	Servo s;
};