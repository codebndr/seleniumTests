class PushButton
{
public:
	PushButton(int pushPin)
		: m_pushPin(pushPin)
		, m_buttonDown(false) {}
		
	void begin()
	{
		pinMode(m_pushPin, INPUT);
	}
	
	bool isDown()
	{
		return digitalRead(m_pushPin) == HIGH;
	}
	
	bool isUp()
	{
		return digitalRead(m_pushPin) == LOW;
	}
	
	bool hasPushed()
	{
		if (isDown() && !m_buttonDown)
			m_buttonDown = true;
			
		if (isUp() && m_buttonDown)
		{
			m_buttonDown = false;
			return true;
		}
		
		return false;
	}
	
private:
	int m_pushPin;
	bool m_buttonDown;
};
