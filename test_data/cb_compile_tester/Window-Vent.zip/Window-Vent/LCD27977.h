#include <SoftwareSerial.h>

class LCD27977
{
public:
	LCD27977(int txPin)
		: m_txPin(txPin)
		, m_serial(255, txPin) {}
	
	void begin(int baud_rate)
	{
		pinMode(m_txPin, OUTPUT);
		digitalWrite(m_txPin, HIGH);
    
		m_serial.begin(baud_rate);
		delay(100);                        // give serial port a bit of time
               
		clear();
		displayOn();  
		backlightOn();
	}
  
	void clear()
	{
		m_serial.write(12);                // Clear
	}
  
	void backlightOn()
	{
		m_serial.write(17);                // Turn backlight on
		delay(5);                          // Required delay
	}
  
	void backlightOff()
	{
		m_serial.write(18);                 // Turn backlight off
	}
  
	void displayOn()
	{
		m_serial.write(22);                // Turn on display, cursor off, no blinking
	}
  
  	void gotoLine(int line, int pos)
  	{
  		const int startCode[4] = {128, 148, 168, 188};
  		m_serial.write(startCode[line] + pos);
  	}
  	
	void nextLine()
	{
		m_serial.write(13);                 // Form feed
	}
  
	void quarterNote()
	{
		m_serial.write(212);                // Quarter note
	}
  
	void tone()
	{
		m_serial.write(220);                // A tone
	}
 
	SoftwareSerial& serial()
	{
		return m_serial;
	}
  
private:
	int m_txPin;
	SoftwareSerial m_serial;
};