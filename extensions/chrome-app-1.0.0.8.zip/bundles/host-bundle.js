(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
function isOldstyleGetManifest (message) {
  // Here is an exemplary oldstyle message:
  //
  // {
  //     timestamp: 1435930180385,
  //     object: "runtime",
  //     method: "getManifestAsync",
  //     args: {
  //       args: [{
  //         type: "function"
  //       }]
  //     },
  //     error: null,
  //     callbackId: 1435930180385,
  //     sender: 1435930180385
  //   }

  return message &&
    message.method == "getManifestAsync" &&
    message.object == "runtime" &&
    message.callbackId;
}


function getState (apiRoot, state, cb) {
  var formattedState = apiRoot.runtime.getManifest();
  formattedState.connections = state.connections.map(function (c) {
    return c && {
      bufferLength: c.bufferLength,
      conf: c.portConf,
      id: c.id,
      closed: c.closed
    };
  }),

  formattedState.keepalives = state.keepalives.map(function (k) {
    return k && {
      clientId: k.clientId,
      conf: k.portConf,
      closed: k.closed
    };
  }),

  cb(formattedState);
};

function setupAdHoc (state) {
  var apiRoot = state.apiRoot;

  // Remember to add these to the client configuration.
  if (apiRoot.runtime) {
    if (!apiRoot.babelfish) apiRoot.babelfish = {};
    apiRoot.babelfish.getState =
      apiRoot.runtime.getManifestAsync =
      getState.bind(null, apiRoot, state);


    // Listen for get state to non-babelfish or early babelfish.
    function provideState (msg, sendResp) {
      if (msg && (msg.method == "getState" || isOldstyleGetManifest(msg))) {
        apiRoot.babelfish.getState(sendResp);
        return false;
      }

      return true;
    };

    state.bootstrapHost.commands.push(provideState);
  }

  if (apiRoot.serial) {
    apiRoot.serial.onReceiveError.forceDispatch = function (info) {
      state.connections.forEach(function (c) {
        if (c.apiEvent.methodName == 'serial.onReceiveError.addListener') {
          c.apiEvent.methodRequest.realCallback().call(null, info);
        }
      });
    };
  }
}

module.exports.setupAdHoc = setupAdHoc;

},{}],2:[function(require,module,exports){
/**
 * @fileOverview A wrapper around a chrome api event or non-pure call
 * that needs cleaning up. Understands the currency of MethodRequests
 * for cleaning up and managing state and provides a unified interface
 * for cleaning any call based on client's instructions upon
 * connection.
 *
 * Due to usb.findDevices which opens multiple devices at once we may
 * need more than one cleanup methods to actually close the event
 * emitter.
 *
 * @name apieventemitter.js
 * @author Chris Perivolaropoulos
 */
var util = require("./util"),
    AckResponse = require('./responses.js').AckResponse,
    ArgsResponse = require('./responses.js').ArgsResponse,
    MethodRequest = require('./requests.js').MethodRequest,
    Arguments = require('./arguments.js').Arguments,
    log = new (require('./log.js').Log)('apieventemitter');


/**
 * Response methods to inject in an api depending on the closing type.
 */
var closingResponses = {
  callingArguments: function (closingRequest) {
    if (!closingRequest) {
      new MethodRequest(null, this.reverser.path, this.args)
        .call(null, this.hostApi);
      return null;
    }

    if (this.reverser.path == closingRequest.method &&
        JSON.stringify(closingRequest.args.forSending()) ==
        JSON.stringify(this.args.forSending())) {
      closingRequest.call(null, this.hostApi);
      this.destroy(true);
      return new AckResponse();
    }

    return null;
  },

  /**
   * Maybe cleanup based on the arguments of the first callback.
   *
   * @param {undefined|MethodReqest} closingRequest A method request
   * that is supposed to close. If not provided make sure we are
   * destroyed as there is noone to report to.
   * @returns {null|ArgsResponse} The response to be sent after the cleanup.
   */
  firstResponse: function (closingRequest) {
    var fr = this.firstResponseMsg;
    if (!fr || fr.responseType != 'ArgsResponse') {
      return null;
    }

    var closingArg = fr.args[0];
    if (this.reverser.firstArgPath) {
      closingArg = closingArg[this.reverser.firstArgPath];
    }

    if (!closingRequest) {
      // Just do your best.
      var mr = new MethodRequest(null, this.reverser.path,
                                 new Arguments([closingArg, function () {}]));
      mr.call(null, this.hostApi);
      return null;
    }

    if (JSON.stringify(closingArg) ==
        JSON.stringify(closingRequest.args.forSending()[0]) &&
        closingRequest.method == this.reverser.path) {
      this.destroy(true);
      // The request will be called and will call an actual callback.
      return ArgsResponse.async(closingRequest, this.hostApi);
    }

    return null;
  },

  // Backwards compatible
  serial: function (closingRequest) {
    var oldfap = this.reverser.firstArgPath = 'connectionId';
    return closingResponses.firstResponse(closingRequest);
    this.reverser.firstArgPath = oldfap;
  },

  default: function (closingRequest) {
    return closingResponses.serial(closingRequest) ||
      closingResponses.firstResponse(closingRequest) ||
      closingResponses.callingArguments(closingRequest);
  }
};


/**
 * An Api event emitter or a method with side effects that need
 * cleaning up.
 *
 * @param {MethodRequest} methodRequest the information on how to call
 * the emitter
 * @param {ReverserObject} reverser a {path, type} reverser object.
 * @param {Object} hostApi The root of the host api.
 * @param {Function} closeCb Call this when closed
 */
function ApiEventEmitter (methodRequest, reverser, hostApi, closeCb) {
  var self = this;
  this.methodName = methodRequest.method;
  this.reverser = reverser;
  this.hostApi = hostApi;
  this.calledClosingRequests = [];

  // Remember the first response
  this.args = methodRequest.args;
  this.args.setLens(function (cb) {
    return function () {
      var args = [].slice.call(arguments);
      self.firstResponseMsg = self.firstResponseMsg || args[0];
      cb.apply(null, args);
    };
  });
  this.methodRequest = methodRequest;
  log.log("Starting [rev type: " + self.reverser.type + "]: ", methodRequest.forSending());

  this.maybeRunCloser = function (closingRequest) {
    if (self.closed) {
      console.error("Trying to close a closed event emitter");
      return null;                 //THis shouldn;t happen
    }

    // Default to *some* way of handling responses.
    var closingResponseFactory = closingResponses[self.reverser.type] ||
        closingResponses.default,
        ret = closingResponseFactory.call(self, closingRequest);

    if (ret) {
      log.log("Closing[" + self.reverser.type + "]:", ret,
              "with", closingRequest);
    }
    return ret;
  };

  // Actually trigger the event.
  this.closeCb = closeCb;
}

ApiEventEmitter.prototype = {
  /**
   * Actually run the api event emitter.
   */
  fire: function () {
    log.log("Connected:", this.methodRequest.forSending());
    // No send function, just a hostapi
    this.methodRequest.call(null, this.hostApi);
  },

  /**
   * Call all the closing requests to close this event.
   * @param {Boolean} shallow True means the API part of destroying
   * has been handled.
   */
  destroy: function (shallow) {
    var self = this;
    // Closing this and the connection will create a loop so don't omit this.
    if (this.closed) return;
    if (!shallow) this.maybeRunCloser();
    this.closed = true;
    this.closeCb();
    log.log("Disconected:", this.methodRequest.forSending());
  },

  missingReverseCb: function () {
    throw new Error("No such method as " + this.methodName);
  },

  missingMethodCb: function () {
    throw new Error("No reverse method for " + this.methodName);
  }
};

module.exports.ApiEventEmitter = ApiEventEmitter;

},{"./arguments.js":3,"./log.js":13,"./requests.js":17,"./responses.js":21,"./util":29}],3:[function(require,module,exports){
/**
 * @fileOverview Abstractions for handling argument transformation for
 * transportation between host-client.
 * @name arguments.js
 * @author Chris Perivolaroulos
 */

// The sorting below will be reflected.
module.exports.CallbackArgument = require('./arguments/callback.js');
module.exports.DataArgument = require('./arguments/data.js');
module.exports.DatabufferArgument = require('./arguments/databuffer.js');
module.exports.BasicArgument = require('./arguments/basic.js');
module.exports.Arguments = require('./arguments/container.js');
module.exports.argumentFactory = require('./arguments/factory.js').argumentFactory;
module.exports.argumentClasses = require('./arguments/factory.js').argumentClasses;

},{"./arguments/basic.js":4,"./arguments/callback.js":5,"./arguments/container.js":6,"./arguments/data.js":7,"./arguments/databuffer.js":8,"./arguments/factory.js":9}],4:[function(require,module,exports){
var argumentClasses = require('./factory.js').argumentClasses;

/**
 * An already serializable argument boxer.
 * @param {argument} arg
 */
function BasicArgument(arg) {
  this.value = arg;
}
/**
 * Wether we can wrap. We assume we always can.
 * @param {anything} arg
 * @returns {Boolean} Always true.
 */
BasicArgument.canWrap = function (arg) {
  return true;
};

BasicArgument.prototype = {
  /**
   * @returns {anything} Just return the value.
   */
  forCalling: function () {
    return this.value;
  },

  /**
   * @returns {anything} Just return the value.
   */
  forSending: function () {
    return this.value;
  }
};
argumentClasses.push(BasicArgument);
module.exports = BasicArgument;

},{"./factory.js":9}],5:[function(require,module,exports){
var argumentClasses = require('./factory.js').argumentClasses;

/**
 * Wrap a callback. The callback will get an id. The arg's id (wether
 * function or object) preceeds the replaceCb id.
 *
 * @param {Function|Object} arg a serialized CallbackArgument or the
 * callback itself.
 * @param {Function} replaceCb if the provided arg was serialized
 * substitute it with this when asked for a callable.
 */
function CallbackArgument(arg, replaceCb) {
  if (!CallbackArgument.canWrap(arg)) {
    throw Error("Cant wrap argument " + arg + "as a function");
  }

  this.replaceCb = replaceCb || null;
  this.id = arg.id ||
    (this.replaceCb && this.replaceCb.id) ||
    Date.now() + Math.random();
  this.callback = arg instanceof Function ? arg : replaceCb;

  if (this.callback) {
    this.callback.id = this.id;
  }

  this.placeholder = {id: this.id, isCallback: true};
}

/**
 * Check if the argument is suitable for wrapping.
 *
 * @param {anything} arg
 * @returns {Boolean} True if it's safe to box with this type.
 */
CallbackArgument.canWrap = function (arg) {
  return arg && (arg instanceof Function || arg.isCallback);
};

CallbackArgument.prototype = {
  /**
   * @returns {Function } A callable that will either do the job on
   * the client, or send a message.
   */
  forCalling: function () {
    return this.lens ? this.lens(this.callback) : this.callback;
  },

  /**
   * @returns {Object} A serializable object.
   */
  forSending: function () {
    return this.placeholder;
  },

  setLens: function (lens) {
    this.lens = lens;
  }
};
argumentClasses.push(CallbackArgument);
module.exports = CallbackArgument;

},{"./factory.js":9}],6:[function(require,module,exports){
/**
 * @fileOverview Abstractions for handling argument transformation for
 * transportation between host-client.
 * @name container.js
 * @author Chris Perivolaroulos
 */

var CallbackArgument = require('./callback.js'),
    argumentFactory = require('./factory.js').argumentFactory;

/**
 * An wrapper around an arguments list that abstracts all
 * trasformations to serialize them, convert them to a callable state,
 * substitute callbacks with 'send response' callbakcs etc. We support
 * only one callback per Arguments object. This object will do the
 * right thing depending on whether weare on the host or the client.
 *
 * @param {Array} arguments An array of arguments either serialized or
 * not. The elements will be handled by argument types.
 * @param {Function} replaceCb The 'send request' callback typically
 * to substitute the callback in the arguments.
 */
function Arguments (arguments, replaceCb) {
  this.arguments = arguments.map(function (a) {
    return argumentFactory(a, replaceCb);
  });
}

Arguments.prototype = {
  /**
   * The argument list suitable for passing to an api method.
   * @returns {Array} An array of arguments as expected by the API
   */
  forCalling: function () {
    return this.arguments.map(function (a) {return a.forCalling();});
  },

  /**
   * The argument list suitable for sending over the message passing
   * api of chrome.
   * @returns {Array} The argument array serialized.
   */
  forSending: function () {
    return this.arguments.map(function (a) {
      return a.forSending();
    });
  },

  /**
   * Depending on wether we are on the client or the host get the
   * callback found in the arguments.
   *
   * @returns {Function} Either the 'send response' callback, or the
   * actual callback.
   */
  getCallback: function () {
    var cbArg = this.arguments.filter(function (a) {
      return a instanceof CallbackArgument;
    })[0],
        ret = cbArg ? cbArg.forCalling() : this.replaceCb;

    return ret;
  },

  setLens: function(lens) {
    if (this.replaceCb) {
      this.replaceCb = lens(this.replaceCb);
    }

    this.arguments.forEach(function(a) {
      if (a.setLens) a.setLens(lens);
    });
  }
};

module.exports = Arguments;

},{"./callback.js":5,"./factory.js":9}],7:[function(require,module,exports){
var argumentClasses = require('./factory.js').argumentClasses,
    DatabufferArgument = require('./databuffer.js');

function DataArgument(arg) {
  if (!DataArgument.canWrap(arg)) {
    throw new Error("Expected object like {data: ArrayBuffer}, got: ", arg);
  }
  this.arg = arg;
  this.data = new DatabufferArgument(arg.data);
}

DataArgument.canWrap = function (arg) {
  return arg instanceof Object &&
    DatabufferArgument.canWrap(arg.data);
};

DataArgument.prototype = {
  argCopy: function () {
    var ret = {}, self = this;
    Object.getOwnPropertyNames(this.arg).forEach(function (k) {
      ret[k] = self.arg[k];
    });

    return ret;
  },

  /**
   * @returns {Object} What the API expects or what is expected by
   * the API.
   */
  forCalling: function () {
    var ret = this.argCopy();
    ret.data = this.data.forCalling();
    return ret;
  },

  /**
   * @returns {Object} An serializable object that we can turn back
   * into a databuffer container.
   */
  forSending: function () {
    var ret = this.argCopy();
    ret.data = this.data.forSending();
    return ret;
  },

  concat: function (msg) {
    if (!msg.data || !msg.data.isArrayBuffer) return this;
    var ret = this.forSending();
    ret.data = this.data.concat(msg.data).forSending();
    return new DataArgument(ret);
  }
};
argumentClasses.push(DataArgument);
module.exports = DataArgument;

},{"./databuffer.js":8,"./factory.js":9}],8:[function(require,module,exports){
var argumentClasses = require('./factory.js').argumentClasses,
    util = require('../util.js');
/**
 * Boxing for databuffers.
 *
 * @param {DataBuffer|Object} arg Either a databuffer or a serialized
 * databuffer object.
 * @throws {Error} Protects you in case you forgot to call canWrap
 */
function DatabufferArgument(arg) {
  if (!DatabufferArgument.canWrap(arg)) {
    throw Error("Cant wrap argument " + arg + " as a databuffer");
  }

  this.buffer = arg instanceof ArrayBuffer ? arg : null;
  this.obj = arg.isArrayBuffer ? arg : null;
}

/**
 * Check if the object is eithe a databuffer or a serialized databuffer
 *
 * @param {anything} arg The object to check
 * @returns {Boolean} True if we can wrap.
 */
DatabufferArgument.canWrap = function (arg) {
  return arg && ((arg instanceof ArrayBuffer) || arg.isArrayBuffer);
};

DatabufferArgument.prototype = {
  /**
   * @returns {DataBuffer} What the API expects or what is expected by
   * the API.
   */
  forCalling: function () {
    return this.buffer || util.arrToBuf(this.obj.data);
  },

  /**
   * @returns {Object} An serializable object that we can turn back
   * into a DataBuffer.
   */
  forSending: function () {
    return this.obj || {data: util.bufToArr(this.buffer),
                        isArrayBuffer: true};
  },

  concat: function (msg) {
    if (!msg.isArrayBuffer) return this;
    var ret = this.forSending();
    ret.data = ret.data.concat(msg.data);
    return new DatabufferArgument(ret);
  }
};
argumentClasses.push(DatabufferArgument);
module.exports = DatabufferArgument;

},{"../util.js":29,"./factory.js":9}],9:[function(require,module,exports){
var argumentClasses = [];

/**
 * Choose the right *Argument type and create it for arg.
 * @param {anything} arg The raw argument
 * @param {Function} replacingCb A callback to replace arg if it is
 * serialized CallbackArgument.
 * @returns {*Argument} An argument in argumentClasses
 */
function argumentFactory(arg, replacingCb) {
  var classes = argumentClasses.filter(function (ac) {
    return ac.canWrap(arg);
  });

  // At least basic argument will be able to do this.
  return new classes[0](arg, replacingCb);
}

module.exports.argumentFactory = argumentFactory;
module.exports.argumentClasses = argumentClasses;

},{}],10:[function(require,module,exports){
var messageApi = require('./messaging.js');

function BootstrapHost () {
  this.commands = [];
  this.listener = null;
  this.listen();
}
BootstrapHost.prototype = {
  listen: function () {
    var self = this;
    this.listener = function (req, sender, sendResp) {
      // Block if a command sais false ->
      // Say false if some command sais false
      return self.commands.length == 0 || !self.commands.some(function (c) {
        return !c(req, sendResp);
      });
    };

    messageApi.onMessageExternal.addListener(this.listener);
  },

  cleanup: function () {
    messageApi.onMessageExternal.removeListener(this.listener);
  }
};
module.exports.BootstrapHost = BootstrapHost;

},{"./messaging.js":14}],11:[function(require,module,exports){
var server = require('./server.js'),
    srv = new server.HostServer(chrome);
window.api = server;
console.log("Serving...");

},{"./server.js":27}],12:[function(require,module,exports){
/**
 * @fileOverview Know when the client closes and also close if
 * orphaned.
 *
 * Common operations:
 * - closeMessage -> closeCall
 * - closeFn(openFn) = closefn
 *
 * Parameterized operation:
 * - closeArgs(closeFn, openArgs, callbackArgs)
 *
 * On connection open:
 * fromOpen(openFn, openArgs, callbackArgs) =
 *     fromClose(closeFn(openFn), closeArgs(closeFn, openArgs, callbackArgs)) =
 *     closeMessage -> closeCall
 *
 * On method:
 * fromClose(closeFn, closeArgs) = closeMessage -> closeCall
 * @name hostconnection.js
 * @author
 * @license
 */

var Arguments = require('./arguments.js').Arguments,
    MethodRequest = require('./requests.js').MethodRequest,
    ApiEventEmitter = require("./apieventemitter.js").ApiEventEmitter,
    r = require("./responses.js"),
    util = require("./util.js"),
    closed = [],
    log = new (require('./log.js').Log)('hostconnection');
require('./setimmediate.js');

/**
 * Method gets the args from the connection. Reverse just gets the
 * provided callback. There is one connection per event per callback
 * per client.
 *
 * There are 3 stages in the lifecycle of a connection
 *
 * - Init where the connection is initiated and the app event is
 *   triggered. Handled by the constructor and init.
 *
 * - Communication where the host pokes the client with a data ready
 *   (DTR) signal that there is data available, and the client requests
 *   for the available data with a separate one time request
 *
 * - Close where the DTR connection is closed and the listener is
 *   removed. Handled by close.
 *
 * @param {Port} port The port returned from onConnectExternal. The
 * name should be a json encoded object with
 *
 * - id: the connection id
 * - clientId: the id of the tab, generated by a KeepAliveConnetion
 * - methodRequest: An object called from MethodRequest.forSending
 * - reverse: A {path, type} object describing the reverser.
 *
 * @param {Function} closeCb Optionally a callback when the connection
 * closes. This should handle the cleanup of the connection for
 * external resources.
 */
function HostConnection (port, hostApi, closeCb) {
  var self = this;
  this.buffer = [];
  this.port = port;
  this.portConf = JSON.parse(port.name);
  this.id = this.portConf.id;
  this.closeCb = closeCb.bind(this);
  this.closed = false;

  // Will not be sent.
  var sendRaw = function (msg) {
    self.pushRequest(msg);
  };
  this.methodRequest = MethodRequest.fromMessage(
    null, this.portConf.methodRequestMsg, sendRaw);

  log.log("Opening connection:", this.repr());
  this.apiEvent = new ApiEventEmitter(this.methodRequest,
                                      this.portConf.reverser,
                                      hostApi,
                                      this.close.bind(this));
  this.port.onMessage.addListener(function (msg) {
    if (msg == "client created") {
      self.port.postMessage("ack");
      self.apiEvent.fire();
    }
  });
  log.log("Registering server side ondisconnect for method connection");
  this.port.onDisconnect.addListener(this.close.bind(this));
}

HostConnection.prototype = {
  repr: function () {
    return this.id +  " ( " + this.methodRequest.method + " )";
  },

  /**
   * Close the connection gracefully.
   */
  close: function () {
    if (this.closed) return;
    log.log("Closing connection:", this.repr());
    this.closed = true;
    this.port.disconnect();
    this.apiEvent.destroy();
    this.port = null;
    this.closeCb();
  },

  /**
   * Send an error message to the client over the connection port.
   *
   * @param {String} message The contents of the error.
   */
  sendError: function (message) {
    if (this.closed) return;

    this.port.postMessage(new r.ErrResponse(message).forSending());
    this.close();
  },

  /**
   * @param {Message} reqMsg A message that was to be called is
   * instead buffered.
   */
  pushRequest: function (reqMsg) {
    if (this.closed) return;

    if (reqMsg.responseType == "ErrResponse") {
      this.sendError(reqMsg.err);
    }

    // We expect they wont contain a function.
    if (!this.apiEvent.firstResponseMsg){
      this.apiEvent.firstResponseMsg = reqMsg;
    }

    if (this.buffer.length == 0){
      // To the end of the queue.
      setImmediate(this.setDtr.bind(this));
    }

    this.buffer.push(reqMsg);
    this.buffer.timestamp = Date.now();
  },

  /**
   * Notify the client that there is data to be read.
   */
  setDtr: function () {
    // This might be lef over on the queue.
    if (this.port)
      this.port.postMessage({timestamp: this.buffer.timestamp,
                             connection: this.id});
  },

  /**
   * Send the list of arguments accumulated.
   *
   * @param {Function} callback callback to accept the buffer of
   * Arguments objects.
   */
  flushBuffer: function (callback) {
    callback(this.buffer);
    this.buffer = [];
  },

  /**
   * Let the connection decide if it wants to apply a closing request
   * on itself.
   *
   * @param {MethodRequest|MethodRequestMessage} closingRequest the
   * request from the client that may be called.
   * @returns {null|AckResponse|ArgsResponse} True if we actually
   * called the request. We may still be open if we need more closing
   * requests to teminate. If the event emitter can call a callback
   * this is an ArgsResponse.
   */
  tryClosing: function (closingRequest) {
    if (this.closed) return false;
    var ret = this.apiEvent.maybeRunCloser(closingRequest);
    if (this.apiEvent.closed) {
      this.close();
    }
    return ret;
  }
};

module.exports.HostConnection = HostConnection;

},{"./apieventemitter.js":2,"./arguments.js":3,"./log.js":13,"./requests.js":17,"./responses.js":21,"./setimmediate.js":28,"./util.js":29}],13:[function(require,module,exports){
(function (global){
var timeOffset = Date.now();
global.debugBabelfish = false;

function zeroFill( number, width )
{
  width -= number.toString().length;
  if ( width > 0 )
  {
    return new Array( width + (/\./.test( number ) ? 2 : 1) ).join( '0' ) + number;
  }
  return number + ""; // always return a string
}

function Log (name, verbosity) {
  this.verbosity = verbosity || 1;
  this.name = name;
  this.resetTimeOffset();

  this.showTimes = false;
  this.error = this.console_('error', 0);
  this.warn = this.console_('warn', 1);
  this.info = this.console_('log', 2);
  this.log =  this.console_('log', 3);
}

Log.prototype = {
  timestampString: function () {
    var now = new Date(new Date() - timeOffset +
                       timeOffset.getTimezoneOffset() * 60000);
    var pad = function (n) {
      if (n < 10) { return "0" + n; }
      return n;
    };
    return pad(now.getHours()) + ":" + pad(now.getMinutes())
      + ":" + pad(now.getSeconds()) + "." + zeroFill(now.getMilliseconds(), 3);
  },

  resetTimeOffset: function () {
    timeOffset = new Date();
  },


  console_: function (type, verbosity) {
    var self = this;
    if (this.showTimes) {
      return function () {
        if (self.verbosity > verbosity || global.debugBabelfish) {
          return console[type].apply(console,
                                     [self.prefix()].concat(arguments));
        }
      };
    }
    if (this.verbosity > verbosity || global.debugBabelfish) {
      return console[type].bind(console, this.prefix());
    }
    return function () {};
  },


  prefix: function () {
    if (this.showTimes)
      return "[" + this.timestampString() +  " : " + this.name + "]";

    return "[" +this.name + "] ";
  }
};
module.exports.Log = Log;

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
},{}],14:[function(require,module,exports){
(function (global){
var DummyRuntime = require('./messaging/dummy.js').DummyRuntime,
    ChromeMessaging = require('./messaging/chrome.js').ChromeMessaging;

/**
 * The messaging intefaces should implement
 *
 * - onConnectExternal
 * - onMessageExternal
 * - sendMessage
 * - connect
 *
 * That behave like tha chrome runtime messaging interface.
 */
var interfaces = {
  chrome: ChromeMessaging,
  test: DummyRuntime
};

if (!global.chrome ||
    !global.chrome.runtime ||
    !global.chrome.runtime.sendMessage) {
  global.MESSAGING_METHOD = 'test';
}

module.exports = new (interfaces[global.MESSAGING_METHOD || 'chrome'])();

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
},{"./messaging/chrome.js":15,"./messaging/dummy.js":16}],15:[function(require,module,exports){
/**
 * @fileOverview The chrome API message passing method.
 * @name chrome.js
 * @author Chris Perivolaropoulos
 */

function ChromeMessaging () {
  this.version = chrome.runtime.getManifest ?
    chrome.runtime.getManifest().version : "1" ;
  this.onConnectExternal = chrome.runtime.onConnectExternal;
  this.onMessageExternal = chrome.runtime.onMessageExternal;
  this.sendMessage = chrome.runtime.sendMessage.bind(chrome.runtime);
  this.connect = chrome.runtime.connect.bind(chrome.runtime);
}
module.exports.ChromeMessaging = ChromeMessaging;

},{}],16:[function(require,module,exports){
(function (global){
// XXX: If disconnect is too soon after the connect the actual
// connection may happen before disconnect.

/**
 * @fileOverview A loopback method mirroring chrome api.
 * @name dummy.js
 * @author Chris Perivolaropoulos
 */

global.APP_ID = global.APP_ID || "fakehostid";
// DEBUG: debug messages
// stackDebug: non async messaging.
var DEBUG = false, stackDebug = false;
var assert = require('assert'),
    maybeAsync = stackDebug ? function (cb) {cb();} : function (cb) {
      var err = new Error("Stack before async message");
      setTimeout(function () {
        try{
          cb();
        } catch (e) {
          console.log(e.stack);
          console.log(err.stack);
          throw err;
        }
      });
    },
    dbg = function () {};
if (DEBUG) {
  dbg = console.log.bind(console, '[dummy messager]');
}

function validateMessage(msg) {
  if (!msg || JSON.stringify(msg) == "{}") {
    throw new Error("Message should be something. Got:" + msg);
  }
}

function Event (jsonOnly, name, buffered) {
  this.listeners = [];
  this.removed = [];
  this.name = name;

  if (buffered) {
    this.buffer = [];
  }

  if (jsonOnly) {
    this.wrap = function (args) {
      return JSON.parse(JSON.stringify(args));
    };
  } else {
    this.wrap = function (a) {return a;};
  }
}

Event.prototype = {
  addListener: function (cb) {
    dbg('Adding listner: ' + cb.id + " to " + this.name);
    var self = this;
    this.listeners = this.listeners.concat([cb]);

    (this.buffer||[]).forEach(function (args) {
      maybeAsync(function () {
        self.listeners.some(function (l) {
          return !l.apply(null, args);
        });
      });
    });
  },

  removeListener: function (cb) {
    dbg('Removing listner: ' + cb.id + " from " + this.name +
        " (" + this.listeners.map(function (l) {return l.id;}) + " - " +
        this.removed + " )");
    this.listeners = this.listeners.filter(function (l) {
      var same = cb === l,
          sameIds = (cb.id && l.id && cb.id == l.id);
      return !(same || sameIds);
    });
  },

  trigger: function (varArgs) {
    var args = [].slice.call(arguments),
        self = this,
        listeners = this.listeners; //Make sure async does't fuck with listeners
    dbg('Triggering[' + this.listeners.length + ']: ' + this.name + "|" +
        ((args[0] instanceof Port) ? "<port>" : JSON.stringify(args)));

    if (this.buffer && this.listeners.length == 0) {
      this.buffer.push(args);
      return;
    }

    maybeAsync(function () {
      var tok = Math.random();
      listeners.some(function (l, i) {
        return !l.apply(null, args);
      });
    });

  }
};

function Runtime () {
  dbg('Creating runtime...');
  this.id = global.APP_ID;
  this.onConnectExternal = new Event(false, "onConnectExternal");
  this.onMessageExternal = new Event(true, "onMessageExternal");
  this.ports = [];
  this.version = "1.0";
}

Runtime.prototype = {
  sendMessage: function (hostId, message, cb) {
    var sendResp = cb,
        sender = null;

    validateMessage(message);
    assert(message);
    assert(hostId);
    if (hostId != this.id || global.blockMessaging) {
      maybeAsync(cb);
      return;
    }

    this.onMessageExternal.trigger(message, sender, function (msg) {
      dbg("Response:", JSON.stringify(msg));
      cb(msg);
    });
  },

  connect: function (hostId, connectInfo) {
    var clientPort = new Port(connectInfo.name, this),
        self = this;
    assert.equal(hostId, this.id);

    if (global.blockMessaging) {
      setImmediate( function () {
        clientPort.onDisconnect.trigger(clientPort);
      });
      return clientPort;
    }

    maybeAsync(function () {
      self.onConnectExternal.trigger(clientPort.otherPort);
    });
    return clientPort;
  }
};

function Port (name, runtime, otherPort) {
  this.name = name;
  this.runtime = runtime;
  runtime.ports = runtime.ports.concat([this]);
  this.prefix = "Port" + (!otherPort ? "<client>" : "<host>");
  this.onDisconnect = new Event(false, this.prefix + ".onDisconnect");
  this.onMessage = new Event(true, this.prefix + ".onMessage", true);

  this.otherPort = otherPort || new Port(name, runtime, this);
  this.connected = true;
}

Port.prototype = {
  postMessage: function (msg) {
    validateMessage(msg);
    this.otherPort.onMessage.trigger(msg);
  },

  disconnect: function (forceListeners) {
    if (this.connected) {
      var self = this;
      this.runtime.ports = this.runtime.ports.filter(function (p) {
        return p !== self;
      });

      this.connected = false;
      this.onMessage.listeners = [];
      if (forceListeners){
        this.onDisconnect.trigger();
      }
      this.onDisconnect.listeners = [];
      this.otherPort.disconnect(true);
    }
  }
};

global.chrome = global.chrome || {runtime: {id: APP_ID}};

module.exports.DummyRuntime = Runtime;
module.exports.Event = Event;
module.exports.Port = Port;

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
},{"assert":30}],17:[function(require,module,exports){
module.exports.BurstRequest = require('./requests/burst.js').BurstRequest;
module.exports.GenericRequest = require('./requests/generic.js').GenericRequest;
module.exports.MethodRequest = require('./requests/method.js').MethodRequest;

},{"./requests/burst.js":18,"./requests/generic.js":19,"./requests/method.js":20}],18:[function(require,module,exports){
/**
 * @fileOverview A request by the client to receive a burst of
 * requests from an api emitter. This is initially triggered by a data
 * ready signal via a connection from the host. When the client
 * receives it they send a BurstRequest when they are ready to receive
 * the data. The main reason for this is that sending messages is
 * quite expensive and we want to bundle them together as much as
 * possible when an event emmitter spams.
 * @name burstrequest.js
 * @author Chris Perivolaropoulos
 */
var Arguments = require('./../arguments.js').Arguements,
    log = new (require('./../log.js').Log)('burstrequest'),
    GenericRequest = require('./generic.js').GenericRequest,
    ErrResponse = require('./../responses.js').ErrResponse,
    BurstResponse = require('./../responses.js').BurstResponse;

/**
 * A request for a burst of callbacks that are destined for the
 * client from a connection.
 *
 * @param {String} hostId The chrome app id.
 * @param {ClientConnection} connection the connection that holds the
 * callback arguments.
 * @param {Function} callback The event callback raw.
 */
function BurstRequest (hostId, connection, callback) {
  this.hostId = hostId;
  this.connection = connection;
  this.callback = callback;
  this.blocked = false;
}

/**
 * Handle a request for a burst on the server. If the message doesn't
 * seem valid, disregard it.
 *
 * @param {ApiMessage} msg The message as taken from the send
 * function, ie the forSending method.
 * @param {Array(HostConnections)} connections An array of connections
 * @param {Function(msg, sender, sendResp)} sendRespRaw callback to
 * send response.
 * @return {Boolean} True if we handled it.
 */
BurstRequest.maybeHandle = function (msg, connections, sendRespRaw) {
  if (msg.requestType !=  "BurstRequest") {
    return false;
  };
  var usefulCons = connections.filter(function (c) {
    return msg.connId == c.id;
  });

  if (usefulCons.length != 1) {
    var errMsg = "Burst request for connection " + msg.connId + " corresponds to " +
          usefulCons.length + " connections",
        errResp = new ErrResponse(errMsg);
    errResp.send(sendRespRaw);
    return true;
  }

  function sendBuffer (buf) {
    var br = new BurstResponse(buf, msg);
    br.send(sendRespRaw);
  }

  usefulCons[0].flushBuffer(sendBuffer);
  return true;
};

BurstRequest.prototype = Object.create(GenericRequest.prototype);

/**
 * Create a serializable object to send over the API.
 * @returns {Message} a serialized messae
 */
BurstRequest.prototype.forSending = function () {
  return {requestType: "BurstRequest",
          connId: this.connection.id};
};

/**
 * Get the callback from the arguments. Will only work on the client
 *
 * @returns {Function} the callback or undefined.
 */
BurstRequest.prototype.getCallback = function () {
  return this.callback;
};

module.exports.BurstRequest = BurstRequest;

},{"./../arguments.js":3,"./../log.js":13,"./../responses.js":21,"./generic.js":19}],19:[function(require,module,exports){
var genericRespHandler = require('./../responses.js').genericRespHandler,
    messageApi = require("./../messaging.js"),
    log = new (require('./../log.js').Log)('genericrequest');

/**
 * A generic request to inherit new ones from. Make sure you define
 * hostId property in your classes and also define a forSending.
 */
function GenericRequest() {};

GenericRequest.prototype = {
  /**
   * Create a serializable object to send over the API.
   * @returns {Message} a serialized messae
   */
  forSending: function () {
    throw Error("forSending not implemented.");
  },

  /**
   * Send the request and handle the response.
   * @param {Function} cb Called when handling is finished. No
   * arguments in case it succeeds, an error object if it failes
   */
  send: function (cb, errorCb) {
    var self = this,
        msg = this.forSending(),
        hostId = this.hostId;

    messageApi.sendMessage(
      hostId, msg, function (resp) {
        genericRespHandler(resp, self,
                           cb || function (err) {
                             if (err) {
                               throw err;
                             };
                           });
      });
  }
};
module.exports.GenericRequest = GenericRequest;

},{"./../log.js":13,"./../messaging.js":14,"./../responses.js":21}],20:[function(require,module,exports){
var Arguments = require("./../arguments.js").Arguments,
    GenericRequest = require('./generic.js').GenericRequest,
    util = require("./../util"),
    ArgsResponse = require("./../responses.js").ArgsResponse,
    ErrResponse = require("./../responses.js").ErrResponse,
    AckResponse = require("./../responses.js").AckResponse,
    log = new (require('./../log.js').Log)('methodrequest');


function isNode () {
  if (typeof window === 'undefined') return true;

  var backup = window,
      window_can_be_deleted = delete window;
  window = backup; // Restoring from backup

  return window_can_be_deleted;
}

/**
 * A request from the client to resolve a method call. Also handles
 * the response.
 *
 * @param {String} hostId The app id. Could be null if you dont intend
 * to send it.
 * @param {String} method The method to be called.
 * @param {Array|Arguments} args The real argument list or a wrapped
 * arguments object.
 * @param {Boolean} isReverser Wether this method request is supposed
 * to revert the side effects of a previous request.
 * @param {Boolean} noCallback true means that host should reply with
 * AckResponse.
 * @param {Function} withError Wrapper to handle errors.
 */
function MethodRequest (hostId, method, args, isReverser, noCallback, withError) {
  this.method = method;
  this.args = args instanceof Arguments ? args :
    new Arguments(args);
  this.hostId = hostId;
  this.isReverser = isReverser || false;
  this.noCallback = noCallback || false;
  this.withError = withError;
  // Node seems to display errors even if we don't throw them and it
  // gets really annoying
  if (!isNode()) {
    this.trace = (new Error()).stack;
  }

  if (this.args.forSending().filter(function (a) {
    return !!(a && a.isCallback);
  }).length > 1) {
    throw Error("We do not support more than one callback in arguments.");
  }
}

MethodRequest.prototype = Object.create(GenericRequest.prototype);

/**
 * Create a method request from a message. When a callback is provided
 * it will be used.
 *
 * @param {String} hostId The host to send the requset. Set this to
 * null if it's just for comparing or for invoking it's callback
 * (generally if you are on the host side.)
 * @param {Message} msg A message as generated by forSending()
 * @param {Function} respCb Raw send response callback.
 * @returns {MethodRequest} A method request.
 */
MethodRequest.fromMessage = function (hostId, msg, respCb) {
  var args = new Arguments(msg.args, respCb);
  return new MethodRequest(hostId, msg.method, args);
};

/**
 * If the message is a request to close a connection (reverser)
 *
 * @param {Message} msg A message generated by a MethodRequest.
 * @param {Array(HostConnection)} connections a list of open connections.
 * @param {Function} sendRespRaw Callback to send a raw message.
 * @param {Boolean} force This is a reverser even if id doesn't look
 * like it.
 * @returns {Boolean} True if we handled it.
 */
function handleReverser (msg, connections, hostApi) {
  if (!connections && !msg.isReverser) return false;
  var req = MethodRequest.fromMessage(null, msg),
      response = connections
        .map(function (c) {
          return c.tryClosing(req);
        }).reduce(function (a, b) {
          return a || b;
        }, false);

  // We won't get a response for args that don't raise a callback.
  if (msg.isReverser && !response) {
    console.warn(
      "You told me " + JSON.stringify(msg) +
        " was a reverser but i found nothing to reverse.");
    if (msg.noCallback) {
      // Trust the user knows what they are doing
      req.call(null, hostApi);
      return new ErrResponse("Tried to clean with " + msg.method + " but failed.",
                             "warning");
    }

    // There may be a callback waiting.
    return ArgsResponse.async(req, hostApi);
  }

  return response;
}

/**
 * Handle the request on the server. Try to run the method and
 * generate a *Response, serialize it and send it over the
 * sendRespApi. If the message doesn't seem valid, disregard it.
 *
 * @param {Message} msg A message generated by a MethodRequest.
 * @param {Array(HostConnection)} connections a list of open connections.
 * @param {hostApiObject} hostApi chrome API likae object where the
 * requrest method is based.
 * @param {Function} sendRespRaw Callback to send a raw message.
 * @returns {Boolean} True if we handled it.
 */
var messagesReceived = 0;
MethodRequest.maybeHandle = function (msg, connections, hostApi, sendRespRaw) {
  var _sendRespRaw = function (sendMsg) {
    if ((++messagesReceived) % 1000 == 0) {
      log.log("Sending 1000 messages");
    }

    if (sendMsg.responseType == "ErrResponse") {
      console.error(msg, "->", sendMsg);
    }

    sendRespRaw(sendMsg);
  };

  if (msg.requestType != "MethodRequest") {
    return false;
  }

  var resp = handleReverser(msg, connections, hostApi);
  if (resp) {
    resp.send(_sendRespRaw);
    return true;
  }

  sendRespRaw = sendRespRaw || function () {};
  var sendArgsAsResponse = function (varArgs) {
    var argsArr = [].slice.call(arguments),
        cbArgs = new Arguments(argsArr),
        argsResp = new ArgsResponse(cbArgs);

    // Internal api error
    if (chrome &&
        chrome.runtime &&
        chrome.runtime.lastError &&
        argsArr.length == 0) {
      new ErrResponse(chrome.runtime.lastError,
                      'chrome.runtime.lastError')
        .send(_sendRespRaw);
      return true;
    }

    // Everything went well.
    argsResp.send(_sendRespRaw);
  }, methodArgs = new Arguments(msg.args, sendArgsAsResponse),
      methodCb = util.path2callable(hostApi, msg.method);

  // Bad path received.
  if (!methodCb) {
    resp = new ErrResponse("Method " + msg.method + " not found.");
    resp.send(_sendRespRaw);
    return true;
  }

  try {
    // All went well
    methodCb.apply(null, methodArgs.forCalling());
    return true;
  } catch (e) {
    resp = new ErrResponse({message: "Error on calling " + msg.method + ":"
                            + e.message,
                            stack: e.stack},
                           'chrome.runtime.lastError');
    resp.send(_sendRespRaw);
    return true;
  }

  // We know this method wont bring up a callback.
  if (msg.noCallback) {
    new AckResponse().send(_sendRespRaw);
    return true;
  }
};

/**
 * @returns {Object} Serializable object to communicate with the server.
 */
MethodRequest.prototype.forSending = function () {
  var ret = {requestType: "MethodRequest",
             method: this.method,
             args: this.args.forSending(),
             noCallback: this.noCallback,
             isReverser: this.isReverser
            };
  return ret;

};

/**
 * Run this method request. This will not handle reversers.
 */
MethodRequest.prototype.call = function (sendResp, hostApi) {
  MethodRequest.maybeHandle(this.forSending(),
                            null,
                            hostApi,
                            sendResp || this.getCallback());
};

/**
 * Get the callback from the arguments. On the server this is a
 * function accepting a response type.
 *
 * @returns {Function} the callback or undefined.
 */
MethodRequest.prototype.getCallback = function () {
  return this.args.getCallback();
};


/**
 * Get the callback from the arguments. A usable one.
 *
 * @returns {Function} the callback or undefined.
 */
MethodRequest.prototype.realCallback = function () {
  var self = this, callback = self.args.getCallback();
  return function () {
    var args = new Arguments([].slice.call(arguments)),
        resp = new ArgsResponse(args);
    callback.call(null, resp.forSending());
  };
};



module.exports.MethodRequest = MethodRequest;

},{"./../arguments.js":3,"./../log.js":13,"./../responses.js":21,"./../util":29,"./generic.js":19}],21:[function(require,module,exports){
/**
 * @fileOverview Responses that can be generated by the host.  Each
 * response is generated ad-hoc so the signature of their constructor
 * is arbitrary but each _type_ has it's own handle method that is
 * executed on the client and accepts the received message, the
 * request generating the response and a callback when we are done
 * handling it.
 * @name responses.js
 * @author Chris Perivolaropulos
 */

module.exports.ErrResponse = require('./responses/error.js');
module.exports.BurstResponse = require('./responses/burst.js');
module.exports.ArgsResponse = require('./responses/arguments.js');
module.exports.AckResponse = require('./responses/ack.js');
module.exports.genericRespHandler =
  require('./responses/generic.js').genericRespHandler;

},{"./responses/ack.js":22,"./responses/arguments.js":23,"./responses/burst.js":24,"./responses/error.js":25,"./responses/generic.js":26}],22:[function(require,module,exports){
var GenericResponse = require('./generic.js').GenericResponse;
require('./../setimmediate.js');

/**
 * The request wasn't supposed to yield any result but was
 * successful.
 */
function AckResponse () {
};

/**
 * Handle the response on the client side if it is of the correct
 * type.
 *
 * @param {Message} msg the raw message received by the server
 * @param {Request} request the request object that msg is a response
 * to.
 * @param {Function} doneCb Call this when you are done. It will be
 * called with no arguments on succes or an error object on error.
 * @return {Boolean} true if we handled it.
 */
AckResponse.maybeHandle = function (msg, request, doneCb) {
  if (msg.responseType != "AckResponse") return false;
  setImmediate(doneCb);
  return true;
};

AckResponse.prototype = Object.create(GenericResponse.prototype);

/**
 * Serialized response that also can be recognized as a response.
 *
 * @returns {Object} the object to be put through the API.
 */
AckResponse.prototype.forSending = function () {
  return {responseType: "AckResponse"};
};
module.exports = AckResponse;

},{"./../setimmediate.js":28,"./generic.js":26}],23:[function(require,module,exports){
var Arguments = require("./../arguments.js").Arguments,
    GenericResponse = require('./generic.js').GenericResponse;
require('./../setimmediate.js');

/**
 * The request yielded by a single callback that is to be called by
 * the client.
 *
 * @param {Arguments} args The callback arguments or a serialized
 * object generated by a server side ArgsResponse. Since these are
 * callback arguments they should contain no callback
 * themselves.
 */
function ArgsResponse (args) {
  this.cbArgs = args;
}

ArgsResponse.async = function (mr, hostApi) {
  var resp = new ArgsResponse();
  resp.mr = mr;
  resp.hostApi = hostApi;
  return resp;
};

/**
 * Handle the response on the client side if it is of the correct
 * type.
 *
 * @param {Message} msg the raw message received by the server
 * @param {Request} request the request object that msg is a response
 * to.
 * @param {Function} doneCb Call this when you are done. It will be
 * called with no arguments on succes or an error object on error.
 * @return {Boolean} true if we handled it.
 */
ArgsResponse.maybeHandle = function (msg, request, doneCb) {
  if (msg.responseType != "ArgsResponse") return false;
  if (!request.getCallback()) {
    doneCb(new Error("No real callback provided on the client."));
    return true;
  }
  var cbArgs = new Arguments(msg.args),
      callArgs = cbArgs.forCalling(),
      callback = request.getCallback();

  // log.log("Received:", cbArgs.forSending(), "for", {fn: String(callback)});
  callback.apply(null, callArgs);
  setImmediate(doneCb);
  return true;
};

ArgsResponse.prototype = Object.create(GenericResponse.prototype);

/**
 * The callback arguments serialized.
 *
 * @returns {Object} the object to be put through the API.
 */
ArgsResponse.prototype.forSending = function () {
  return {responseType: "ArgsResponse",
          args: this.cbArgs.forSending()};
};

ArgsResponse.prototype.send = function (sendCb) {
  if (this.mr) {
    // NOTE: ArgsRepsonse for connection cleanups are lazy. The
    // callback of the api call does the actual work of sending the
    // respinse.
    this.mr.call(sendCb, this.hostApi);
    return;
  }

  sendCb(this.forSending());
};
module.exports = ArgsResponse;

},{"./../arguments.js":3,"./../setimmediate.js":28,"./generic.js":26}],24:[function(require,module,exports){
var Arguments = require("./../arguments.js").Arguments,
    DataArgument = require("./../arguments.js").DataArgument,
    log = new (require('./../log.js').Log)('burstresponse'),
    GenericResponse = require('./generic.js').GenericResponse,
    ArgsResponse = require('./arguments.js'),
    genericRespHandler = require('./generic.js').genericRespHandler;
require('./../setimmediate.js');

/**
 * Serving a burst response.
 *
 * @param {Array(Arguments)} cbArgsArr an array the arguments of calls
 * to a callback. We trust these contain no callbacks since they are
 * responses to the client.
 * @param {Message} reqMessage The message generated by BurstRequest.
 */
function BurstResponse (cbArgsArr, reqMessage) {
  this.cbArgsArr = cbArgsArr;
  this.callbackId = reqMessage.callbackId;
};

/**
 * Handle the response on the client side if it is of the correct
 * type.
 *
 * @param {Message} msg the raw message received by the server
 * @param {BurstRequest} request the request object that msg is a response
 * to.
 * @param {Function} doneCb Call this when you are done. It will be
 * called with no arguments on succes or an error object on error.
 * @return {Boolean} true if we handled it.
 */
var servedBurstMetrics = [];
BurstResponse.maybeHandle = function (msg, request, doneCb) {
  if (msg.responseType != "BurstResponse") return false;
  // Throw each response in the queue when the previous one is
  // finished. Before serving check if they are zombified by the
  // request.
  function arrInQueue(responses, err) {
    if (err) {
      doneCb(err);
      return;
    }

    if (responses.length == 0) {
      doneCb();
      return;
    }

    setImmediate(function () {
      var car = responses[0], cdr = responses.slice(1);

      if (!request.closed) {
        genericRespHandler(car, request, arrInQueue.bind(null, cdr));
        return;
      }
      doneCb();
      // Allow the generic handler to throw at least some stuff in the
      // queue.
    });
  }

  // It is assumed that the ordering of data from different sources
  // and the size of the packets does not matter. Concat together
  // packets that have everything in common except the data field.
  function maybeConcatData(msgs) {
    var dataSources = {},
        concatArg = msgs.forEach(function (m, i) {
          // Just keep this one as is
          if (!(m.args && DataArgument.canWrap(m.args[0]) && m.args.length == 1)) {
            dataSources[i] = m;
            return;
          }

          // Mask the data to make a source-unique token.
          var arg = m.args[0], backup = arg.data;
          arg.data = null;
          var token = JSON.stringify(arg);
          arg.data = backup;
          var ret = dataSources[token];
          if (ret) {
            dataSources[token] = ret.concat(arg);
            return;
          }

          dataSources[token] = new DataArgument(arg);
        });

    return Object.getOwnPropertyNames(dataSources).map(function (k) {
      var concatArg = dataSources[k];
      if (concatArg instanceof DataArgument) {
        return new ArgsResponse(
          new Arguments([concatArg.forSending()])).forSending();
      }

      return concatArg;
    });
  }

  // Some debugging information
  if (0) {
    servedBurstMetrics.push({time: Date.now(), length: msg.cbArgsArr.length});
    var totalRequests = servedBurstMetrics.reduce(function (sum, m) {
      return sum + m.length;
    }, 0);
    log.log("Burst summary:", {
      requestPerSec: totalRequests * 1000 /
        (Date.now() - servedBurstMetrics[0].time),
      totalRequests: totalRequests,
      currentRequests: msg.cbArgsArr.length
    });
  }
  arrInQueue(maybeConcatData(msg.cbArgsArr));

  return true;
};
BurstResponse.prototype = Object.create(GenericResponse.prototype);

/**
 * Serialized response that also can be recognized as a response.
 *
 * @returns {Object} the object to be put through the API.
 */
BurstResponse.prototype.forSending = function () {
  return {responseType: "BurstResponse",
          cbArgsArr: this.cbArgsArr,
          callbackId: this.callbackId};
};
module.exports = BurstResponse;

},{"./../arguments.js":3,"./../log.js":13,"./../setimmediate.js":28,"./arguments.js":23,"./generic.js":26}],25:[function(require,module,exports){
var GenericResponse = require('./generic.js').GenericResponse;

/**
 * An error occured serving the request.
 *
 * @param {String} error The error message.
 * @param {Boolean} isUncaught True if we want to raise an uncaught
 * error when this happens and false if it should be passed to
 * chrome.runtime.lastError
 */
function ErrResponse (error, type) {
  this.error = error;
  this.type = type;
};

/**
 * Handle the response on the client side if it is of the correct
 * type. This will also handle messages that are undefined messages.
 *
 * @param {Message|undefined} msg the raw message received by the server
 * @param {Request} request the request object that msg is a response
 * to.
 * @param {Function} doneCb Call this when you are done. It will be
 * called with no arguments on succes or an error object on error.
 * @return {Boolean} true if we handled it.
 */
ErrResponse.maybeHandle = function (msg, request, doneCb) {
  if (msg && msg.responseType != "ErrResponse") return false;

  var rawError = msg ? msg.err : "Undefined message, probably host is disconnected.";
  if (request.trace) {
    console.warn("Received error:", msg.err);
    console.warn(request.trace);
  };

  var withError = function (err, cb) {
    cb();

    if (err){
      console.error("Uncaught:", err);
    }
  };

  if (request.getCallback()) {
    (request.withError || withError)(rawError, request.getCallback());
    doneCb();
    return true;
  }

  doneCb(rawError);
  return true;
};

ErrResponse.prototype = new GenericResponse();

/**
 * Serialized response that also can be recognized as a response.
 *
 * @returns {Object} the object to be put through the API.
 */
ErrResponse.prototype.forSending = function () {
  return {responseType: "ErrResponse",
          err: this.error,
          type: this.type
         };
};
module.exports = ErrResponse;

},{"./generic.js":26}],26:[function(require,module,exports){
/**
 * @fileOverview The interface that all response types need to be
 * implementing
 * @name generic.js
 * @author Chris Perivolaropoulos
 */

function GenericResponse () {}
GenericResponse.prototype = {
  send: function (sendCb) {
    return sendCb(this.forSending());
  },

  forSending: function () {
    throw new Error("Not implemented");
  }
};



/**
 * Iterate over the response handlers and coose the correct one to
 * handle an incoming message on the clients.
 *
 * @param {Message} msg the raw message received by the server
 * @param {Request} request the request object that msg is a response
 * to.
 * @param {Function} done Call this when you are done. It will be
 * called with no arguments on succes or an error object on error.
 */

function genericRespHandler (msg, request, done) {
  // Be sure to throw done in the queue.
  function doneCb (err) {
    done(err);
  }

  var responseTypesArr = [
    require('./error.js'),                  //Catch the errors first
    require('./burst.js'),
    require('./arguments.js'),
    require('./ack.js'),
  ];

  if (!responseTypesArr.some(function (RT) {
    return RT.maybeHandle(msg, request, doneCb);
  })) {
    done(new Error("Couldn't handle message: " + JSON.stringify(msg)));
  }
}
module.exports.GenericResponse = GenericResponse;
module.exports.genericRespHandler = genericRespHandler;

},{"./ack.js":22,"./arguments.js":23,"./burst.js":24,"./error.js":25}],27:[function(require,module,exports){
/**
 * @fileOverview Initialize and handle requests and connections.
 * @name server.js
 * @author Chris Perivolaropoulos
 */
var HostConnection = require("./hostconnection.js").HostConnection,
    MethodRequest = require("./requests.js").MethodRequest,
    BurstRequest = require("./requests.js").BurstRequest,
    ErrResponse = require("./responses.js").ErrResponse,
    AckResponse = require("./responses.js").AckResponse,
    log = new (require('./log.js').Log)('server'),
    messageApi = require('./messaging.js'),
    BootstrapHost = require('./bootstraphost.js').BootstrapHost;
require('./setimmediate.js');

var state = {connections: [],
             keepalives: [],
             uniqueId: 0,
             version: messageApi.version};

/**
 * A port to keep track of a client. It also sets the id of the client;
 * @param {Port} port
 * @param {Function} dieCb Called when the client dies.
 */
function HostKeepAliveConnection (port, closeCb) {
  log.log("Creating host keepalive");
  var self = this;
  this.port = port;
  port.onDisconnect.addListener(this.close.bind(this));
  this.closeCb = closeCb.bind(null, this);
  this.clientId = state.uniqueId++;
  this.portConf = JSON.parse(port.name);

  // Set the clientId
  port.onDisconnect.addListener(function () {
    log.log("Client disconnected:" + self.clientId);
  });
  port.postMessage({
    clientId: self.clientId,
    version: state.version});
  log.log("Client connected:" + self.clientId);
  this.closed = false;
}

HostKeepAliveConnection.is = function (port) {
  return JSON.parse(port.name).type == "KeepAliveConnection";
};

HostKeepAliveConnection.prototype = {
  maybeClose: function (c) {

    if (c.clientId == this.clientId) {
      c.close();
    }
  },

  close: function () {
    if (this.closed) return;
    // Cleaning up may require the port.
    this.closed = true;
    this.closeCb();
    this.port.disconnect();
    this.port = null;
  }
};

/**
 * Get a keep alive connection token for the client. The object is
 * {port, clientId}.
 *
 * @param {String} hostId The ide of the host to connect to.
 * @param {Function} connectCb The callback to be called when the
 * connection is successful.
 * @param {Function} diconnectCb Will be called when the host
 * disconencts. Will be called immediately if the connection fails.
 */
function getKeepAliveConnection (hostId, connectCb, disconnectCb, timeout) {
  messageApi = require("./messaging.js");

  var portName = JSON.stringify({type:"KeepAliveConnection"}),
      port = messageApi.connect(hostId, {name: portName});
  if (disconnectCb) {
    log.log("Detected disconnect cb on client keepalive");
    port.onDisconnect.addListener(function () {disconnectCb();});
  }

  var gotToken = false;
  port.onMessage.addListener(function tokenizer (msg) {
    port.onMessage.removeListener(tokenizer);
    gotToken = true;

    if (!msg) {
      log.warn("Empty message came on keepalive port.");
      disconnectCb("no_host");
      port.disconnect();
      return true;
    }

    // Only matching major version numbers can communicate.
    if (msg && msg.version &&
        msg.version.split('.')[0] != messageApi.version.split('.')[0]) {
      log.warn("Received bad app version:", msg.version);
      disconnectCb("bad_version");
      port.disconnect();
      return true;
    }


    if (typeof msg.clientId !== 'number') {
      return false;
    }

    var token = {
      port: port,
      version: msg.version,
      clientId: msg.clientId,
      disconnectCb: disconnectCb
    };
    setImmediate(connectCb.bind(null, token));
  });

  if (typeof timeout !== 'undefined') {
    setTimeout(function() {
      if (gotToken) return;
      log.warn("Host keepalive connection was silent for too long.");
      disconnectCb("timeout");
      port.disconnect();
      return true;
    }, timeout);
  }
}


/**
 * Handle (or delegate) connections and messages from any client. Also
 * keep track of open connections and clean them up if the user asks
 * for it.
 *
 * @param {Object} apiRoot the root of the api to serve.
 */
function HostServer (apiRoot) {
  if (state.apiRoot === apiRoot) {
    throw Error("You are trying to host a second server on the same api.");
  }

  var adhoc = require("./adhoc/host.js");
  apiRoot.messageApi = messageApi;
  apiRoot.serverId = Math.random();
  state.apiRoot = apiRoot;
  state.bootstrapHost = new BootstrapHost();
  adhoc.setupAdHoc(state);

  function closeCb (connection) {
    var len = state.connections.length;
    state.connections = state.connections.filter(function (c) {
      return c !== connection;
    });
    log.log("Cleanined:", connection.repr(), '(before: ', len,'after: ',
            state.connections.length, ')');
  };

  function tabDiedCb (keepalive) {
    // Keep only one reference to each connection, ie don't register
    // them to keepalives or whatever.
    state.connections.forEach(function (c) {
      keepalive.maybeClose(c);
    });
    state.keepalives = state.keepalives.filter(function (ka) {
      return !ka.closed;
    });
  }

  function messageHandle (message, sender, sendResp) {
    return (
      MethodRequest.maybeHandle(message, state.connections, apiRoot, sendResp) ||
        BurstRequest.maybeHandle(message, state.connections, sendResp) ||
        (new ErrResponse("Nothing to do for message." +
                         JSON.stringify(message), false)
         .send(sendResp)));
  }

  function connectHandle (port) {
    if (HostKeepAliveConnection.is(port)) {
      var keepalive = new HostKeepAliveConnection(port, tabDiedCb);
      state.keepalives.push(keepalive);
      return;
    }

    var conn = new HostConnection(port, apiRoot, function () {
      closeCb(conn);
    });
    state.connections.push(conn);
  }

  messageApi.onConnectExternal.addListener(connectHandle);
  log.log("Listening on connections...");
  messageApi.onMessageExternal.addListener(messageHandle);
  log.log("Listening on messages...");

  function cleanUp () {
    log.log("Cleaning connect");
    messageApi.onConnectExternal.removeListener(connectHandle);
    log.log("Cleaning message");
    messageApi.onMessageExternal.removeListener(messageHandle);

    state.connections.forEach(function(c) {
      c.close();
    });

    state.keepalives.forEach(function(k) {
      k.close();
    });

    state.bootstrapHost.cleanup();
    state.apiRoot = null;
  }

  return cleanUp;
}

module.exports.state = state;
module.exports.HostServer = HostServer;
module.exports.getKeepAliveConnection = getKeepAliveConnection;
module.exports.messageApi = messageApi;

},{"./adhoc/host.js":1,"./bootstraphost.js":10,"./hostconnection.js":12,"./log.js":13,"./messaging.js":14,"./requests.js":17,"./responses.js":21,"./setimmediate.js":28}],28:[function(require,module,exports){
(function (global){
// setTimeout is clamped to 1000ms min time for background tabs.

// Check wether we are in the app context.
function isApp () {
  // getManifest resturns a value and thus is not available to the
  // client
  return !!chrome.runtime.getManifest;
};

// Not in a browser makes it ok to use setTimeout
if (!(global.postMessage && global.addEventListener) || isApp()) {
  global.setImmediate = global.setTimeout.bind(global);
  global.clearTimeout = global.clearTimeout.bind(global);
} else {
  (function () {
    "use strict";
    var i = 0;
    var timeouts = {};
    var messageName = "setImmediate" + new Date().getTime();

    function post(fn) {
      if (i === 0x100000000) // max queue size
        i = 0;
      if (++i in timeouts)
        throw new Error("setImmediate queue overflow.");
      timeouts[i] = fn;
      global.postMessage({ type: messageName, id: i }, "*");
      return i;
    }

    function receive(ev) {
      if (ev.source !== window)
        return;
      var data = ev.data;
      if (data && data instanceof Object && data.type === messageName) {
        ev.stopPropagation();
        var id = ev.data.id;
        var fn = timeouts[id];
        if (fn) {
          delete timeouts[id];
          fn();
        }
      }
    }

    function clear(id) {
      delete timeouts[id];
    }

    global.addEventListener("message", receive, true);
    global.setImmediate = post;
    global.clearImmediate = clear;
  })();
}

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
},{}],29:[function(require,module,exports){
function errorThrower (name) {
  return function () {
    throw new Error("No such method: " + name);
  };
}

function arrToBuf(hex) {
  var buffer = new ArrayBuffer(hex.length);
  var bufferView = new Uint8Array(buffer);
  for (var i = 0; i < hex.length; i++) {
    bufferView[i] = hex[i];
  }

  return buffer;
}
module.exports.arrToBuf = arrToBuf;

function bufToArr(bin) {
  var bufferView = new Uint8Array(bin);
  var hexes = [];
  for (var i = 0; i < bufferView.length; ++i) {
    hexes.push(bufferView[i]);
  }
  return hexes;
}
module.exports.bufToArr = bufToArr;

// Get a callable member of this.obj given the name. Dot paths are
// supported.
function path2callable (object, name, callable) {
  var names = name.split('.'),
      method = names.pop(),
      obj = (names.reduce(function (ob, meth) {return ob[meth];}, object)
             || object),
      self = this;

  if (!obj[method]) {
    console.warn("Tried to resolve bad object path: " + name);
    console.warn("Server:", object);
    return null; // errorThrower(name);
  }

  return obj[method].bind(obj);
};
module.exports.path2callable = path2callable;

},{}],30:[function(require,module,exports){
// http://wiki.commonjs.org/wiki/Unit_Testing/1.0
//
// THIS IS NOT TESTED NOR LIKELY TO WORK OUTSIDE V8!
//
// Originally from narwhal.js (http://narwhaljs.org)
// Copyright (c) 2009 Thomas Robinson <280north.com>
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the 'Software'), to
// deal in the Software without restriction, including without limitation the
// rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
// sell copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED 'AS IS', WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
// ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
// WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

// when used in node, this will actually load the util module we depend on
// versus loading the builtin util module as happens otherwise
// this is a bug in node module loading as far as I am concerned
var util = require('util/');

var pSlice = Array.prototype.slice;
var hasOwn = Object.prototype.hasOwnProperty;

// 1. The assert module provides functions that throw
// AssertionError's when particular conditions are not met. The
// assert module must conform to the following interface.

var assert = module.exports = ok;

// 2. The AssertionError is defined in assert.
// new assert.AssertionError({ message: message,
//                             actual: actual,
//                             expected: expected })

assert.AssertionError = function AssertionError(options) {
  this.name = 'AssertionError';
  this.actual = options.actual;
  this.expected = options.expected;
  this.operator = options.operator;
  if (options.message) {
    this.message = options.message;
    this.generatedMessage = false;
  } else {
    this.message = getMessage(this);
    this.generatedMessage = true;
  }
  var stackStartFunction = options.stackStartFunction || fail;

  if (Error.captureStackTrace) {
    Error.captureStackTrace(this, stackStartFunction);
  }
  else {
    // non v8 browsers so we can have a stacktrace
    var err = new Error();
    if (err.stack) {
      var out = err.stack;

      // try to strip useless frames
      var fn_name = stackStartFunction.name;
      var idx = out.indexOf('\n' + fn_name);
      if (idx >= 0) {
        // once we have located the function frame
        // we need to strip out everything before it (and its line)
        var next_line = out.indexOf('\n', idx + 1);
        out = out.substring(next_line + 1);
      }

      this.stack = out;
    }
  }
};

// assert.AssertionError instanceof Error
util.inherits(assert.AssertionError, Error);

function replacer(key, value) {
  if (util.isUndefined(value)) {
    return '' + value;
  }
  if (util.isNumber(value) && (isNaN(value) || !isFinite(value))) {
    return value.toString();
  }
  if (util.isFunction(value) || util.isRegExp(value)) {
    return value.toString();
  }
  return value;
}

function truncate(s, n) {
  if (util.isString(s)) {
    return s.length < n ? s : s.slice(0, n);
  } else {
    return s;
  }
}

function getMessage(self) {
  return truncate(JSON.stringify(self.actual, replacer), 128) + ' ' +
         self.operator + ' ' +
         truncate(JSON.stringify(self.expected, replacer), 128);
}

// At present only the three keys mentioned above are used and
// understood by the spec. Implementations or sub modules can pass
// other keys to the AssertionError's constructor - they will be
// ignored.

// 3. All of the following functions must throw an AssertionError
// when a corresponding condition is not met, with a message that
// may be undefined if not provided.  All assertion methods provide
// both the actual and expected values to the assertion error for
// display purposes.

function fail(actual, expected, message, operator, stackStartFunction) {
  throw new assert.AssertionError({
    message: message,
    actual: actual,
    expected: expected,
    operator: operator,
    stackStartFunction: stackStartFunction
  });
}

// EXTENSION! allows for well behaved errors defined elsewhere.
assert.fail = fail;

// 4. Pure assertion tests whether a value is truthy, as determined
// by !!guard.
// assert.ok(guard, message_opt);
// This statement is equivalent to assert.equal(true, !!guard,
// message_opt);. To test strictly for the value true, use
// assert.strictEqual(true, guard, message_opt);.

function ok(value, message) {
  if (!value) fail(value, true, message, '==', assert.ok);
}
assert.ok = ok;

// 5. The equality assertion tests shallow, coercive equality with
// ==.
// assert.equal(actual, expected, message_opt);

assert.equal = function equal(actual, expected, message) {
  if (actual != expected) fail(actual, expected, message, '==', assert.equal);
};

// 6. The non-equality assertion tests for whether two objects are not equal
// with != assert.notEqual(actual, expected, message_opt);

assert.notEqual = function notEqual(actual, expected, message) {
  if (actual == expected) {
    fail(actual, expected, message, '!=', assert.notEqual);
  }
};

// 7. The equivalence assertion tests a deep equality relation.
// assert.deepEqual(actual, expected, message_opt);

assert.deepEqual = function deepEqual(actual, expected, message) {
  if (!_deepEqual(actual, expected)) {
    fail(actual, expected, message, 'deepEqual', assert.deepEqual);
  }
};

function _deepEqual(actual, expected) {
  // 7.1. All identical values are equivalent, as determined by ===.
  if (actual === expected) {
    return true;

  } else if (util.isBuffer(actual) && util.isBuffer(expected)) {
    if (actual.length != expected.length) return false;

    for (var i = 0; i < actual.length; i++) {
      if (actual[i] !== expected[i]) return false;
    }

    return true;

  // 7.2. If the expected value is a Date object, the actual value is
  // equivalent if it is also a Date object that refers to the same time.
  } else if (util.isDate(actual) && util.isDate(expected)) {
    return actual.getTime() === expected.getTime();

  // 7.3 If the expected value is a RegExp object, the actual value is
  // equivalent if it is also a RegExp object with the same source and
  // properties (`global`, `multiline`, `lastIndex`, `ignoreCase`).
  } else if (util.isRegExp(actual) && util.isRegExp(expected)) {
    return actual.source === expected.source &&
           actual.global === expected.global &&
           actual.multiline === expected.multiline &&
           actual.lastIndex === expected.lastIndex &&
           actual.ignoreCase === expected.ignoreCase;

  // 7.4. Other pairs that do not both pass typeof value == 'object',
  // equivalence is determined by ==.
  } else if (!util.isObject(actual) && !util.isObject(expected)) {
    return actual == expected;

  // 7.5 For all other Object pairs, including Array objects, equivalence is
  // determined by having the same number of owned properties (as verified
  // with Object.prototype.hasOwnProperty.call), the same set of keys
  // (although not necessarily the same order), equivalent values for every
  // corresponding key, and an identical 'prototype' property. Note: this
  // accounts for both named and indexed properties on Arrays.
  } else {
    return objEquiv(actual, expected);
  }
}

function isArguments(object) {
  return Object.prototype.toString.call(object) == '[object Arguments]';
}

function objEquiv(a, b) {
  if (util.isNullOrUndefined(a) || util.isNullOrUndefined(b))
    return false;
  // an identical 'prototype' property.
  if (a.prototype !== b.prototype) return false;
  //~~~I've managed to break Object.keys through screwy arguments passing.
  //   Converting to array solves the problem.
  if (isArguments(a)) {
    if (!isArguments(b)) {
      return false;
    }
    a = pSlice.call(a);
    b = pSlice.call(b);
    return _deepEqual(a, b);
  }
  try {
    var ka = objectKeys(a),
        kb = objectKeys(b),
        key, i;
  } catch (e) {//happens when one is a string literal and the other isn't
    return false;
  }
  // having the same number of owned properties (keys incorporates
  // hasOwnProperty)
  if (ka.length != kb.length)
    return false;
  //the same set of keys (although not necessarily the same order),
  ka.sort();
  kb.sort();
  //~~~cheap key test
  for (i = ka.length - 1; i >= 0; i--) {
    if (ka[i] != kb[i])
      return false;
  }
  //equivalent values for every corresponding key, and
  //~~~possibly expensive deep test
  for (i = ka.length - 1; i >= 0; i--) {
    key = ka[i];
    if (!_deepEqual(a[key], b[key])) return false;
  }
  return true;
}

// 8. The non-equivalence assertion tests for any deep inequality.
// assert.notDeepEqual(actual, expected, message_opt);

assert.notDeepEqual = function notDeepEqual(actual, expected, message) {
  if (_deepEqual(actual, expected)) {
    fail(actual, expected, message, 'notDeepEqual', assert.notDeepEqual);
  }
};

// 9. The strict equality assertion tests strict equality, as determined by ===.
// assert.strictEqual(actual, expected, message_opt);

assert.strictEqual = function strictEqual(actual, expected, message) {
  if (actual !== expected) {
    fail(actual, expected, message, '===', assert.strictEqual);
  }
};

// 10. The strict non-equality assertion tests for strict inequality, as
// determined by !==.  assert.notStrictEqual(actual, expected, message_opt);

assert.notStrictEqual = function notStrictEqual(actual, expected, message) {
  if (actual === expected) {
    fail(actual, expected, message, '!==', assert.notStrictEqual);
  }
};

function expectedException(actual, expected) {
  if (!actual || !expected) {
    return false;
  }

  if (Object.prototype.toString.call(expected) == '[object RegExp]') {
    return expected.test(actual);
  } else if (actual instanceof expected) {
    return true;
  } else if (expected.call({}, actual) === true) {
    return true;
  }

  return false;
}

function _throws(shouldThrow, block, expected, message) {
  var actual;

  if (util.isString(expected)) {
    message = expected;
    expected = null;
  }

  try {
    block();
  } catch (e) {
    actual = e;
  }

  message = (expected && expected.name ? ' (' + expected.name + ').' : '.') +
            (message ? ' ' + message : '.');

  if (shouldThrow && !actual) {
    fail(actual, expected, 'Missing expected exception' + message);
  }

  if (!shouldThrow && expectedException(actual, expected)) {
    fail(actual, expected, 'Got unwanted exception' + message);
  }

  if ((shouldThrow && actual && expected &&
      !expectedException(actual, expected)) || (!shouldThrow && actual)) {
    throw actual;
  }
}

// 11. Expected to throw an error:
// assert.throws(block, Error_opt, message_opt);

assert.throws = function(block, /*optional*/error, /*optional*/message) {
  _throws.apply(this, [true].concat(pSlice.call(arguments)));
};

// EXTENSION! This is annoying to write outside this module.
assert.doesNotThrow = function(block, /*optional*/message) {
  _throws.apply(this, [false].concat(pSlice.call(arguments)));
};

assert.ifError = function(err) { if (err) {throw err;}};

var objectKeys = Object.keys || function (obj) {
  var keys = [];
  for (var key in obj) {
    if (hasOwn.call(obj, key)) keys.push(key);
  }
  return keys;
};

},{"util/":34}],31:[function(require,module,exports){
if (typeof Object.create === 'function') {
  // implementation from standard node.js 'util' module
  module.exports = function inherits(ctor, superCtor) {
    ctor.super_ = superCtor
    ctor.prototype = Object.create(superCtor.prototype, {
      constructor: {
        value: ctor,
        enumerable: false,
        writable: true,
        configurable: true
      }
    });
  };
} else {
  // old school shim for old browsers
  module.exports = function inherits(ctor, superCtor) {
    ctor.super_ = superCtor
    var TempCtor = function () {}
    TempCtor.prototype = superCtor.prototype
    ctor.prototype = new TempCtor()
    ctor.prototype.constructor = ctor
  }
}

},{}],32:[function(require,module,exports){
// shim for using process in browser

var process = module.exports = {};

process.nextTick = (function () {
    var canSetImmediate = typeof window !== 'undefined'
    && window.setImmediate;
    var canMutationObserver = typeof window !== 'undefined'
    && window.MutationObserver;
    var canPost = typeof window !== 'undefined'
    && window.postMessage && window.addEventListener
    ;

    if (canSetImmediate) {
        return function (f) { return window.setImmediate(f) };
    }

    var queue = [];

    if (canMutationObserver) {
        var hiddenDiv = document.createElement("div");
        var observer = new MutationObserver(function () {
            var queueList = queue.slice();
            queue.length = 0;
            queueList.forEach(function (fn) {
                fn();
            });
        });

        observer.observe(hiddenDiv, { attributes: true });

        return function nextTick(fn) {
            if (!queue.length) {
                hiddenDiv.setAttribute('yes', 'no');
            }
            queue.push(fn);
        };
    }

    if (canPost) {
        window.addEventListener('message', function (ev) {
            var source = ev.source;
            if ((source === window || source === null) && ev.data === 'process-tick') {
                ev.stopPropagation();
                if (queue.length > 0) {
                    var fn = queue.shift();
                    fn();
                }
            }
        }, true);

        return function nextTick(fn) {
            queue.push(fn);
            window.postMessage('process-tick', '*');
        };
    }

    return function nextTick(fn) {
        setTimeout(fn, 0);
    };
})();

process.title = 'browser';
process.browser = true;
process.env = {};
process.argv = [];

function noop() {}

process.on = noop;
process.addListener = noop;
process.once = noop;
process.off = noop;
process.removeListener = noop;
process.removeAllListeners = noop;
process.emit = noop;

process.binding = function (name) {
    throw new Error('process.binding is not supported');
};

// TODO(shtylman)
process.cwd = function () { return '/' };
process.chdir = function (dir) {
    throw new Error('process.chdir is not supported');
};

},{}],33:[function(require,module,exports){
module.exports = function isBuffer(arg) {
  return arg && typeof arg === 'object'
    && typeof arg.copy === 'function'
    && typeof arg.fill === 'function'
    && typeof arg.readUInt8 === 'function';
}
},{}],34:[function(require,module,exports){
(function (process,global){
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.

var formatRegExp = /%[sdj%]/g;
exports.format = function(f) {
  if (!isString(f)) {
    var objects = [];
    for (var i = 0; i < arguments.length; i++) {
      objects.push(inspect(arguments[i]));
    }
    return objects.join(' ');
  }

  var i = 1;
  var args = arguments;
  var len = args.length;
  var str = String(f).replace(formatRegExp, function(x) {
    if (x === '%%') return '%';
    if (i >= len) return x;
    switch (x) {
      case '%s': return String(args[i++]);
      case '%d': return Number(args[i++]);
      case '%j':
        try {
          return JSON.stringify(args[i++]);
        } catch (_) {
          return '[Circular]';
        }
      default:
        return x;
    }
  });
  for (var x = args[i]; i < len; x = args[++i]) {
    if (isNull(x) || !isObject(x)) {
      str += ' ' + x;
    } else {
      str += ' ' + inspect(x);
    }
  }
  return str;
};


// Mark that a method should not be used.
// Returns a modified function which warns once by default.
// If --no-deprecation is set, then it is a no-op.
exports.deprecate = function(fn, msg) {
  // Allow for deprecating things in the process of starting up.
  if (isUndefined(global.process)) {
    return function() {
      return exports.deprecate(fn, msg).apply(this, arguments);
    };
  }

  if (process.noDeprecation === true) {
    return fn;
  }

  var warned = false;
  function deprecated() {
    if (!warned) {
      if (process.throwDeprecation) {
        throw new Error(msg);
      } else if (process.traceDeprecation) {
        console.trace(msg);
      } else {
        console.error(msg);
      }
      warned = true;
    }
    return fn.apply(this, arguments);
  }

  return deprecated;
};


var debugs = {};
var debugEnviron;
exports.debuglog = function(set) {
  if (isUndefined(debugEnviron))
    debugEnviron = process.env.NODE_DEBUG || '';
  set = set.toUpperCase();
  if (!debugs[set]) {
    if (new RegExp('\\b' + set + '\\b', 'i').test(debugEnviron)) {
      var pid = process.pid;
      debugs[set] = function() {
        var msg = exports.format.apply(exports, arguments);
        console.error('%s %d: %s', set, pid, msg);
      };
    } else {
      debugs[set] = function() {};
    }
  }
  return debugs[set];
};


/**
 * Echos the value of a value. Trys to print the value out
 * in the best way possible given the different types.
 *
 * @param {Object} obj The object to print out.
 * @param {Object} opts Optional options object that alters the output.
 */
/* legacy: obj, showHidden, depth, colors*/
function inspect(obj, opts) {
  // default options
  var ctx = {
    seen: [],
    stylize: stylizeNoColor
  };
  // legacy...
  if (arguments.length >= 3) ctx.depth = arguments[2];
  if (arguments.length >= 4) ctx.colors = arguments[3];
  if (isBoolean(opts)) {
    // legacy...
    ctx.showHidden = opts;
  } else if (opts) {
    // got an "options" object
    exports._extend(ctx, opts);
  }
  // set default options
  if (isUndefined(ctx.showHidden)) ctx.showHidden = false;
  if (isUndefined(ctx.depth)) ctx.depth = 2;
  if (isUndefined(ctx.colors)) ctx.colors = false;
  if (isUndefined(ctx.customInspect)) ctx.customInspect = true;
  if (ctx.colors) ctx.stylize = stylizeWithColor;
  return formatValue(ctx, obj, ctx.depth);
}
exports.inspect = inspect;


// http://en.wikipedia.org/wiki/ANSI_escape_code#graphics
inspect.colors = {
  'bold' : [1, 22],
  'italic' : [3, 23],
  'underline' : [4, 24],
  'inverse' : [7, 27],
  'white' : [37, 39],
  'grey' : [90, 39],
  'black' : [30, 39],
  'blue' : [34, 39],
  'cyan' : [36, 39],
  'green' : [32, 39],
  'magenta' : [35, 39],
  'red' : [31, 39],
  'yellow' : [33, 39]
};

// Don't use 'blue' not visible on cmd.exe
inspect.styles = {
  'special': 'cyan',
  'number': 'yellow',
  'boolean': 'yellow',
  'undefined': 'grey',
  'null': 'bold',
  'string': 'green',
  'date': 'magenta',
  // "name": intentionally not styling
  'regexp': 'red'
};


function stylizeWithColor(str, styleType) {
  var style = inspect.styles[styleType];

  if (style) {
    return '\u001b[' + inspect.colors[style][0] + 'm' + str +
           '\u001b[' + inspect.colors[style][1] + 'm';
  } else {
    return str;
  }
}


function stylizeNoColor(str, styleType) {
  return str;
}


function arrayToHash(array) {
  var hash = {};

  array.forEach(function(val, idx) {
    hash[val] = true;
  });

  return hash;
}


function formatValue(ctx, value, recurseTimes) {
  // Provide a hook for user-specified inspect functions.
  // Check that value is an object with an inspect function on it
  if (ctx.customInspect &&
      value &&
      isFunction(value.inspect) &&
      // Filter out the util module, it's inspect function is special
      value.inspect !== exports.inspect &&
      // Also filter out any prototype objects using the circular check.
      !(value.constructor && value.constructor.prototype === value)) {
    var ret = value.inspect(recurseTimes, ctx);
    if (!isString(ret)) {
      ret = formatValue(ctx, ret, recurseTimes);
    }
    return ret;
  }

  // Primitive types cannot have properties
  var primitive = formatPrimitive(ctx, value);
  if (primitive) {
    return primitive;
  }

  // Look up the keys of the object.
  var keys = Object.keys(value);
  var visibleKeys = arrayToHash(keys);

  if (ctx.showHidden) {
    keys = Object.getOwnPropertyNames(value);
  }

  // IE doesn't make error fields non-enumerable
  // http://msdn.microsoft.com/en-us/library/ie/dww52sbt(v=vs.94).aspx
  if (isError(value)
      && (keys.indexOf('message') >= 0 || keys.indexOf('description') >= 0)) {
    return formatError(value);
  }

  // Some type of object without properties can be shortcutted.
  if (keys.length === 0) {
    if (isFunction(value)) {
      var name = value.name ? ': ' + value.name : '';
      return ctx.stylize('[Function' + name + ']', 'special');
    }
    if (isRegExp(value)) {
      return ctx.stylize(RegExp.prototype.toString.call(value), 'regexp');
    }
    if (isDate(value)) {
      return ctx.stylize(Date.prototype.toString.call(value), 'date');
    }
    if (isError(value)) {
      return formatError(value);
    }
  }

  var base = '', array = false, braces = ['{', '}'];

  // Make Array say that they are Array
  if (isArray(value)) {
    array = true;
    braces = ['[', ']'];
  }

  // Make functions say that they are functions
  if (isFunction(value)) {
    var n = value.name ? ': ' + value.name : '';
    base = ' [Function' + n + ']';
  }

  // Make RegExps say that they are RegExps
  if (isRegExp(value)) {
    base = ' ' + RegExp.prototype.toString.call(value);
  }

  // Make dates with properties first say the date
  if (isDate(value)) {
    base = ' ' + Date.prototype.toUTCString.call(value);
  }

  // Make error with message first say the error
  if (isError(value)) {
    base = ' ' + formatError(value);
  }

  if (keys.length === 0 && (!array || value.length == 0)) {
    return braces[0] + base + braces[1];
  }

  if (recurseTimes < 0) {
    if (isRegExp(value)) {
      return ctx.stylize(RegExp.prototype.toString.call(value), 'regexp');
    } else {
      return ctx.stylize('[Object]', 'special');
    }
  }

  ctx.seen.push(value);

  var output;
  if (array) {
    output = formatArray(ctx, value, recurseTimes, visibleKeys, keys);
  } else {
    output = keys.map(function(key) {
      return formatProperty(ctx, value, recurseTimes, visibleKeys, key, array);
    });
  }

  ctx.seen.pop();

  return reduceToSingleString(output, base, braces);
}


function formatPrimitive(ctx, value) {
  if (isUndefined(value))
    return ctx.stylize('undefined', 'undefined');
  if (isString(value)) {
    var simple = '\'' + JSON.stringify(value).replace(/^"|"$/g, '')
                                             .replace(/'/g, "\\'")
                                             .replace(/\\"/g, '"') + '\'';
    return ctx.stylize(simple, 'string');
  }
  if (isNumber(value))
    return ctx.stylize('' + value, 'number');
  if (isBoolean(value))
    return ctx.stylize('' + value, 'boolean');
  // For some reason typeof null is "object", so special case here.
  if (isNull(value))
    return ctx.stylize('null', 'null');
}


function formatError(value) {
  return '[' + Error.prototype.toString.call(value) + ']';
}


function formatArray(ctx, value, recurseTimes, visibleKeys, keys) {
  var output = [];
  for (var i = 0, l = value.length; i < l; ++i) {
    if (hasOwnProperty(value, String(i))) {
      output.push(formatProperty(ctx, value, recurseTimes, visibleKeys,
          String(i), true));
    } else {
      output.push('');
    }
  }
  keys.forEach(function(key) {
    if (!key.match(/^\d+$/)) {
      output.push(formatProperty(ctx, value, recurseTimes, visibleKeys,
          key, true));
    }
  });
  return output;
}


function formatProperty(ctx, value, recurseTimes, visibleKeys, key, array) {
  var name, str, desc;
  desc = Object.getOwnPropertyDescriptor(value, key) || { value: value[key] };
  if (desc.get) {
    if (desc.set) {
      str = ctx.stylize('[Getter/Setter]', 'special');
    } else {
      str = ctx.stylize('[Getter]', 'special');
    }
  } else {
    if (desc.set) {
      str = ctx.stylize('[Setter]', 'special');
    }
  }
  if (!hasOwnProperty(visibleKeys, key)) {
    name = '[' + key + ']';
  }
  if (!str) {
    if (ctx.seen.indexOf(desc.value) < 0) {
      if (isNull(recurseTimes)) {
        str = formatValue(ctx, desc.value, null);
      } else {
        str = formatValue(ctx, desc.value, recurseTimes - 1);
      }
      if (str.indexOf('\n') > -1) {
        if (array) {
          str = str.split('\n').map(function(line) {
            return '  ' + line;
          }).join('\n').substr(2);
        } else {
          str = '\n' + str.split('\n').map(function(line) {
            return '   ' + line;
          }).join('\n');
        }
      }
    } else {
      str = ctx.stylize('[Circular]', 'special');
    }
  }
  if (isUndefined(name)) {
    if (array && key.match(/^\d+$/)) {
      return str;
    }
    name = JSON.stringify('' + key);
    if (name.match(/^"([a-zA-Z_][a-zA-Z_0-9]*)"$/)) {
      name = name.substr(1, name.length - 2);
      name = ctx.stylize(name, 'name');
    } else {
      name = name.replace(/'/g, "\\'")
                 .replace(/\\"/g, '"')
                 .replace(/(^"|"$)/g, "'");
      name = ctx.stylize(name, 'string');
    }
  }

  return name + ': ' + str;
}


function reduceToSingleString(output, base, braces) {
  var numLinesEst = 0;
  var length = output.reduce(function(prev, cur) {
    numLinesEst++;
    if (cur.indexOf('\n') >= 0) numLinesEst++;
    return prev + cur.replace(/\u001b\[\d\d?m/g, '').length + 1;
  }, 0);

  if (length > 60) {
    return braces[0] +
           (base === '' ? '' : base + '\n ') +
           ' ' +
           output.join(',\n  ') +
           ' ' +
           braces[1];
  }

  return braces[0] + base + ' ' + output.join(', ') + ' ' + braces[1];
}


// NOTE: These type checking functions intentionally don't use `instanceof`
// because it is fragile and can be easily faked with `Object.create()`.
function isArray(ar) {
  return Array.isArray(ar);
}
exports.isArray = isArray;

function isBoolean(arg) {
  return typeof arg === 'boolean';
}
exports.isBoolean = isBoolean;

function isNull(arg) {
  return arg === null;
}
exports.isNull = isNull;

function isNullOrUndefined(arg) {
  return arg == null;
}
exports.isNullOrUndefined = isNullOrUndefined;

function isNumber(arg) {
  return typeof arg === 'number';
}
exports.isNumber = isNumber;

function isString(arg) {
  return typeof arg === 'string';
}
exports.isString = isString;

function isSymbol(arg) {
  return typeof arg === 'symbol';
}
exports.isSymbol = isSymbol;

function isUndefined(arg) {
  return arg === void 0;
}
exports.isUndefined = isUndefined;

function isRegExp(re) {
  return isObject(re) && objectToString(re) === '[object RegExp]';
}
exports.isRegExp = isRegExp;

function isObject(arg) {
  return typeof arg === 'object' && arg !== null;
}
exports.isObject = isObject;

function isDate(d) {
  return isObject(d) && objectToString(d) === '[object Date]';
}
exports.isDate = isDate;

function isError(e) {
  return isObject(e) &&
      (objectToString(e) === '[object Error]' || e instanceof Error);
}
exports.isError = isError;

function isFunction(arg) {
  return typeof arg === 'function';
}
exports.isFunction = isFunction;

function isPrimitive(arg) {
  return arg === null ||
         typeof arg === 'boolean' ||
         typeof arg === 'number' ||
         typeof arg === 'string' ||
         typeof arg === 'symbol' ||  // ES6 symbol
         typeof arg === 'undefined';
}
exports.isPrimitive = isPrimitive;

exports.isBuffer = require('./support/isBuffer');

function objectToString(o) {
  return Object.prototype.toString.call(o);
}


function pad(n) {
  return n < 10 ? '0' + n.toString(10) : n.toString(10);
}


var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep',
              'Oct', 'Nov', 'Dec'];

// 26 Feb 16:19:34
function timestamp() {
  var d = new Date();
  var time = [pad(d.getHours()),
              pad(d.getMinutes()),
              pad(d.getSeconds())].join(':');
  return [d.getDate(), months[d.getMonth()], time].join(' ');
}


// log is just a thin wrapper to console.log that prepends a timestamp
exports.log = function() {
  console.log('%s - %s', timestamp(), exports.format.apply(exports, arguments));
};


/**
 * Inherit the prototype methods from one constructor into another.
 *
 * The Function.prototype.inherits from lang.js rewritten as a standalone
 * function (not on Function.prototype). NOTE: If this file is to be loaded
 * during bootstrapping this function needs to be rewritten using some native
 * functions as prototype setup using normal JavaScript does not work as
 * expected during bootstrapping (see mirror.js in r114903).
 *
 * @param {function} ctor Constructor function which needs to inherit the
 *     prototype.
 * @param {function} superCtor Constructor function to inherit prototype from.
 */
exports.inherits = require('inherits');

exports._extend = function(origin, add) {
  // Don't do anything if add isn't an object
  if (!add || !isObject(add)) return origin;

  var keys = Object.keys(add);
  var i = keys.length;
  while (i--) {
    origin[keys[i]] = add[keys[i]];
  }
  return origin;
};

function hasOwnProperty(obj, prop) {
  return Object.prototype.hasOwnProperty.call(obj, prop);
}

}).call(this,require('_process'),typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
},{"./support/isBuffer":33,"_process":32,"inherits":31}]},{},[11])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3Vzci9sb2NhbC9saWIvbm9kZV9tb2R1bGVzL2Jyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2Jyb3dzZXItcGFjay9fcHJlbHVkZS5qcyIsImNocm9tZS1leHRlbnNpb24vc3JjL2FkaG9jL2hvc3QuanMiLCJjaHJvbWUtZXh0ZW5zaW9uL3NyYy9hcGlldmVudGVtaXR0ZXIuanMiLCJjaHJvbWUtZXh0ZW5zaW9uL3NyYy9hcmd1bWVudHMuanMiLCJjaHJvbWUtZXh0ZW5zaW9uL3NyYy9hcmd1bWVudHMvYmFzaWMuanMiLCJjaHJvbWUtZXh0ZW5zaW9uL3NyYy9hcmd1bWVudHMvY2FsbGJhY2suanMiLCJjaHJvbWUtZXh0ZW5zaW9uL3NyYy9hcmd1bWVudHMvY29udGFpbmVyLmpzIiwiY2hyb21lLWV4dGVuc2lvbi9zcmMvYXJndW1lbnRzL2RhdGEuanMiLCJjaHJvbWUtZXh0ZW5zaW9uL3NyYy9hcmd1bWVudHMvZGF0YWJ1ZmZlci5qcyIsImNocm9tZS1leHRlbnNpb24vc3JjL2FyZ3VtZW50cy9mYWN0b3J5LmpzIiwiY2hyb21lLWV4dGVuc2lvbi9zcmMvYm9vdHN0cmFwaG9zdC5qcyIsImNocm9tZS1leHRlbnNpb24vc3JjL2hvc3QuanMiLCJjaHJvbWUtZXh0ZW5zaW9uL3NyYy9ob3N0Y29ubmVjdGlvbi5qcyIsImNocm9tZS1leHRlbnNpb24vc3JjL2xvZy5qcyIsImNocm9tZS1leHRlbnNpb24vc3JjL21lc3NhZ2luZy5qcyIsImNocm9tZS1leHRlbnNpb24vc3JjL21lc3NhZ2luZy9jaHJvbWUuanMiLCJjaHJvbWUtZXh0ZW5zaW9uL3NyYy9tZXNzYWdpbmcvZHVtbXkuanMiLCJjaHJvbWUtZXh0ZW5zaW9uL3NyYy9yZXF1ZXN0cy5qcyIsImNocm9tZS1leHRlbnNpb24vc3JjL3JlcXVlc3RzL2J1cnN0LmpzIiwiY2hyb21lLWV4dGVuc2lvbi9zcmMvcmVxdWVzdHMvZ2VuZXJpYy5qcyIsImNocm9tZS1leHRlbnNpb24vc3JjL3JlcXVlc3RzL21ldGhvZC5qcyIsImNocm9tZS1leHRlbnNpb24vc3JjL3Jlc3BvbnNlcy5qcyIsImNocm9tZS1leHRlbnNpb24vc3JjL3Jlc3BvbnNlcy9hY2suanMiLCJjaHJvbWUtZXh0ZW5zaW9uL3NyYy9yZXNwb25zZXMvYXJndW1lbnRzLmpzIiwiY2hyb21lLWV4dGVuc2lvbi9zcmMvcmVzcG9uc2VzL2J1cnN0LmpzIiwiY2hyb21lLWV4dGVuc2lvbi9zcmMvcmVzcG9uc2VzL2Vycm9yLmpzIiwiY2hyb21lLWV4dGVuc2lvbi9zcmMvcmVzcG9uc2VzL2dlbmVyaWMuanMiLCJjaHJvbWUtZXh0ZW5zaW9uL3NyYy9zZXJ2ZXIuanMiLCJjaHJvbWUtZXh0ZW5zaW9uL3NyYy9zZXRpbW1lZGlhdGUuanMiLCJjaHJvbWUtZXh0ZW5zaW9uL3NyYy91dGlsLmpzIiwiLi4vLi4vLi4vLi4vLi4vdXNyL2xvY2FsL2xpYi9ub2RlX21vZHVsZXMvYnJvd3NlcmlmeS9ub2RlX21vZHVsZXMvYXNzZXJ0L2Fzc2VydC5qcyIsIi4uLy4uLy4uLy4uLy4uL3Vzci9sb2NhbC9saWIvbm9kZV9tb2R1bGVzL2Jyb3dzZXJpZnkvbm9kZV9tb2R1bGVzL2luaGVyaXRzL2luaGVyaXRzX2Jyb3dzZXIuanMiLCIuLi8uLi8uLi8uLi8uLi91c3IvbG9jYWwvbGliL25vZGVfbW9kdWxlcy9icm93c2VyaWZ5L25vZGVfbW9kdWxlcy9wcm9jZXNzL2Jyb3dzZXIuanMiLCIuLi8uLi8uLi8uLi8uLi91c3IvbG9jYWwvbGliL25vZGVfbW9kdWxlcy9icm93c2VyaWZ5L25vZGVfbW9kdWxlcy91dGlsL3N1cHBvcnQvaXNCdWZmZXJCcm93c2VyLmpzIiwiLi4vLi4vLi4vLi4vLi4vdXNyL2xvY2FsL2xpYi9ub2RlX21vZHVsZXMvYnJvd3NlcmlmeS9ub2RlX21vZHVsZXMvdXRpbC91dGlsLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNsRkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDdkxBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2ZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNuQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUM3REE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUM1RUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN2REE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN2REE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3BCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDMUJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDSkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUM5TEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDckVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzNCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNmQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2pNQTtBQUNBO0FBQ0E7QUFDQTs7QUNIQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUMxRkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3pDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN6UEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2pCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDdENBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzNFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNqSUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNuRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNwREE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDak9BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN4REE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDN0NBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3hXQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDdkJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN0RkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ0xBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwiZmlsZSI6ImdlbmVyYXRlZC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzQ29udGVudCI6WyIoZnVuY3Rpb24gZSh0LG4scil7ZnVuY3Rpb24gcyhvLHUpe2lmKCFuW29dKXtpZighdFtvXSl7dmFyIGE9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtpZighdSYmYSlyZXR1cm4gYShvLCEwKTtpZihpKXJldHVybiBpKG8sITApO3ZhciBmPW5ldyBFcnJvcihcIkNhbm5vdCBmaW5kIG1vZHVsZSAnXCIrbytcIidcIik7dGhyb3cgZi5jb2RlPVwiTU9EVUxFX05PVF9GT1VORFwiLGZ9dmFyIGw9bltvXT17ZXhwb3J0czp7fX07dFtvXVswXS5jYWxsKGwuZXhwb3J0cyxmdW5jdGlvbihlKXt2YXIgbj10W29dWzFdW2VdO3JldHVybiBzKG4/bjplKX0sbCxsLmV4cG9ydHMsZSx0LG4scil9cmV0dXJuIG5bb10uZXhwb3J0c312YXIgaT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2Zvcih2YXIgbz0wO288ci5sZW5ndGg7bysrKXMocltvXSk7cmV0dXJuIHN9KSIsImZ1bmN0aW9uIGlzT2xkc3R5bGVHZXRNYW5pZmVzdCAobWVzc2FnZSkge1xuICAvLyBIZXJlIGlzIGFuIGV4ZW1wbGFyeSBvbGRzdHlsZSBtZXNzYWdlOlxuICAvL1xuICAvLyB7XG4gIC8vICAgICB0aW1lc3RhbXA6IDE0MzU5MzAxODAzODUsXG4gIC8vICAgICBvYmplY3Q6IFwicnVudGltZVwiLFxuICAvLyAgICAgbWV0aG9kOiBcImdldE1hbmlmZXN0QXN5bmNcIixcbiAgLy8gICAgIGFyZ3M6IHtcbiAgLy8gICAgICAgYXJnczogW3tcbiAgLy8gICAgICAgICB0eXBlOiBcImZ1bmN0aW9uXCJcbiAgLy8gICAgICAgfV1cbiAgLy8gICAgIH0sXG4gIC8vICAgICBlcnJvcjogbnVsbCxcbiAgLy8gICAgIGNhbGxiYWNrSWQ6IDE0MzU5MzAxODAzODUsXG4gIC8vICAgICBzZW5kZXI6IDE0MzU5MzAxODAzODVcbiAgLy8gICB9XG5cbiAgcmV0dXJuIG1lc3NhZ2UgJiZcbiAgICBtZXNzYWdlLm1ldGhvZCA9PSBcImdldE1hbmlmZXN0QXN5bmNcIiAmJlxuICAgIG1lc3NhZ2Uub2JqZWN0ID09IFwicnVudGltZVwiICYmXG4gICAgbWVzc2FnZS5jYWxsYmFja0lkO1xufVxuXG5cbmZ1bmN0aW9uIGdldFN0YXRlIChhcGlSb290LCBzdGF0ZSwgY2IpIHtcbiAgdmFyIGZvcm1hdHRlZFN0YXRlID0gYXBpUm9vdC5ydW50aW1lLmdldE1hbmlmZXN0KCk7XG4gIGZvcm1hdHRlZFN0YXRlLmNvbm5lY3Rpb25zID0gc3RhdGUuY29ubmVjdGlvbnMubWFwKGZ1bmN0aW9uIChjKSB7XG4gICAgcmV0dXJuIGMgJiYge1xuICAgICAgYnVmZmVyTGVuZ3RoOiBjLmJ1ZmZlckxlbmd0aCxcbiAgICAgIGNvbmY6IGMucG9ydENvbmYsXG4gICAgICBpZDogYy5pZCxcbiAgICAgIGNsb3NlZDogYy5jbG9zZWRcbiAgICB9O1xuICB9KSxcblxuICBmb3JtYXR0ZWRTdGF0ZS5rZWVwYWxpdmVzID0gc3RhdGUua2VlcGFsaXZlcy5tYXAoZnVuY3Rpb24gKGspIHtcbiAgICByZXR1cm4gayAmJiB7XG4gICAgICBjbGllbnRJZDogay5jbGllbnRJZCxcbiAgICAgIGNvbmY6IGsucG9ydENvbmYsXG4gICAgICBjbG9zZWQ6IGsuY2xvc2VkXG4gICAgfTtcbiAgfSksXG5cbiAgY2IoZm9ybWF0dGVkU3RhdGUpO1xufTtcblxuZnVuY3Rpb24gc2V0dXBBZEhvYyAoc3RhdGUpIHtcbiAgdmFyIGFwaVJvb3QgPSBzdGF0ZS5hcGlSb290O1xuXG4gIC8vIFJlbWVtYmVyIHRvIGFkZCB0aGVzZSB0byB0aGUgY2xpZW50IGNvbmZpZ3VyYXRpb24uXG4gIGlmIChhcGlSb290LnJ1bnRpbWUpIHtcbiAgICBpZiAoIWFwaVJvb3QuYmFiZWxmaXNoKSBhcGlSb290LmJhYmVsZmlzaCA9IHt9O1xuICAgIGFwaVJvb3QuYmFiZWxmaXNoLmdldFN0YXRlID1cbiAgICAgIGFwaVJvb3QucnVudGltZS5nZXRNYW5pZmVzdEFzeW5jID1cbiAgICAgIGdldFN0YXRlLmJpbmQobnVsbCwgYXBpUm9vdCwgc3RhdGUpO1xuXG5cbiAgICAvLyBMaXN0ZW4gZm9yIGdldCBzdGF0ZSB0byBub24tYmFiZWxmaXNoIG9yIGVhcmx5IGJhYmVsZmlzaC5cbiAgICBmdW5jdGlvbiBwcm92aWRlU3RhdGUgKG1zZywgc2VuZFJlc3ApIHtcbiAgICAgIGlmIChtc2cgJiYgKG1zZy5tZXRob2QgPT0gXCJnZXRTdGF0ZVwiIHx8IGlzT2xkc3R5bGVHZXRNYW5pZmVzdChtc2cpKSkge1xuICAgICAgICBhcGlSb290LmJhYmVsZmlzaC5nZXRTdGF0ZShzZW5kUmVzcCk7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfTtcblxuICAgIHN0YXRlLmJvb3RzdHJhcEhvc3QuY29tbWFuZHMucHVzaChwcm92aWRlU3RhdGUpO1xuICB9XG5cbiAgaWYgKGFwaVJvb3Quc2VyaWFsKSB7XG4gICAgYXBpUm9vdC5zZXJpYWwub25SZWNlaXZlRXJyb3IuZm9yY2VEaXNwYXRjaCA9IGZ1bmN0aW9uIChpbmZvKSB7XG4gICAgICBzdGF0ZS5jb25uZWN0aW9ucy5mb3JFYWNoKGZ1bmN0aW9uIChjKSB7XG4gICAgICAgIGlmIChjLmFwaUV2ZW50Lm1ldGhvZE5hbWUgPT0gJ3NlcmlhbC5vblJlY2VpdmVFcnJvci5hZGRMaXN0ZW5lcicpIHtcbiAgICAgICAgICBjLmFwaUV2ZW50Lm1ldGhvZFJlcXVlc3QucmVhbENhbGxiYWNrKCkuY2FsbChudWxsLCBpbmZvKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfTtcbiAgfVxufVxuXG5tb2R1bGUuZXhwb3J0cy5zZXR1cEFkSG9jID0gc2V0dXBBZEhvYztcbiIsIi8qKlxuICogQGZpbGVPdmVydmlldyBBIHdyYXBwZXIgYXJvdW5kIGEgY2hyb21lIGFwaSBldmVudCBvciBub24tcHVyZSBjYWxsXG4gKiB0aGF0IG5lZWRzIGNsZWFuaW5nIHVwLiBVbmRlcnN0YW5kcyB0aGUgY3VycmVuY3kgb2YgTWV0aG9kUmVxdWVzdHNcbiAqIGZvciBjbGVhbmluZyB1cCBhbmQgbWFuYWdpbmcgc3RhdGUgYW5kIHByb3ZpZGVzIGEgdW5pZmllZCBpbnRlcmZhY2VcbiAqIGZvciBjbGVhbmluZyBhbnkgY2FsbCBiYXNlZCBvbiBjbGllbnQncyBpbnN0cnVjdGlvbnMgdXBvblxuICogY29ubmVjdGlvbi5cbiAqXG4gKiBEdWUgdG8gdXNiLmZpbmREZXZpY2VzIHdoaWNoIG9wZW5zIG11bHRpcGxlIGRldmljZXMgYXQgb25jZSB3ZSBtYXlcbiAqIG5lZWQgbW9yZSB0aGFuIG9uZSBjbGVhbnVwIG1ldGhvZHMgdG8gYWN0dWFsbHkgY2xvc2UgdGhlIGV2ZW50XG4gKiBlbWl0dGVyLlxuICpcbiAqIEBuYW1lIGFwaWV2ZW50ZW1pdHRlci5qc1xuICogQGF1dGhvciBDaHJpcyBQZXJpdm9sYXJvcG91bG9zXG4gKi9cbnZhciB1dGlsID0gcmVxdWlyZShcIi4vdXRpbFwiKSxcbiAgICBBY2tSZXNwb25zZSA9IHJlcXVpcmUoJy4vcmVzcG9uc2VzLmpzJykuQWNrUmVzcG9uc2UsXG4gICAgQXJnc1Jlc3BvbnNlID0gcmVxdWlyZSgnLi9yZXNwb25zZXMuanMnKS5BcmdzUmVzcG9uc2UsXG4gICAgTWV0aG9kUmVxdWVzdCA9IHJlcXVpcmUoJy4vcmVxdWVzdHMuanMnKS5NZXRob2RSZXF1ZXN0LFxuICAgIEFyZ3VtZW50cyA9IHJlcXVpcmUoJy4vYXJndW1lbnRzLmpzJykuQXJndW1lbnRzLFxuICAgIGxvZyA9IG5ldyAocmVxdWlyZSgnLi9sb2cuanMnKS5Mb2cpKCdhcGlldmVudGVtaXR0ZXInKTtcblxuXG4vKipcbiAqIFJlc3BvbnNlIG1ldGhvZHMgdG8gaW5qZWN0IGluIGFuIGFwaSBkZXBlbmRpbmcgb24gdGhlIGNsb3NpbmcgdHlwZS5cbiAqL1xudmFyIGNsb3NpbmdSZXNwb25zZXMgPSB7XG4gIGNhbGxpbmdBcmd1bWVudHM6IGZ1bmN0aW9uIChjbG9zaW5nUmVxdWVzdCkge1xuICAgIGlmICghY2xvc2luZ1JlcXVlc3QpIHtcbiAgICAgIG5ldyBNZXRob2RSZXF1ZXN0KG51bGwsIHRoaXMucmV2ZXJzZXIucGF0aCwgdGhpcy5hcmdzKVxuICAgICAgICAuY2FsbChudWxsLCB0aGlzLmhvc3RBcGkpO1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuXG4gICAgaWYgKHRoaXMucmV2ZXJzZXIucGF0aCA9PSBjbG9zaW5nUmVxdWVzdC5tZXRob2QgJiZcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoY2xvc2luZ1JlcXVlc3QuYXJncy5mb3JTZW5kaW5nKCkpID09XG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHRoaXMuYXJncy5mb3JTZW5kaW5nKCkpKSB7XG4gICAgICBjbG9zaW5nUmVxdWVzdC5jYWxsKG51bGwsIHRoaXMuaG9zdEFwaSk7XG4gICAgICB0aGlzLmRlc3Ryb3kodHJ1ZSk7XG4gICAgICByZXR1cm4gbmV3IEFja1Jlc3BvbnNlKCk7XG4gICAgfVxuXG4gICAgcmV0dXJuIG51bGw7XG4gIH0sXG5cbiAgLyoqXG4gICAqIE1heWJlIGNsZWFudXAgYmFzZWQgb24gdGhlIGFyZ3VtZW50cyBvZiB0aGUgZmlyc3QgY2FsbGJhY2suXG4gICAqXG4gICAqIEBwYXJhbSB7dW5kZWZpbmVkfE1ldGhvZFJlcWVzdH0gY2xvc2luZ1JlcXVlc3QgQSBtZXRob2QgcmVxdWVzdFxuICAgKiB0aGF0IGlzIHN1cHBvc2VkIHRvIGNsb3NlLiBJZiBub3QgcHJvdmlkZWQgbWFrZSBzdXJlIHdlIGFyZVxuICAgKiBkZXN0cm95ZWQgYXMgdGhlcmUgaXMgbm9vbmUgdG8gcmVwb3J0IHRvLlxuICAgKiBAcmV0dXJucyB7bnVsbHxBcmdzUmVzcG9uc2V9IFRoZSByZXNwb25zZSB0byBiZSBzZW50IGFmdGVyIHRoZSBjbGVhbnVwLlxuICAgKi9cbiAgZmlyc3RSZXNwb25zZTogZnVuY3Rpb24gKGNsb3NpbmdSZXF1ZXN0KSB7XG4gICAgdmFyIGZyID0gdGhpcy5maXJzdFJlc3BvbnNlTXNnO1xuICAgIGlmICghZnIgfHwgZnIucmVzcG9uc2VUeXBlICE9ICdBcmdzUmVzcG9uc2UnKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG5cbiAgICB2YXIgY2xvc2luZ0FyZyA9IGZyLmFyZ3NbMF07XG4gICAgaWYgKHRoaXMucmV2ZXJzZXIuZmlyc3RBcmdQYXRoKSB7XG4gICAgICBjbG9zaW5nQXJnID0gY2xvc2luZ0FyZ1t0aGlzLnJldmVyc2VyLmZpcnN0QXJnUGF0aF07XG4gICAgfVxuXG4gICAgaWYgKCFjbG9zaW5nUmVxdWVzdCkge1xuICAgICAgLy8gSnVzdCBkbyB5b3VyIGJlc3QuXG4gICAgICB2YXIgbXIgPSBuZXcgTWV0aG9kUmVxdWVzdChudWxsLCB0aGlzLnJldmVyc2VyLnBhdGgsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuZXcgQXJndW1lbnRzKFtjbG9zaW5nQXJnLCBmdW5jdGlvbiAoKSB7fV0pKTtcbiAgICAgIG1yLmNhbGwobnVsbCwgdGhpcy5ob3N0QXBpKTtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cblxuICAgIGlmIChKU09OLnN0cmluZ2lmeShjbG9zaW5nQXJnKSA9PVxuICAgICAgICBKU09OLnN0cmluZ2lmeShjbG9zaW5nUmVxdWVzdC5hcmdzLmZvclNlbmRpbmcoKVswXSkgJiZcbiAgICAgICAgY2xvc2luZ1JlcXVlc3QubWV0aG9kID09IHRoaXMucmV2ZXJzZXIucGF0aCkge1xuICAgICAgdGhpcy5kZXN0cm95KHRydWUpO1xuICAgICAgLy8gVGhlIHJlcXVlc3Qgd2lsbCBiZSBjYWxsZWQgYW5kIHdpbGwgY2FsbCBhbiBhY3R1YWwgY2FsbGJhY2suXG4gICAgICByZXR1cm4gQXJnc1Jlc3BvbnNlLmFzeW5jKGNsb3NpbmdSZXF1ZXN0LCB0aGlzLmhvc3RBcGkpO1xuICAgIH1cblxuICAgIHJldHVybiBudWxsO1xuICB9LFxuXG4gIC8vIEJhY2t3YXJkcyBjb21wYXRpYmxlXG4gIHNlcmlhbDogZnVuY3Rpb24gKGNsb3NpbmdSZXF1ZXN0KSB7XG4gICAgdmFyIG9sZGZhcCA9IHRoaXMucmV2ZXJzZXIuZmlyc3RBcmdQYXRoID0gJ2Nvbm5lY3Rpb25JZCc7XG4gICAgcmV0dXJuIGNsb3NpbmdSZXNwb25zZXMuZmlyc3RSZXNwb25zZShjbG9zaW5nUmVxdWVzdCk7XG4gICAgdGhpcy5yZXZlcnNlci5maXJzdEFyZ1BhdGggPSBvbGRmYXA7XG4gIH0sXG5cbiAgZGVmYXVsdDogZnVuY3Rpb24gKGNsb3NpbmdSZXF1ZXN0KSB7XG4gICAgcmV0dXJuIGNsb3NpbmdSZXNwb25zZXMuc2VyaWFsKGNsb3NpbmdSZXF1ZXN0KSB8fFxuICAgICAgY2xvc2luZ1Jlc3BvbnNlcy5maXJzdFJlc3BvbnNlKGNsb3NpbmdSZXF1ZXN0KSB8fFxuICAgICAgY2xvc2luZ1Jlc3BvbnNlcy5jYWxsaW5nQXJndW1lbnRzKGNsb3NpbmdSZXF1ZXN0KTtcbiAgfVxufTtcblxuXG4vKipcbiAqIEFuIEFwaSBldmVudCBlbWl0dGVyIG9yIGEgbWV0aG9kIHdpdGggc2lkZSBlZmZlY3RzIHRoYXQgbmVlZFxuICogY2xlYW5pbmcgdXAuXG4gKlxuICogQHBhcmFtIHtNZXRob2RSZXF1ZXN0fSBtZXRob2RSZXF1ZXN0IHRoZSBpbmZvcm1hdGlvbiBvbiBob3cgdG8gY2FsbFxuICogdGhlIGVtaXR0ZXJcbiAqIEBwYXJhbSB7UmV2ZXJzZXJPYmplY3R9IHJldmVyc2VyIGEge3BhdGgsIHR5cGV9IHJldmVyc2VyIG9iamVjdC5cbiAqIEBwYXJhbSB7T2JqZWN0fSBob3N0QXBpIFRoZSByb290IG9mIHRoZSBob3N0IGFwaS5cbiAqIEBwYXJhbSB7RnVuY3Rpb259IGNsb3NlQ2IgQ2FsbCB0aGlzIHdoZW4gY2xvc2VkXG4gKi9cbmZ1bmN0aW9uIEFwaUV2ZW50RW1pdHRlciAobWV0aG9kUmVxdWVzdCwgcmV2ZXJzZXIsIGhvc3RBcGksIGNsb3NlQ2IpIHtcbiAgdmFyIHNlbGYgPSB0aGlzO1xuICB0aGlzLm1ldGhvZE5hbWUgPSBtZXRob2RSZXF1ZXN0Lm1ldGhvZDtcbiAgdGhpcy5yZXZlcnNlciA9IHJldmVyc2VyO1xuICB0aGlzLmhvc3RBcGkgPSBob3N0QXBpO1xuICB0aGlzLmNhbGxlZENsb3NpbmdSZXF1ZXN0cyA9IFtdO1xuXG4gIC8vIFJlbWVtYmVyIHRoZSBmaXJzdCByZXNwb25zZVxuICB0aGlzLmFyZ3MgPSBtZXRob2RSZXF1ZXN0LmFyZ3M7XG4gIHRoaXMuYXJncy5zZXRMZW5zKGZ1bmN0aW9uIChjYikge1xuICAgIHJldHVybiBmdW5jdGlvbiAoKSB7XG4gICAgICB2YXIgYXJncyA9IFtdLnNsaWNlLmNhbGwoYXJndW1lbnRzKTtcbiAgICAgIHNlbGYuZmlyc3RSZXNwb25zZU1zZyA9IHNlbGYuZmlyc3RSZXNwb25zZU1zZyB8fCBhcmdzWzBdO1xuICAgICAgY2IuYXBwbHkobnVsbCwgYXJncyk7XG4gICAgfTtcbiAgfSk7XG4gIHRoaXMubWV0aG9kUmVxdWVzdCA9IG1ldGhvZFJlcXVlc3Q7XG4gIGxvZy5sb2coXCJTdGFydGluZyBbcmV2IHR5cGU6IFwiICsgc2VsZi5yZXZlcnNlci50eXBlICsgXCJdOiBcIiwgbWV0aG9kUmVxdWVzdC5mb3JTZW5kaW5nKCkpO1xuXG4gIHRoaXMubWF5YmVSdW5DbG9zZXIgPSBmdW5jdGlvbiAoY2xvc2luZ1JlcXVlc3QpIHtcbiAgICBpZiAoc2VsZi5jbG9zZWQpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJUcnlpbmcgdG8gY2xvc2UgYSBjbG9zZWQgZXZlbnQgZW1pdHRlclwiKTtcbiAgICAgIHJldHVybiBudWxsOyAgICAgICAgICAgICAgICAgLy9USGlzIHNob3VsZG47dCBoYXBwZW5cbiAgICB9XG5cbiAgICAvLyBEZWZhdWx0IHRvICpzb21lKiB3YXkgb2YgaGFuZGxpbmcgcmVzcG9uc2VzLlxuICAgIHZhciBjbG9zaW5nUmVzcG9uc2VGYWN0b3J5ID0gY2xvc2luZ1Jlc3BvbnNlc1tzZWxmLnJldmVyc2VyLnR5cGVdIHx8XG4gICAgICAgIGNsb3NpbmdSZXNwb25zZXMuZGVmYXVsdCxcbiAgICAgICAgcmV0ID0gY2xvc2luZ1Jlc3BvbnNlRmFjdG9yeS5jYWxsKHNlbGYsIGNsb3NpbmdSZXF1ZXN0KTtcblxuICAgIGlmIChyZXQpIHtcbiAgICAgIGxvZy5sb2coXCJDbG9zaW5nW1wiICsgc2VsZi5yZXZlcnNlci50eXBlICsgXCJdOlwiLCByZXQsXG4gICAgICAgICAgICAgIFwid2l0aFwiLCBjbG9zaW5nUmVxdWVzdCk7XG4gICAgfVxuICAgIHJldHVybiByZXQ7XG4gIH07XG5cbiAgLy8gQWN0dWFsbHkgdHJpZ2dlciB0aGUgZXZlbnQuXG4gIHRoaXMuY2xvc2VDYiA9IGNsb3NlQ2I7XG59XG5cbkFwaUV2ZW50RW1pdHRlci5wcm90b3R5cGUgPSB7XG4gIC8qKlxuICAgKiBBY3R1YWxseSBydW4gdGhlIGFwaSBldmVudCBlbWl0dGVyLlxuICAgKi9cbiAgZmlyZTogZnVuY3Rpb24gKCkge1xuICAgIGxvZy5sb2coXCJDb25uZWN0ZWQ6XCIsIHRoaXMubWV0aG9kUmVxdWVzdC5mb3JTZW5kaW5nKCkpO1xuICAgIC8vIE5vIHNlbmQgZnVuY3Rpb24sIGp1c3QgYSBob3N0YXBpXG4gICAgdGhpcy5tZXRob2RSZXF1ZXN0LmNhbGwobnVsbCwgdGhpcy5ob3N0QXBpKTtcbiAgfSxcblxuICAvKipcbiAgICogQ2FsbCBhbGwgdGhlIGNsb3NpbmcgcmVxdWVzdHMgdG8gY2xvc2UgdGhpcyBldmVudC5cbiAgICogQHBhcmFtIHtCb29sZWFufSBzaGFsbG93IFRydWUgbWVhbnMgdGhlIEFQSSBwYXJ0IG9mIGRlc3Ryb3lpbmdcbiAgICogaGFzIGJlZW4gaGFuZGxlZC5cbiAgICovXG4gIGRlc3Ryb3k6IGZ1bmN0aW9uIChzaGFsbG93KSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgIC8vIENsb3NpbmcgdGhpcyBhbmQgdGhlIGNvbm5lY3Rpb24gd2lsbCBjcmVhdGUgYSBsb29wIHNvIGRvbid0IG9taXQgdGhpcy5cbiAgICBpZiAodGhpcy5jbG9zZWQpIHJldHVybjtcbiAgICBpZiAoIXNoYWxsb3cpIHRoaXMubWF5YmVSdW5DbG9zZXIoKTtcbiAgICB0aGlzLmNsb3NlZCA9IHRydWU7XG4gICAgdGhpcy5jbG9zZUNiKCk7XG4gICAgbG9nLmxvZyhcIkRpc2NvbmVjdGVkOlwiLCB0aGlzLm1ldGhvZFJlcXVlc3QuZm9yU2VuZGluZygpKTtcbiAgfSxcblxuICBtaXNzaW5nUmV2ZXJzZUNiOiBmdW5jdGlvbiAoKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiTm8gc3VjaCBtZXRob2QgYXMgXCIgKyB0aGlzLm1ldGhvZE5hbWUpO1xuICB9LFxuXG4gIG1pc3NpbmdNZXRob2RDYjogZnVuY3Rpb24gKCkge1xuICAgIHRocm93IG5ldyBFcnJvcihcIk5vIHJldmVyc2UgbWV0aG9kIGZvciBcIiArIHRoaXMubWV0aG9kTmFtZSk7XG4gIH1cbn07XG5cbm1vZHVsZS5leHBvcnRzLkFwaUV2ZW50RW1pdHRlciA9IEFwaUV2ZW50RW1pdHRlcjtcbiIsIi8qKlxuICogQGZpbGVPdmVydmlldyBBYnN0cmFjdGlvbnMgZm9yIGhhbmRsaW5nIGFyZ3VtZW50IHRyYW5zZm9ybWF0aW9uIGZvclxuICogdHJhbnNwb3J0YXRpb24gYmV0d2VlbiBob3N0LWNsaWVudC5cbiAqIEBuYW1lIGFyZ3VtZW50cy5qc1xuICogQGF1dGhvciBDaHJpcyBQZXJpdm9sYXJvdWxvc1xuICovXG5cbi8vIFRoZSBzb3J0aW5nIGJlbG93IHdpbGwgYmUgcmVmbGVjdGVkLlxubW9kdWxlLmV4cG9ydHMuQ2FsbGJhY2tBcmd1bWVudCA9IHJlcXVpcmUoJy4vYXJndW1lbnRzL2NhbGxiYWNrLmpzJyk7XG5tb2R1bGUuZXhwb3J0cy5EYXRhQXJndW1lbnQgPSByZXF1aXJlKCcuL2FyZ3VtZW50cy9kYXRhLmpzJyk7XG5tb2R1bGUuZXhwb3J0cy5EYXRhYnVmZmVyQXJndW1lbnQgPSByZXF1aXJlKCcuL2FyZ3VtZW50cy9kYXRhYnVmZmVyLmpzJyk7XG5tb2R1bGUuZXhwb3J0cy5CYXNpY0FyZ3VtZW50ID0gcmVxdWlyZSgnLi9hcmd1bWVudHMvYmFzaWMuanMnKTtcbm1vZHVsZS5leHBvcnRzLkFyZ3VtZW50cyA9IHJlcXVpcmUoJy4vYXJndW1lbnRzL2NvbnRhaW5lci5qcycpO1xubW9kdWxlLmV4cG9ydHMuYXJndW1lbnRGYWN0b3J5ID0gcmVxdWlyZSgnLi9hcmd1bWVudHMvZmFjdG9yeS5qcycpLmFyZ3VtZW50RmFjdG9yeTtcbm1vZHVsZS5leHBvcnRzLmFyZ3VtZW50Q2xhc3NlcyA9IHJlcXVpcmUoJy4vYXJndW1lbnRzL2ZhY3RvcnkuanMnKS5hcmd1bWVudENsYXNzZXM7XG4iLCJ2YXIgYXJndW1lbnRDbGFzc2VzID0gcmVxdWlyZSgnLi9mYWN0b3J5LmpzJykuYXJndW1lbnRDbGFzc2VzO1xuXG4vKipcbiAqIEFuIGFscmVhZHkgc2VyaWFsaXphYmxlIGFyZ3VtZW50IGJveGVyLlxuICogQHBhcmFtIHthcmd1bWVudH0gYXJnXG4gKi9cbmZ1bmN0aW9uIEJhc2ljQXJndW1lbnQoYXJnKSB7XG4gIHRoaXMudmFsdWUgPSBhcmc7XG59XG4vKipcbiAqIFdldGhlciB3ZSBjYW4gd3JhcC4gV2UgYXNzdW1lIHdlIGFsd2F5cyBjYW4uXG4gKiBAcGFyYW0ge2FueXRoaW5nfSBhcmdcbiAqIEByZXR1cm5zIHtCb29sZWFufSBBbHdheXMgdHJ1ZS5cbiAqL1xuQmFzaWNBcmd1bWVudC5jYW5XcmFwID0gZnVuY3Rpb24gKGFyZykge1xuICByZXR1cm4gdHJ1ZTtcbn07XG5cbkJhc2ljQXJndW1lbnQucHJvdG90eXBlID0ge1xuICAvKipcbiAgICogQHJldHVybnMge2FueXRoaW5nfSBKdXN0IHJldHVybiB0aGUgdmFsdWUuXG4gICAqL1xuICBmb3JDYWxsaW5nOiBmdW5jdGlvbiAoKSB7XG4gICAgcmV0dXJuIHRoaXMudmFsdWU7XG4gIH0sXG5cbiAgLyoqXG4gICAqIEByZXR1cm5zIHthbnl0aGluZ30gSnVzdCByZXR1cm4gdGhlIHZhbHVlLlxuICAgKi9cbiAgZm9yU2VuZGluZzogZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiB0aGlzLnZhbHVlO1xuICB9XG59O1xuYXJndW1lbnRDbGFzc2VzLnB1c2goQmFzaWNBcmd1bWVudCk7XG5tb2R1bGUuZXhwb3J0cyA9IEJhc2ljQXJndW1lbnQ7XG4iLCJ2YXIgYXJndW1lbnRDbGFzc2VzID0gcmVxdWlyZSgnLi9mYWN0b3J5LmpzJykuYXJndW1lbnRDbGFzc2VzO1xuXG4vKipcbiAqIFdyYXAgYSBjYWxsYmFjay4gVGhlIGNhbGxiYWNrIHdpbGwgZ2V0IGFuIGlkLiBUaGUgYXJnJ3MgaWQgKHdldGhlclxuICogZnVuY3Rpb24gb3Igb2JqZWN0KSBwcmVjZWVkcyB0aGUgcmVwbGFjZUNiIGlkLlxuICpcbiAqIEBwYXJhbSB7RnVuY3Rpb258T2JqZWN0fSBhcmcgYSBzZXJpYWxpemVkIENhbGxiYWNrQXJndW1lbnQgb3IgdGhlXG4gKiBjYWxsYmFjayBpdHNlbGYuXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSByZXBsYWNlQ2IgaWYgdGhlIHByb3ZpZGVkIGFyZyB3YXMgc2VyaWFsaXplZFxuICogc3Vic3RpdHV0ZSBpdCB3aXRoIHRoaXMgd2hlbiBhc2tlZCBmb3IgYSBjYWxsYWJsZS5cbiAqL1xuZnVuY3Rpb24gQ2FsbGJhY2tBcmd1bWVudChhcmcsIHJlcGxhY2VDYikge1xuICBpZiAoIUNhbGxiYWNrQXJndW1lbnQuY2FuV3JhcChhcmcpKSB7XG4gICAgdGhyb3cgRXJyb3IoXCJDYW50IHdyYXAgYXJndW1lbnQgXCIgKyBhcmcgKyBcImFzIGEgZnVuY3Rpb25cIik7XG4gIH1cblxuICB0aGlzLnJlcGxhY2VDYiA9IHJlcGxhY2VDYiB8fCBudWxsO1xuICB0aGlzLmlkID0gYXJnLmlkIHx8XG4gICAgKHRoaXMucmVwbGFjZUNiICYmIHRoaXMucmVwbGFjZUNiLmlkKSB8fFxuICAgIERhdGUubm93KCkgKyBNYXRoLnJhbmRvbSgpO1xuICB0aGlzLmNhbGxiYWNrID0gYXJnIGluc3RhbmNlb2YgRnVuY3Rpb24gPyBhcmcgOiByZXBsYWNlQ2I7XG5cbiAgaWYgKHRoaXMuY2FsbGJhY2spIHtcbiAgICB0aGlzLmNhbGxiYWNrLmlkID0gdGhpcy5pZDtcbiAgfVxuXG4gIHRoaXMucGxhY2Vob2xkZXIgPSB7aWQ6IHRoaXMuaWQsIGlzQ2FsbGJhY2s6IHRydWV9O1xufVxuXG4vKipcbiAqIENoZWNrIGlmIHRoZSBhcmd1bWVudCBpcyBzdWl0YWJsZSBmb3Igd3JhcHBpbmcuXG4gKlxuICogQHBhcmFtIHthbnl0aGluZ30gYXJnXG4gKiBAcmV0dXJucyB7Qm9vbGVhbn0gVHJ1ZSBpZiBpdCdzIHNhZmUgdG8gYm94IHdpdGggdGhpcyB0eXBlLlxuICovXG5DYWxsYmFja0FyZ3VtZW50LmNhbldyYXAgPSBmdW5jdGlvbiAoYXJnKSB7XG4gIHJldHVybiBhcmcgJiYgKGFyZyBpbnN0YW5jZW9mIEZ1bmN0aW9uIHx8IGFyZy5pc0NhbGxiYWNrKTtcbn07XG5cbkNhbGxiYWNrQXJndW1lbnQucHJvdG90eXBlID0ge1xuICAvKipcbiAgICogQHJldHVybnMge0Z1bmN0aW9uIH0gQSBjYWxsYWJsZSB0aGF0IHdpbGwgZWl0aGVyIGRvIHRoZSBqb2Igb25cbiAgICogdGhlIGNsaWVudCwgb3Igc2VuZCBhIG1lc3NhZ2UuXG4gICAqL1xuICBmb3JDYWxsaW5nOiBmdW5jdGlvbiAoKSB7XG4gICAgcmV0dXJuIHRoaXMubGVucyA/IHRoaXMubGVucyh0aGlzLmNhbGxiYWNrKSA6IHRoaXMuY2FsbGJhY2s7XG4gIH0sXG5cbiAgLyoqXG4gICAqIEByZXR1cm5zIHtPYmplY3R9IEEgc2VyaWFsaXphYmxlIG9iamVjdC5cbiAgICovXG4gIGZvclNlbmRpbmc6IGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gdGhpcy5wbGFjZWhvbGRlcjtcbiAgfSxcblxuICBzZXRMZW5zOiBmdW5jdGlvbiAobGVucykge1xuICAgIHRoaXMubGVucyA9IGxlbnM7XG4gIH1cbn07XG5hcmd1bWVudENsYXNzZXMucHVzaChDYWxsYmFja0FyZ3VtZW50KTtcbm1vZHVsZS5leHBvcnRzID0gQ2FsbGJhY2tBcmd1bWVudDtcbiIsIi8qKlxuICogQGZpbGVPdmVydmlldyBBYnN0cmFjdGlvbnMgZm9yIGhhbmRsaW5nIGFyZ3VtZW50IHRyYW5zZm9ybWF0aW9uIGZvclxuICogdHJhbnNwb3J0YXRpb24gYmV0d2VlbiBob3N0LWNsaWVudC5cbiAqIEBuYW1lIGNvbnRhaW5lci5qc1xuICogQGF1dGhvciBDaHJpcyBQZXJpdm9sYXJvdWxvc1xuICovXG5cbnZhciBDYWxsYmFja0FyZ3VtZW50ID0gcmVxdWlyZSgnLi9jYWxsYmFjay5qcycpLFxuICAgIGFyZ3VtZW50RmFjdG9yeSA9IHJlcXVpcmUoJy4vZmFjdG9yeS5qcycpLmFyZ3VtZW50RmFjdG9yeTtcblxuLyoqXG4gKiBBbiB3cmFwcGVyIGFyb3VuZCBhbiBhcmd1bWVudHMgbGlzdCB0aGF0IGFic3RyYWN0cyBhbGxcbiAqIHRyYXNmb3JtYXRpb25zIHRvIHNlcmlhbGl6ZSB0aGVtLCBjb252ZXJ0IHRoZW0gdG8gYSBjYWxsYWJsZSBzdGF0ZSxcbiAqIHN1YnN0aXR1dGUgY2FsbGJhY2tzIHdpdGggJ3NlbmQgcmVzcG9uc2UnIGNhbGxiYWtjcyBldGMuIFdlIHN1cHBvcnRcbiAqIG9ubHkgb25lIGNhbGxiYWNrIHBlciBBcmd1bWVudHMgb2JqZWN0LiBUaGlzIG9iamVjdCB3aWxsIGRvIHRoZVxuICogcmlnaHQgdGhpbmcgZGVwZW5kaW5nIG9uIHdoZXRoZXIgd2VhcmUgb24gdGhlIGhvc3Qgb3IgdGhlIGNsaWVudC5cbiAqXG4gKiBAcGFyYW0ge0FycmF5fSBhcmd1bWVudHMgQW4gYXJyYXkgb2YgYXJndW1lbnRzIGVpdGhlciBzZXJpYWxpemVkIG9yXG4gKiBub3QuIFRoZSBlbGVtZW50cyB3aWxsIGJlIGhhbmRsZWQgYnkgYXJndW1lbnQgdHlwZXMuXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSByZXBsYWNlQ2IgVGhlICdzZW5kIHJlcXVlc3QnIGNhbGxiYWNrIHR5cGljYWxseVxuICogdG8gc3Vic3RpdHV0ZSB0aGUgY2FsbGJhY2sgaW4gdGhlIGFyZ3VtZW50cy5cbiAqL1xuZnVuY3Rpb24gQXJndW1lbnRzIChhcmd1bWVudHMsIHJlcGxhY2VDYikge1xuICB0aGlzLmFyZ3VtZW50cyA9IGFyZ3VtZW50cy5tYXAoZnVuY3Rpb24gKGEpIHtcbiAgICByZXR1cm4gYXJndW1lbnRGYWN0b3J5KGEsIHJlcGxhY2VDYik7XG4gIH0pO1xufVxuXG5Bcmd1bWVudHMucHJvdG90eXBlID0ge1xuICAvKipcbiAgICogVGhlIGFyZ3VtZW50IGxpc3Qgc3VpdGFibGUgZm9yIHBhc3NpbmcgdG8gYW4gYXBpIG1ldGhvZC5cbiAgICogQHJldHVybnMge0FycmF5fSBBbiBhcnJheSBvZiBhcmd1bWVudHMgYXMgZXhwZWN0ZWQgYnkgdGhlIEFQSVxuICAgKi9cbiAgZm9yQ2FsbGluZzogZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiB0aGlzLmFyZ3VtZW50cy5tYXAoZnVuY3Rpb24gKGEpIHtyZXR1cm4gYS5mb3JDYWxsaW5nKCk7fSk7XG4gIH0sXG5cbiAgLyoqXG4gICAqIFRoZSBhcmd1bWVudCBsaXN0IHN1aXRhYmxlIGZvciBzZW5kaW5nIG92ZXIgdGhlIG1lc3NhZ2UgcGFzc2luZ1xuICAgKiBhcGkgb2YgY2hyb21lLlxuICAgKiBAcmV0dXJucyB7QXJyYXl9IFRoZSBhcmd1bWVudCBhcnJheSBzZXJpYWxpemVkLlxuICAgKi9cbiAgZm9yU2VuZGluZzogZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiB0aGlzLmFyZ3VtZW50cy5tYXAoZnVuY3Rpb24gKGEpIHtcbiAgICAgIHJldHVybiBhLmZvclNlbmRpbmcoKTtcbiAgICB9KTtcbiAgfSxcblxuICAvKipcbiAgICogRGVwZW5kaW5nIG9uIHdldGhlciB3ZSBhcmUgb24gdGhlIGNsaWVudCBvciB0aGUgaG9zdCBnZXQgdGhlXG4gICAqIGNhbGxiYWNrIGZvdW5kIGluIHRoZSBhcmd1bWVudHMuXG4gICAqXG4gICAqIEByZXR1cm5zIHtGdW5jdGlvbn0gRWl0aGVyIHRoZSAnc2VuZCByZXNwb25zZScgY2FsbGJhY2ssIG9yIHRoZVxuICAgKiBhY3R1YWwgY2FsbGJhY2suXG4gICAqL1xuICBnZXRDYWxsYmFjazogZnVuY3Rpb24gKCkge1xuICAgIHZhciBjYkFyZyA9IHRoaXMuYXJndW1lbnRzLmZpbHRlcihmdW5jdGlvbiAoYSkge1xuICAgICAgcmV0dXJuIGEgaW5zdGFuY2VvZiBDYWxsYmFja0FyZ3VtZW50O1xuICAgIH0pWzBdLFxuICAgICAgICByZXQgPSBjYkFyZyA/IGNiQXJnLmZvckNhbGxpbmcoKSA6IHRoaXMucmVwbGFjZUNiO1xuXG4gICAgcmV0dXJuIHJldDtcbiAgfSxcblxuICBzZXRMZW5zOiBmdW5jdGlvbihsZW5zKSB7XG4gICAgaWYgKHRoaXMucmVwbGFjZUNiKSB7XG4gICAgICB0aGlzLnJlcGxhY2VDYiA9IGxlbnModGhpcy5yZXBsYWNlQ2IpO1xuICAgIH1cblxuICAgIHRoaXMuYXJndW1lbnRzLmZvckVhY2goZnVuY3Rpb24oYSkge1xuICAgICAgaWYgKGEuc2V0TGVucykgYS5zZXRMZW5zKGxlbnMpO1xuICAgIH0pO1xuICB9XG59O1xuXG5tb2R1bGUuZXhwb3J0cyA9IEFyZ3VtZW50cztcbiIsInZhciBhcmd1bWVudENsYXNzZXMgPSByZXF1aXJlKCcuL2ZhY3RvcnkuanMnKS5hcmd1bWVudENsYXNzZXMsXG4gICAgRGF0YWJ1ZmZlckFyZ3VtZW50ID0gcmVxdWlyZSgnLi9kYXRhYnVmZmVyLmpzJyk7XG5cbmZ1bmN0aW9uIERhdGFBcmd1bWVudChhcmcpIHtcbiAgaWYgKCFEYXRhQXJndW1lbnQuY2FuV3JhcChhcmcpKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgb2JqZWN0IGxpa2Uge2RhdGE6IEFycmF5QnVmZmVyfSwgZ290OiBcIiwgYXJnKTtcbiAgfVxuICB0aGlzLmFyZyA9IGFyZztcbiAgdGhpcy5kYXRhID0gbmV3IERhdGFidWZmZXJBcmd1bWVudChhcmcuZGF0YSk7XG59XG5cbkRhdGFBcmd1bWVudC5jYW5XcmFwID0gZnVuY3Rpb24gKGFyZykge1xuICByZXR1cm4gYXJnIGluc3RhbmNlb2YgT2JqZWN0ICYmXG4gICAgRGF0YWJ1ZmZlckFyZ3VtZW50LmNhbldyYXAoYXJnLmRhdGEpO1xufTtcblxuRGF0YUFyZ3VtZW50LnByb3RvdHlwZSA9IHtcbiAgYXJnQ29weTogZnVuY3Rpb24gKCkge1xuICAgIHZhciByZXQgPSB7fSwgc2VsZiA9IHRoaXM7XG4gICAgT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXModGhpcy5hcmcpLmZvckVhY2goZnVuY3Rpb24gKGspIHtcbiAgICAgIHJldFtrXSA9IHNlbGYuYXJnW2tdO1xuICAgIH0pO1xuXG4gICAgcmV0dXJuIHJldDtcbiAgfSxcblxuICAvKipcbiAgICogQHJldHVybnMge09iamVjdH0gV2hhdCB0aGUgQVBJIGV4cGVjdHMgb3Igd2hhdCBpcyBleHBlY3RlZCBieVxuICAgKiB0aGUgQVBJLlxuICAgKi9cbiAgZm9yQ2FsbGluZzogZnVuY3Rpb24gKCkge1xuICAgIHZhciByZXQgPSB0aGlzLmFyZ0NvcHkoKTtcbiAgICByZXQuZGF0YSA9IHRoaXMuZGF0YS5mb3JDYWxsaW5nKCk7XG4gICAgcmV0dXJuIHJldDtcbiAgfSxcblxuICAvKipcbiAgICogQHJldHVybnMge09iamVjdH0gQW4gc2VyaWFsaXphYmxlIG9iamVjdCB0aGF0IHdlIGNhbiB0dXJuIGJhY2tcbiAgICogaW50byBhIGRhdGFidWZmZXIgY29udGFpbmVyLlxuICAgKi9cbiAgZm9yU2VuZGluZzogZnVuY3Rpb24gKCkge1xuICAgIHZhciByZXQgPSB0aGlzLmFyZ0NvcHkoKTtcbiAgICByZXQuZGF0YSA9IHRoaXMuZGF0YS5mb3JTZW5kaW5nKCk7XG4gICAgcmV0dXJuIHJldDtcbiAgfSxcblxuICBjb25jYXQ6IGZ1bmN0aW9uIChtc2cpIHtcbiAgICBpZiAoIW1zZy5kYXRhIHx8ICFtc2cuZGF0YS5pc0FycmF5QnVmZmVyKSByZXR1cm4gdGhpcztcbiAgICB2YXIgcmV0ID0gdGhpcy5mb3JTZW5kaW5nKCk7XG4gICAgcmV0LmRhdGEgPSB0aGlzLmRhdGEuY29uY2F0KG1zZy5kYXRhKS5mb3JTZW5kaW5nKCk7XG4gICAgcmV0dXJuIG5ldyBEYXRhQXJndW1lbnQocmV0KTtcbiAgfVxufTtcbmFyZ3VtZW50Q2xhc3Nlcy5wdXNoKERhdGFBcmd1bWVudCk7XG5tb2R1bGUuZXhwb3J0cyA9IERhdGFBcmd1bWVudDtcbiIsInZhciBhcmd1bWVudENsYXNzZXMgPSByZXF1aXJlKCcuL2ZhY3RvcnkuanMnKS5hcmd1bWVudENsYXNzZXMsXG4gICAgdXRpbCA9IHJlcXVpcmUoJy4uL3V0aWwuanMnKTtcbi8qKlxuICogQm94aW5nIGZvciBkYXRhYnVmZmVycy5cbiAqXG4gKiBAcGFyYW0ge0RhdGFCdWZmZXJ8T2JqZWN0fSBhcmcgRWl0aGVyIGEgZGF0YWJ1ZmZlciBvciBhIHNlcmlhbGl6ZWRcbiAqIGRhdGFidWZmZXIgb2JqZWN0LlxuICogQHRocm93cyB7RXJyb3J9IFByb3RlY3RzIHlvdSBpbiBjYXNlIHlvdSBmb3Jnb3QgdG8gY2FsbCBjYW5XcmFwXG4gKi9cbmZ1bmN0aW9uIERhdGFidWZmZXJBcmd1bWVudChhcmcpIHtcbiAgaWYgKCFEYXRhYnVmZmVyQXJndW1lbnQuY2FuV3JhcChhcmcpKSB7XG4gICAgdGhyb3cgRXJyb3IoXCJDYW50IHdyYXAgYXJndW1lbnQgXCIgKyBhcmcgKyBcIiBhcyBhIGRhdGFidWZmZXJcIik7XG4gIH1cblxuICB0aGlzLmJ1ZmZlciA9IGFyZyBpbnN0YW5jZW9mIEFycmF5QnVmZmVyID8gYXJnIDogbnVsbDtcbiAgdGhpcy5vYmogPSBhcmcuaXNBcnJheUJ1ZmZlciA/IGFyZyA6IG51bGw7XG59XG5cbi8qKlxuICogQ2hlY2sgaWYgdGhlIG9iamVjdCBpcyBlaXRoZSBhIGRhdGFidWZmZXIgb3IgYSBzZXJpYWxpemVkIGRhdGFidWZmZXJcbiAqXG4gKiBAcGFyYW0ge2FueXRoaW5nfSBhcmcgVGhlIG9iamVjdCB0byBjaGVja1xuICogQHJldHVybnMge0Jvb2xlYW59IFRydWUgaWYgd2UgY2FuIHdyYXAuXG4gKi9cbkRhdGFidWZmZXJBcmd1bWVudC5jYW5XcmFwID0gZnVuY3Rpb24gKGFyZykge1xuICByZXR1cm4gYXJnICYmICgoYXJnIGluc3RhbmNlb2YgQXJyYXlCdWZmZXIpIHx8IGFyZy5pc0FycmF5QnVmZmVyKTtcbn07XG5cbkRhdGFidWZmZXJBcmd1bWVudC5wcm90b3R5cGUgPSB7XG4gIC8qKlxuICAgKiBAcmV0dXJucyB7RGF0YUJ1ZmZlcn0gV2hhdCB0aGUgQVBJIGV4cGVjdHMgb3Igd2hhdCBpcyBleHBlY3RlZCBieVxuICAgKiB0aGUgQVBJLlxuICAgKi9cbiAgZm9yQ2FsbGluZzogZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiB0aGlzLmJ1ZmZlciB8fCB1dGlsLmFyclRvQnVmKHRoaXMub2JqLmRhdGEpO1xuICB9LFxuXG4gIC8qKlxuICAgKiBAcmV0dXJucyB7T2JqZWN0fSBBbiBzZXJpYWxpemFibGUgb2JqZWN0IHRoYXQgd2UgY2FuIHR1cm4gYmFja1xuICAgKiBpbnRvIGEgRGF0YUJ1ZmZlci5cbiAgICovXG4gIGZvclNlbmRpbmc6IGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gdGhpcy5vYmogfHwge2RhdGE6IHV0aWwuYnVmVG9BcnIodGhpcy5idWZmZXIpLFxuICAgICAgICAgICAgICAgICAgICAgICAgaXNBcnJheUJ1ZmZlcjogdHJ1ZX07XG4gIH0sXG5cbiAgY29uY2F0OiBmdW5jdGlvbiAobXNnKSB7XG4gICAgaWYgKCFtc2cuaXNBcnJheUJ1ZmZlcikgcmV0dXJuIHRoaXM7XG4gICAgdmFyIHJldCA9IHRoaXMuZm9yU2VuZGluZygpO1xuICAgIHJldC5kYXRhID0gcmV0LmRhdGEuY29uY2F0KG1zZy5kYXRhKTtcbiAgICByZXR1cm4gbmV3IERhdGFidWZmZXJBcmd1bWVudChyZXQpO1xuICB9XG59O1xuYXJndW1lbnRDbGFzc2VzLnB1c2goRGF0YWJ1ZmZlckFyZ3VtZW50KTtcbm1vZHVsZS5leHBvcnRzID0gRGF0YWJ1ZmZlckFyZ3VtZW50O1xuIiwidmFyIGFyZ3VtZW50Q2xhc3NlcyA9IFtdO1xuXG4vKipcbiAqIENob29zZSB0aGUgcmlnaHQgKkFyZ3VtZW50IHR5cGUgYW5kIGNyZWF0ZSBpdCBmb3IgYXJnLlxuICogQHBhcmFtIHthbnl0aGluZ30gYXJnIFRoZSByYXcgYXJndW1lbnRcbiAqIEBwYXJhbSB7RnVuY3Rpb259IHJlcGxhY2luZ0NiIEEgY2FsbGJhY2sgdG8gcmVwbGFjZSBhcmcgaWYgaXQgaXNcbiAqIHNlcmlhbGl6ZWQgQ2FsbGJhY2tBcmd1bWVudC5cbiAqIEByZXR1cm5zIHsqQXJndW1lbnR9IEFuIGFyZ3VtZW50IGluIGFyZ3VtZW50Q2xhc3Nlc1xuICovXG5mdW5jdGlvbiBhcmd1bWVudEZhY3RvcnkoYXJnLCByZXBsYWNpbmdDYikge1xuICB2YXIgY2xhc3NlcyA9IGFyZ3VtZW50Q2xhc3Nlcy5maWx0ZXIoZnVuY3Rpb24gKGFjKSB7XG4gICAgcmV0dXJuIGFjLmNhbldyYXAoYXJnKTtcbiAgfSk7XG5cbiAgLy8gQXQgbGVhc3QgYmFzaWMgYXJndW1lbnQgd2lsbCBiZSBhYmxlIHRvIGRvIHRoaXMuXG4gIHJldHVybiBuZXcgY2xhc3Nlc1swXShhcmcsIHJlcGxhY2luZ0NiKTtcbn1cblxubW9kdWxlLmV4cG9ydHMuYXJndW1lbnRGYWN0b3J5ID0gYXJndW1lbnRGYWN0b3J5O1xubW9kdWxlLmV4cG9ydHMuYXJndW1lbnRDbGFzc2VzID0gYXJndW1lbnRDbGFzc2VzO1xuIiwidmFyIG1lc3NhZ2VBcGkgPSByZXF1aXJlKCcuL21lc3NhZ2luZy5qcycpO1xuXG5mdW5jdGlvbiBCb290c3RyYXBIb3N0ICgpIHtcbiAgdGhpcy5jb21tYW5kcyA9IFtdO1xuICB0aGlzLmxpc3RlbmVyID0gbnVsbDtcbiAgdGhpcy5saXN0ZW4oKTtcbn1cbkJvb3RzdHJhcEhvc3QucHJvdG90eXBlID0ge1xuICBsaXN0ZW46IGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgdGhpcy5saXN0ZW5lciA9IGZ1bmN0aW9uIChyZXEsIHNlbmRlciwgc2VuZFJlc3ApIHtcbiAgICAgIC8vIEJsb2NrIGlmIGEgY29tbWFuZCBzYWlzIGZhbHNlIC0+XG4gICAgICAvLyBTYXkgZmFsc2UgaWYgc29tZSBjb21tYW5kIHNhaXMgZmFsc2VcbiAgICAgIHJldHVybiBzZWxmLmNvbW1hbmRzLmxlbmd0aCA9PSAwIHx8ICFzZWxmLmNvbW1hbmRzLnNvbWUoZnVuY3Rpb24gKGMpIHtcbiAgICAgICAgcmV0dXJuICFjKHJlcSwgc2VuZFJlc3ApO1xuICAgICAgfSk7XG4gICAgfTtcblxuICAgIG1lc3NhZ2VBcGkub25NZXNzYWdlRXh0ZXJuYWwuYWRkTGlzdGVuZXIodGhpcy5saXN0ZW5lcik7XG4gIH0sXG5cbiAgY2xlYW51cDogZnVuY3Rpb24gKCkge1xuICAgIG1lc3NhZ2VBcGkub25NZXNzYWdlRXh0ZXJuYWwucmVtb3ZlTGlzdGVuZXIodGhpcy5saXN0ZW5lcik7XG4gIH1cbn07XG5tb2R1bGUuZXhwb3J0cy5Cb290c3RyYXBIb3N0ID0gQm9vdHN0cmFwSG9zdDtcbiIsInZhciBzZXJ2ZXIgPSByZXF1aXJlKCcuL3NlcnZlci5qcycpLFxuICAgIHNydiA9IG5ldyBzZXJ2ZXIuSG9zdFNlcnZlcihjaHJvbWUpO1xud2luZG93LmFwaSA9IHNlcnZlcjtcbmNvbnNvbGUubG9nKFwiU2VydmluZy4uLlwiKTtcbiIsIi8qKlxuICogQGZpbGVPdmVydmlldyBLbm93IHdoZW4gdGhlIGNsaWVudCBjbG9zZXMgYW5kIGFsc28gY2xvc2UgaWZcbiAqIG9ycGhhbmVkLlxuICpcbiAqIENvbW1vbiBvcGVyYXRpb25zOlxuICogLSBjbG9zZU1lc3NhZ2UgLT4gY2xvc2VDYWxsXG4gKiAtIGNsb3NlRm4ob3BlbkZuKSA9IGNsb3NlZm5cbiAqXG4gKiBQYXJhbWV0ZXJpemVkIG9wZXJhdGlvbjpcbiAqIC0gY2xvc2VBcmdzKGNsb3NlRm4sIG9wZW5BcmdzLCBjYWxsYmFja0FyZ3MpXG4gKlxuICogT24gY29ubmVjdGlvbiBvcGVuOlxuICogZnJvbU9wZW4ob3BlbkZuLCBvcGVuQXJncywgY2FsbGJhY2tBcmdzKSA9XG4gKiAgICAgZnJvbUNsb3NlKGNsb3NlRm4ob3BlbkZuKSwgY2xvc2VBcmdzKGNsb3NlRm4sIG9wZW5BcmdzLCBjYWxsYmFja0FyZ3MpKSA9XG4gKiAgICAgY2xvc2VNZXNzYWdlIC0+IGNsb3NlQ2FsbFxuICpcbiAqIE9uIG1ldGhvZDpcbiAqIGZyb21DbG9zZShjbG9zZUZuLCBjbG9zZUFyZ3MpID0gY2xvc2VNZXNzYWdlIC0+IGNsb3NlQ2FsbFxuICogQG5hbWUgaG9zdGNvbm5lY3Rpb24uanNcbiAqIEBhdXRob3JcbiAqIEBsaWNlbnNlXG4gKi9cblxudmFyIEFyZ3VtZW50cyA9IHJlcXVpcmUoJy4vYXJndW1lbnRzLmpzJykuQXJndW1lbnRzLFxuICAgIE1ldGhvZFJlcXVlc3QgPSByZXF1aXJlKCcuL3JlcXVlc3RzLmpzJykuTWV0aG9kUmVxdWVzdCxcbiAgICBBcGlFdmVudEVtaXR0ZXIgPSByZXF1aXJlKFwiLi9hcGlldmVudGVtaXR0ZXIuanNcIikuQXBpRXZlbnRFbWl0dGVyLFxuICAgIHIgPSByZXF1aXJlKFwiLi9yZXNwb25zZXMuanNcIiksXG4gICAgdXRpbCA9IHJlcXVpcmUoXCIuL3V0aWwuanNcIiksXG4gICAgY2xvc2VkID0gW10sXG4gICAgbG9nID0gbmV3IChyZXF1aXJlKCcuL2xvZy5qcycpLkxvZykoJ2hvc3Rjb25uZWN0aW9uJyk7XG5yZXF1aXJlKCcuL3NldGltbWVkaWF0ZS5qcycpO1xuXG4vKipcbiAqIE1ldGhvZCBnZXRzIHRoZSBhcmdzIGZyb20gdGhlIGNvbm5lY3Rpb24uIFJldmVyc2UganVzdCBnZXRzIHRoZVxuICogcHJvdmlkZWQgY2FsbGJhY2suIFRoZXJlIGlzIG9uZSBjb25uZWN0aW9uIHBlciBldmVudCBwZXIgY2FsbGJhY2tcbiAqIHBlciBjbGllbnQuXG4gKlxuICogVGhlcmUgYXJlIDMgc3RhZ2VzIGluIHRoZSBsaWZlY3ljbGUgb2YgYSBjb25uZWN0aW9uXG4gKlxuICogLSBJbml0IHdoZXJlIHRoZSBjb25uZWN0aW9uIGlzIGluaXRpYXRlZCBhbmQgdGhlIGFwcCBldmVudCBpc1xuICogICB0cmlnZ2VyZWQuIEhhbmRsZWQgYnkgdGhlIGNvbnN0cnVjdG9yIGFuZCBpbml0LlxuICpcbiAqIC0gQ29tbXVuaWNhdGlvbiB3aGVyZSB0aGUgaG9zdCBwb2tlcyB0aGUgY2xpZW50IHdpdGggYSBkYXRhIHJlYWR5XG4gKiAgIChEVFIpIHNpZ25hbCB0aGF0IHRoZXJlIGlzIGRhdGEgYXZhaWxhYmxlLCBhbmQgdGhlIGNsaWVudCByZXF1ZXN0c1xuICogICBmb3IgdGhlIGF2YWlsYWJsZSBkYXRhIHdpdGggYSBzZXBhcmF0ZSBvbmUgdGltZSByZXF1ZXN0XG4gKlxuICogLSBDbG9zZSB3aGVyZSB0aGUgRFRSIGNvbm5lY3Rpb24gaXMgY2xvc2VkIGFuZCB0aGUgbGlzdGVuZXIgaXNcbiAqICAgcmVtb3ZlZC4gSGFuZGxlZCBieSBjbG9zZS5cbiAqXG4gKiBAcGFyYW0ge1BvcnR9IHBvcnQgVGhlIHBvcnQgcmV0dXJuZWQgZnJvbSBvbkNvbm5lY3RFeHRlcm5hbC4gVGhlXG4gKiBuYW1lIHNob3VsZCBiZSBhIGpzb24gZW5jb2RlZCBvYmplY3Qgd2l0aFxuICpcbiAqIC0gaWQ6IHRoZSBjb25uZWN0aW9uIGlkXG4gKiAtIGNsaWVudElkOiB0aGUgaWQgb2YgdGhlIHRhYiwgZ2VuZXJhdGVkIGJ5IGEgS2VlcEFsaXZlQ29ubmV0aW9uXG4gKiAtIG1ldGhvZFJlcXVlc3Q6IEFuIG9iamVjdCBjYWxsZWQgZnJvbSBNZXRob2RSZXF1ZXN0LmZvclNlbmRpbmdcbiAqIC0gcmV2ZXJzZTogQSB7cGF0aCwgdHlwZX0gb2JqZWN0IGRlc2NyaWJpbmcgdGhlIHJldmVyc2VyLlxuICpcbiAqIEBwYXJhbSB7RnVuY3Rpb259IGNsb3NlQ2IgT3B0aW9uYWxseSBhIGNhbGxiYWNrIHdoZW4gdGhlIGNvbm5lY3Rpb25cbiAqIGNsb3Nlcy4gVGhpcyBzaG91bGQgaGFuZGxlIHRoZSBjbGVhbnVwIG9mIHRoZSBjb25uZWN0aW9uIGZvclxuICogZXh0ZXJuYWwgcmVzb3VyY2VzLlxuICovXG5mdW5jdGlvbiBIb3N0Q29ubmVjdGlvbiAocG9ydCwgaG9zdEFwaSwgY2xvc2VDYikge1xuICB2YXIgc2VsZiA9IHRoaXM7XG4gIHRoaXMuYnVmZmVyID0gW107XG4gIHRoaXMucG9ydCA9IHBvcnQ7XG4gIHRoaXMucG9ydENvbmYgPSBKU09OLnBhcnNlKHBvcnQubmFtZSk7XG4gIHRoaXMuaWQgPSB0aGlzLnBvcnRDb25mLmlkO1xuICB0aGlzLmNsb3NlQ2IgPSBjbG9zZUNiLmJpbmQodGhpcyk7XG4gIHRoaXMuY2xvc2VkID0gZmFsc2U7XG5cbiAgLy8gV2lsbCBub3QgYmUgc2VudC5cbiAgdmFyIHNlbmRSYXcgPSBmdW5jdGlvbiAobXNnKSB7XG4gICAgc2VsZi5wdXNoUmVxdWVzdChtc2cpO1xuICB9O1xuICB0aGlzLm1ldGhvZFJlcXVlc3QgPSBNZXRob2RSZXF1ZXN0LmZyb21NZXNzYWdlKFxuICAgIG51bGwsIHRoaXMucG9ydENvbmYubWV0aG9kUmVxdWVzdE1zZywgc2VuZFJhdyk7XG5cbiAgbG9nLmxvZyhcIk9wZW5pbmcgY29ubmVjdGlvbjpcIiwgdGhpcy5yZXByKCkpO1xuICB0aGlzLmFwaUV2ZW50ID0gbmV3IEFwaUV2ZW50RW1pdHRlcih0aGlzLm1ldGhvZFJlcXVlc3QsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucG9ydENvbmYucmV2ZXJzZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhvc3RBcGksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY2xvc2UuYmluZCh0aGlzKSk7XG4gIHRoaXMucG9ydC5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIoZnVuY3Rpb24gKG1zZykge1xuICAgIGlmIChtc2cgPT0gXCJjbGllbnQgY3JlYXRlZFwiKSB7XG4gICAgICBzZWxmLnBvcnQucG9zdE1lc3NhZ2UoXCJhY2tcIik7XG4gICAgICBzZWxmLmFwaUV2ZW50LmZpcmUoKTtcbiAgICB9XG4gIH0pO1xuICBsb2cubG9nKFwiUmVnaXN0ZXJpbmcgc2VydmVyIHNpZGUgb25kaXNjb25uZWN0IGZvciBtZXRob2QgY29ubmVjdGlvblwiKTtcbiAgdGhpcy5wb3J0Lm9uRGlzY29ubmVjdC5hZGRMaXN0ZW5lcih0aGlzLmNsb3NlLmJpbmQodGhpcykpO1xufVxuXG5Ib3N0Q29ubmVjdGlvbi5wcm90b3R5cGUgPSB7XG4gIHJlcHI6IGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gdGhpcy5pZCArICBcIiAoIFwiICsgdGhpcy5tZXRob2RSZXF1ZXN0Lm1ldGhvZCArIFwiIClcIjtcbiAgfSxcblxuICAvKipcbiAgICogQ2xvc2UgdGhlIGNvbm5lY3Rpb24gZ3JhY2VmdWxseS5cbiAgICovXG4gIGNsb3NlOiBmdW5jdGlvbiAoKSB7XG4gICAgaWYgKHRoaXMuY2xvc2VkKSByZXR1cm47XG4gICAgbG9nLmxvZyhcIkNsb3NpbmcgY29ubmVjdGlvbjpcIiwgdGhpcy5yZXByKCkpO1xuICAgIHRoaXMuY2xvc2VkID0gdHJ1ZTtcbiAgICB0aGlzLnBvcnQuZGlzY29ubmVjdCgpO1xuICAgIHRoaXMuYXBpRXZlbnQuZGVzdHJveSgpO1xuICAgIHRoaXMucG9ydCA9IG51bGw7XG4gICAgdGhpcy5jbG9zZUNiKCk7XG4gIH0sXG5cbiAgLyoqXG4gICAqIFNlbmQgYW4gZXJyb3IgbWVzc2FnZSB0byB0aGUgY2xpZW50IG92ZXIgdGhlIGNvbm5lY3Rpb24gcG9ydC5cbiAgICpcbiAgICogQHBhcmFtIHtTdHJpbmd9IG1lc3NhZ2UgVGhlIGNvbnRlbnRzIG9mIHRoZSBlcnJvci5cbiAgICovXG4gIHNlbmRFcnJvcjogZnVuY3Rpb24gKG1lc3NhZ2UpIHtcbiAgICBpZiAodGhpcy5jbG9zZWQpIHJldHVybjtcblxuICAgIHRoaXMucG9ydC5wb3N0TWVzc2FnZShuZXcgci5FcnJSZXNwb25zZShtZXNzYWdlKS5mb3JTZW5kaW5nKCkpO1xuICAgIHRoaXMuY2xvc2UoKTtcbiAgfSxcblxuICAvKipcbiAgICogQHBhcmFtIHtNZXNzYWdlfSByZXFNc2cgQSBtZXNzYWdlIHRoYXQgd2FzIHRvIGJlIGNhbGxlZCBpc1xuICAgKiBpbnN0ZWFkIGJ1ZmZlcmVkLlxuICAgKi9cbiAgcHVzaFJlcXVlc3Q6IGZ1bmN0aW9uIChyZXFNc2cpIHtcbiAgICBpZiAodGhpcy5jbG9zZWQpIHJldHVybjtcblxuICAgIGlmIChyZXFNc2cucmVzcG9uc2VUeXBlID09IFwiRXJyUmVzcG9uc2VcIikge1xuICAgICAgdGhpcy5zZW5kRXJyb3IocmVxTXNnLmVycik7XG4gICAgfVxuXG4gICAgLy8gV2UgZXhwZWN0IHRoZXkgd29udCBjb250YWluIGEgZnVuY3Rpb24uXG4gICAgaWYgKCF0aGlzLmFwaUV2ZW50LmZpcnN0UmVzcG9uc2VNc2cpe1xuICAgICAgdGhpcy5hcGlFdmVudC5maXJzdFJlc3BvbnNlTXNnID0gcmVxTXNnO1xuICAgIH1cblxuICAgIGlmICh0aGlzLmJ1ZmZlci5sZW5ndGggPT0gMCl7XG4gICAgICAvLyBUbyB0aGUgZW5kIG9mIHRoZSBxdWV1ZS5cbiAgICAgIHNldEltbWVkaWF0ZSh0aGlzLnNldER0ci5iaW5kKHRoaXMpKTtcbiAgICB9XG5cbiAgICB0aGlzLmJ1ZmZlci5wdXNoKHJlcU1zZyk7XG4gICAgdGhpcy5idWZmZXIudGltZXN0YW1wID0gRGF0ZS5ub3coKTtcbiAgfSxcblxuICAvKipcbiAgICogTm90aWZ5IHRoZSBjbGllbnQgdGhhdCB0aGVyZSBpcyBkYXRhIHRvIGJlIHJlYWQuXG4gICAqL1xuICBzZXREdHI6IGZ1bmN0aW9uICgpIHtcbiAgICAvLyBUaGlzIG1pZ2h0IGJlIGxlZiBvdmVyIG9uIHRoZSBxdWV1ZS5cbiAgICBpZiAodGhpcy5wb3J0KVxuICAgICAgdGhpcy5wb3J0LnBvc3RNZXNzYWdlKHt0aW1lc3RhbXA6IHRoaXMuYnVmZmVyLnRpbWVzdGFtcCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29ubmVjdGlvbjogdGhpcy5pZH0pO1xuICB9LFxuXG4gIC8qKlxuICAgKiBTZW5kIHRoZSBsaXN0IG9mIGFyZ3VtZW50cyBhY2N1bXVsYXRlZC5cbiAgICpcbiAgICogQHBhcmFtIHtGdW5jdGlvbn0gY2FsbGJhY2sgY2FsbGJhY2sgdG8gYWNjZXB0IHRoZSBidWZmZXIgb2ZcbiAgICogQXJndW1lbnRzIG9iamVjdHMuXG4gICAqL1xuICBmbHVzaEJ1ZmZlcjogZnVuY3Rpb24gKGNhbGxiYWNrKSB7XG4gICAgY2FsbGJhY2sodGhpcy5idWZmZXIpO1xuICAgIHRoaXMuYnVmZmVyID0gW107XG4gIH0sXG5cbiAgLyoqXG4gICAqIExldCB0aGUgY29ubmVjdGlvbiBkZWNpZGUgaWYgaXQgd2FudHMgdG8gYXBwbHkgYSBjbG9zaW5nIHJlcXVlc3RcbiAgICogb24gaXRzZWxmLlxuICAgKlxuICAgKiBAcGFyYW0ge01ldGhvZFJlcXVlc3R8TWV0aG9kUmVxdWVzdE1lc3NhZ2V9IGNsb3NpbmdSZXF1ZXN0IHRoZVxuICAgKiByZXF1ZXN0IGZyb20gdGhlIGNsaWVudCB0aGF0IG1heSBiZSBjYWxsZWQuXG4gICAqIEByZXR1cm5zIHtudWxsfEFja1Jlc3BvbnNlfEFyZ3NSZXNwb25zZX0gVHJ1ZSBpZiB3ZSBhY3R1YWxseVxuICAgKiBjYWxsZWQgdGhlIHJlcXVlc3QuIFdlIG1heSBzdGlsbCBiZSBvcGVuIGlmIHdlIG5lZWQgbW9yZSBjbG9zaW5nXG4gICAqIHJlcXVlc3RzIHRvIHRlbWluYXRlLiBJZiB0aGUgZXZlbnQgZW1pdHRlciBjYW4gY2FsbCBhIGNhbGxiYWNrXG4gICAqIHRoaXMgaXMgYW4gQXJnc1Jlc3BvbnNlLlxuICAgKi9cbiAgdHJ5Q2xvc2luZzogZnVuY3Rpb24gKGNsb3NpbmdSZXF1ZXN0KSB7XG4gICAgaWYgKHRoaXMuY2xvc2VkKSByZXR1cm4gZmFsc2U7XG4gICAgdmFyIHJldCA9IHRoaXMuYXBpRXZlbnQubWF5YmVSdW5DbG9zZXIoY2xvc2luZ1JlcXVlc3QpO1xuICAgIGlmICh0aGlzLmFwaUV2ZW50LmNsb3NlZCkge1xuICAgICAgdGhpcy5jbG9zZSgpO1xuICAgIH1cbiAgICByZXR1cm4gcmV0O1xuICB9XG59O1xuXG5tb2R1bGUuZXhwb3J0cy5Ib3N0Q29ubmVjdGlvbiA9IEhvc3RDb25uZWN0aW9uO1xuIiwiKGZ1bmN0aW9uIChnbG9iYWwpe1xudmFyIHRpbWVPZmZzZXQgPSBEYXRlLm5vdygpO1xuZ2xvYmFsLmRlYnVnQmFiZWxmaXNoID0gZmFsc2U7XG5cbmZ1bmN0aW9uIHplcm9GaWxsKCBudW1iZXIsIHdpZHRoIClcbntcbiAgd2lkdGggLT0gbnVtYmVyLnRvU3RyaW5nKCkubGVuZ3RoO1xuICBpZiAoIHdpZHRoID4gMCApXG4gIHtcbiAgICByZXR1cm4gbmV3IEFycmF5KCB3aWR0aCArICgvXFwuLy50ZXN0KCBudW1iZXIgKSA/IDIgOiAxKSApLmpvaW4oICcwJyApICsgbnVtYmVyO1xuICB9XG4gIHJldHVybiBudW1iZXIgKyBcIlwiOyAvLyBhbHdheXMgcmV0dXJuIGEgc3RyaW5nXG59XG5cbmZ1bmN0aW9uIExvZyAobmFtZSwgdmVyYm9zaXR5KSB7XG4gIHRoaXMudmVyYm9zaXR5ID0gdmVyYm9zaXR5IHx8IDE7XG4gIHRoaXMubmFtZSA9IG5hbWU7XG4gIHRoaXMucmVzZXRUaW1lT2Zmc2V0KCk7XG5cbiAgdGhpcy5zaG93VGltZXMgPSBmYWxzZTtcbiAgdGhpcy5lcnJvciA9IHRoaXMuY29uc29sZV8oJ2Vycm9yJywgMCk7XG4gIHRoaXMud2FybiA9IHRoaXMuY29uc29sZV8oJ3dhcm4nLCAxKTtcbiAgdGhpcy5pbmZvID0gdGhpcy5jb25zb2xlXygnbG9nJywgMik7XG4gIHRoaXMubG9nID0gIHRoaXMuY29uc29sZV8oJ2xvZycsIDMpO1xufVxuXG5Mb2cucHJvdG90eXBlID0ge1xuICB0aW1lc3RhbXBTdHJpbmc6IGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgbm93ID0gbmV3IERhdGUobmV3IERhdGUoKSAtIHRpbWVPZmZzZXQgK1xuICAgICAgICAgICAgICAgICAgICAgICB0aW1lT2Zmc2V0LmdldFRpbWV6b25lT2Zmc2V0KCkgKiA2MDAwMCk7XG4gICAgdmFyIHBhZCA9IGZ1bmN0aW9uIChuKSB7XG4gICAgICBpZiAobiA8IDEwKSB7IHJldHVybiBcIjBcIiArIG47IH1cbiAgICAgIHJldHVybiBuO1xuICAgIH07XG4gICAgcmV0dXJuIHBhZChub3cuZ2V0SG91cnMoKSkgKyBcIjpcIiArIHBhZChub3cuZ2V0TWludXRlcygpKVxuICAgICAgKyBcIjpcIiArIHBhZChub3cuZ2V0U2Vjb25kcygpKSArIFwiLlwiICsgemVyb0ZpbGwobm93LmdldE1pbGxpc2Vjb25kcygpLCAzKTtcbiAgfSxcblxuICByZXNldFRpbWVPZmZzZXQ6IGZ1bmN0aW9uICgpIHtcbiAgICB0aW1lT2Zmc2V0ID0gbmV3IERhdGUoKTtcbiAgfSxcblxuXG4gIGNvbnNvbGVfOiBmdW5jdGlvbiAodHlwZSwgdmVyYm9zaXR5KSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgIGlmICh0aGlzLnNob3dUaW1lcykge1xuICAgICAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgaWYgKHNlbGYudmVyYm9zaXR5ID4gdmVyYm9zaXR5IHx8IGdsb2JhbC5kZWJ1Z0JhYmVsZmlzaCkge1xuICAgICAgICAgIHJldHVybiBjb25zb2xlW3R5cGVdLmFwcGx5KGNvbnNvbGUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW3NlbGYucHJlZml4KCldLmNvbmNhdChhcmd1bWVudHMpKTtcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICB9XG4gICAgaWYgKHRoaXMudmVyYm9zaXR5ID4gdmVyYm9zaXR5IHx8IGdsb2JhbC5kZWJ1Z0JhYmVsZmlzaCkge1xuICAgICAgcmV0dXJuIGNvbnNvbGVbdHlwZV0uYmluZChjb25zb2xlLCB0aGlzLnByZWZpeCgpKTtcbiAgICB9XG4gICAgcmV0dXJuIGZ1bmN0aW9uICgpIHt9O1xuICB9LFxuXG5cbiAgcHJlZml4OiBmdW5jdGlvbiAoKSB7XG4gICAgaWYgKHRoaXMuc2hvd1RpbWVzKVxuICAgICAgcmV0dXJuIFwiW1wiICsgdGhpcy50aW1lc3RhbXBTdHJpbmcoKSArICBcIiA6IFwiICsgdGhpcy5uYW1lICsgXCJdXCI7XG5cbiAgICByZXR1cm4gXCJbXCIgK3RoaXMubmFtZSArIFwiXSBcIjtcbiAgfVxufTtcbm1vZHVsZS5leHBvcnRzLkxvZyA9IExvZztcblxufSkuY2FsbCh0aGlzLHR5cGVvZiBnbG9iYWwgIT09IFwidW5kZWZpbmVkXCIgPyBnbG9iYWwgOiB0eXBlb2Ygc2VsZiAhPT0gXCJ1bmRlZmluZWRcIiA/IHNlbGYgOiB0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiID8gd2luZG93IDoge30pIiwiKGZ1bmN0aW9uIChnbG9iYWwpe1xudmFyIER1bW15UnVudGltZSA9IHJlcXVpcmUoJy4vbWVzc2FnaW5nL2R1bW15LmpzJykuRHVtbXlSdW50aW1lLFxuICAgIENocm9tZU1lc3NhZ2luZyA9IHJlcXVpcmUoJy4vbWVzc2FnaW5nL2Nocm9tZS5qcycpLkNocm9tZU1lc3NhZ2luZztcblxuLyoqXG4gKiBUaGUgbWVzc2FnaW5nIGludGVmYWNlcyBzaG91bGQgaW1wbGVtZW50XG4gKlxuICogLSBvbkNvbm5lY3RFeHRlcm5hbFxuICogLSBvbk1lc3NhZ2VFeHRlcm5hbFxuICogLSBzZW5kTWVzc2FnZVxuICogLSBjb25uZWN0XG4gKlxuICogVGhhdCBiZWhhdmUgbGlrZSB0aGEgY2hyb21lIHJ1bnRpbWUgbWVzc2FnaW5nIGludGVyZmFjZS5cbiAqL1xudmFyIGludGVyZmFjZXMgPSB7XG4gIGNocm9tZTogQ2hyb21lTWVzc2FnaW5nLFxuICB0ZXN0OiBEdW1teVJ1bnRpbWVcbn07XG5cbmlmICghZ2xvYmFsLmNocm9tZSB8fFxuICAgICFnbG9iYWwuY2hyb21lLnJ1bnRpbWUgfHxcbiAgICAhZ2xvYmFsLmNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKSB7XG4gIGdsb2JhbC5NRVNTQUdJTkdfTUVUSE9EID0gJ3Rlc3QnO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IG5ldyAoaW50ZXJmYWNlc1tnbG9iYWwuTUVTU0FHSU5HX01FVEhPRCB8fCAnY2hyb21lJ10pKCk7XG5cbn0pLmNhbGwodGhpcyx0eXBlb2YgZ2xvYmFsICE9PSBcInVuZGVmaW5lZFwiID8gZ2xvYmFsIDogdHlwZW9mIHNlbGYgIT09IFwidW5kZWZpbmVkXCIgPyBzZWxmIDogdHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIiA/IHdpbmRvdyA6IHt9KSIsIi8qKlxuICogQGZpbGVPdmVydmlldyBUaGUgY2hyb21lIEFQSSBtZXNzYWdlIHBhc3NpbmcgbWV0aG9kLlxuICogQG5hbWUgY2hyb21lLmpzXG4gKiBAYXV0aG9yIENocmlzIFBlcml2b2xhcm9wb3Vsb3NcbiAqL1xuXG5mdW5jdGlvbiBDaHJvbWVNZXNzYWdpbmcgKCkge1xuICB0aGlzLnZlcnNpb24gPSBjaHJvbWUucnVudGltZS5nZXRNYW5pZmVzdCA/XG4gICAgY2hyb21lLnJ1bnRpbWUuZ2V0TWFuaWZlc3QoKS52ZXJzaW9uIDogXCIxXCIgO1xuICB0aGlzLm9uQ29ubmVjdEV4dGVybmFsID0gY2hyb21lLnJ1bnRpbWUub25Db25uZWN0RXh0ZXJuYWw7XG4gIHRoaXMub25NZXNzYWdlRXh0ZXJuYWwgPSBjaHJvbWUucnVudGltZS5vbk1lc3NhZ2VFeHRlcm5hbDtcbiAgdGhpcy5zZW5kTWVzc2FnZSA9IGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlLmJpbmQoY2hyb21lLnJ1bnRpbWUpO1xuICB0aGlzLmNvbm5lY3QgPSBjaHJvbWUucnVudGltZS5jb25uZWN0LmJpbmQoY2hyb21lLnJ1bnRpbWUpO1xufVxubW9kdWxlLmV4cG9ydHMuQ2hyb21lTWVzc2FnaW5nID0gQ2hyb21lTWVzc2FnaW5nO1xuIiwiKGZ1bmN0aW9uIChnbG9iYWwpe1xuLy8gWFhYOiBJZiBkaXNjb25uZWN0IGlzIHRvbyBzb29uIGFmdGVyIHRoZSBjb25uZWN0IHRoZSBhY3R1YWxcbi8vIGNvbm5lY3Rpb24gbWF5IGhhcHBlbiBiZWZvcmUgZGlzY29ubmVjdC5cblxuLyoqXG4gKiBAZmlsZU92ZXJ2aWV3IEEgbG9vcGJhY2sgbWV0aG9kIG1pcnJvcmluZyBjaHJvbWUgYXBpLlxuICogQG5hbWUgZHVtbXkuanNcbiAqIEBhdXRob3IgQ2hyaXMgUGVyaXZvbGFyb3BvdWxvc1xuICovXG5cbmdsb2JhbC5BUFBfSUQgPSBnbG9iYWwuQVBQX0lEIHx8IFwiZmFrZWhvc3RpZFwiO1xuLy8gREVCVUc6IGRlYnVnIG1lc3NhZ2VzXG4vLyBzdGFja0RlYnVnOiBub24gYXN5bmMgbWVzc2FnaW5nLlxudmFyIERFQlVHID0gZmFsc2UsIHN0YWNrRGVidWcgPSBmYWxzZTtcbnZhciBhc3NlcnQgPSByZXF1aXJlKCdhc3NlcnQnKSxcbiAgICBtYXliZUFzeW5jID0gc3RhY2tEZWJ1ZyA/IGZ1bmN0aW9uIChjYikge2NiKCk7fSA6IGZ1bmN0aW9uIChjYikge1xuICAgICAgdmFyIGVyciA9IG5ldyBFcnJvcihcIlN0YWNrIGJlZm9yZSBhc3luYyBtZXNzYWdlXCIpO1xuICAgICAgc2V0VGltZW91dChmdW5jdGlvbiAoKSB7XG4gICAgICAgIHRyeXtcbiAgICAgICAgICBjYigpO1xuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgY29uc29sZS5sb2coZS5zdGFjayk7XG4gICAgICAgICAgY29uc29sZS5sb2coZXJyLnN0YWNrKTtcbiAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0sXG4gICAgZGJnID0gZnVuY3Rpb24gKCkge307XG5pZiAoREVCVUcpIHtcbiAgZGJnID0gY29uc29sZS5sb2cuYmluZChjb25zb2xlLCAnW2R1bW15IG1lc3NhZ2VyXScpO1xufVxuXG5mdW5jdGlvbiB2YWxpZGF0ZU1lc3NhZ2UobXNnKSB7XG4gIGlmICghbXNnIHx8IEpTT04uc3RyaW5naWZ5KG1zZykgPT0gXCJ7fVwiKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiTWVzc2FnZSBzaG91bGQgYmUgc29tZXRoaW5nLiBHb3Q6XCIgKyBtc2cpO1xuICB9XG59XG5cbmZ1bmN0aW9uIEV2ZW50IChqc29uT25seSwgbmFtZSwgYnVmZmVyZWQpIHtcbiAgdGhpcy5saXN0ZW5lcnMgPSBbXTtcbiAgdGhpcy5yZW1vdmVkID0gW107XG4gIHRoaXMubmFtZSA9IG5hbWU7XG5cbiAgaWYgKGJ1ZmZlcmVkKSB7XG4gICAgdGhpcy5idWZmZXIgPSBbXTtcbiAgfVxuXG4gIGlmIChqc29uT25seSkge1xuICAgIHRoaXMud3JhcCA9IGZ1bmN0aW9uIChhcmdzKSB7XG4gICAgICByZXR1cm4gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShhcmdzKSk7XG4gICAgfTtcbiAgfSBlbHNlIHtcbiAgICB0aGlzLndyYXAgPSBmdW5jdGlvbiAoYSkge3JldHVybiBhO307XG4gIH1cbn1cblxuRXZlbnQucHJvdG90eXBlID0ge1xuICBhZGRMaXN0ZW5lcjogZnVuY3Rpb24gKGNiKSB7XG4gICAgZGJnKCdBZGRpbmcgbGlzdG5lcjogJyArIGNiLmlkICsgXCIgdG8gXCIgKyB0aGlzLm5hbWUpO1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICB0aGlzLmxpc3RlbmVycyA9IHRoaXMubGlzdGVuZXJzLmNvbmNhdChbY2JdKTtcblxuICAgICh0aGlzLmJ1ZmZlcnx8W10pLmZvckVhY2goZnVuY3Rpb24gKGFyZ3MpIHtcbiAgICAgIG1heWJlQXN5bmMoZnVuY3Rpb24gKCkge1xuICAgICAgICBzZWxmLmxpc3RlbmVycy5zb21lKGZ1bmN0aW9uIChsKSB7XG4gICAgICAgICAgcmV0dXJuICFsLmFwcGx5KG51bGwsIGFyZ3MpO1xuICAgICAgICB9KTtcbiAgICAgIH0pO1xuICAgIH0pO1xuICB9LFxuXG4gIHJlbW92ZUxpc3RlbmVyOiBmdW5jdGlvbiAoY2IpIHtcbiAgICBkYmcoJ1JlbW92aW5nIGxpc3RuZXI6ICcgKyBjYi5pZCArIFwiIGZyb20gXCIgKyB0aGlzLm5hbWUgK1xuICAgICAgICBcIiAoXCIgKyB0aGlzLmxpc3RlbmVycy5tYXAoZnVuY3Rpb24gKGwpIHtyZXR1cm4gbC5pZDt9KSArIFwiIC0gXCIgK1xuICAgICAgICB0aGlzLnJlbW92ZWQgKyBcIiApXCIpO1xuICAgIHRoaXMubGlzdGVuZXJzID0gdGhpcy5saXN0ZW5lcnMuZmlsdGVyKGZ1bmN0aW9uIChsKSB7XG4gICAgICB2YXIgc2FtZSA9IGNiID09PSBsLFxuICAgICAgICAgIHNhbWVJZHMgPSAoY2IuaWQgJiYgbC5pZCAmJiBjYi5pZCA9PSBsLmlkKTtcbiAgICAgIHJldHVybiAhKHNhbWUgfHwgc2FtZUlkcyk7XG4gICAgfSk7XG4gIH0sXG5cbiAgdHJpZ2dlcjogZnVuY3Rpb24gKHZhckFyZ3MpIHtcbiAgICB2YXIgYXJncyA9IFtdLnNsaWNlLmNhbGwoYXJndW1lbnRzKSxcbiAgICAgICAgc2VsZiA9IHRoaXMsXG4gICAgICAgIGxpc3RlbmVycyA9IHRoaXMubGlzdGVuZXJzOyAvL01ha2Ugc3VyZSBhc3luYyBkb2VzJ3QgZnVjayB3aXRoIGxpc3RlbmVyc1xuICAgIGRiZygnVHJpZ2dlcmluZ1snICsgdGhpcy5saXN0ZW5lcnMubGVuZ3RoICsgJ106ICcgKyB0aGlzLm5hbWUgKyBcInxcIiArXG4gICAgICAgICgoYXJnc1swXSBpbnN0YW5jZW9mIFBvcnQpID8gXCI8cG9ydD5cIiA6IEpTT04uc3RyaW5naWZ5KGFyZ3MpKSk7XG5cbiAgICBpZiAodGhpcy5idWZmZXIgJiYgdGhpcy5saXN0ZW5lcnMubGVuZ3RoID09IDApIHtcbiAgICAgIHRoaXMuYnVmZmVyLnB1c2goYXJncyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgbWF5YmVBc3luYyhmdW5jdGlvbiAoKSB7XG4gICAgICB2YXIgdG9rID0gTWF0aC5yYW5kb20oKTtcbiAgICAgIGxpc3RlbmVycy5zb21lKGZ1bmN0aW9uIChsLCBpKSB7XG4gICAgICAgIHJldHVybiAhbC5hcHBseShudWxsLCBhcmdzKTtcbiAgICAgIH0pO1xuICAgIH0pO1xuXG4gIH1cbn07XG5cbmZ1bmN0aW9uIFJ1bnRpbWUgKCkge1xuICBkYmcoJ0NyZWF0aW5nIHJ1bnRpbWUuLi4nKTtcbiAgdGhpcy5pZCA9IGdsb2JhbC5BUFBfSUQ7XG4gIHRoaXMub25Db25uZWN0RXh0ZXJuYWwgPSBuZXcgRXZlbnQoZmFsc2UsIFwib25Db25uZWN0RXh0ZXJuYWxcIik7XG4gIHRoaXMub25NZXNzYWdlRXh0ZXJuYWwgPSBuZXcgRXZlbnQodHJ1ZSwgXCJvbk1lc3NhZ2VFeHRlcm5hbFwiKTtcbiAgdGhpcy5wb3J0cyA9IFtdO1xuICB0aGlzLnZlcnNpb24gPSBcIjEuMFwiO1xufVxuXG5SdW50aW1lLnByb3RvdHlwZSA9IHtcbiAgc2VuZE1lc3NhZ2U6IGZ1bmN0aW9uIChob3N0SWQsIG1lc3NhZ2UsIGNiKSB7XG4gICAgdmFyIHNlbmRSZXNwID0gY2IsXG4gICAgICAgIHNlbmRlciA9IG51bGw7XG5cbiAgICB2YWxpZGF0ZU1lc3NhZ2UobWVzc2FnZSk7XG4gICAgYXNzZXJ0KG1lc3NhZ2UpO1xuICAgIGFzc2VydChob3N0SWQpO1xuICAgIGlmIChob3N0SWQgIT0gdGhpcy5pZCB8fCBnbG9iYWwuYmxvY2tNZXNzYWdpbmcpIHtcbiAgICAgIG1heWJlQXN5bmMoY2IpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHRoaXMub25NZXNzYWdlRXh0ZXJuYWwudHJpZ2dlcihtZXNzYWdlLCBzZW5kZXIsIGZ1bmN0aW9uIChtc2cpIHtcbiAgICAgIGRiZyhcIlJlc3BvbnNlOlwiLCBKU09OLnN0cmluZ2lmeShtc2cpKTtcbiAgICAgIGNiKG1zZyk7XG4gICAgfSk7XG4gIH0sXG5cbiAgY29ubmVjdDogZnVuY3Rpb24gKGhvc3RJZCwgY29ubmVjdEluZm8pIHtcbiAgICB2YXIgY2xpZW50UG9ydCA9IG5ldyBQb3J0KGNvbm5lY3RJbmZvLm5hbWUsIHRoaXMpLFxuICAgICAgICBzZWxmID0gdGhpcztcbiAgICBhc3NlcnQuZXF1YWwoaG9zdElkLCB0aGlzLmlkKTtcblxuICAgIGlmIChnbG9iYWwuYmxvY2tNZXNzYWdpbmcpIHtcbiAgICAgIHNldEltbWVkaWF0ZSggZnVuY3Rpb24gKCkge1xuICAgICAgICBjbGllbnRQb3J0Lm9uRGlzY29ubmVjdC50cmlnZ2VyKGNsaWVudFBvcnQpO1xuICAgICAgfSk7XG4gICAgICByZXR1cm4gY2xpZW50UG9ydDtcbiAgICB9XG5cbiAgICBtYXliZUFzeW5jKGZ1bmN0aW9uICgpIHtcbiAgICAgIHNlbGYub25Db25uZWN0RXh0ZXJuYWwudHJpZ2dlcihjbGllbnRQb3J0Lm90aGVyUG9ydCk7XG4gICAgfSk7XG4gICAgcmV0dXJuIGNsaWVudFBvcnQ7XG4gIH1cbn07XG5cbmZ1bmN0aW9uIFBvcnQgKG5hbWUsIHJ1bnRpbWUsIG90aGVyUG9ydCkge1xuICB0aGlzLm5hbWUgPSBuYW1lO1xuICB0aGlzLnJ1bnRpbWUgPSBydW50aW1lO1xuICBydW50aW1lLnBvcnRzID0gcnVudGltZS5wb3J0cy5jb25jYXQoW3RoaXNdKTtcbiAgdGhpcy5wcmVmaXggPSBcIlBvcnRcIiArICghb3RoZXJQb3J0ID8gXCI8Y2xpZW50PlwiIDogXCI8aG9zdD5cIik7XG4gIHRoaXMub25EaXNjb25uZWN0ID0gbmV3IEV2ZW50KGZhbHNlLCB0aGlzLnByZWZpeCArIFwiLm9uRGlzY29ubmVjdFwiKTtcbiAgdGhpcy5vbk1lc3NhZ2UgPSBuZXcgRXZlbnQodHJ1ZSwgdGhpcy5wcmVmaXggKyBcIi5vbk1lc3NhZ2VcIiwgdHJ1ZSk7XG5cbiAgdGhpcy5vdGhlclBvcnQgPSBvdGhlclBvcnQgfHwgbmV3IFBvcnQobmFtZSwgcnVudGltZSwgdGhpcyk7XG4gIHRoaXMuY29ubmVjdGVkID0gdHJ1ZTtcbn1cblxuUG9ydC5wcm90b3R5cGUgPSB7XG4gIHBvc3RNZXNzYWdlOiBmdW5jdGlvbiAobXNnKSB7XG4gICAgdmFsaWRhdGVNZXNzYWdlKG1zZyk7XG4gICAgdGhpcy5vdGhlclBvcnQub25NZXNzYWdlLnRyaWdnZXIobXNnKTtcbiAgfSxcblxuICBkaXNjb25uZWN0OiBmdW5jdGlvbiAoZm9yY2VMaXN0ZW5lcnMpIHtcbiAgICBpZiAodGhpcy5jb25uZWN0ZWQpIHtcbiAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgIHRoaXMucnVudGltZS5wb3J0cyA9IHRoaXMucnVudGltZS5wb3J0cy5maWx0ZXIoZnVuY3Rpb24gKHApIHtcbiAgICAgICAgcmV0dXJuIHAgIT09IHNlbGY7XG4gICAgICB9KTtcblxuICAgICAgdGhpcy5jb25uZWN0ZWQgPSBmYWxzZTtcbiAgICAgIHRoaXMub25NZXNzYWdlLmxpc3RlbmVycyA9IFtdO1xuICAgICAgaWYgKGZvcmNlTGlzdGVuZXJzKXtcbiAgICAgICAgdGhpcy5vbkRpc2Nvbm5lY3QudHJpZ2dlcigpO1xuICAgICAgfVxuICAgICAgdGhpcy5vbkRpc2Nvbm5lY3QubGlzdGVuZXJzID0gW107XG4gICAgICB0aGlzLm90aGVyUG9ydC5kaXNjb25uZWN0KHRydWUpO1xuICAgIH1cbiAgfVxufTtcblxuZ2xvYmFsLmNocm9tZSA9IGdsb2JhbC5jaHJvbWUgfHwge3J1bnRpbWU6IHtpZDogQVBQX0lEfX07XG5cbm1vZHVsZS5leHBvcnRzLkR1bW15UnVudGltZSA9IFJ1bnRpbWU7XG5tb2R1bGUuZXhwb3J0cy5FdmVudCA9IEV2ZW50O1xubW9kdWxlLmV4cG9ydHMuUG9ydCA9IFBvcnQ7XG5cbn0pLmNhbGwodGhpcyx0eXBlb2YgZ2xvYmFsICE9PSBcInVuZGVmaW5lZFwiID8gZ2xvYmFsIDogdHlwZW9mIHNlbGYgIT09IFwidW5kZWZpbmVkXCIgPyBzZWxmIDogdHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIiA/IHdpbmRvdyA6IHt9KSIsIm1vZHVsZS5leHBvcnRzLkJ1cnN0UmVxdWVzdCA9IHJlcXVpcmUoJy4vcmVxdWVzdHMvYnVyc3QuanMnKS5CdXJzdFJlcXVlc3Q7XG5tb2R1bGUuZXhwb3J0cy5HZW5lcmljUmVxdWVzdCA9IHJlcXVpcmUoJy4vcmVxdWVzdHMvZ2VuZXJpYy5qcycpLkdlbmVyaWNSZXF1ZXN0O1xubW9kdWxlLmV4cG9ydHMuTWV0aG9kUmVxdWVzdCA9IHJlcXVpcmUoJy4vcmVxdWVzdHMvbWV0aG9kLmpzJykuTWV0aG9kUmVxdWVzdDtcbiIsIi8qKlxuICogQGZpbGVPdmVydmlldyBBIHJlcXVlc3QgYnkgdGhlIGNsaWVudCB0byByZWNlaXZlIGEgYnVyc3Qgb2ZcbiAqIHJlcXVlc3RzIGZyb20gYW4gYXBpIGVtaXR0ZXIuIFRoaXMgaXMgaW5pdGlhbGx5IHRyaWdnZXJlZCBieSBhIGRhdGFcbiAqIHJlYWR5IHNpZ25hbCB2aWEgYSBjb25uZWN0aW9uIGZyb20gdGhlIGhvc3QuIFdoZW4gdGhlIGNsaWVudFxuICogcmVjZWl2ZXMgaXQgdGhleSBzZW5kIGEgQnVyc3RSZXF1ZXN0IHdoZW4gdGhleSBhcmUgcmVhZHkgdG8gcmVjZWl2ZVxuICogdGhlIGRhdGEuIFRoZSBtYWluIHJlYXNvbiBmb3IgdGhpcyBpcyB0aGF0IHNlbmRpbmcgbWVzc2FnZXMgaXNcbiAqIHF1aXRlIGV4cGVuc2l2ZSBhbmQgd2Ugd2FudCB0byBidW5kbGUgdGhlbSB0b2dldGhlciBhcyBtdWNoIGFzXG4gKiBwb3NzaWJsZSB3aGVuIGFuIGV2ZW50IGVtbWl0dGVyIHNwYW1zLlxuICogQG5hbWUgYnVyc3RyZXF1ZXN0LmpzXG4gKiBAYXV0aG9yIENocmlzIFBlcml2b2xhcm9wb3Vsb3NcbiAqL1xudmFyIEFyZ3VtZW50cyA9IHJlcXVpcmUoJy4vLi4vYXJndW1lbnRzLmpzJykuQXJndWVtZW50cyxcbiAgICBsb2cgPSBuZXcgKHJlcXVpcmUoJy4vLi4vbG9nLmpzJykuTG9nKSgnYnVyc3RyZXF1ZXN0JyksXG4gICAgR2VuZXJpY1JlcXVlc3QgPSByZXF1aXJlKCcuL2dlbmVyaWMuanMnKS5HZW5lcmljUmVxdWVzdCxcbiAgICBFcnJSZXNwb25zZSA9IHJlcXVpcmUoJy4vLi4vcmVzcG9uc2VzLmpzJykuRXJyUmVzcG9uc2UsXG4gICAgQnVyc3RSZXNwb25zZSA9IHJlcXVpcmUoJy4vLi4vcmVzcG9uc2VzLmpzJykuQnVyc3RSZXNwb25zZTtcblxuLyoqXG4gKiBBIHJlcXVlc3QgZm9yIGEgYnVyc3Qgb2YgY2FsbGJhY2tzIHRoYXQgYXJlIGRlc3RpbmVkIGZvciB0aGVcbiAqIGNsaWVudCBmcm9tIGEgY29ubmVjdGlvbi5cbiAqXG4gKiBAcGFyYW0ge1N0cmluZ30gaG9zdElkIFRoZSBjaHJvbWUgYXBwIGlkLlxuICogQHBhcmFtIHtDbGllbnRDb25uZWN0aW9ufSBjb25uZWN0aW9uIHRoZSBjb25uZWN0aW9uIHRoYXQgaG9sZHMgdGhlXG4gKiBjYWxsYmFjayBhcmd1bWVudHMuXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBjYWxsYmFjayBUaGUgZXZlbnQgY2FsbGJhY2sgcmF3LlxuICovXG5mdW5jdGlvbiBCdXJzdFJlcXVlc3QgKGhvc3RJZCwgY29ubmVjdGlvbiwgY2FsbGJhY2spIHtcbiAgdGhpcy5ob3N0SWQgPSBob3N0SWQ7XG4gIHRoaXMuY29ubmVjdGlvbiA9IGNvbm5lY3Rpb247XG4gIHRoaXMuY2FsbGJhY2sgPSBjYWxsYmFjaztcbiAgdGhpcy5ibG9ja2VkID0gZmFsc2U7XG59XG5cbi8qKlxuICogSGFuZGxlIGEgcmVxdWVzdCBmb3IgYSBidXJzdCBvbiB0aGUgc2VydmVyLiBJZiB0aGUgbWVzc2FnZSBkb2Vzbid0XG4gKiBzZWVtIHZhbGlkLCBkaXNyZWdhcmQgaXQuXG4gKlxuICogQHBhcmFtIHtBcGlNZXNzYWdlfSBtc2cgVGhlIG1lc3NhZ2UgYXMgdGFrZW4gZnJvbSB0aGUgc2VuZFxuICogZnVuY3Rpb24sIGllIHRoZSBmb3JTZW5kaW5nIG1ldGhvZC5cbiAqIEBwYXJhbSB7QXJyYXkoSG9zdENvbm5lY3Rpb25zKX0gY29ubmVjdGlvbnMgQW4gYXJyYXkgb2YgY29ubmVjdGlvbnNcbiAqIEBwYXJhbSB7RnVuY3Rpb24obXNnLCBzZW5kZXIsIHNlbmRSZXNwKX0gc2VuZFJlc3BSYXcgY2FsbGJhY2sgdG9cbiAqIHNlbmQgcmVzcG9uc2UuXG4gKiBAcmV0dXJuIHtCb29sZWFufSBUcnVlIGlmIHdlIGhhbmRsZWQgaXQuXG4gKi9cbkJ1cnN0UmVxdWVzdC5tYXliZUhhbmRsZSA9IGZ1bmN0aW9uIChtc2csIGNvbm5lY3Rpb25zLCBzZW5kUmVzcFJhdykge1xuICBpZiAobXNnLnJlcXVlc3RUeXBlICE9ICBcIkJ1cnN0UmVxdWVzdFwiKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9O1xuICB2YXIgdXNlZnVsQ29ucyA9IGNvbm5lY3Rpb25zLmZpbHRlcihmdW5jdGlvbiAoYykge1xuICAgIHJldHVybiBtc2cuY29ubklkID09IGMuaWQ7XG4gIH0pO1xuXG4gIGlmICh1c2VmdWxDb25zLmxlbmd0aCAhPSAxKSB7XG4gICAgdmFyIGVyck1zZyA9IFwiQnVyc3QgcmVxdWVzdCBmb3IgY29ubmVjdGlvbiBcIiArIG1zZy5jb25uSWQgKyBcIiBjb3JyZXNwb25kcyB0byBcIiArXG4gICAgICAgICAgdXNlZnVsQ29ucy5sZW5ndGggKyBcIiBjb25uZWN0aW9uc1wiLFxuICAgICAgICBlcnJSZXNwID0gbmV3IEVyclJlc3BvbnNlKGVyck1zZyk7XG4gICAgZXJyUmVzcC5zZW5kKHNlbmRSZXNwUmF3KTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuXG4gIGZ1bmN0aW9uIHNlbmRCdWZmZXIgKGJ1Zikge1xuICAgIHZhciBiciA9IG5ldyBCdXJzdFJlc3BvbnNlKGJ1ZiwgbXNnKTtcbiAgICBici5zZW5kKHNlbmRSZXNwUmF3KTtcbiAgfVxuXG4gIHVzZWZ1bENvbnNbMF0uZmx1c2hCdWZmZXIoc2VuZEJ1ZmZlcik7XG4gIHJldHVybiB0cnVlO1xufTtcblxuQnVyc3RSZXF1ZXN0LnByb3RvdHlwZSA9IE9iamVjdC5jcmVhdGUoR2VuZXJpY1JlcXVlc3QucHJvdG90eXBlKTtcblxuLyoqXG4gKiBDcmVhdGUgYSBzZXJpYWxpemFibGUgb2JqZWN0IHRvIHNlbmQgb3ZlciB0aGUgQVBJLlxuICogQHJldHVybnMge01lc3NhZ2V9IGEgc2VyaWFsaXplZCBtZXNzYWVcbiAqL1xuQnVyc3RSZXF1ZXN0LnByb3RvdHlwZS5mb3JTZW5kaW5nID0gZnVuY3Rpb24gKCkge1xuICByZXR1cm4ge3JlcXVlc3RUeXBlOiBcIkJ1cnN0UmVxdWVzdFwiLFxuICAgICAgICAgIGNvbm5JZDogdGhpcy5jb25uZWN0aW9uLmlkfTtcbn07XG5cbi8qKlxuICogR2V0IHRoZSBjYWxsYmFjayBmcm9tIHRoZSBhcmd1bWVudHMuIFdpbGwgb25seSB3b3JrIG9uIHRoZSBjbGllbnRcbiAqXG4gKiBAcmV0dXJucyB7RnVuY3Rpb259IHRoZSBjYWxsYmFjayBvciB1bmRlZmluZWQuXG4gKi9cbkJ1cnN0UmVxdWVzdC5wcm90b3R5cGUuZ2V0Q2FsbGJhY2sgPSBmdW5jdGlvbiAoKSB7XG4gIHJldHVybiB0aGlzLmNhbGxiYWNrO1xufTtcblxubW9kdWxlLmV4cG9ydHMuQnVyc3RSZXF1ZXN0ID0gQnVyc3RSZXF1ZXN0O1xuIiwidmFyIGdlbmVyaWNSZXNwSGFuZGxlciA9IHJlcXVpcmUoJy4vLi4vcmVzcG9uc2VzLmpzJykuZ2VuZXJpY1Jlc3BIYW5kbGVyLFxuICAgIG1lc3NhZ2VBcGkgPSByZXF1aXJlKFwiLi8uLi9tZXNzYWdpbmcuanNcIiksXG4gICAgbG9nID0gbmV3IChyZXF1aXJlKCcuLy4uL2xvZy5qcycpLkxvZykoJ2dlbmVyaWNyZXF1ZXN0Jyk7XG5cbi8qKlxuICogQSBnZW5lcmljIHJlcXVlc3QgdG8gaW5oZXJpdCBuZXcgb25lcyBmcm9tLiBNYWtlIHN1cmUgeW91IGRlZmluZVxuICogaG9zdElkIHByb3BlcnR5IGluIHlvdXIgY2xhc3NlcyBhbmQgYWxzbyBkZWZpbmUgYSBmb3JTZW5kaW5nLlxuICovXG5mdW5jdGlvbiBHZW5lcmljUmVxdWVzdCgpIHt9O1xuXG5HZW5lcmljUmVxdWVzdC5wcm90b3R5cGUgPSB7XG4gIC8qKlxuICAgKiBDcmVhdGUgYSBzZXJpYWxpemFibGUgb2JqZWN0IHRvIHNlbmQgb3ZlciB0aGUgQVBJLlxuICAgKiBAcmV0dXJucyB7TWVzc2FnZX0gYSBzZXJpYWxpemVkIG1lc3NhZVxuICAgKi9cbiAgZm9yU2VuZGluZzogZnVuY3Rpb24gKCkge1xuICAgIHRocm93IEVycm9yKFwiZm9yU2VuZGluZyBub3QgaW1wbGVtZW50ZWQuXCIpO1xuICB9LFxuXG4gIC8qKlxuICAgKiBTZW5kIHRoZSByZXF1ZXN0IGFuZCBoYW5kbGUgdGhlIHJlc3BvbnNlLlxuICAgKiBAcGFyYW0ge0Z1bmN0aW9ufSBjYiBDYWxsZWQgd2hlbiBoYW5kbGluZyBpcyBmaW5pc2hlZC4gTm9cbiAgICogYXJndW1lbnRzIGluIGNhc2UgaXQgc3VjY2VlZHMsIGFuIGVycm9yIG9iamVjdCBpZiBpdCBmYWlsZXNcbiAgICovXG4gIHNlbmQ6IGZ1bmN0aW9uIChjYiwgZXJyb3JDYikge1xuICAgIHZhciBzZWxmID0gdGhpcyxcbiAgICAgICAgbXNnID0gdGhpcy5mb3JTZW5kaW5nKCksXG4gICAgICAgIGhvc3RJZCA9IHRoaXMuaG9zdElkO1xuXG4gICAgbWVzc2FnZUFwaS5zZW5kTWVzc2FnZShcbiAgICAgIGhvc3RJZCwgbXNnLCBmdW5jdGlvbiAocmVzcCkge1xuICAgICAgICBnZW5lcmljUmVzcEhhbmRsZXIocmVzcCwgc2VsZixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIGNiIHx8IGZ1bmN0aW9uIChlcnIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGVycikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgfSk7XG4gIH1cbn07XG5tb2R1bGUuZXhwb3J0cy5HZW5lcmljUmVxdWVzdCA9IEdlbmVyaWNSZXF1ZXN0O1xuIiwidmFyIEFyZ3VtZW50cyA9IHJlcXVpcmUoXCIuLy4uL2FyZ3VtZW50cy5qc1wiKS5Bcmd1bWVudHMsXG4gICAgR2VuZXJpY1JlcXVlc3QgPSByZXF1aXJlKCcuL2dlbmVyaWMuanMnKS5HZW5lcmljUmVxdWVzdCxcbiAgICB1dGlsID0gcmVxdWlyZShcIi4vLi4vdXRpbFwiKSxcbiAgICBBcmdzUmVzcG9uc2UgPSByZXF1aXJlKFwiLi8uLi9yZXNwb25zZXMuanNcIikuQXJnc1Jlc3BvbnNlLFxuICAgIEVyclJlc3BvbnNlID0gcmVxdWlyZShcIi4vLi4vcmVzcG9uc2VzLmpzXCIpLkVyclJlc3BvbnNlLFxuICAgIEFja1Jlc3BvbnNlID0gcmVxdWlyZShcIi4vLi4vcmVzcG9uc2VzLmpzXCIpLkFja1Jlc3BvbnNlLFxuICAgIGxvZyA9IG5ldyAocmVxdWlyZSgnLi8uLi9sb2cuanMnKS5Mb2cpKCdtZXRob2RyZXF1ZXN0Jyk7XG5cblxuZnVuY3Rpb24gaXNOb2RlICgpIHtcbiAgaWYgKHR5cGVvZiB3aW5kb3cgPT09ICd1bmRlZmluZWQnKSByZXR1cm4gdHJ1ZTtcblxuICB2YXIgYmFja3VwID0gd2luZG93LFxuICAgICAgd2luZG93X2Nhbl9iZV9kZWxldGVkID0gZGVsZXRlIHdpbmRvdztcbiAgd2luZG93ID0gYmFja3VwOyAvLyBSZXN0b3JpbmcgZnJvbSBiYWNrdXBcblxuICByZXR1cm4gd2luZG93X2Nhbl9iZV9kZWxldGVkO1xufVxuXG4vKipcbiAqIEEgcmVxdWVzdCBmcm9tIHRoZSBjbGllbnQgdG8gcmVzb2x2ZSBhIG1ldGhvZCBjYWxsLiBBbHNvIGhhbmRsZXNcbiAqIHRoZSByZXNwb25zZS5cbiAqXG4gKiBAcGFyYW0ge1N0cmluZ30gaG9zdElkIFRoZSBhcHAgaWQuIENvdWxkIGJlIG51bGwgaWYgeW91IGRvbnQgaW50ZW5kXG4gKiB0byBzZW5kIGl0LlxuICogQHBhcmFtIHtTdHJpbmd9IG1ldGhvZCBUaGUgbWV0aG9kIHRvIGJlIGNhbGxlZC5cbiAqIEBwYXJhbSB7QXJyYXl8QXJndW1lbnRzfSBhcmdzIFRoZSByZWFsIGFyZ3VtZW50IGxpc3Qgb3IgYSB3cmFwcGVkXG4gKiBhcmd1bWVudHMgb2JqZWN0LlxuICogQHBhcmFtIHtCb29sZWFufSBpc1JldmVyc2VyIFdldGhlciB0aGlzIG1ldGhvZCByZXF1ZXN0IGlzIHN1cHBvc2VkXG4gKiB0byByZXZlcnQgdGhlIHNpZGUgZWZmZWN0cyBvZiBhIHByZXZpb3VzIHJlcXVlc3QuXG4gKiBAcGFyYW0ge0Jvb2xlYW59IG5vQ2FsbGJhY2sgdHJ1ZSBtZWFucyB0aGF0IGhvc3Qgc2hvdWxkIHJlcGx5IHdpdGhcbiAqIEFja1Jlc3BvbnNlLlxuICogQHBhcmFtIHtGdW5jdGlvbn0gd2l0aEVycm9yIFdyYXBwZXIgdG8gaGFuZGxlIGVycm9ycy5cbiAqL1xuZnVuY3Rpb24gTWV0aG9kUmVxdWVzdCAoaG9zdElkLCBtZXRob2QsIGFyZ3MsIGlzUmV2ZXJzZXIsIG5vQ2FsbGJhY2ssIHdpdGhFcnJvcikge1xuICB0aGlzLm1ldGhvZCA9IG1ldGhvZDtcbiAgdGhpcy5hcmdzID0gYXJncyBpbnN0YW5jZW9mIEFyZ3VtZW50cyA/IGFyZ3MgOlxuICAgIG5ldyBBcmd1bWVudHMoYXJncyk7XG4gIHRoaXMuaG9zdElkID0gaG9zdElkO1xuICB0aGlzLmlzUmV2ZXJzZXIgPSBpc1JldmVyc2VyIHx8IGZhbHNlO1xuICB0aGlzLm5vQ2FsbGJhY2sgPSBub0NhbGxiYWNrIHx8IGZhbHNlO1xuICB0aGlzLndpdGhFcnJvciA9IHdpdGhFcnJvcjtcbiAgLy8gTm9kZSBzZWVtcyB0byBkaXNwbGF5IGVycm9ycyBldmVuIGlmIHdlIGRvbid0IHRocm93IHRoZW0gYW5kIGl0XG4gIC8vIGdldHMgcmVhbGx5IGFubm95aW5nXG4gIGlmICghaXNOb2RlKCkpIHtcbiAgICB0aGlzLnRyYWNlID0gKG5ldyBFcnJvcigpKS5zdGFjaztcbiAgfVxuXG4gIGlmICh0aGlzLmFyZ3MuZm9yU2VuZGluZygpLmZpbHRlcihmdW5jdGlvbiAoYSkge1xuICAgIHJldHVybiAhIShhICYmIGEuaXNDYWxsYmFjayk7XG4gIH0pLmxlbmd0aCA+IDEpIHtcbiAgICB0aHJvdyBFcnJvcihcIldlIGRvIG5vdCBzdXBwb3J0IG1vcmUgdGhhbiBvbmUgY2FsbGJhY2sgaW4gYXJndW1lbnRzLlwiKTtcbiAgfVxufVxuXG5NZXRob2RSZXF1ZXN0LnByb3RvdHlwZSA9IE9iamVjdC5jcmVhdGUoR2VuZXJpY1JlcXVlc3QucHJvdG90eXBlKTtcblxuLyoqXG4gKiBDcmVhdGUgYSBtZXRob2QgcmVxdWVzdCBmcm9tIGEgbWVzc2FnZS4gV2hlbiBhIGNhbGxiYWNrIGlzIHByb3ZpZGVkXG4gKiBpdCB3aWxsIGJlIHVzZWQuXG4gKlxuICogQHBhcmFtIHtTdHJpbmd9IGhvc3RJZCBUaGUgaG9zdCB0byBzZW5kIHRoZSByZXF1c2V0LiBTZXQgdGhpcyB0b1xuICogbnVsbCBpZiBpdCdzIGp1c3QgZm9yIGNvbXBhcmluZyBvciBmb3IgaW52b2tpbmcgaXQncyBjYWxsYmFja1xuICogKGdlbmVyYWxseSBpZiB5b3UgYXJlIG9uIHRoZSBob3N0IHNpZGUuKVxuICogQHBhcmFtIHtNZXNzYWdlfSBtc2cgQSBtZXNzYWdlIGFzIGdlbmVyYXRlZCBieSBmb3JTZW5kaW5nKClcbiAqIEBwYXJhbSB7RnVuY3Rpb259IHJlc3BDYiBSYXcgc2VuZCByZXNwb25zZSBjYWxsYmFjay5cbiAqIEByZXR1cm5zIHtNZXRob2RSZXF1ZXN0fSBBIG1ldGhvZCByZXF1ZXN0LlxuICovXG5NZXRob2RSZXF1ZXN0LmZyb21NZXNzYWdlID0gZnVuY3Rpb24gKGhvc3RJZCwgbXNnLCByZXNwQ2IpIHtcbiAgdmFyIGFyZ3MgPSBuZXcgQXJndW1lbnRzKG1zZy5hcmdzLCByZXNwQ2IpO1xuICByZXR1cm4gbmV3IE1ldGhvZFJlcXVlc3QoaG9zdElkLCBtc2cubWV0aG9kLCBhcmdzKTtcbn07XG5cbi8qKlxuICogSWYgdGhlIG1lc3NhZ2UgaXMgYSByZXF1ZXN0IHRvIGNsb3NlIGEgY29ubmVjdGlvbiAocmV2ZXJzZXIpXG4gKlxuICogQHBhcmFtIHtNZXNzYWdlfSBtc2cgQSBtZXNzYWdlIGdlbmVyYXRlZCBieSBhIE1ldGhvZFJlcXVlc3QuXG4gKiBAcGFyYW0ge0FycmF5KEhvc3RDb25uZWN0aW9uKX0gY29ubmVjdGlvbnMgYSBsaXN0IG9mIG9wZW4gY29ubmVjdGlvbnMuXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBzZW5kUmVzcFJhdyBDYWxsYmFjayB0byBzZW5kIGEgcmF3IG1lc3NhZ2UuXG4gKiBAcGFyYW0ge0Jvb2xlYW59IGZvcmNlIFRoaXMgaXMgYSByZXZlcnNlciBldmVuIGlmIGlkIGRvZXNuJ3QgbG9va1xuICogbGlrZSBpdC5cbiAqIEByZXR1cm5zIHtCb29sZWFufSBUcnVlIGlmIHdlIGhhbmRsZWQgaXQuXG4gKi9cbmZ1bmN0aW9uIGhhbmRsZVJldmVyc2VyIChtc2csIGNvbm5lY3Rpb25zLCBob3N0QXBpKSB7XG4gIGlmICghY29ubmVjdGlvbnMgJiYgIW1zZy5pc1JldmVyc2VyKSByZXR1cm4gZmFsc2U7XG4gIHZhciByZXEgPSBNZXRob2RSZXF1ZXN0LmZyb21NZXNzYWdlKG51bGwsIG1zZyksXG4gICAgICByZXNwb25zZSA9IGNvbm5lY3Rpb25zXG4gICAgICAgIC5tYXAoZnVuY3Rpb24gKGMpIHtcbiAgICAgICAgICByZXR1cm4gYy50cnlDbG9zaW5nKHJlcSk7XG4gICAgICAgIH0pLnJlZHVjZShmdW5jdGlvbiAoYSwgYikge1xuICAgICAgICAgIHJldHVybiBhIHx8IGI7XG4gICAgICAgIH0sIGZhbHNlKTtcblxuICAvLyBXZSB3b24ndCBnZXQgYSByZXNwb25zZSBmb3IgYXJncyB0aGF0IGRvbid0IHJhaXNlIGEgY2FsbGJhY2suXG4gIGlmIChtc2cuaXNSZXZlcnNlciAmJiAhcmVzcG9uc2UpIHtcbiAgICBjb25zb2xlLndhcm4oXG4gICAgICBcIllvdSB0b2xkIG1lIFwiICsgSlNPTi5zdHJpbmdpZnkobXNnKSArXG4gICAgICAgIFwiIHdhcyBhIHJldmVyc2VyIGJ1dCBpIGZvdW5kIG5vdGhpbmcgdG8gcmV2ZXJzZS5cIik7XG4gICAgaWYgKG1zZy5ub0NhbGxiYWNrKSB7XG4gICAgICAvLyBUcnVzdCB0aGUgdXNlciBrbm93cyB3aGF0IHRoZXkgYXJlIGRvaW5nXG4gICAgICByZXEuY2FsbChudWxsLCBob3N0QXBpKTtcbiAgICAgIHJldHVybiBuZXcgRXJyUmVzcG9uc2UoXCJUcmllZCB0byBjbGVhbiB3aXRoIFwiICsgbXNnLm1ldGhvZCArIFwiIGJ1dCBmYWlsZWQuXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwid2FybmluZ1wiKTtcbiAgICB9XG5cbiAgICAvLyBUaGVyZSBtYXkgYmUgYSBjYWxsYmFjayB3YWl0aW5nLlxuICAgIHJldHVybiBBcmdzUmVzcG9uc2UuYXN5bmMocmVxLCBob3N0QXBpKTtcbiAgfVxuXG4gIHJldHVybiByZXNwb25zZTtcbn1cblxuLyoqXG4gKiBIYW5kbGUgdGhlIHJlcXVlc3Qgb24gdGhlIHNlcnZlci4gVHJ5IHRvIHJ1biB0aGUgbWV0aG9kIGFuZFxuICogZ2VuZXJhdGUgYSAqUmVzcG9uc2UsIHNlcmlhbGl6ZSBpdCBhbmQgc2VuZCBpdCBvdmVyIHRoZVxuICogc2VuZFJlc3BBcGkuIElmIHRoZSBtZXNzYWdlIGRvZXNuJ3Qgc2VlbSB2YWxpZCwgZGlzcmVnYXJkIGl0LlxuICpcbiAqIEBwYXJhbSB7TWVzc2FnZX0gbXNnIEEgbWVzc2FnZSBnZW5lcmF0ZWQgYnkgYSBNZXRob2RSZXF1ZXN0LlxuICogQHBhcmFtIHtBcnJheShIb3N0Q29ubmVjdGlvbil9IGNvbm5lY3Rpb25zIGEgbGlzdCBvZiBvcGVuIGNvbm5lY3Rpb25zLlxuICogQHBhcmFtIHtob3N0QXBpT2JqZWN0fSBob3N0QXBpIGNocm9tZSBBUEkgbGlrYWUgb2JqZWN0IHdoZXJlIHRoZVxuICogcmVxdXJlc3QgbWV0aG9kIGlzIGJhc2VkLlxuICogQHBhcmFtIHtGdW5jdGlvbn0gc2VuZFJlc3BSYXcgQ2FsbGJhY2sgdG8gc2VuZCBhIHJhdyBtZXNzYWdlLlxuICogQHJldHVybnMge0Jvb2xlYW59IFRydWUgaWYgd2UgaGFuZGxlZCBpdC5cbiAqL1xudmFyIG1lc3NhZ2VzUmVjZWl2ZWQgPSAwO1xuTWV0aG9kUmVxdWVzdC5tYXliZUhhbmRsZSA9IGZ1bmN0aW9uIChtc2csIGNvbm5lY3Rpb25zLCBob3N0QXBpLCBzZW5kUmVzcFJhdykge1xuICB2YXIgX3NlbmRSZXNwUmF3ID0gZnVuY3Rpb24gKHNlbmRNc2cpIHtcbiAgICBpZiAoKCsrbWVzc2FnZXNSZWNlaXZlZCkgJSAxMDAwID09IDApIHtcbiAgICAgIGxvZy5sb2coXCJTZW5kaW5nIDEwMDAgbWVzc2FnZXNcIik7XG4gICAgfVxuXG4gICAgaWYgKHNlbmRNc2cucmVzcG9uc2VUeXBlID09IFwiRXJyUmVzcG9uc2VcIikge1xuICAgICAgY29uc29sZS5lcnJvcihtc2csIFwiLT5cIiwgc2VuZE1zZyk7XG4gICAgfVxuXG4gICAgc2VuZFJlc3BSYXcoc2VuZE1zZyk7XG4gIH07XG5cbiAgaWYgKG1zZy5yZXF1ZXN0VHlwZSAhPSBcIk1ldGhvZFJlcXVlc3RcIikge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIHZhciByZXNwID0gaGFuZGxlUmV2ZXJzZXIobXNnLCBjb25uZWN0aW9ucywgaG9zdEFwaSk7XG4gIGlmIChyZXNwKSB7XG4gICAgcmVzcC5zZW5kKF9zZW5kUmVzcFJhdyk7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cblxuICBzZW5kUmVzcFJhdyA9IHNlbmRSZXNwUmF3IHx8IGZ1bmN0aW9uICgpIHt9O1xuICB2YXIgc2VuZEFyZ3NBc1Jlc3BvbnNlID0gZnVuY3Rpb24gKHZhckFyZ3MpIHtcbiAgICB2YXIgYXJnc0FyciA9IFtdLnNsaWNlLmNhbGwoYXJndW1lbnRzKSxcbiAgICAgICAgY2JBcmdzID0gbmV3IEFyZ3VtZW50cyhhcmdzQXJyKSxcbiAgICAgICAgYXJnc1Jlc3AgPSBuZXcgQXJnc1Jlc3BvbnNlKGNiQXJncyk7XG5cbiAgICAvLyBJbnRlcm5hbCBhcGkgZXJyb3JcbiAgICBpZiAoY2hyb21lICYmXG4gICAgICAgIGNocm9tZS5ydW50aW1lICYmXG4gICAgICAgIGNocm9tZS5ydW50aW1lLmxhc3RFcnJvciAmJlxuICAgICAgICBhcmdzQXJyLmxlbmd0aCA9PSAwKSB7XG4gICAgICBuZXcgRXJyUmVzcG9uc2UoY2hyb21lLnJ1bnRpbWUubGFzdEVycm9yLFxuICAgICAgICAgICAgICAgICAgICAgICdjaHJvbWUucnVudGltZS5sYXN0RXJyb3InKVxuICAgICAgICAuc2VuZChfc2VuZFJlc3BSYXcpO1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuXG4gICAgLy8gRXZlcnl0aGluZyB3ZW50IHdlbGwuXG4gICAgYXJnc1Jlc3Auc2VuZChfc2VuZFJlc3BSYXcpO1xuICB9LCBtZXRob2RBcmdzID0gbmV3IEFyZ3VtZW50cyhtc2cuYXJncywgc2VuZEFyZ3NBc1Jlc3BvbnNlKSxcbiAgICAgIG1ldGhvZENiID0gdXRpbC5wYXRoMmNhbGxhYmxlKGhvc3RBcGksIG1zZy5tZXRob2QpO1xuXG4gIC8vIEJhZCBwYXRoIHJlY2VpdmVkLlxuICBpZiAoIW1ldGhvZENiKSB7XG4gICAgcmVzcCA9IG5ldyBFcnJSZXNwb25zZShcIk1ldGhvZCBcIiArIG1zZy5tZXRob2QgKyBcIiBub3QgZm91bmQuXCIpO1xuICAgIHJlc3Auc2VuZChfc2VuZFJlc3BSYXcpO1xuICAgIHJldHVybiB0cnVlO1xuICB9XG5cbiAgdHJ5IHtcbiAgICAvLyBBbGwgd2VudCB3ZWxsXG4gICAgbWV0aG9kQ2IuYXBwbHkobnVsbCwgbWV0aG9kQXJncy5mb3JDYWxsaW5nKCkpO1xuICAgIHJldHVybiB0cnVlO1xuICB9IGNhdGNoIChlKSB7XG4gICAgcmVzcCA9IG5ldyBFcnJSZXNwb25zZSh7bWVzc2FnZTogXCJFcnJvciBvbiBjYWxsaW5nIFwiICsgbXNnLm1ldGhvZCArIFwiOlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKyBlLm1lc3NhZ2UsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhY2s6IGUuc3RhY2t9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2Nocm9tZS5ydW50aW1lLmxhc3RFcnJvcicpO1xuICAgIHJlc3Auc2VuZChfc2VuZFJlc3BSYXcpO1xuICAgIHJldHVybiB0cnVlO1xuICB9XG5cbiAgLy8gV2Uga25vdyB0aGlzIG1ldGhvZCB3b250IGJyaW5nIHVwIGEgY2FsbGJhY2suXG4gIGlmIChtc2cubm9DYWxsYmFjaykge1xuICAgIG5ldyBBY2tSZXNwb25zZSgpLnNlbmQoX3NlbmRSZXNwUmF3KTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxufTtcblxuLyoqXG4gKiBAcmV0dXJucyB7T2JqZWN0fSBTZXJpYWxpemFibGUgb2JqZWN0IHRvIGNvbW11bmljYXRlIHdpdGggdGhlIHNlcnZlci5cbiAqL1xuTWV0aG9kUmVxdWVzdC5wcm90b3R5cGUuZm9yU2VuZGluZyA9IGZ1bmN0aW9uICgpIHtcbiAgdmFyIHJldCA9IHtyZXF1ZXN0VHlwZTogXCJNZXRob2RSZXF1ZXN0XCIsXG4gICAgICAgICAgICAgbWV0aG9kOiB0aGlzLm1ldGhvZCxcbiAgICAgICAgICAgICBhcmdzOiB0aGlzLmFyZ3MuZm9yU2VuZGluZygpLFxuICAgICAgICAgICAgIG5vQ2FsbGJhY2s6IHRoaXMubm9DYWxsYmFjayxcbiAgICAgICAgICAgICBpc1JldmVyc2VyOiB0aGlzLmlzUmV2ZXJzZXJcbiAgICAgICAgICAgIH07XG4gIHJldHVybiByZXQ7XG5cbn07XG5cbi8qKlxuICogUnVuIHRoaXMgbWV0aG9kIHJlcXVlc3QuIFRoaXMgd2lsbCBub3QgaGFuZGxlIHJldmVyc2Vycy5cbiAqL1xuTWV0aG9kUmVxdWVzdC5wcm90b3R5cGUuY2FsbCA9IGZ1bmN0aW9uIChzZW5kUmVzcCwgaG9zdEFwaSkge1xuICBNZXRob2RSZXF1ZXN0Lm1heWJlSGFuZGxlKHRoaXMuZm9yU2VuZGluZygpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG51bGwsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaG9zdEFwaSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZW5kUmVzcCB8fCB0aGlzLmdldENhbGxiYWNrKCkpO1xufTtcblxuLyoqXG4gKiBHZXQgdGhlIGNhbGxiYWNrIGZyb20gdGhlIGFyZ3VtZW50cy4gT24gdGhlIHNlcnZlciB0aGlzIGlzIGFcbiAqIGZ1bmN0aW9uIGFjY2VwdGluZyBhIHJlc3BvbnNlIHR5cGUuXG4gKlxuICogQHJldHVybnMge0Z1bmN0aW9ufSB0aGUgY2FsbGJhY2sgb3IgdW5kZWZpbmVkLlxuICovXG5NZXRob2RSZXF1ZXN0LnByb3RvdHlwZS5nZXRDYWxsYmFjayA9IGZ1bmN0aW9uICgpIHtcbiAgcmV0dXJuIHRoaXMuYXJncy5nZXRDYWxsYmFjaygpO1xufTtcblxuXG4vKipcbiAqIEdldCB0aGUgY2FsbGJhY2sgZnJvbSB0aGUgYXJndW1lbnRzLiBBIHVzYWJsZSBvbmUuXG4gKlxuICogQHJldHVybnMge0Z1bmN0aW9ufSB0aGUgY2FsbGJhY2sgb3IgdW5kZWZpbmVkLlxuICovXG5NZXRob2RSZXF1ZXN0LnByb3RvdHlwZS5yZWFsQ2FsbGJhY2sgPSBmdW5jdGlvbiAoKSB7XG4gIHZhciBzZWxmID0gdGhpcywgY2FsbGJhY2sgPSBzZWxmLmFyZ3MuZ2V0Q2FsbGJhY2soKTtcbiAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgYXJncyA9IG5ldyBBcmd1bWVudHMoW10uc2xpY2UuY2FsbChhcmd1bWVudHMpKSxcbiAgICAgICAgcmVzcCA9IG5ldyBBcmdzUmVzcG9uc2UoYXJncyk7XG4gICAgY2FsbGJhY2suY2FsbChudWxsLCByZXNwLmZvclNlbmRpbmcoKSk7XG4gIH07XG59O1xuXG5cblxubW9kdWxlLmV4cG9ydHMuTWV0aG9kUmVxdWVzdCA9IE1ldGhvZFJlcXVlc3Q7XG4iLCIvKipcbiAqIEBmaWxlT3ZlcnZpZXcgUmVzcG9uc2VzIHRoYXQgY2FuIGJlIGdlbmVyYXRlZCBieSB0aGUgaG9zdC4gIEVhY2hcbiAqIHJlc3BvbnNlIGlzIGdlbmVyYXRlZCBhZC1ob2Mgc28gdGhlIHNpZ25hdHVyZSBvZiB0aGVpciBjb25zdHJ1Y3RvclxuICogaXMgYXJiaXRyYXJ5IGJ1dCBlYWNoIF90eXBlXyBoYXMgaXQncyBvd24gaGFuZGxlIG1ldGhvZCB0aGF0IGlzXG4gKiBleGVjdXRlZCBvbiB0aGUgY2xpZW50IGFuZCBhY2NlcHRzIHRoZSByZWNlaXZlZCBtZXNzYWdlLCB0aGVcbiAqIHJlcXVlc3QgZ2VuZXJhdGluZyB0aGUgcmVzcG9uc2UgYW5kIGEgY2FsbGJhY2sgd2hlbiB3ZSBhcmUgZG9uZVxuICogaGFuZGxpbmcgaXQuXG4gKiBAbmFtZSByZXNwb25zZXMuanNcbiAqIEBhdXRob3IgQ2hyaXMgUGVyaXZvbGFyb3B1bG9zXG4gKi9cblxubW9kdWxlLmV4cG9ydHMuRXJyUmVzcG9uc2UgPSByZXF1aXJlKCcuL3Jlc3BvbnNlcy9lcnJvci5qcycpO1xubW9kdWxlLmV4cG9ydHMuQnVyc3RSZXNwb25zZSA9IHJlcXVpcmUoJy4vcmVzcG9uc2VzL2J1cnN0LmpzJyk7XG5tb2R1bGUuZXhwb3J0cy5BcmdzUmVzcG9uc2UgPSByZXF1aXJlKCcuL3Jlc3BvbnNlcy9hcmd1bWVudHMuanMnKTtcbm1vZHVsZS5leHBvcnRzLkFja1Jlc3BvbnNlID0gcmVxdWlyZSgnLi9yZXNwb25zZXMvYWNrLmpzJyk7XG5tb2R1bGUuZXhwb3J0cy5nZW5lcmljUmVzcEhhbmRsZXIgPVxuICByZXF1aXJlKCcuL3Jlc3BvbnNlcy9nZW5lcmljLmpzJykuZ2VuZXJpY1Jlc3BIYW5kbGVyO1xuIiwidmFyIEdlbmVyaWNSZXNwb25zZSA9IHJlcXVpcmUoJy4vZ2VuZXJpYy5qcycpLkdlbmVyaWNSZXNwb25zZTtcbnJlcXVpcmUoJy4vLi4vc2V0aW1tZWRpYXRlLmpzJyk7XG5cbi8qKlxuICogVGhlIHJlcXVlc3Qgd2Fzbid0IHN1cHBvc2VkIHRvIHlpZWxkIGFueSByZXN1bHQgYnV0IHdhc1xuICogc3VjY2Vzc2Z1bC5cbiAqL1xuZnVuY3Rpb24gQWNrUmVzcG9uc2UgKCkge1xufTtcblxuLyoqXG4gKiBIYW5kbGUgdGhlIHJlc3BvbnNlIG9uIHRoZSBjbGllbnQgc2lkZSBpZiBpdCBpcyBvZiB0aGUgY29ycmVjdFxuICogdHlwZS5cbiAqXG4gKiBAcGFyYW0ge01lc3NhZ2V9IG1zZyB0aGUgcmF3IG1lc3NhZ2UgcmVjZWl2ZWQgYnkgdGhlIHNlcnZlclxuICogQHBhcmFtIHtSZXF1ZXN0fSByZXF1ZXN0IHRoZSByZXF1ZXN0IG9iamVjdCB0aGF0IG1zZyBpcyBhIHJlc3BvbnNlXG4gKiB0by5cbiAqIEBwYXJhbSB7RnVuY3Rpb259IGRvbmVDYiBDYWxsIHRoaXMgd2hlbiB5b3UgYXJlIGRvbmUuIEl0IHdpbGwgYmVcbiAqIGNhbGxlZCB3aXRoIG5vIGFyZ3VtZW50cyBvbiBzdWNjZXMgb3IgYW4gZXJyb3Igb2JqZWN0IG9uIGVycm9yLlxuICogQHJldHVybiB7Qm9vbGVhbn0gdHJ1ZSBpZiB3ZSBoYW5kbGVkIGl0LlxuICovXG5BY2tSZXNwb25zZS5tYXliZUhhbmRsZSA9IGZ1bmN0aW9uIChtc2csIHJlcXVlc3QsIGRvbmVDYikge1xuICBpZiAobXNnLnJlc3BvbnNlVHlwZSAhPSBcIkFja1Jlc3BvbnNlXCIpIHJldHVybiBmYWxzZTtcbiAgc2V0SW1tZWRpYXRlKGRvbmVDYik7XG4gIHJldHVybiB0cnVlO1xufTtcblxuQWNrUmVzcG9uc2UucHJvdG90eXBlID0gT2JqZWN0LmNyZWF0ZShHZW5lcmljUmVzcG9uc2UucHJvdG90eXBlKTtcblxuLyoqXG4gKiBTZXJpYWxpemVkIHJlc3BvbnNlIHRoYXQgYWxzbyBjYW4gYmUgcmVjb2duaXplZCBhcyBhIHJlc3BvbnNlLlxuICpcbiAqIEByZXR1cm5zIHtPYmplY3R9IHRoZSBvYmplY3QgdG8gYmUgcHV0IHRocm91Z2ggdGhlIEFQSS5cbiAqL1xuQWNrUmVzcG9uc2UucHJvdG90eXBlLmZvclNlbmRpbmcgPSBmdW5jdGlvbiAoKSB7XG4gIHJldHVybiB7cmVzcG9uc2VUeXBlOiBcIkFja1Jlc3BvbnNlXCJ9O1xufTtcbm1vZHVsZS5leHBvcnRzID0gQWNrUmVzcG9uc2U7XG4iLCJ2YXIgQXJndW1lbnRzID0gcmVxdWlyZShcIi4vLi4vYXJndW1lbnRzLmpzXCIpLkFyZ3VtZW50cyxcbiAgICBHZW5lcmljUmVzcG9uc2UgPSByZXF1aXJlKCcuL2dlbmVyaWMuanMnKS5HZW5lcmljUmVzcG9uc2U7XG5yZXF1aXJlKCcuLy4uL3NldGltbWVkaWF0ZS5qcycpO1xuXG4vKipcbiAqIFRoZSByZXF1ZXN0IHlpZWxkZWQgYnkgYSBzaW5nbGUgY2FsbGJhY2sgdGhhdCBpcyB0byBiZSBjYWxsZWQgYnlcbiAqIHRoZSBjbGllbnQuXG4gKlxuICogQHBhcmFtIHtBcmd1bWVudHN9IGFyZ3MgVGhlIGNhbGxiYWNrIGFyZ3VtZW50cyBvciBhIHNlcmlhbGl6ZWRcbiAqIG9iamVjdCBnZW5lcmF0ZWQgYnkgYSBzZXJ2ZXIgc2lkZSBBcmdzUmVzcG9uc2UuIFNpbmNlIHRoZXNlIGFyZVxuICogY2FsbGJhY2sgYXJndW1lbnRzIHRoZXkgc2hvdWxkIGNvbnRhaW4gbm8gY2FsbGJhY2tcbiAqIHRoZW1zZWx2ZXMuXG4gKi9cbmZ1bmN0aW9uIEFyZ3NSZXNwb25zZSAoYXJncykge1xuICB0aGlzLmNiQXJncyA9IGFyZ3M7XG59XG5cbkFyZ3NSZXNwb25zZS5hc3luYyA9IGZ1bmN0aW9uIChtciwgaG9zdEFwaSkge1xuICB2YXIgcmVzcCA9IG5ldyBBcmdzUmVzcG9uc2UoKTtcbiAgcmVzcC5tciA9IG1yO1xuICByZXNwLmhvc3RBcGkgPSBob3N0QXBpO1xuICByZXR1cm4gcmVzcDtcbn07XG5cbi8qKlxuICogSGFuZGxlIHRoZSByZXNwb25zZSBvbiB0aGUgY2xpZW50IHNpZGUgaWYgaXQgaXMgb2YgdGhlIGNvcnJlY3RcbiAqIHR5cGUuXG4gKlxuICogQHBhcmFtIHtNZXNzYWdlfSBtc2cgdGhlIHJhdyBtZXNzYWdlIHJlY2VpdmVkIGJ5IHRoZSBzZXJ2ZXJcbiAqIEBwYXJhbSB7UmVxdWVzdH0gcmVxdWVzdCB0aGUgcmVxdWVzdCBvYmplY3QgdGhhdCBtc2cgaXMgYSByZXNwb25zZVxuICogdG8uXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBkb25lQ2IgQ2FsbCB0aGlzIHdoZW4geW91IGFyZSBkb25lLiBJdCB3aWxsIGJlXG4gKiBjYWxsZWQgd2l0aCBubyBhcmd1bWVudHMgb24gc3VjY2VzIG9yIGFuIGVycm9yIG9iamVjdCBvbiBlcnJvci5cbiAqIEByZXR1cm4ge0Jvb2xlYW59IHRydWUgaWYgd2UgaGFuZGxlZCBpdC5cbiAqL1xuQXJnc1Jlc3BvbnNlLm1heWJlSGFuZGxlID0gZnVuY3Rpb24gKG1zZywgcmVxdWVzdCwgZG9uZUNiKSB7XG4gIGlmIChtc2cucmVzcG9uc2VUeXBlICE9IFwiQXJnc1Jlc3BvbnNlXCIpIHJldHVybiBmYWxzZTtcbiAgaWYgKCFyZXF1ZXN0LmdldENhbGxiYWNrKCkpIHtcbiAgICBkb25lQ2IobmV3IEVycm9yKFwiTm8gcmVhbCBjYWxsYmFjayBwcm92aWRlZCBvbiB0aGUgY2xpZW50LlwiKSk7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgdmFyIGNiQXJncyA9IG5ldyBBcmd1bWVudHMobXNnLmFyZ3MpLFxuICAgICAgY2FsbEFyZ3MgPSBjYkFyZ3MuZm9yQ2FsbGluZygpLFxuICAgICAgY2FsbGJhY2sgPSByZXF1ZXN0LmdldENhbGxiYWNrKCk7XG5cbiAgLy8gbG9nLmxvZyhcIlJlY2VpdmVkOlwiLCBjYkFyZ3MuZm9yU2VuZGluZygpLCBcImZvclwiLCB7Zm46IFN0cmluZyhjYWxsYmFjayl9KTtcbiAgY2FsbGJhY2suYXBwbHkobnVsbCwgY2FsbEFyZ3MpO1xuICBzZXRJbW1lZGlhdGUoZG9uZUNiKTtcbiAgcmV0dXJuIHRydWU7XG59O1xuXG5BcmdzUmVzcG9uc2UucHJvdG90eXBlID0gT2JqZWN0LmNyZWF0ZShHZW5lcmljUmVzcG9uc2UucHJvdG90eXBlKTtcblxuLyoqXG4gKiBUaGUgY2FsbGJhY2sgYXJndW1lbnRzIHNlcmlhbGl6ZWQuXG4gKlxuICogQHJldHVybnMge09iamVjdH0gdGhlIG9iamVjdCB0byBiZSBwdXQgdGhyb3VnaCB0aGUgQVBJLlxuICovXG5BcmdzUmVzcG9uc2UucHJvdG90eXBlLmZvclNlbmRpbmcgPSBmdW5jdGlvbiAoKSB7XG4gIHJldHVybiB7cmVzcG9uc2VUeXBlOiBcIkFyZ3NSZXNwb25zZVwiLFxuICAgICAgICAgIGFyZ3M6IHRoaXMuY2JBcmdzLmZvclNlbmRpbmcoKX07XG59O1xuXG5BcmdzUmVzcG9uc2UucHJvdG90eXBlLnNlbmQgPSBmdW5jdGlvbiAoc2VuZENiKSB7XG4gIGlmICh0aGlzLm1yKSB7XG4gICAgLy8gTk9URTogQXJnc1JlcHNvbnNlIGZvciBjb25uZWN0aW9uIGNsZWFudXBzIGFyZSBsYXp5LiBUaGVcbiAgICAvLyBjYWxsYmFjayBvZiB0aGUgYXBpIGNhbGwgZG9lcyB0aGUgYWN0dWFsIHdvcmsgb2Ygc2VuZGluZyB0aGVcbiAgICAvLyByZXNwaW5zZS5cbiAgICB0aGlzLm1yLmNhbGwoc2VuZENiLCB0aGlzLmhvc3RBcGkpO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIHNlbmRDYih0aGlzLmZvclNlbmRpbmcoKSk7XG59O1xubW9kdWxlLmV4cG9ydHMgPSBBcmdzUmVzcG9uc2U7XG4iLCJ2YXIgQXJndW1lbnRzID0gcmVxdWlyZShcIi4vLi4vYXJndW1lbnRzLmpzXCIpLkFyZ3VtZW50cyxcbiAgICBEYXRhQXJndW1lbnQgPSByZXF1aXJlKFwiLi8uLi9hcmd1bWVudHMuanNcIikuRGF0YUFyZ3VtZW50LFxuICAgIGxvZyA9IG5ldyAocmVxdWlyZSgnLi8uLi9sb2cuanMnKS5Mb2cpKCdidXJzdHJlc3BvbnNlJyksXG4gICAgR2VuZXJpY1Jlc3BvbnNlID0gcmVxdWlyZSgnLi9nZW5lcmljLmpzJykuR2VuZXJpY1Jlc3BvbnNlLFxuICAgIEFyZ3NSZXNwb25zZSA9IHJlcXVpcmUoJy4vYXJndW1lbnRzLmpzJyksXG4gICAgZ2VuZXJpY1Jlc3BIYW5kbGVyID0gcmVxdWlyZSgnLi9nZW5lcmljLmpzJykuZ2VuZXJpY1Jlc3BIYW5kbGVyO1xucmVxdWlyZSgnLi8uLi9zZXRpbW1lZGlhdGUuanMnKTtcblxuLyoqXG4gKiBTZXJ2aW5nIGEgYnVyc3QgcmVzcG9uc2UuXG4gKlxuICogQHBhcmFtIHtBcnJheShBcmd1bWVudHMpfSBjYkFyZ3NBcnIgYW4gYXJyYXkgdGhlIGFyZ3VtZW50cyBvZiBjYWxsc1xuICogdG8gYSBjYWxsYmFjay4gV2UgdHJ1c3QgdGhlc2UgY29udGFpbiBubyBjYWxsYmFja3Mgc2luY2UgdGhleSBhcmVcbiAqIHJlc3BvbnNlcyB0byB0aGUgY2xpZW50LlxuICogQHBhcmFtIHtNZXNzYWdlfSByZXFNZXNzYWdlIFRoZSBtZXNzYWdlIGdlbmVyYXRlZCBieSBCdXJzdFJlcXVlc3QuXG4gKi9cbmZ1bmN0aW9uIEJ1cnN0UmVzcG9uc2UgKGNiQXJnc0FyciwgcmVxTWVzc2FnZSkge1xuICB0aGlzLmNiQXJnc0FyciA9IGNiQXJnc0FycjtcbiAgdGhpcy5jYWxsYmFja0lkID0gcmVxTWVzc2FnZS5jYWxsYmFja0lkO1xufTtcblxuLyoqXG4gKiBIYW5kbGUgdGhlIHJlc3BvbnNlIG9uIHRoZSBjbGllbnQgc2lkZSBpZiBpdCBpcyBvZiB0aGUgY29ycmVjdFxuICogdHlwZS5cbiAqXG4gKiBAcGFyYW0ge01lc3NhZ2V9IG1zZyB0aGUgcmF3IG1lc3NhZ2UgcmVjZWl2ZWQgYnkgdGhlIHNlcnZlclxuICogQHBhcmFtIHtCdXJzdFJlcXVlc3R9IHJlcXVlc3QgdGhlIHJlcXVlc3Qgb2JqZWN0IHRoYXQgbXNnIGlzIGEgcmVzcG9uc2VcbiAqIHRvLlxuICogQHBhcmFtIHtGdW5jdGlvbn0gZG9uZUNiIENhbGwgdGhpcyB3aGVuIHlvdSBhcmUgZG9uZS4gSXQgd2lsbCBiZVxuICogY2FsbGVkIHdpdGggbm8gYXJndW1lbnRzIG9uIHN1Y2NlcyBvciBhbiBlcnJvciBvYmplY3Qgb24gZXJyb3IuXG4gKiBAcmV0dXJuIHtCb29sZWFufSB0cnVlIGlmIHdlIGhhbmRsZWQgaXQuXG4gKi9cbnZhciBzZXJ2ZWRCdXJzdE1ldHJpY3MgPSBbXTtcbkJ1cnN0UmVzcG9uc2UubWF5YmVIYW5kbGUgPSBmdW5jdGlvbiAobXNnLCByZXF1ZXN0LCBkb25lQ2IpIHtcbiAgaWYgKG1zZy5yZXNwb25zZVR5cGUgIT0gXCJCdXJzdFJlc3BvbnNlXCIpIHJldHVybiBmYWxzZTtcbiAgLy8gVGhyb3cgZWFjaCByZXNwb25zZSBpbiB0aGUgcXVldWUgd2hlbiB0aGUgcHJldmlvdXMgb25lIGlzXG4gIC8vIGZpbmlzaGVkLiBCZWZvcmUgc2VydmluZyBjaGVjayBpZiB0aGV5IGFyZSB6b21iaWZpZWQgYnkgdGhlXG4gIC8vIHJlcXVlc3QuXG4gIGZ1bmN0aW9uIGFyckluUXVldWUocmVzcG9uc2VzLCBlcnIpIHtcbiAgICBpZiAoZXJyKSB7XG4gICAgICBkb25lQ2IoZXJyKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAocmVzcG9uc2VzLmxlbmd0aCA9PSAwKSB7XG4gICAgICBkb25lQ2IoKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBzZXRJbW1lZGlhdGUoZnVuY3Rpb24gKCkge1xuICAgICAgdmFyIGNhciA9IHJlc3BvbnNlc1swXSwgY2RyID0gcmVzcG9uc2VzLnNsaWNlKDEpO1xuXG4gICAgICBpZiAoIXJlcXVlc3QuY2xvc2VkKSB7XG4gICAgICAgIGdlbmVyaWNSZXNwSGFuZGxlcihjYXIsIHJlcXVlc3QsIGFyckluUXVldWUuYmluZChudWxsLCBjZHIpKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgZG9uZUNiKCk7XG4gICAgICAvLyBBbGxvdyB0aGUgZ2VuZXJpYyBoYW5kbGVyIHRvIHRocm93IGF0IGxlYXN0IHNvbWUgc3R1ZmYgaW4gdGhlXG4gICAgICAvLyBxdWV1ZS5cbiAgICB9KTtcbiAgfVxuXG4gIC8vIEl0IGlzIGFzc3VtZWQgdGhhdCB0aGUgb3JkZXJpbmcgb2YgZGF0YSBmcm9tIGRpZmZlcmVudCBzb3VyY2VzXG4gIC8vIGFuZCB0aGUgc2l6ZSBvZiB0aGUgcGFja2V0cyBkb2VzIG5vdCBtYXR0ZXIuIENvbmNhdCB0b2dldGhlclxuICAvLyBwYWNrZXRzIHRoYXQgaGF2ZSBldmVyeXRoaW5nIGluIGNvbW1vbiBleGNlcHQgdGhlIGRhdGEgZmllbGQuXG4gIGZ1bmN0aW9uIG1heWJlQ29uY2F0RGF0YShtc2dzKSB7XG4gICAgdmFyIGRhdGFTb3VyY2VzID0ge30sXG4gICAgICAgIGNvbmNhdEFyZyA9IG1zZ3MuZm9yRWFjaChmdW5jdGlvbiAobSwgaSkge1xuICAgICAgICAgIC8vIEp1c3Qga2VlcCB0aGlzIG9uZSBhcyBpc1xuICAgICAgICAgIGlmICghKG0uYXJncyAmJiBEYXRhQXJndW1lbnQuY2FuV3JhcChtLmFyZ3NbMF0pICYmIG0uYXJncy5sZW5ndGggPT0gMSkpIHtcbiAgICAgICAgICAgIGRhdGFTb3VyY2VzW2ldID0gbTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICAvLyBNYXNrIHRoZSBkYXRhIHRvIG1ha2UgYSBzb3VyY2UtdW5pcXVlIHRva2VuLlxuICAgICAgICAgIHZhciBhcmcgPSBtLmFyZ3NbMF0sIGJhY2t1cCA9IGFyZy5kYXRhO1xuICAgICAgICAgIGFyZy5kYXRhID0gbnVsbDtcbiAgICAgICAgICB2YXIgdG9rZW4gPSBKU09OLnN0cmluZ2lmeShhcmcpO1xuICAgICAgICAgIGFyZy5kYXRhID0gYmFja3VwO1xuICAgICAgICAgIHZhciByZXQgPSBkYXRhU291cmNlc1t0b2tlbl07XG4gICAgICAgICAgaWYgKHJldCkge1xuICAgICAgICAgICAgZGF0YVNvdXJjZXNbdG9rZW5dID0gcmV0LmNvbmNhdChhcmcpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGRhdGFTb3VyY2VzW3Rva2VuXSA9IG5ldyBEYXRhQXJndW1lbnQoYXJnKTtcbiAgICAgICAgfSk7XG5cbiAgICByZXR1cm4gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXMoZGF0YVNvdXJjZXMpLm1hcChmdW5jdGlvbiAoaykge1xuICAgICAgdmFyIGNvbmNhdEFyZyA9IGRhdGFTb3VyY2VzW2tdO1xuICAgICAgaWYgKGNvbmNhdEFyZyBpbnN0YW5jZW9mIERhdGFBcmd1bWVudCkge1xuICAgICAgICByZXR1cm4gbmV3IEFyZ3NSZXNwb25zZShcbiAgICAgICAgICBuZXcgQXJndW1lbnRzKFtjb25jYXRBcmcuZm9yU2VuZGluZygpXSkpLmZvclNlbmRpbmcoKTtcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIGNvbmNhdEFyZztcbiAgICB9KTtcbiAgfVxuXG4gIC8vIFNvbWUgZGVidWdnaW5nIGluZm9ybWF0aW9uXG4gIGlmICgwKSB7XG4gICAgc2VydmVkQnVyc3RNZXRyaWNzLnB1c2goe3RpbWU6IERhdGUubm93KCksIGxlbmd0aDogbXNnLmNiQXJnc0Fyci5sZW5ndGh9KTtcbiAgICB2YXIgdG90YWxSZXF1ZXN0cyA9IHNlcnZlZEJ1cnN0TWV0cmljcy5yZWR1Y2UoZnVuY3Rpb24gKHN1bSwgbSkge1xuICAgICAgcmV0dXJuIHN1bSArIG0ubGVuZ3RoO1xuICAgIH0sIDApO1xuICAgIGxvZy5sb2coXCJCdXJzdCBzdW1tYXJ5OlwiLCB7XG4gICAgICByZXF1ZXN0UGVyU2VjOiB0b3RhbFJlcXVlc3RzICogMTAwMCAvXG4gICAgICAgIChEYXRlLm5vdygpIC0gc2VydmVkQnVyc3RNZXRyaWNzWzBdLnRpbWUpLFxuICAgICAgdG90YWxSZXF1ZXN0czogdG90YWxSZXF1ZXN0cyxcbiAgICAgIGN1cnJlbnRSZXF1ZXN0czogbXNnLmNiQXJnc0Fyci5sZW5ndGhcbiAgICB9KTtcbiAgfVxuICBhcnJJblF1ZXVlKG1heWJlQ29uY2F0RGF0YShtc2cuY2JBcmdzQXJyKSk7XG5cbiAgcmV0dXJuIHRydWU7XG59O1xuQnVyc3RSZXNwb25zZS5wcm90b3R5cGUgPSBPYmplY3QuY3JlYXRlKEdlbmVyaWNSZXNwb25zZS5wcm90b3R5cGUpO1xuXG4vKipcbiAqIFNlcmlhbGl6ZWQgcmVzcG9uc2UgdGhhdCBhbHNvIGNhbiBiZSByZWNvZ25pemVkIGFzIGEgcmVzcG9uc2UuXG4gKlxuICogQHJldHVybnMge09iamVjdH0gdGhlIG9iamVjdCB0byBiZSBwdXQgdGhyb3VnaCB0aGUgQVBJLlxuICovXG5CdXJzdFJlc3BvbnNlLnByb3RvdHlwZS5mb3JTZW5kaW5nID0gZnVuY3Rpb24gKCkge1xuICByZXR1cm4ge3Jlc3BvbnNlVHlwZTogXCJCdXJzdFJlc3BvbnNlXCIsXG4gICAgICAgICAgY2JBcmdzQXJyOiB0aGlzLmNiQXJnc0FycixcbiAgICAgICAgICBjYWxsYmFja0lkOiB0aGlzLmNhbGxiYWNrSWR9O1xufTtcbm1vZHVsZS5leHBvcnRzID0gQnVyc3RSZXNwb25zZTtcbiIsInZhciBHZW5lcmljUmVzcG9uc2UgPSByZXF1aXJlKCcuL2dlbmVyaWMuanMnKS5HZW5lcmljUmVzcG9uc2U7XG5cbi8qKlxuICogQW4gZXJyb3Igb2NjdXJlZCBzZXJ2aW5nIHRoZSByZXF1ZXN0LlxuICpcbiAqIEBwYXJhbSB7U3RyaW5nfSBlcnJvciBUaGUgZXJyb3IgbWVzc2FnZS5cbiAqIEBwYXJhbSB7Qm9vbGVhbn0gaXNVbmNhdWdodCBUcnVlIGlmIHdlIHdhbnQgdG8gcmFpc2UgYW4gdW5jYXVnaHRcbiAqIGVycm9yIHdoZW4gdGhpcyBoYXBwZW5zIGFuZCBmYWxzZSBpZiBpdCBzaG91bGQgYmUgcGFzc2VkIHRvXG4gKiBjaHJvbWUucnVudGltZS5sYXN0RXJyb3JcbiAqL1xuZnVuY3Rpb24gRXJyUmVzcG9uc2UgKGVycm9yLCB0eXBlKSB7XG4gIHRoaXMuZXJyb3IgPSBlcnJvcjtcbiAgdGhpcy50eXBlID0gdHlwZTtcbn07XG5cbi8qKlxuICogSGFuZGxlIHRoZSByZXNwb25zZSBvbiB0aGUgY2xpZW50IHNpZGUgaWYgaXQgaXMgb2YgdGhlIGNvcnJlY3RcbiAqIHR5cGUuIFRoaXMgd2lsbCBhbHNvIGhhbmRsZSBtZXNzYWdlcyB0aGF0IGFyZSB1bmRlZmluZWQgbWVzc2FnZXMuXG4gKlxuICogQHBhcmFtIHtNZXNzYWdlfHVuZGVmaW5lZH0gbXNnIHRoZSByYXcgbWVzc2FnZSByZWNlaXZlZCBieSB0aGUgc2VydmVyXG4gKiBAcGFyYW0ge1JlcXVlc3R9IHJlcXVlc3QgdGhlIHJlcXVlc3Qgb2JqZWN0IHRoYXQgbXNnIGlzIGEgcmVzcG9uc2VcbiAqIHRvLlxuICogQHBhcmFtIHtGdW5jdGlvbn0gZG9uZUNiIENhbGwgdGhpcyB3aGVuIHlvdSBhcmUgZG9uZS4gSXQgd2lsbCBiZVxuICogY2FsbGVkIHdpdGggbm8gYXJndW1lbnRzIG9uIHN1Y2NlcyBvciBhbiBlcnJvciBvYmplY3Qgb24gZXJyb3IuXG4gKiBAcmV0dXJuIHtCb29sZWFufSB0cnVlIGlmIHdlIGhhbmRsZWQgaXQuXG4gKi9cbkVyclJlc3BvbnNlLm1heWJlSGFuZGxlID0gZnVuY3Rpb24gKG1zZywgcmVxdWVzdCwgZG9uZUNiKSB7XG4gIGlmIChtc2cgJiYgbXNnLnJlc3BvbnNlVHlwZSAhPSBcIkVyclJlc3BvbnNlXCIpIHJldHVybiBmYWxzZTtcblxuICB2YXIgcmF3RXJyb3IgPSBtc2cgPyBtc2cuZXJyIDogXCJVbmRlZmluZWQgbWVzc2FnZSwgcHJvYmFibHkgaG9zdCBpcyBkaXNjb25uZWN0ZWQuXCI7XG4gIGlmIChyZXF1ZXN0LnRyYWNlKSB7XG4gICAgY29uc29sZS53YXJuKFwiUmVjZWl2ZWQgZXJyb3I6XCIsIG1zZy5lcnIpO1xuICAgIGNvbnNvbGUud2FybihyZXF1ZXN0LnRyYWNlKTtcbiAgfTtcblxuICB2YXIgd2l0aEVycm9yID0gZnVuY3Rpb24gKGVyciwgY2IpIHtcbiAgICBjYigpO1xuXG4gICAgaWYgKGVycil7XG4gICAgICBjb25zb2xlLmVycm9yKFwiVW5jYXVnaHQ6XCIsIGVycik7XG4gICAgfVxuICB9O1xuXG4gIGlmIChyZXF1ZXN0LmdldENhbGxiYWNrKCkpIHtcbiAgICAocmVxdWVzdC53aXRoRXJyb3IgfHwgd2l0aEVycm9yKShyYXdFcnJvciwgcmVxdWVzdC5nZXRDYWxsYmFjaygpKTtcbiAgICBkb25lQ2IoKTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuXG4gIGRvbmVDYihyYXdFcnJvcik7XG4gIHJldHVybiB0cnVlO1xufTtcblxuRXJyUmVzcG9uc2UucHJvdG90eXBlID0gbmV3IEdlbmVyaWNSZXNwb25zZSgpO1xuXG4vKipcbiAqIFNlcmlhbGl6ZWQgcmVzcG9uc2UgdGhhdCBhbHNvIGNhbiBiZSByZWNvZ25pemVkIGFzIGEgcmVzcG9uc2UuXG4gKlxuICogQHJldHVybnMge09iamVjdH0gdGhlIG9iamVjdCB0byBiZSBwdXQgdGhyb3VnaCB0aGUgQVBJLlxuICovXG5FcnJSZXNwb25zZS5wcm90b3R5cGUuZm9yU2VuZGluZyA9IGZ1bmN0aW9uICgpIHtcbiAgcmV0dXJuIHtyZXNwb25zZVR5cGU6IFwiRXJyUmVzcG9uc2VcIixcbiAgICAgICAgICBlcnI6IHRoaXMuZXJyb3IsXG4gICAgICAgICAgdHlwZTogdGhpcy50eXBlXG4gICAgICAgICB9O1xufTtcbm1vZHVsZS5leHBvcnRzID0gRXJyUmVzcG9uc2U7XG4iLCIvKipcbiAqIEBmaWxlT3ZlcnZpZXcgVGhlIGludGVyZmFjZSB0aGF0IGFsbCByZXNwb25zZSB0eXBlcyBuZWVkIHRvIGJlXG4gKiBpbXBsZW1lbnRpbmdcbiAqIEBuYW1lIGdlbmVyaWMuanNcbiAqIEBhdXRob3IgQ2hyaXMgUGVyaXZvbGFyb3BvdWxvc1xuICovXG5cbmZ1bmN0aW9uIEdlbmVyaWNSZXNwb25zZSAoKSB7fVxuR2VuZXJpY1Jlc3BvbnNlLnByb3RvdHlwZSA9IHtcbiAgc2VuZDogZnVuY3Rpb24gKHNlbmRDYikge1xuICAgIHJldHVybiBzZW5kQ2IodGhpcy5mb3JTZW5kaW5nKCkpO1xuICB9LFxuXG4gIGZvclNlbmRpbmc6IGZ1bmN0aW9uICgpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJOb3QgaW1wbGVtZW50ZWRcIik7XG4gIH1cbn07XG5cblxuXG4vKipcbiAqIEl0ZXJhdGUgb3ZlciB0aGUgcmVzcG9uc2UgaGFuZGxlcnMgYW5kIGNvb3NlIHRoZSBjb3JyZWN0IG9uZSB0b1xuICogaGFuZGxlIGFuIGluY29taW5nIG1lc3NhZ2Ugb24gdGhlIGNsaWVudHMuXG4gKlxuICogQHBhcmFtIHtNZXNzYWdlfSBtc2cgdGhlIHJhdyBtZXNzYWdlIHJlY2VpdmVkIGJ5IHRoZSBzZXJ2ZXJcbiAqIEBwYXJhbSB7UmVxdWVzdH0gcmVxdWVzdCB0aGUgcmVxdWVzdCBvYmplY3QgdGhhdCBtc2cgaXMgYSByZXNwb25zZVxuICogdG8uXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBkb25lIENhbGwgdGhpcyB3aGVuIHlvdSBhcmUgZG9uZS4gSXQgd2lsbCBiZVxuICogY2FsbGVkIHdpdGggbm8gYXJndW1lbnRzIG9uIHN1Y2NlcyBvciBhbiBlcnJvciBvYmplY3Qgb24gZXJyb3IuXG4gKi9cblxuZnVuY3Rpb24gZ2VuZXJpY1Jlc3BIYW5kbGVyIChtc2csIHJlcXVlc3QsIGRvbmUpIHtcbiAgLy8gQmUgc3VyZSB0byB0aHJvdyBkb25lIGluIHRoZSBxdWV1ZS5cbiAgZnVuY3Rpb24gZG9uZUNiIChlcnIpIHtcbiAgICBkb25lKGVycik7XG4gIH1cblxuICB2YXIgcmVzcG9uc2VUeXBlc0FyciA9IFtcbiAgICByZXF1aXJlKCcuL2Vycm9yLmpzJyksICAgICAgICAgICAgICAgICAgLy9DYXRjaCB0aGUgZXJyb3JzIGZpcnN0XG4gICAgcmVxdWlyZSgnLi9idXJzdC5qcycpLFxuICAgIHJlcXVpcmUoJy4vYXJndW1lbnRzLmpzJyksXG4gICAgcmVxdWlyZSgnLi9hY2suanMnKSxcbiAgXTtcblxuICBpZiAoIXJlc3BvbnNlVHlwZXNBcnIuc29tZShmdW5jdGlvbiAoUlQpIHtcbiAgICByZXR1cm4gUlQubWF5YmVIYW5kbGUobXNnLCByZXF1ZXN0LCBkb25lQ2IpO1xuICB9KSkge1xuICAgIGRvbmUobmV3IEVycm9yKFwiQ291bGRuJ3QgaGFuZGxlIG1lc3NhZ2U6IFwiICsgSlNPTi5zdHJpbmdpZnkobXNnKSkpO1xuICB9XG59XG5tb2R1bGUuZXhwb3J0cy5HZW5lcmljUmVzcG9uc2UgPSBHZW5lcmljUmVzcG9uc2U7XG5tb2R1bGUuZXhwb3J0cy5nZW5lcmljUmVzcEhhbmRsZXIgPSBnZW5lcmljUmVzcEhhbmRsZXI7XG4iLCIvKipcbiAqIEBmaWxlT3ZlcnZpZXcgSW5pdGlhbGl6ZSBhbmQgaGFuZGxlIHJlcXVlc3RzIGFuZCBjb25uZWN0aW9ucy5cbiAqIEBuYW1lIHNlcnZlci5qc1xuICogQGF1dGhvciBDaHJpcyBQZXJpdm9sYXJvcG91bG9zXG4gKi9cbnZhciBIb3N0Q29ubmVjdGlvbiA9IHJlcXVpcmUoXCIuL2hvc3Rjb25uZWN0aW9uLmpzXCIpLkhvc3RDb25uZWN0aW9uLFxuICAgIE1ldGhvZFJlcXVlc3QgPSByZXF1aXJlKFwiLi9yZXF1ZXN0cy5qc1wiKS5NZXRob2RSZXF1ZXN0LFxuICAgIEJ1cnN0UmVxdWVzdCA9IHJlcXVpcmUoXCIuL3JlcXVlc3RzLmpzXCIpLkJ1cnN0UmVxdWVzdCxcbiAgICBFcnJSZXNwb25zZSA9IHJlcXVpcmUoXCIuL3Jlc3BvbnNlcy5qc1wiKS5FcnJSZXNwb25zZSxcbiAgICBBY2tSZXNwb25zZSA9IHJlcXVpcmUoXCIuL3Jlc3BvbnNlcy5qc1wiKS5BY2tSZXNwb25zZSxcbiAgICBsb2cgPSBuZXcgKHJlcXVpcmUoJy4vbG9nLmpzJykuTG9nKSgnc2VydmVyJyksXG4gICAgbWVzc2FnZUFwaSA9IHJlcXVpcmUoJy4vbWVzc2FnaW5nLmpzJyksXG4gICAgQm9vdHN0cmFwSG9zdCA9IHJlcXVpcmUoJy4vYm9vdHN0cmFwaG9zdC5qcycpLkJvb3RzdHJhcEhvc3Q7XG5yZXF1aXJlKCcuL3NldGltbWVkaWF0ZS5qcycpO1xuXG52YXIgc3RhdGUgPSB7Y29ubmVjdGlvbnM6IFtdLFxuICAgICAgICAgICAgIGtlZXBhbGl2ZXM6IFtdLFxuICAgICAgICAgICAgIHVuaXF1ZUlkOiAwLFxuICAgICAgICAgICAgIHZlcnNpb246IG1lc3NhZ2VBcGkudmVyc2lvbn07XG5cbi8qKlxuICogQSBwb3J0IHRvIGtlZXAgdHJhY2sgb2YgYSBjbGllbnQuIEl0IGFsc28gc2V0cyB0aGUgaWQgb2YgdGhlIGNsaWVudDtcbiAqIEBwYXJhbSB7UG9ydH0gcG9ydFxuICogQHBhcmFtIHtGdW5jdGlvbn0gZGllQ2IgQ2FsbGVkIHdoZW4gdGhlIGNsaWVudCBkaWVzLlxuICovXG5mdW5jdGlvbiBIb3N0S2VlcEFsaXZlQ29ubmVjdGlvbiAocG9ydCwgY2xvc2VDYikge1xuICBsb2cubG9nKFwiQ3JlYXRpbmcgaG9zdCBrZWVwYWxpdmVcIik7XG4gIHZhciBzZWxmID0gdGhpcztcbiAgdGhpcy5wb3J0ID0gcG9ydDtcbiAgcG9ydC5vbkRpc2Nvbm5lY3QuYWRkTGlzdGVuZXIodGhpcy5jbG9zZS5iaW5kKHRoaXMpKTtcbiAgdGhpcy5jbG9zZUNiID0gY2xvc2VDYi5iaW5kKG51bGwsIHRoaXMpO1xuICB0aGlzLmNsaWVudElkID0gc3RhdGUudW5pcXVlSWQrKztcbiAgdGhpcy5wb3J0Q29uZiA9IEpTT04ucGFyc2UocG9ydC5uYW1lKTtcblxuICAvLyBTZXQgdGhlIGNsaWVudElkXG4gIHBvcnQub25EaXNjb25uZWN0LmFkZExpc3RlbmVyKGZ1bmN0aW9uICgpIHtcbiAgICBsb2cubG9nKFwiQ2xpZW50IGRpc2Nvbm5lY3RlZDpcIiArIHNlbGYuY2xpZW50SWQpO1xuICB9KTtcbiAgcG9ydC5wb3N0TWVzc2FnZSh7XG4gICAgY2xpZW50SWQ6IHNlbGYuY2xpZW50SWQsXG4gICAgdmVyc2lvbjogc3RhdGUudmVyc2lvbn0pO1xuICBsb2cubG9nKFwiQ2xpZW50IGNvbm5lY3RlZDpcIiArIHNlbGYuY2xpZW50SWQpO1xuICB0aGlzLmNsb3NlZCA9IGZhbHNlO1xufVxuXG5Ib3N0S2VlcEFsaXZlQ29ubmVjdGlvbi5pcyA9IGZ1bmN0aW9uIChwb3J0KSB7XG4gIHJldHVybiBKU09OLnBhcnNlKHBvcnQubmFtZSkudHlwZSA9PSBcIktlZXBBbGl2ZUNvbm5lY3Rpb25cIjtcbn07XG5cbkhvc3RLZWVwQWxpdmVDb25uZWN0aW9uLnByb3RvdHlwZSA9IHtcbiAgbWF5YmVDbG9zZTogZnVuY3Rpb24gKGMpIHtcblxuICAgIGlmIChjLmNsaWVudElkID09IHRoaXMuY2xpZW50SWQpIHtcbiAgICAgIGMuY2xvc2UoKTtcbiAgICB9XG4gIH0sXG5cbiAgY2xvc2U6IGZ1bmN0aW9uICgpIHtcbiAgICBpZiAodGhpcy5jbG9zZWQpIHJldHVybjtcbiAgICAvLyBDbGVhbmluZyB1cCBtYXkgcmVxdWlyZSB0aGUgcG9ydC5cbiAgICB0aGlzLmNsb3NlZCA9IHRydWU7XG4gICAgdGhpcy5jbG9zZUNiKCk7XG4gICAgdGhpcy5wb3J0LmRpc2Nvbm5lY3QoKTtcbiAgICB0aGlzLnBvcnQgPSBudWxsO1xuICB9XG59O1xuXG4vKipcbiAqIEdldCBhIGtlZXAgYWxpdmUgY29ubmVjdGlvbiB0b2tlbiBmb3IgdGhlIGNsaWVudC4gVGhlIG9iamVjdCBpc1xuICoge3BvcnQsIGNsaWVudElkfS5cbiAqXG4gKiBAcGFyYW0ge1N0cmluZ30gaG9zdElkIFRoZSBpZGUgb2YgdGhlIGhvc3QgdG8gY29ubmVjdCB0by5cbiAqIEBwYXJhbSB7RnVuY3Rpb259IGNvbm5lY3RDYiBUaGUgY2FsbGJhY2sgdG8gYmUgY2FsbGVkIHdoZW4gdGhlXG4gKiBjb25uZWN0aW9uIGlzIHN1Y2Nlc3NmdWwuXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBkaWNvbm5lY3RDYiBXaWxsIGJlIGNhbGxlZCB3aGVuIHRoZSBob3N0XG4gKiBkaXNjb25lbmN0cy4gV2lsbCBiZSBjYWxsZWQgaW1tZWRpYXRlbHkgaWYgdGhlIGNvbm5lY3Rpb24gZmFpbHMuXG4gKi9cbmZ1bmN0aW9uIGdldEtlZXBBbGl2ZUNvbm5lY3Rpb24gKGhvc3RJZCwgY29ubmVjdENiLCBkaXNjb25uZWN0Q2IsIHRpbWVvdXQpIHtcbiAgbWVzc2FnZUFwaSA9IHJlcXVpcmUoXCIuL21lc3NhZ2luZy5qc1wiKTtcblxuICB2YXIgcG9ydE5hbWUgPSBKU09OLnN0cmluZ2lmeSh7dHlwZTpcIktlZXBBbGl2ZUNvbm5lY3Rpb25cIn0pLFxuICAgICAgcG9ydCA9IG1lc3NhZ2VBcGkuY29ubmVjdChob3N0SWQsIHtuYW1lOiBwb3J0TmFtZX0pO1xuICBpZiAoZGlzY29ubmVjdENiKSB7XG4gICAgbG9nLmxvZyhcIkRldGVjdGVkIGRpc2Nvbm5lY3QgY2Igb24gY2xpZW50IGtlZXBhbGl2ZVwiKTtcbiAgICBwb3J0Lm9uRGlzY29ubmVjdC5hZGRMaXN0ZW5lcihmdW5jdGlvbiAoKSB7ZGlzY29ubmVjdENiKCk7fSk7XG4gIH1cblxuICB2YXIgZ290VG9rZW4gPSBmYWxzZTtcbiAgcG9ydC5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIoZnVuY3Rpb24gdG9rZW5pemVyIChtc2cpIHtcbiAgICBwb3J0Lm9uTWVzc2FnZS5yZW1vdmVMaXN0ZW5lcih0b2tlbml6ZXIpO1xuICAgIGdvdFRva2VuID0gdHJ1ZTtcblxuICAgIGlmICghbXNnKSB7XG4gICAgICBsb2cud2FybihcIkVtcHR5IG1lc3NhZ2UgY2FtZSBvbiBrZWVwYWxpdmUgcG9ydC5cIik7XG4gICAgICBkaXNjb25uZWN0Q2IoXCJub19ob3N0XCIpO1xuICAgICAgcG9ydC5kaXNjb25uZWN0KCk7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG5cbiAgICAvLyBPbmx5IG1hdGNoaW5nIG1ham9yIHZlcnNpb24gbnVtYmVycyBjYW4gY29tbXVuaWNhdGUuXG4gICAgaWYgKG1zZyAmJiBtc2cudmVyc2lvbiAmJlxuICAgICAgICBtc2cudmVyc2lvbi5zcGxpdCgnLicpWzBdICE9IG1lc3NhZ2VBcGkudmVyc2lvbi5zcGxpdCgnLicpWzBdKSB7XG4gICAgICBsb2cud2FybihcIlJlY2VpdmVkIGJhZCBhcHAgdmVyc2lvbjpcIiwgbXNnLnZlcnNpb24pO1xuICAgICAgZGlzY29ubmVjdENiKFwiYmFkX3ZlcnNpb25cIik7XG4gICAgICBwb3J0LmRpc2Nvbm5lY3QoKTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cblxuXG4gICAgaWYgKHR5cGVvZiBtc2cuY2xpZW50SWQgIT09ICdudW1iZXInKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgdmFyIHRva2VuID0ge1xuICAgICAgcG9ydDogcG9ydCxcbiAgICAgIHZlcnNpb246IG1zZy52ZXJzaW9uLFxuICAgICAgY2xpZW50SWQ6IG1zZy5jbGllbnRJZCxcbiAgICAgIGRpc2Nvbm5lY3RDYjogZGlzY29ubmVjdENiXG4gICAgfTtcbiAgICBzZXRJbW1lZGlhdGUoY29ubmVjdENiLmJpbmQobnVsbCwgdG9rZW4pKTtcbiAgfSk7XG5cbiAgaWYgKHR5cGVvZiB0aW1lb3V0ICE9PSAndW5kZWZpbmVkJykge1xuICAgIHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7XG4gICAgICBpZiAoZ290VG9rZW4pIHJldHVybjtcbiAgICAgIGxvZy53YXJuKFwiSG9zdCBrZWVwYWxpdmUgY29ubmVjdGlvbiB3YXMgc2lsZW50IGZvciB0b28gbG9uZy5cIik7XG4gICAgICBkaXNjb25uZWN0Q2IoXCJ0aW1lb3V0XCIpO1xuICAgICAgcG9ydC5kaXNjb25uZWN0KCk7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9LCB0aW1lb3V0KTtcbiAgfVxufVxuXG5cbi8qKlxuICogSGFuZGxlIChvciBkZWxlZ2F0ZSkgY29ubmVjdGlvbnMgYW5kIG1lc3NhZ2VzIGZyb20gYW55IGNsaWVudC4gQWxzb1xuICoga2VlcCB0cmFjayBvZiBvcGVuIGNvbm5lY3Rpb25zIGFuZCBjbGVhbiB0aGVtIHVwIGlmIHRoZSB1c2VyIGFza3NcbiAqIGZvciBpdC5cbiAqXG4gKiBAcGFyYW0ge09iamVjdH0gYXBpUm9vdCB0aGUgcm9vdCBvZiB0aGUgYXBpIHRvIHNlcnZlLlxuICovXG5mdW5jdGlvbiBIb3N0U2VydmVyIChhcGlSb290KSB7XG4gIGlmIChzdGF0ZS5hcGlSb290ID09PSBhcGlSb290KSB7XG4gICAgdGhyb3cgRXJyb3IoXCJZb3UgYXJlIHRyeWluZyB0byBob3N0IGEgc2Vjb25kIHNlcnZlciBvbiB0aGUgc2FtZSBhcGkuXCIpO1xuICB9XG5cbiAgdmFyIGFkaG9jID0gcmVxdWlyZShcIi4vYWRob2MvaG9zdC5qc1wiKTtcbiAgYXBpUm9vdC5tZXNzYWdlQXBpID0gbWVzc2FnZUFwaTtcbiAgYXBpUm9vdC5zZXJ2ZXJJZCA9IE1hdGgucmFuZG9tKCk7XG4gIHN0YXRlLmFwaVJvb3QgPSBhcGlSb290O1xuICBzdGF0ZS5ib290c3RyYXBIb3N0ID0gbmV3IEJvb3RzdHJhcEhvc3QoKTtcbiAgYWRob2Muc2V0dXBBZEhvYyhzdGF0ZSk7XG5cbiAgZnVuY3Rpb24gY2xvc2VDYiAoY29ubmVjdGlvbikge1xuICAgIHZhciBsZW4gPSBzdGF0ZS5jb25uZWN0aW9ucy5sZW5ndGg7XG4gICAgc3RhdGUuY29ubmVjdGlvbnMgPSBzdGF0ZS5jb25uZWN0aW9ucy5maWx0ZXIoZnVuY3Rpb24gKGMpIHtcbiAgICAgIHJldHVybiBjICE9PSBjb25uZWN0aW9uO1xuICAgIH0pO1xuICAgIGxvZy5sb2coXCJDbGVhbmluZWQ6XCIsIGNvbm5lY3Rpb24ucmVwcigpLCAnKGJlZm9yZTogJywgbGVuLCdhZnRlcjogJyxcbiAgICAgICAgICAgIHN0YXRlLmNvbm5lY3Rpb25zLmxlbmd0aCwgJyknKTtcbiAgfTtcblxuICBmdW5jdGlvbiB0YWJEaWVkQ2IgKGtlZXBhbGl2ZSkge1xuICAgIC8vIEtlZXAgb25seSBvbmUgcmVmZXJlbmNlIHRvIGVhY2ggY29ubmVjdGlvbiwgaWUgZG9uJ3QgcmVnaXN0ZXJcbiAgICAvLyB0aGVtIHRvIGtlZXBhbGl2ZXMgb3Igd2hhdGV2ZXIuXG4gICAgc3RhdGUuY29ubmVjdGlvbnMuZm9yRWFjaChmdW5jdGlvbiAoYykge1xuICAgICAga2VlcGFsaXZlLm1heWJlQ2xvc2UoYyk7XG4gICAgfSk7XG4gICAgc3RhdGUua2VlcGFsaXZlcyA9IHN0YXRlLmtlZXBhbGl2ZXMuZmlsdGVyKGZ1bmN0aW9uIChrYSkge1xuICAgICAgcmV0dXJuICFrYS5jbG9zZWQ7XG4gICAgfSk7XG4gIH1cblxuICBmdW5jdGlvbiBtZXNzYWdlSGFuZGxlIChtZXNzYWdlLCBzZW5kZXIsIHNlbmRSZXNwKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIE1ldGhvZFJlcXVlc3QubWF5YmVIYW5kbGUobWVzc2FnZSwgc3RhdGUuY29ubmVjdGlvbnMsIGFwaVJvb3QsIHNlbmRSZXNwKSB8fFxuICAgICAgICBCdXJzdFJlcXVlc3QubWF5YmVIYW5kbGUobWVzc2FnZSwgc3RhdGUuY29ubmVjdGlvbnMsIHNlbmRSZXNwKSB8fFxuICAgICAgICAobmV3IEVyclJlc3BvbnNlKFwiTm90aGluZyB0byBkbyBmb3IgbWVzc2FnZS5cIiArXG4gICAgICAgICAgICAgICAgICAgICAgICAgSlNPTi5zdHJpbmdpZnkobWVzc2FnZSksIGZhbHNlKVxuICAgICAgICAgLnNlbmQoc2VuZFJlc3ApKSk7XG4gIH1cblxuICBmdW5jdGlvbiBjb25uZWN0SGFuZGxlIChwb3J0KSB7XG4gICAgaWYgKEhvc3RLZWVwQWxpdmVDb25uZWN0aW9uLmlzKHBvcnQpKSB7XG4gICAgICB2YXIga2VlcGFsaXZlID0gbmV3IEhvc3RLZWVwQWxpdmVDb25uZWN0aW9uKHBvcnQsIHRhYkRpZWRDYik7XG4gICAgICBzdGF0ZS5rZWVwYWxpdmVzLnB1c2goa2VlcGFsaXZlKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICB2YXIgY29ubiA9IG5ldyBIb3N0Q29ubmVjdGlvbihwb3J0LCBhcGlSb290LCBmdW5jdGlvbiAoKSB7XG4gICAgICBjbG9zZUNiKGNvbm4pO1xuICAgIH0pO1xuICAgIHN0YXRlLmNvbm5lY3Rpb25zLnB1c2goY29ubik7XG4gIH1cblxuICBtZXNzYWdlQXBpLm9uQ29ubmVjdEV4dGVybmFsLmFkZExpc3RlbmVyKGNvbm5lY3RIYW5kbGUpO1xuICBsb2cubG9nKFwiTGlzdGVuaW5nIG9uIGNvbm5lY3Rpb25zLi4uXCIpO1xuICBtZXNzYWdlQXBpLm9uTWVzc2FnZUV4dGVybmFsLmFkZExpc3RlbmVyKG1lc3NhZ2VIYW5kbGUpO1xuICBsb2cubG9nKFwiTGlzdGVuaW5nIG9uIG1lc3NhZ2VzLi4uXCIpO1xuXG4gIGZ1bmN0aW9uIGNsZWFuVXAgKCkge1xuICAgIGxvZy5sb2coXCJDbGVhbmluZyBjb25uZWN0XCIpO1xuICAgIG1lc3NhZ2VBcGkub25Db25uZWN0RXh0ZXJuYWwucmVtb3ZlTGlzdGVuZXIoY29ubmVjdEhhbmRsZSk7XG4gICAgbG9nLmxvZyhcIkNsZWFuaW5nIG1lc3NhZ2VcIik7XG4gICAgbWVzc2FnZUFwaS5vbk1lc3NhZ2VFeHRlcm5hbC5yZW1vdmVMaXN0ZW5lcihtZXNzYWdlSGFuZGxlKTtcblxuICAgIHN0YXRlLmNvbm5lY3Rpb25zLmZvckVhY2goZnVuY3Rpb24oYykge1xuICAgICAgYy5jbG9zZSgpO1xuICAgIH0pO1xuXG4gICAgc3RhdGUua2VlcGFsaXZlcy5mb3JFYWNoKGZ1bmN0aW9uKGspIHtcbiAgICAgIGsuY2xvc2UoKTtcbiAgICB9KTtcblxuICAgIHN0YXRlLmJvb3RzdHJhcEhvc3QuY2xlYW51cCgpO1xuICAgIHN0YXRlLmFwaVJvb3QgPSBudWxsO1xuICB9XG5cbiAgcmV0dXJuIGNsZWFuVXA7XG59XG5cbm1vZHVsZS5leHBvcnRzLnN0YXRlID0gc3RhdGU7XG5tb2R1bGUuZXhwb3J0cy5Ib3N0U2VydmVyID0gSG9zdFNlcnZlcjtcbm1vZHVsZS5leHBvcnRzLmdldEtlZXBBbGl2ZUNvbm5lY3Rpb24gPSBnZXRLZWVwQWxpdmVDb25uZWN0aW9uO1xubW9kdWxlLmV4cG9ydHMubWVzc2FnZUFwaSA9IG1lc3NhZ2VBcGk7XG4iLCIoZnVuY3Rpb24gKGdsb2JhbCl7XG4vLyBzZXRUaW1lb3V0IGlzIGNsYW1wZWQgdG8gMTAwMG1zIG1pbiB0aW1lIGZvciBiYWNrZ3JvdW5kIHRhYnMuXG5cbi8vIENoZWNrIHdldGhlciB3ZSBhcmUgaW4gdGhlIGFwcCBjb250ZXh0LlxuZnVuY3Rpb24gaXNBcHAgKCkge1xuICAvLyBnZXRNYW5pZmVzdCByZXN0dXJucyBhIHZhbHVlIGFuZCB0aHVzIGlzIG5vdCBhdmFpbGFibGUgdG8gdGhlXG4gIC8vIGNsaWVudFxuICByZXR1cm4gISFjaHJvbWUucnVudGltZS5nZXRNYW5pZmVzdDtcbn07XG5cbi8vIE5vdCBpbiBhIGJyb3dzZXIgbWFrZXMgaXQgb2sgdG8gdXNlIHNldFRpbWVvdXRcbmlmICghKGdsb2JhbC5wb3N0TWVzc2FnZSAmJiBnbG9iYWwuYWRkRXZlbnRMaXN0ZW5lcikgfHwgaXNBcHAoKSkge1xuICBnbG9iYWwuc2V0SW1tZWRpYXRlID0gZ2xvYmFsLnNldFRpbWVvdXQuYmluZChnbG9iYWwpO1xuICBnbG9iYWwuY2xlYXJUaW1lb3V0ID0gZ2xvYmFsLmNsZWFyVGltZW91dC5iaW5kKGdsb2JhbCk7XG59IGVsc2Uge1xuICAoZnVuY3Rpb24gKCkge1xuICAgIFwidXNlIHN0cmljdFwiO1xuICAgIHZhciBpID0gMDtcbiAgICB2YXIgdGltZW91dHMgPSB7fTtcbiAgICB2YXIgbWVzc2FnZU5hbWUgPSBcInNldEltbWVkaWF0ZVwiICsgbmV3IERhdGUoKS5nZXRUaW1lKCk7XG5cbiAgICBmdW5jdGlvbiBwb3N0KGZuKSB7XG4gICAgICBpZiAoaSA9PT0gMHgxMDAwMDAwMDApIC8vIG1heCBxdWV1ZSBzaXplXG4gICAgICAgIGkgPSAwO1xuICAgICAgaWYgKCsraSBpbiB0aW1lb3V0cylcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwic2V0SW1tZWRpYXRlIHF1ZXVlIG92ZXJmbG93LlwiKTtcbiAgICAgIHRpbWVvdXRzW2ldID0gZm47XG4gICAgICBnbG9iYWwucG9zdE1lc3NhZ2UoeyB0eXBlOiBtZXNzYWdlTmFtZSwgaWQ6IGkgfSwgXCIqXCIpO1xuICAgICAgcmV0dXJuIGk7XG4gICAgfVxuXG4gICAgZnVuY3Rpb24gcmVjZWl2ZShldikge1xuICAgICAgaWYgKGV2LnNvdXJjZSAhPT0gd2luZG93KVxuICAgICAgICByZXR1cm47XG4gICAgICB2YXIgZGF0YSA9IGV2LmRhdGE7XG4gICAgICBpZiAoZGF0YSAmJiBkYXRhIGluc3RhbmNlb2YgT2JqZWN0ICYmIGRhdGEudHlwZSA9PT0gbWVzc2FnZU5hbWUpIHtcbiAgICAgICAgZXYuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICAgIHZhciBpZCA9IGV2LmRhdGEuaWQ7XG4gICAgICAgIHZhciBmbiA9IHRpbWVvdXRzW2lkXTtcbiAgICAgICAgaWYgKGZuKSB7XG4gICAgICAgICAgZGVsZXRlIHRpbWVvdXRzW2lkXTtcbiAgICAgICAgICBmbigpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgZnVuY3Rpb24gY2xlYXIoaWQpIHtcbiAgICAgIGRlbGV0ZSB0aW1lb3V0c1tpZF07XG4gICAgfVxuXG4gICAgZ2xvYmFsLmFkZEV2ZW50TGlzdGVuZXIoXCJtZXNzYWdlXCIsIHJlY2VpdmUsIHRydWUpO1xuICAgIGdsb2JhbC5zZXRJbW1lZGlhdGUgPSBwb3N0O1xuICAgIGdsb2JhbC5jbGVhckltbWVkaWF0ZSA9IGNsZWFyO1xuICB9KSgpO1xufVxuXG59KS5jYWxsKHRoaXMsdHlwZW9mIGdsb2JhbCAhPT0gXCJ1bmRlZmluZWRcIiA/IGdsb2JhbCA6IHR5cGVvZiBzZWxmICE9PSBcInVuZGVmaW5lZFwiID8gc2VsZiA6IHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIgPyB3aW5kb3cgOiB7fSkiLCJmdW5jdGlvbiBlcnJvclRocm93ZXIgKG5hbWUpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJObyBzdWNoIG1ldGhvZDogXCIgKyBuYW1lKTtcbiAgfTtcbn1cblxuZnVuY3Rpb24gYXJyVG9CdWYoaGV4KSB7XG4gIHZhciBidWZmZXIgPSBuZXcgQXJyYXlCdWZmZXIoaGV4Lmxlbmd0aCk7XG4gIHZhciBidWZmZXJWaWV3ID0gbmV3IFVpbnQ4QXJyYXkoYnVmZmVyKTtcbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBoZXgubGVuZ3RoOyBpKyspIHtcbiAgICBidWZmZXJWaWV3W2ldID0gaGV4W2ldO1xuICB9XG5cbiAgcmV0dXJuIGJ1ZmZlcjtcbn1cbm1vZHVsZS5leHBvcnRzLmFyclRvQnVmID0gYXJyVG9CdWY7XG5cbmZ1bmN0aW9uIGJ1ZlRvQXJyKGJpbikge1xuICB2YXIgYnVmZmVyVmlldyA9IG5ldyBVaW50OEFycmF5KGJpbik7XG4gIHZhciBoZXhlcyA9IFtdO1xuICBmb3IgKHZhciBpID0gMDsgaSA8IGJ1ZmZlclZpZXcubGVuZ3RoOyArK2kpIHtcbiAgICBoZXhlcy5wdXNoKGJ1ZmZlclZpZXdbaV0pO1xuICB9XG4gIHJldHVybiBoZXhlcztcbn1cbm1vZHVsZS5leHBvcnRzLmJ1ZlRvQXJyID0gYnVmVG9BcnI7XG5cbi8vIEdldCBhIGNhbGxhYmxlIG1lbWJlciBvZiB0aGlzLm9iaiBnaXZlbiB0aGUgbmFtZS4gRG90IHBhdGhzIGFyZVxuLy8gc3VwcG9ydGVkLlxuZnVuY3Rpb24gcGF0aDJjYWxsYWJsZSAob2JqZWN0LCBuYW1lLCBjYWxsYWJsZSkge1xuICB2YXIgbmFtZXMgPSBuYW1lLnNwbGl0KCcuJyksXG4gICAgICBtZXRob2QgPSBuYW1lcy5wb3AoKSxcbiAgICAgIG9iaiA9IChuYW1lcy5yZWR1Y2UoZnVuY3Rpb24gKG9iLCBtZXRoKSB7cmV0dXJuIG9iW21ldGhdO30sIG9iamVjdClcbiAgICAgICAgICAgICB8fCBvYmplY3QpLFxuICAgICAgc2VsZiA9IHRoaXM7XG5cbiAgaWYgKCFvYmpbbWV0aG9kXSkge1xuICAgIGNvbnNvbGUud2FybihcIlRyaWVkIHRvIHJlc29sdmUgYmFkIG9iamVjdCBwYXRoOiBcIiArIG5hbWUpO1xuICAgIGNvbnNvbGUud2FybihcIlNlcnZlcjpcIiwgb2JqZWN0KTtcbiAgICByZXR1cm4gbnVsbDsgLy8gZXJyb3JUaHJvd2VyKG5hbWUpO1xuICB9XG5cbiAgcmV0dXJuIG9ialttZXRob2RdLmJpbmQob2JqKTtcbn07XG5tb2R1bGUuZXhwb3J0cy5wYXRoMmNhbGxhYmxlID0gcGF0aDJjYWxsYWJsZTtcbiIsIi8vIGh0dHA6Ly93aWtpLmNvbW1vbmpzLm9yZy93aWtpL1VuaXRfVGVzdGluZy8xLjBcbi8vXG4vLyBUSElTIElTIE5PVCBURVNURUQgTk9SIExJS0VMWSBUTyBXT1JLIE9VVFNJREUgVjghXG4vL1xuLy8gT3JpZ2luYWxseSBmcm9tIG5hcndoYWwuanMgKGh0dHA6Ly9uYXJ3aGFsanMub3JnKVxuLy8gQ29weXJpZ2h0IChjKSAyMDA5IFRob21hcyBSb2JpbnNvbiA8Mjgwbm9ydGguY29tPlxuLy9cbi8vIFBlcm1pc3Npb24gaXMgaGVyZWJ5IGdyYW50ZWQsIGZyZWUgb2YgY2hhcmdlLCB0byBhbnkgcGVyc29uIG9idGFpbmluZyBhIGNvcHlcbi8vIG9mIHRoaXMgc29mdHdhcmUgYW5kIGFzc29jaWF0ZWQgZG9jdW1lbnRhdGlvbiBmaWxlcyAodGhlICdTb2Z0d2FyZScpLCB0b1xuLy8gZGVhbCBpbiB0aGUgU29mdHdhcmUgd2l0aG91dCByZXN0cmljdGlvbiwgaW5jbHVkaW5nIHdpdGhvdXQgbGltaXRhdGlvbiB0aGVcbi8vIHJpZ2h0cyB0byB1c2UsIGNvcHksIG1vZGlmeSwgbWVyZ2UsIHB1Ymxpc2gsIGRpc3RyaWJ1dGUsIHN1YmxpY2Vuc2UsIGFuZC9vclxuLy8gc2VsbCBjb3BpZXMgb2YgdGhlIFNvZnR3YXJlLCBhbmQgdG8gcGVybWl0IHBlcnNvbnMgdG8gd2hvbSB0aGUgU29mdHdhcmUgaXNcbi8vIGZ1cm5pc2hlZCB0byBkbyBzbywgc3ViamVjdCB0byB0aGUgZm9sbG93aW5nIGNvbmRpdGlvbnM6XG4vL1xuLy8gVGhlIGFib3ZlIGNvcHlyaWdodCBub3RpY2UgYW5kIHRoaXMgcGVybWlzc2lvbiBub3RpY2Ugc2hhbGwgYmUgaW5jbHVkZWQgaW5cbi8vIGFsbCBjb3BpZXMgb3Igc3Vic3RhbnRpYWwgcG9ydGlvbnMgb2YgdGhlIFNvZnR3YXJlLlxuLy9cbi8vIFRIRSBTT0ZUV0FSRSBJUyBQUk9WSURFRCAnQVMgSVMnLCBXSVRIT1VUIFdBUlJBTlRZIE9GIEFOWSBLSU5ELCBFWFBSRVNTIE9SXG4vLyBJTVBMSUVELCBJTkNMVURJTkcgQlVUIE5PVCBMSU1JVEVEIFRPIFRIRSBXQVJSQU5USUVTIE9GIE1FUkNIQU5UQUJJTElUWSxcbi8vIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFIEFORCBOT05JTkZSSU5HRU1FTlQuIElOIE5PIEVWRU5UIFNIQUxMIFRIRVxuLy8gQVVUSE9SUyBCRSBMSUFCTEUgRk9SIEFOWSBDTEFJTSwgREFNQUdFUyBPUiBPVEhFUiBMSUFCSUxJVFksIFdIRVRIRVIgSU4gQU5cbi8vIEFDVElPTiBPRiBDT05UUkFDVCwgVE9SVCBPUiBPVEhFUldJU0UsIEFSSVNJTkcgRlJPTSwgT1VUIE9GIE9SIElOIENPTk5FQ1RJT05cbi8vIFdJVEggVEhFIFNPRlRXQVJFIE9SIFRIRSBVU0UgT1IgT1RIRVIgREVBTElOR1MgSU4gVEhFIFNPRlRXQVJFLlxuXG4vLyB3aGVuIHVzZWQgaW4gbm9kZSwgdGhpcyB3aWxsIGFjdHVhbGx5IGxvYWQgdGhlIHV0aWwgbW9kdWxlIHdlIGRlcGVuZCBvblxuLy8gdmVyc3VzIGxvYWRpbmcgdGhlIGJ1aWx0aW4gdXRpbCBtb2R1bGUgYXMgaGFwcGVucyBvdGhlcndpc2Vcbi8vIHRoaXMgaXMgYSBidWcgaW4gbm9kZSBtb2R1bGUgbG9hZGluZyBhcyBmYXIgYXMgSSBhbSBjb25jZXJuZWRcbnZhciB1dGlsID0gcmVxdWlyZSgndXRpbC8nKTtcblxudmFyIHBTbGljZSA9IEFycmF5LnByb3RvdHlwZS5zbGljZTtcbnZhciBoYXNPd24gPSBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5O1xuXG4vLyAxLiBUaGUgYXNzZXJ0IG1vZHVsZSBwcm92aWRlcyBmdW5jdGlvbnMgdGhhdCB0aHJvd1xuLy8gQXNzZXJ0aW9uRXJyb3IncyB3aGVuIHBhcnRpY3VsYXIgY29uZGl0aW9ucyBhcmUgbm90IG1ldC4gVGhlXG4vLyBhc3NlcnQgbW9kdWxlIG11c3QgY29uZm9ybSB0byB0aGUgZm9sbG93aW5nIGludGVyZmFjZS5cblxudmFyIGFzc2VydCA9IG1vZHVsZS5leHBvcnRzID0gb2s7XG5cbi8vIDIuIFRoZSBBc3NlcnRpb25FcnJvciBpcyBkZWZpbmVkIGluIGFzc2VydC5cbi8vIG5ldyBhc3NlcnQuQXNzZXJ0aW9uRXJyb3IoeyBtZXNzYWdlOiBtZXNzYWdlLFxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFjdHVhbDogYWN0dWFsLFxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4cGVjdGVkOiBleHBlY3RlZCB9KVxuXG5hc3NlcnQuQXNzZXJ0aW9uRXJyb3IgPSBmdW5jdGlvbiBBc3NlcnRpb25FcnJvcihvcHRpb25zKSB7XG4gIHRoaXMubmFtZSA9ICdBc3NlcnRpb25FcnJvcic7XG4gIHRoaXMuYWN0dWFsID0gb3B0aW9ucy5hY3R1YWw7XG4gIHRoaXMuZXhwZWN0ZWQgPSBvcHRpb25zLmV4cGVjdGVkO1xuICB0aGlzLm9wZXJhdG9yID0gb3B0aW9ucy5vcGVyYXRvcjtcbiAgaWYgKG9wdGlvbnMubWVzc2FnZSkge1xuICAgIHRoaXMubWVzc2FnZSA9IG9wdGlvbnMubWVzc2FnZTtcbiAgICB0aGlzLmdlbmVyYXRlZE1lc3NhZ2UgPSBmYWxzZTtcbiAgfSBlbHNlIHtcbiAgICB0aGlzLm1lc3NhZ2UgPSBnZXRNZXNzYWdlKHRoaXMpO1xuICAgIHRoaXMuZ2VuZXJhdGVkTWVzc2FnZSA9IHRydWU7XG4gIH1cbiAgdmFyIHN0YWNrU3RhcnRGdW5jdGlvbiA9IG9wdGlvbnMuc3RhY2tTdGFydEZ1bmN0aW9uIHx8IGZhaWw7XG5cbiAgaWYgKEVycm9yLmNhcHR1cmVTdGFja1RyYWNlKSB7XG4gICAgRXJyb3IuY2FwdHVyZVN0YWNrVHJhY2UodGhpcywgc3RhY2tTdGFydEZ1bmN0aW9uKTtcbiAgfVxuICBlbHNlIHtcbiAgICAvLyBub24gdjggYnJvd3NlcnMgc28gd2UgY2FuIGhhdmUgYSBzdGFja3RyYWNlXG4gICAgdmFyIGVyciA9IG5ldyBFcnJvcigpO1xuICAgIGlmIChlcnIuc3RhY2spIHtcbiAgICAgIHZhciBvdXQgPSBlcnIuc3RhY2s7XG5cbiAgICAgIC8vIHRyeSB0byBzdHJpcCB1c2VsZXNzIGZyYW1lc1xuICAgICAgdmFyIGZuX25hbWUgPSBzdGFja1N0YXJ0RnVuY3Rpb24ubmFtZTtcbiAgICAgIHZhciBpZHggPSBvdXQuaW5kZXhPZignXFxuJyArIGZuX25hbWUpO1xuICAgICAgaWYgKGlkeCA+PSAwKSB7XG4gICAgICAgIC8vIG9uY2Ugd2UgaGF2ZSBsb2NhdGVkIHRoZSBmdW5jdGlvbiBmcmFtZVxuICAgICAgICAvLyB3ZSBuZWVkIHRvIHN0cmlwIG91dCBldmVyeXRoaW5nIGJlZm9yZSBpdCAoYW5kIGl0cyBsaW5lKVxuICAgICAgICB2YXIgbmV4dF9saW5lID0gb3V0LmluZGV4T2YoJ1xcbicsIGlkeCArIDEpO1xuICAgICAgICBvdXQgPSBvdXQuc3Vic3RyaW5nKG5leHRfbGluZSArIDEpO1xuICAgICAgfVxuXG4gICAgICB0aGlzLnN0YWNrID0gb3V0O1xuICAgIH1cbiAgfVxufTtcblxuLy8gYXNzZXJ0LkFzc2VydGlvbkVycm9yIGluc3RhbmNlb2YgRXJyb3JcbnV0aWwuaW5oZXJpdHMoYXNzZXJ0LkFzc2VydGlvbkVycm9yLCBFcnJvcik7XG5cbmZ1bmN0aW9uIHJlcGxhY2VyKGtleSwgdmFsdWUpIHtcbiAgaWYgKHV0aWwuaXNVbmRlZmluZWQodmFsdWUpKSB7XG4gICAgcmV0dXJuICcnICsgdmFsdWU7XG4gIH1cbiAgaWYgKHV0aWwuaXNOdW1iZXIodmFsdWUpICYmIChpc05hTih2YWx1ZSkgfHwgIWlzRmluaXRlKHZhbHVlKSkpIHtcbiAgICByZXR1cm4gdmFsdWUudG9TdHJpbmcoKTtcbiAgfVxuICBpZiAodXRpbC5pc0Z1bmN0aW9uKHZhbHVlKSB8fCB1dGlsLmlzUmVnRXhwKHZhbHVlKSkge1xuICAgIHJldHVybiB2YWx1ZS50b1N0cmluZygpO1xuICB9XG4gIHJldHVybiB2YWx1ZTtcbn1cblxuZnVuY3Rpb24gdHJ1bmNhdGUocywgbikge1xuICBpZiAodXRpbC5pc1N0cmluZyhzKSkge1xuICAgIHJldHVybiBzLmxlbmd0aCA8IG4gPyBzIDogcy5zbGljZSgwLCBuKTtcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gcztcbiAgfVxufVxuXG5mdW5jdGlvbiBnZXRNZXNzYWdlKHNlbGYpIHtcbiAgcmV0dXJuIHRydW5jYXRlKEpTT04uc3RyaW5naWZ5KHNlbGYuYWN0dWFsLCByZXBsYWNlciksIDEyOCkgKyAnICcgK1xuICAgICAgICAgc2VsZi5vcGVyYXRvciArICcgJyArXG4gICAgICAgICB0cnVuY2F0ZShKU09OLnN0cmluZ2lmeShzZWxmLmV4cGVjdGVkLCByZXBsYWNlciksIDEyOCk7XG59XG5cbi8vIEF0IHByZXNlbnQgb25seSB0aGUgdGhyZWUga2V5cyBtZW50aW9uZWQgYWJvdmUgYXJlIHVzZWQgYW5kXG4vLyB1bmRlcnN0b29kIGJ5IHRoZSBzcGVjLiBJbXBsZW1lbnRhdGlvbnMgb3Igc3ViIG1vZHVsZXMgY2FuIHBhc3Ncbi8vIG90aGVyIGtleXMgdG8gdGhlIEFzc2VydGlvbkVycm9yJ3MgY29uc3RydWN0b3IgLSB0aGV5IHdpbGwgYmVcbi8vIGlnbm9yZWQuXG5cbi8vIDMuIEFsbCBvZiB0aGUgZm9sbG93aW5nIGZ1bmN0aW9ucyBtdXN0IHRocm93IGFuIEFzc2VydGlvbkVycm9yXG4vLyB3aGVuIGEgY29ycmVzcG9uZGluZyBjb25kaXRpb24gaXMgbm90IG1ldCwgd2l0aCBhIG1lc3NhZ2UgdGhhdFxuLy8gbWF5IGJlIHVuZGVmaW5lZCBpZiBub3QgcHJvdmlkZWQuICBBbGwgYXNzZXJ0aW9uIG1ldGhvZHMgcHJvdmlkZVxuLy8gYm90aCB0aGUgYWN0dWFsIGFuZCBleHBlY3RlZCB2YWx1ZXMgdG8gdGhlIGFzc2VydGlvbiBlcnJvciBmb3Jcbi8vIGRpc3BsYXkgcHVycG9zZXMuXG5cbmZ1bmN0aW9uIGZhaWwoYWN0dWFsLCBleHBlY3RlZCwgbWVzc2FnZSwgb3BlcmF0b3IsIHN0YWNrU3RhcnRGdW5jdGlvbikge1xuICB0aHJvdyBuZXcgYXNzZXJ0LkFzc2VydGlvbkVycm9yKHtcbiAgICBtZXNzYWdlOiBtZXNzYWdlLFxuICAgIGFjdHVhbDogYWN0dWFsLFxuICAgIGV4cGVjdGVkOiBleHBlY3RlZCxcbiAgICBvcGVyYXRvcjogb3BlcmF0b3IsXG4gICAgc3RhY2tTdGFydEZ1bmN0aW9uOiBzdGFja1N0YXJ0RnVuY3Rpb25cbiAgfSk7XG59XG5cbi8vIEVYVEVOU0lPTiEgYWxsb3dzIGZvciB3ZWxsIGJlaGF2ZWQgZXJyb3JzIGRlZmluZWQgZWxzZXdoZXJlLlxuYXNzZXJ0LmZhaWwgPSBmYWlsO1xuXG4vLyA0LiBQdXJlIGFzc2VydGlvbiB0ZXN0cyB3aGV0aGVyIGEgdmFsdWUgaXMgdHJ1dGh5LCBhcyBkZXRlcm1pbmVkXG4vLyBieSAhIWd1YXJkLlxuLy8gYXNzZXJ0Lm9rKGd1YXJkLCBtZXNzYWdlX29wdCk7XG4vLyBUaGlzIHN0YXRlbWVudCBpcyBlcXVpdmFsZW50IHRvIGFzc2VydC5lcXVhbCh0cnVlLCAhIWd1YXJkLFxuLy8gbWVzc2FnZV9vcHQpOy4gVG8gdGVzdCBzdHJpY3RseSBmb3IgdGhlIHZhbHVlIHRydWUsIHVzZVxuLy8gYXNzZXJ0LnN0cmljdEVxdWFsKHRydWUsIGd1YXJkLCBtZXNzYWdlX29wdCk7LlxuXG5mdW5jdGlvbiBvayh2YWx1ZSwgbWVzc2FnZSkge1xuICBpZiAoIXZhbHVlKSBmYWlsKHZhbHVlLCB0cnVlLCBtZXNzYWdlLCAnPT0nLCBhc3NlcnQub2spO1xufVxuYXNzZXJ0Lm9rID0gb2s7XG5cbi8vIDUuIFRoZSBlcXVhbGl0eSBhc3NlcnRpb24gdGVzdHMgc2hhbGxvdywgY29lcmNpdmUgZXF1YWxpdHkgd2l0aFxuLy8gPT0uXG4vLyBhc3NlcnQuZXF1YWwoYWN0dWFsLCBleHBlY3RlZCwgbWVzc2FnZV9vcHQpO1xuXG5hc3NlcnQuZXF1YWwgPSBmdW5jdGlvbiBlcXVhbChhY3R1YWwsIGV4cGVjdGVkLCBtZXNzYWdlKSB7XG4gIGlmIChhY3R1YWwgIT0gZXhwZWN0ZWQpIGZhaWwoYWN0dWFsLCBleHBlY3RlZCwgbWVzc2FnZSwgJz09JywgYXNzZXJ0LmVxdWFsKTtcbn07XG5cbi8vIDYuIFRoZSBub24tZXF1YWxpdHkgYXNzZXJ0aW9uIHRlc3RzIGZvciB3aGV0aGVyIHR3byBvYmplY3RzIGFyZSBub3QgZXF1YWxcbi8vIHdpdGggIT0gYXNzZXJ0Lm5vdEVxdWFsKGFjdHVhbCwgZXhwZWN0ZWQsIG1lc3NhZ2Vfb3B0KTtcblxuYXNzZXJ0Lm5vdEVxdWFsID0gZnVuY3Rpb24gbm90RXF1YWwoYWN0dWFsLCBleHBlY3RlZCwgbWVzc2FnZSkge1xuICBpZiAoYWN0dWFsID09IGV4cGVjdGVkKSB7XG4gICAgZmFpbChhY3R1YWwsIGV4cGVjdGVkLCBtZXNzYWdlLCAnIT0nLCBhc3NlcnQubm90RXF1YWwpO1xuICB9XG59O1xuXG4vLyA3LiBUaGUgZXF1aXZhbGVuY2UgYXNzZXJ0aW9uIHRlc3RzIGEgZGVlcCBlcXVhbGl0eSByZWxhdGlvbi5cbi8vIGFzc2VydC5kZWVwRXF1YWwoYWN0dWFsLCBleHBlY3RlZCwgbWVzc2FnZV9vcHQpO1xuXG5hc3NlcnQuZGVlcEVxdWFsID0gZnVuY3Rpb24gZGVlcEVxdWFsKGFjdHVhbCwgZXhwZWN0ZWQsIG1lc3NhZ2UpIHtcbiAgaWYgKCFfZGVlcEVxdWFsKGFjdHVhbCwgZXhwZWN0ZWQpKSB7XG4gICAgZmFpbChhY3R1YWwsIGV4cGVjdGVkLCBtZXNzYWdlLCAnZGVlcEVxdWFsJywgYXNzZXJ0LmRlZXBFcXVhbCk7XG4gIH1cbn07XG5cbmZ1bmN0aW9uIF9kZWVwRXF1YWwoYWN0dWFsLCBleHBlY3RlZCkge1xuICAvLyA3LjEuIEFsbCBpZGVudGljYWwgdmFsdWVzIGFyZSBlcXVpdmFsZW50LCBhcyBkZXRlcm1pbmVkIGJ5ID09PS5cbiAgaWYgKGFjdHVhbCA9PT0gZXhwZWN0ZWQpIHtcbiAgICByZXR1cm4gdHJ1ZTtcblxuICB9IGVsc2UgaWYgKHV0aWwuaXNCdWZmZXIoYWN0dWFsKSAmJiB1dGlsLmlzQnVmZmVyKGV4cGVjdGVkKSkge1xuICAgIGlmIChhY3R1YWwubGVuZ3RoICE9IGV4cGVjdGVkLmxlbmd0aCkgcmV0dXJuIGZhbHNlO1xuXG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBhY3R1YWwubGVuZ3RoOyBpKyspIHtcbiAgICAgIGlmIChhY3R1YWxbaV0gIT09IGV4cGVjdGVkW2ldKSByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgcmV0dXJuIHRydWU7XG5cbiAgLy8gNy4yLiBJZiB0aGUgZXhwZWN0ZWQgdmFsdWUgaXMgYSBEYXRlIG9iamVjdCwgdGhlIGFjdHVhbCB2YWx1ZSBpc1xuICAvLyBlcXVpdmFsZW50IGlmIGl0IGlzIGFsc28gYSBEYXRlIG9iamVjdCB0aGF0IHJlZmVycyB0byB0aGUgc2FtZSB0aW1lLlxuICB9IGVsc2UgaWYgKHV0aWwuaXNEYXRlKGFjdHVhbCkgJiYgdXRpbC5pc0RhdGUoZXhwZWN0ZWQpKSB7XG4gICAgcmV0dXJuIGFjdHVhbC5nZXRUaW1lKCkgPT09IGV4cGVjdGVkLmdldFRpbWUoKTtcblxuICAvLyA3LjMgSWYgdGhlIGV4cGVjdGVkIHZhbHVlIGlzIGEgUmVnRXhwIG9iamVjdCwgdGhlIGFjdHVhbCB2YWx1ZSBpc1xuICAvLyBlcXVpdmFsZW50IGlmIGl0IGlzIGFsc28gYSBSZWdFeHAgb2JqZWN0IHdpdGggdGhlIHNhbWUgc291cmNlIGFuZFxuICAvLyBwcm9wZXJ0aWVzIChgZ2xvYmFsYCwgYG11bHRpbGluZWAsIGBsYXN0SW5kZXhgLCBgaWdub3JlQ2FzZWApLlxuICB9IGVsc2UgaWYgKHV0aWwuaXNSZWdFeHAoYWN0dWFsKSAmJiB1dGlsLmlzUmVnRXhwKGV4cGVjdGVkKSkge1xuICAgIHJldHVybiBhY3R1YWwuc291cmNlID09PSBleHBlY3RlZC5zb3VyY2UgJiZcbiAgICAgICAgICAgYWN0dWFsLmdsb2JhbCA9PT0gZXhwZWN0ZWQuZ2xvYmFsICYmXG4gICAgICAgICAgIGFjdHVhbC5tdWx0aWxpbmUgPT09IGV4cGVjdGVkLm11bHRpbGluZSAmJlxuICAgICAgICAgICBhY3R1YWwubGFzdEluZGV4ID09PSBleHBlY3RlZC5sYXN0SW5kZXggJiZcbiAgICAgICAgICAgYWN0dWFsLmlnbm9yZUNhc2UgPT09IGV4cGVjdGVkLmlnbm9yZUNhc2U7XG5cbiAgLy8gNy40LiBPdGhlciBwYWlycyB0aGF0IGRvIG5vdCBib3RoIHBhc3MgdHlwZW9mIHZhbHVlID09ICdvYmplY3QnLFxuICAvLyBlcXVpdmFsZW5jZSBpcyBkZXRlcm1pbmVkIGJ5ID09LlxuICB9IGVsc2UgaWYgKCF1dGlsLmlzT2JqZWN0KGFjdHVhbCkgJiYgIXV0aWwuaXNPYmplY3QoZXhwZWN0ZWQpKSB7XG4gICAgcmV0dXJuIGFjdHVhbCA9PSBleHBlY3RlZDtcblxuICAvLyA3LjUgRm9yIGFsbCBvdGhlciBPYmplY3QgcGFpcnMsIGluY2x1ZGluZyBBcnJheSBvYmplY3RzLCBlcXVpdmFsZW5jZSBpc1xuICAvLyBkZXRlcm1pbmVkIGJ5IGhhdmluZyB0aGUgc2FtZSBudW1iZXIgb2Ygb3duZWQgcHJvcGVydGllcyAoYXMgdmVyaWZpZWRcbiAgLy8gd2l0aCBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwpLCB0aGUgc2FtZSBzZXQgb2Yga2V5c1xuICAvLyAoYWx0aG91Z2ggbm90IG5lY2Vzc2FyaWx5IHRoZSBzYW1lIG9yZGVyKSwgZXF1aXZhbGVudCB2YWx1ZXMgZm9yIGV2ZXJ5XG4gIC8vIGNvcnJlc3BvbmRpbmcga2V5LCBhbmQgYW4gaWRlbnRpY2FsICdwcm90b3R5cGUnIHByb3BlcnR5LiBOb3RlOiB0aGlzXG4gIC8vIGFjY291bnRzIGZvciBib3RoIG5hbWVkIGFuZCBpbmRleGVkIHByb3BlcnRpZXMgb24gQXJyYXlzLlxuICB9IGVsc2Uge1xuICAgIHJldHVybiBvYmpFcXVpdihhY3R1YWwsIGV4cGVjdGVkKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBpc0FyZ3VtZW50cyhvYmplY3QpIHtcbiAgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbChvYmplY3QpID09ICdbb2JqZWN0IEFyZ3VtZW50c10nO1xufVxuXG5mdW5jdGlvbiBvYmpFcXVpdihhLCBiKSB7XG4gIGlmICh1dGlsLmlzTnVsbE9yVW5kZWZpbmVkKGEpIHx8IHV0aWwuaXNOdWxsT3JVbmRlZmluZWQoYikpXG4gICAgcmV0dXJuIGZhbHNlO1xuICAvLyBhbiBpZGVudGljYWwgJ3Byb3RvdHlwZScgcHJvcGVydHkuXG4gIGlmIChhLnByb3RvdHlwZSAhPT0gYi5wcm90b3R5cGUpIHJldHVybiBmYWxzZTtcbiAgLy9+fn5JJ3ZlIG1hbmFnZWQgdG8gYnJlYWsgT2JqZWN0LmtleXMgdGhyb3VnaCBzY3Jld3kgYXJndW1lbnRzIHBhc3NpbmcuXG4gIC8vICAgQ29udmVydGluZyB0byBhcnJheSBzb2x2ZXMgdGhlIHByb2JsZW0uXG4gIGlmIChpc0FyZ3VtZW50cyhhKSkge1xuICAgIGlmICghaXNBcmd1bWVudHMoYikpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgYSA9IHBTbGljZS5jYWxsKGEpO1xuICAgIGIgPSBwU2xpY2UuY2FsbChiKTtcbiAgICByZXR1cm4gX2RlZXBFcXVhbChhLCBiKTtcbiAgfVxuICB0cnkge1xuICAgIHZhciBrYSA9IG9iamVjdEtleXMoYSksXG4gICAgICAgIGtiID0gb2JqZWN0S2V5cyhiKSxcbiAgICAgICAga2V5LCBpO1xuICB9IGNhdGNoIChlKSB7Ly9oYXBwZW5zIHdoZW4gb25lIGlzIGEgc3RyaW5nIGxpdGVyYWwgYW5kIHRoZSBvdGhlciBpc24ndFxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICAvLyBoYXZpbmcgdGhlIHNhbWUgbnVtYmVyIG9mIG93bmVkIHByb3BlcnRpZXMgKGtleXMgaW5jb3Jwb3JhdGVzXG4gIC8vIGhhc093blByb3BlcnR5KVxuICBpZiAoa2EubGVuZ3RoICE9IGtiLmxlbmd0aClcbiAgICByZXR1cm4gZmFsc2U7XG4gIC8vdGhlIHNhbWUgc2V0IG9mIGtleXMgKGFsdGhvdWdoIG5vdCBuZWNlc3NhcmlseSB0aGUgc2FtZSBvcmRlciksXG4gIGthLnNvcnQoKTtcbiAga2Iuc29ydCgpO1xuICAvL35+fmNoZWFwIGtleSB0ZXN0XG4gIGZvciAoaSA9IGthLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG4gICAgaWYgKGthW2ldICE9IGtiW2ldKVxuICAgICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIC8vZXF1aXZhbGVudCB2YWx1ZXMgZm9yIGV2ZXJ5IGNvcnJlc3BvbmRpbmcga2V5LCBhbmRcbiAgLy9+fn5wb3NzaWJseSBleHBlbnNpdmUgZGVlcCB0ZXN0XG4gIGZvciAoaSA9IGthLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG4gICAga2V5ID0ga2FbaV07XG4gICAgaWYgKCFfZGVlcEVxdWFsKGFba2V5XSwgYltrZXldKSkgcmV0dXJuIGZhbHNlO1xuICB9XG4gIHJldHVybiB0cnVlO1xufVxuXG4vLyA4LiBUaGUgbm9uLWVxdWl2YWxlbmNlIGFzc2VydGlvbiB0ZXN0cyBmb3IgYW55IGRlZXAgaW5lcXVhbGl0eS5cbi8vIGFzc2VydC5ub3REZWVwRXF1YWwoYWN0dWFsLCBleHBlY3RlZCwgbWVzc2FnZV9vcHQpO1xuXG5hc3NlcnQubm90RGVlcEVxdWFsID0gZnVuY3Rpb24gbm90RGVlcEVxdWFsKGFjdHVhbCwgZXhwZWN0ZWQsIG1lc3NhZ2UpIHtcbiAgaWYgKF9kZWVwRXF1YWwoYWN0dWFsLCBleHBlY3RlZCkpIHtcbiAgICBmYWlsKGFjdHVhbCwgZXhwZWN0ZWQsIG1lc3NhZ2UsICdub3REZWVwRXF1YWwnLCBhc3NlcnQubm90RGVlcEVxdWFsKTtcbiAgfVxufTtcblxuLy8gOS4gVGhlIHN0cmljdCBlcXVhbGl0eSBhc3NlcnRpb24gdGVzdHMgc3RyaWN0IGVxdWFsaXR5LCBhcyBkZXRlcm1pbmVkIGJ5ID09PS5cbi8vIGFzc2VydC5zdHJpY3RFcXVhbChhY3R1YWwsIGV4cGVjdGVkLCBtZXNzYWdlX29wdCk7XG5cbmFzc2VydC5zdHJpY3RFcXVhbCA9IGZ1bmN0aW9uIHN0cmljdEVxdWFsKGFjdHVhbCwgZXhwZWN0ZWQsIG1lc3NhZ2UpIHtcbiAgaWYgKGFjdHVhbCAhPT0gZXhwZWN0ZWQpIHtcbiAgICBmYWlsKGFjdHVhbCwgZXhwZWN0ZWQsIG1lc3NhZ2UsICc9PT0nLCBhc3NlcnQuc3RyaWN0RXF1YWwpO1xuICB9XG59O1xuXG4vLyAxMC4gVGhlIHN0cmljdCBub24tZXF1YWxpdHkgYXNzZXJ0aW9uIHRlc3RzIGZvciBzdHJpY3QgaW5lcXVhbGl0eSwgYXNcbi8vIGRldGVybWluZWQgYnkgIT09LiAgYXNzZXJ0Lm5vdFN0cmljdEVxdWFsKGFjdHVhbCwgZXhwZWN0ZWQsIG1lc3NhZ2Vfb3B0KTtcblxuYXNzZXJ0Lm5vdFN0cmljdEVxdWFsID0gZnVuY3Rpb24gbm90U3RyaWN0RXF1YWwoYWN0dWFsLCBleHBlY3RlZCwgbWVzc2FnZSkge1xuICBpZiAoYWN0dWFsID09PSBleHBlY3RlZCkge1xuICAgIGZhaWwoYWN0dWFsLCBleHBlY3RlZCwgbWVzc2FnZSwgJyE9PScsIGFzc2VydC5ub3RTdHJpY3RFcXVhbCk7XG4gIH1cbn07XG5cbmZ1bmN0aW9uIGV4cGVjdGVkRXhjZXB0aW9uKGFjdHVhbCwgZXhwZWN0ZWQpIHtcbiAgaWYgKCFhY3R1YWwgfHwgIWV4cGVjdGVkKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgaWYgKE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbChleHBlY3RlZCkgPT0gJ1tvYmplY3QgUmVnRXhwXScpIHtcbiAgICByZXR1cm4gZXhwZWN0ZWQudGVzdChhY3R1YWwpO1xuICB9IGVsc2UgaWYgKGFjdHVhbCBpbnN0YW5jZW9mIGV4cGVjdGVkKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH0gZWxzZSBpZiAoZXhwZWN0ZWQuY2FsbCh7fSwgYWN0dWFsKSA9PT0gdHJ1ZSkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG5cbiAgcmV0dXJuIGZhbHNlO1xufVxuXG5mdW5jdGlvbiBfdGhyb3dzKHNob3VsZFRocm93LCBibG9jaywgZXhwZWN0ZWQsIG1lc3NhZ2UpIHtcbiAgdmFyIGFjdHVhbDtcblxuICBpZiAodXRpbC5pc1N0cmluZyhleHBlY3RlZCkpIHtcbiAgICBtZXNzYWdlID0gZXhwZWN0ZWQ7XG4gICAgZXhwZWN0ZWQgPSBudWxsO1xuICB9XG5cbiAgdHJ5IHtcbiAgICBibG9jaygpO1xuICB9IGNhdGNoIChlKSB7XG4gICAgYWN0dWFsID0gZTtcbiAgfVxuXG4gIG1lc3NhZ2UgPSAoZXhwZWN0ZWQgJiYgZXhwZWN0ZWQubmFtZSA/ICcgKCcgKyBleHBlY3RlZC5uYW1lICsgJykuJyA6ICcuJykgK1xuICAgICAgICAgICAgKG1lc3NhZ2UgPyAnICcgKyBtZXNzYWdlIDogJy4nKTtcblxuICBpZiAoc2hvdWxkVGhyb3cgJiYgIWFjdHVhbCkge1xuICAgIGZhaWwoYWN0dWFsLCBleHBlY3RlZCwgJ01pc3NpbmcgZXhwZWN0ZWQgZXhjZXB0aW9uJyArIG1lc3NhZ2UpO1xuICB9XG5cbiAgaWYgKCFzaG91bGRUaHJvdyAmJiBleHBlY3RlZEV4Y2VwdGlvbihhY3R1YWwsIGV4cGVjdGVkKSkge1xuICAgIGZhaWwoYWN0dWFsLCBleHBlY3RlZCwgJ0dvdCB1bndhbnRlZCBleGNlcHRpb24nICsgbWVzc2FnZSk7XG4gIH1cblxuICBpZiAoKHNob3VsZFRocm93ICYmIGFjdHVhbCAmJiBleHBlY3RlZCAmJlxuICAgICAgIWV4cGVjdGVkRXhjZXB0aW9uKGFjdHVhbCwgZXhwZWN0ZWQpKSB8fCAoIXNob3VsZFRocm93ICYmIGFjdHVhbCkpIHtcbiAgICB0aHJvdyBhY3R1YWw7XG4gIH1cbn1cblxuLy8gMTEuIEV4cGVjdGVkIHRvIHRocm93IGFuIGVycm9yOlxuLy8gYXNzZXJ0LnRocm93cyhibG9jaywgRXJyb3Jfb3B0LCBtZXNzYWdlX29wdCk7XG5cbmFzc2VydC50aHJvd3MgPSBmdW5jdGlvbihibG9jaywgLypvcHRpb25hbCovZXJyb3IsIC8qb3B0aW9uYWwqL21lc3NhZ2UpIHtcbiAgX3Rocm93cy5hcHBseSh0aGlzLCBbdHJ1ZV0uY29uY2F0KHBTbGljZS5jYWxsKGFyZ3VtZW50cykpKTtcbn07XG5cbi8vIEVYVEVOU0lPTiEgVGhpcyBpcyBhbm5veWluZyB0byB3cml0ZSBvdXRzaWRlIHRoaXMgbW9kdWxlLlxuYXNzZXJ0LmRvZXNOb3RUaHJvdyA9IGZ1bmN0aW9uKGJsb2NrLCAvKm9wdGlvbmFsKi9tZXNzYWdlKSB7XG4gIF90aHJvd3MuYXBwbHkodGhpcywgW2ZhbHNlXS5jb25jYXQocFNsaWNlLmNhbGwoYXJndW1lbnRzKSkpO1xufTtcblxuYXNzZXJ0LmlmRXJyb3IgPSBmdW5jdGlvbihlcnIpIHsgaWYgKGVycikge3Rocm93IGVycjt9fTtcblxudmFyIG9iamVjdEtleXMgPSBPYmplY3Qua2V5cyB8fCBmdW5jdGlvbiAob2JqKSB7XG4gIHZhciBrZXlzID0gW107XG4gIGZvciAodmFyIGtleSBpbiBvYmopIHtcbiAgICBpZiAoaGFzT3duLmNhbGwob2JqLCBrZXkpKSBrZXlzLnB1c2goa2V5KTtcbiAgfVxuICByZXR1cm4ga2V5cztcbn07XG4iLCJpZiAodHlwZW9mIE9iamVjdC5jcmVhdGUgPT09ICdmdW5jdGlvbicpIHtcbiAgLy8gaW1wbGVtZW50YXRpb24gZnJvbSBzdGFuZGFyZCBub2RlLmpzICd1dGlsJyBtb2R1bGVcbiAgbW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiBpbmhlcml0cyhjdG9yLCBzdXBlckN0b3IpIHtcbiAgICBjdG9yLnN1cGVyXyA9IHN1cGVyQ3RvclxuICAgIGN0b3IucHJvdG90eXBlID0gT2JqZWN0LmNyZWF0ZShzdXBlckN0b3IucHJvdG90eXBlLCB7XG4gICAgICBjb25zdHJ1Y3Rvcjoge1xuICAgICAgICB2YWx1ZTogY3RvcixcbiAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXG4gICAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICAgIH1cbiAgICB9KTtcbiAgfTtcbn0gZWxzZSB7XG4gIC8vIG9sZCBzY2hvb2wgc2hpbSBmb3Igb2xkIGJyb3dzZXJzXG4gIG1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gaW5oZXJpdHMoY3Rvciwgc3VwZXJDdG9yKSB7XG4gICAgY3Rvci5zdXBlcl8gPSBzdXBlckN0b3JcbiAgICB2YXIgVGVtcEN0b3IgPSBmdW5jdGlvbiAoKSB7fVxuICAgIFRlbXBDdG9yLnByb3RvdHlwZSA9IHN1cGVyQ3Rvci5wcm90b3R5cGVcbiAgICBjdG9yLnByb3RvdHlwZSA9IG5ldyBUZW1wQ3RvcigpXG4gICAgY3Rvci5wcm90b3R5cGUuY29uc3RydWN0b3IgPSBjdG9yXG4gIH1cbn1cbiIsIi8vIHNoaW0gZm9yIHVzaW5nIHByb2Nlc3MgaW4gYnJvd3NlclxuXG52YXIgcHJvY2VzcyA9IG1vZHVsZS5leHBvcnRzID0ge307XG5cbnByb2Nlc3MubmV4dFRpY2sgPSAoZnVuY3Rpb24gKCkge1xuICAgIHZhciBjYW5TZXRJbW1lZGlhdGUgPSB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJ1xuICAgICYmIHdpbmRvdy5zZXRJbW1lZGlhdGU7XG4gICAgdmFyIGNhbk11dGF0aW9uT2JzZXJ2ZXIgPSB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJ1xuICAgICYmIHdpbmRvdy5NdXRhdGlvbk9ic2VydmVyO1xuICAgIHZhciBjYW5Qb3N0ID0gdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCdcbiAgICAmJiB3aW5kb3cucG9zdE1lc3NhZ2UgJiYgd2luZG93LmFkZEV2ZW50TGlzdGVuZXJcbiAgICA7XG5cbiAgICBpZiAoY2FuU2V0SW1tZWRpYXRlKSB7XG4gICAgICAgIHJldHVybiBmdW5jdGlvbiAoZikgeyByZXR1cm4gd2luZG93LnNldEltbWVkaWF0ZShmKSB9O1xuICAgIH1cblxuICAgIHZhciBxdWV1ZSA9IFtdO1xuXG4gICAgaWYgKGNhbk11dGF0aW9uT2JzZXJ2ZXIpIHtcbiAgICAgICAgdmFyIGhpZGRlbkRpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gICAgICAgIHZhciBvYnNlcnZlciA9IG5ldyBNdXRhdGlvbk9ic2VydmVyKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHZhciBxdWV1ZUxpc3QgPSBxdWV1ZS5zbGljZSgpO1xuICAgICAgICAgICAgcXVldWUubGVuZ3RoID0gMDtcbiAgICAgICAgICAgIHF1ZXVlTGlzdC5mb3JFYWNoKGZ1bmN0aW9uIChmbikge1xuICAgICAgICAgICAgICAgIGZuKCk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgb2JzZXJ2ZXIub2JzZXJ2ZShoaWRkZW5EaXYsIHsgYXR0cmlidXRlczogdHJ1ZSB9KTtcblxuICAgICAgICByZXR1cm4gZnVuY3Rpb24gbmV4dFRpY2soZm4pIHtcbiAgICAgICAgICAgIGlmICghcXVldWUubGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgaGlkZGVuRGl2LnNldEF0dHJpYnV0ZSgneWVzJywgJ25vJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBxdWV1ZS5wdXNoKGZuKTtcbiAgICAgICAgfTtcbiAgICB9XG5cbiAgICBpZiAoY2FuUG9zdCkge1xuICAgICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignbWVzc2FnZScsIGZ1bmN0aW9uIChldikge1xuICAgICAgICAgICAgdmFyIHNvdXJjZSA9IGV2LnNvdXJjZTtcbiAgICAgICAgICAgIGlmICgoc291cmNlID09PSB3aW5kb3cgfHwgc291cmNlID09PSBudWxsKSAmJiBldi5kYXRhID09PSAncHJvY2Vzcy10aWNrJykge1xuICAgICAgICAgICAgICAgIGV2LnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICAgICAgICAgIGlmIChxdWV1ZS5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciBmbiA9IHF1ZXVlLnNoaWZ0KCk7XG4gICAgICAgICAgICAgICAgICAgIGZuKCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9LCB0cnVlKTtcblxuICAgICAgICByZXR1cm4gZnVuY3Rpb24gbmV4dFRpY2soZm4pIHtcbiAgICAgICAgICAgIHF1ZXVlLnB1c2goZm4pO1xuICAgICAgICAgICAgd2luZG93LnBvc3RNZXNzYWdlKCdwcm9jZXNzLXRpY2snLCAnKicpO1xuICAgICAgICB9O1xuICAgIH1cblxuICAgIHJldHVybiBmdW5jdGlvbiBuZXh0VGljayhmbikge1xuICAgICAgICBzZXRUaW1lb3V0KGZuLCAwKTtcbiAgICB9O1xufSkoKTtcblxucHJvY2Vzcy50aXRsZSA9ICdicm93c2VyJztcbnByb2Nlc3MuYnJvd3NlciA9IHRydWU7XG5wcm9jZXNzLmVudiA9IHt9O1xucHJvY2Vzcy5hcmd2ID0gW107XG5cbmZ1bmN0aW9uIG5vb3AoKSB7fVxuXG5wcm9jZXNzLm9uID0gbm9vcDtcbnByb2Nlc3MuYWRkTGlzdGVuZXIgPSBub29wO1xucHJvY2Vzcy5vbmNlID0gbm9vcDtcbnByb2Nlc3Mub2ZmID0gbm9vcDtcbnByb2Nlc3MucmVtb3ZlTGlzdGVuZXIgPSBub29wO1xucHJvY2Vzcy5yZW1vdmVBbGxMaXN0ZW5lcnMgPSBub29wO1xucHJvY2Vzcy5lbWl0ID0gbm9vcDtcblxucHJvY2Vzcy5iaW5kaW5nID0gZnVuY3Rpb24gKG5hbWUpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ3Byb2Nlc3MuYmluZGluZyBpcyBub3Qgc3VwcG9ydGVkJyk7XG59O1xuXG4vLyBUT0RPKHNodHlsbWFuKVxucHJvY2Vzcy5jd2QgPSBmdW5jdGlvbiAoKSB7IHJldHVybiAnLycgfTtcbnByb2Nlc3MuY2hkaXIgPSBmdW5jdGlvbiAoZGlyKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdwcm9jZXNzLmNoZGlyIGlzIG5vdCBzdXBwb3J0ZWQnKTtcbn07XG4iLCJtb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIGlzQnVmZmVyKGFyZykge1xuICByZXR1cm4gYXJnICYmIHR5cGVvZiBhcmcgPT09ICdvYmplY3QnXG4gICAgJiYgdHlwZW9mIGFyZy5jb3B5ID09PSAnZnVuY3Rpb24nXG4gICAgJiYgdHlwZW9mIGFyZy5maWxsID09PSAnZnVuY3Rpb24nXG4gICAgJiYgdHlwZW9mIGFyZy5yZWFkVUludDggPT09ICdmdW5jdGlvbic7XG59IiwiKGZ1bmN0aW9uIChwcm9jZXNzLGdsb2JhbCl7XG4vLyBDb3B5cmlnaHQgSm95ZW50LCBJbmMuIGFuZCBvdGhlciBOb2RlIGNvbnRyaWJ1dG9ycy5cbi8vXG4vLyBQZXJtaXNzaW9uIGlzIGhlcmVieSBncmFudGVkLCBmcmVlIG9mIGNoYXJnZSwgdG8gYW55IHBlcnNvbiBvYnRhaW5pbmcgYVxuLy8gY29weSBvZiB0aGlzIHNvZnR3YXJlIGFuZCBhc3NvY2lhdGVkIGRvY3VtZW50YXRpb24gZmlsZXMgKHRoZVxuLy8gXCJTb2Z0d2FyZVwiKSwgdG8gZGVhbCBpbiB0aGUgU29mdHdhcmUgd2l0aG91dCByZXN0cmljdGlvbiwgaW5jbHVkaW5nXG4vLyB3aXRob3V0IGxpbWl0YXRpb24gdGhlIHJpZ2h0cyB0byB1c2UsIGNvcHksIG1vZGlmeSwgbWVyZ2UsIHB1Ymxpc2gsXG4vLyBkaXN0cmlidXRlLCBzdWJsaWNlbnNlLCBhbmQvb3Igc2VsbCBjb3BpZXMgb2YgdGhlIFNvZnR3YXJlLCBhbmQgdG8gcGVybWl0XG4vLyBwZXJzb25zIHRvIHdob20gdGhlIFNvZnR3YXJlIGlzIGZ1cm5pc2hlZCB0byBkbyBzbywgc3ViamVjdCB0byB0aGVcbi8vIGZvbGxvd2luZyBjb25kaXRpb25zOlxuLy9cbi8vIFRoZSBhYm92ZSBjb3B5cmlnaHQgbm90aWNlIGFuZCB0aGlzIHBlcm1pc3Npb24gbm90aWNlIHNoYWxsIGJlIGluY2x1ZGVkXG4vLyBpbiBhbGwgY29waWVzIG9yIHN1YnN0YW50aWFsIHBvcnRpb25zIG9mIHRoZSBTb2Z0d2FyZS5cbi8vXG4vLyBUSEUgU09GVFdBUkUgSVMgUFJPVklERUQgXCJBUyBJU1wiLCBXSVRIT1VUIFdBUlJBTlRZIE9GIEFOWSBLSU5ELCBFWFBSRVNTXG4vLyBPUiBJTVBMSUVELCBJTkNMVURJTkcgQlVUIE5PVCBMSU1JVEVEIFRPIFRIRSBXQVJSQU5USUVTIE9GXG4vLyBNRVJDSEFOVEFCSUxJVFksIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFIEFORCBOT05JTkZSSU5HRU1FTlQuIElOXG4vLyBOTyBFVkVOVCBTSEFMTCBUSEUgQVVUSE9SUyBPUiBDT1BZUklHSFQgSE9MREVSUyBCRSBMSUFCTEUgRk9SIEFOWSBDTEFJTSxcbi8vIERBTUFHRVMgT1IgT1RIRVIgTElBQklMSVRZLCBXSEVUSEVSIElOIEFOIEFDVElPTiBPRiBDT05UUkFDVCwgVE9SVCBPUlxuLy8gT1RIRVJXSVNFLCBBUklTSU5HIEZST00sIE9VVCBPRiBPUiBJTiBDT05ORUNUSU9OIFdJVEggVEhFIFNPRlRXQVJFIE9SIFRIRVxuLy8gVVNFIE9SIE9USEVSIERFQUxJTkdTIElOIFRIRSBTT0ZUV0FSRS5cblxudmFyIGZvcm1hdFJlZ0V4cCA9IC8lW3NkaiVdL2c7XG5leHBvcnRzLmZvcm1hdCA9IGZ1bmN0aW9uKGYpIHtcbiAgaWYgKCFpc1N0cmluZyhmKSkge1xuICAgIHZhciBvYmplY3RzID0gW107XG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBhcmd1bWVudHMubGVuZ3RoOyBpKyspIHtcbiAgICAgIG9iamVjdHMucHVzaChpbnNwZWN0KGFyZ3VtZW50c1tpXSkpO1xuICAgIH1cbiAgICByZXR1cm4gb2JqZWN0cy5qb2luKCcgJyk7XG4gIH1cblxuICB2YXIgaSA9IDE7XG4gIHZhciBhcmdzID0gYXJndW1lbnRzO1xuICB2YXIgbGVuID0gYXJncy5sZW5ndGg7XG4gIHZhciBzdHIgPSBTdHJpbmcoZikucmVwbGFjZShmb3JtYXRSZWdFeHAsIGZ1bmN0aW9uKHgpIHtcbiAgICBpZiAoeCA9PT0gJyUlJykgcmV0dXJuICclJztcbiAgICBpZiAoaSA+PSBsZW4pIHJldHVybiB4O1xuICAgIHN3aXRjaCAoeCkge1xuICAgICAgY2FzZSAnJXMnOiByZXR1cm4gU3RyaW5nKGFyZ3NbaSsrXSk7XG4gICAgICBjYXNlICclZCc6IHJldHVybiBOdW1iZXIoYXJnc1tpKytdKTtcbiAgICAgIGNhc2UgJyVqJzpcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICByZXR1cm4gSlNPTi5zdHJpbmdpZnkoYXJnc1tpKytdKTtcbiAgICAgICAgfSBjYXRjaCAoXykge1xuICAgICAgICAgIHJldHVybiAnW0NpcmN1bGFyXSc7XG4gICAgICAgIH1cbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIHJldHVybiB4O1xuICAgIH1cbiAgfSk7XG4gIGZvciAodmFyIHggPSBhcmdzW2ldOyBpIDwgbGVuOyB4ID0gYXJnc1srK2ldKSB7XG4gICAgaWYgKGlzTnVsbCh4KSB8fCAhaXNPYmplY3QoeCkpIHtcbiAgICAgIHN0ciArPSAnICcgKyB4O1xuICAgIH0gZWxzZSB7XG4gICAgICBzdHIgKz0gJyAnICsgaW5zcGVjdCh4KTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHN0cjtcbn07XG5cblxuLy8gTWFyayB0aGF0IGEgbWV0aG9kIHNob3VsZCBub3QgYmUgdXNlZC5cbi8vIFJldHVybnMgYSBtb2RpZmllZCBmdW5jdGlvbiB3aGljaCB3YXJucyBvbmNlIGJ5IGRlZmF1bHQuXG4vLyBJZiAtLW5vLWRlcHJlY2F0aW9uIGlzIHNldCwgdGhlbiBpdCBpcyBhIG5vLW9wLlxuZXhwb3J0cy5kZXByZWNhdGUgPSBmdW5jdGlvbihmbiwgbXNnKSB7XG4gIC8vIEFsbG93IGZvciBkZXByZWNhdGluZyB0aGluZ3MgaW4gdGhlIHByb2Nlc3Mgb2Ygc3RhcnRpbmcgdXAuXG4gIGlmIChpc1VuZGVmaW5lZChnbG9iYWwucHJvY2VzcykpIHtcbiAgICByZXR1cm4gZnVuY3Rpb24oKSB7XG4gICAgICByZXR1cm4gZXhwb3J0cy5kZXByZWNhdGUoZm4sIG1zZykuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbiAgICB9O1xuICB9XG5cbiAgaWYgKHByb2Nlc3Mubm9EZXByZWNhdGlvbiA9PT0gdHJ1ZSkge1xuICAgIHJldHVybiBmbjtcbiAgfVxuXG4gIHZhciB3YXJuZWQgPSBmYWxzZTtcbiAgZnVuY3Rpb24gZGVwcmVjYXRlZCgpIHtcbiAgICBpZiAoIXdhcm5lZCkge1xuICAgICAgaWYgKHByb2Nlc3MudGhyb3dEZXByZWNhdGlvbikge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IobXNnKTtcbiAgICAgIH0gZWxzZSBpZiAocHJvY2Vzcy50cmFjZURlcHJlY2F0aW9uKSB7XG4gICAgICAgIGNvbnNvbGUudHJhY2UobXNnKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IobXNnKTtcbiAgICAgIH1cbiAgICAgIHdhcm5lZCA9IHRydWU7XG4gICAgfVxuICAgIHJldHVybiBmbi5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICB9XG5cbiAgcmV0dXJuIGRlcHJlY2F0ZWQ7XG59O1xuXG5cbnZhciBkZWJ1Z3MgPSB7fTtcbnZhciBkZWJ1Z0Vudmlyb247XG5leHBvcnRzLmRlYnVnbG9nID0gZnVuY3Rpb24oc2V0KSB7XG4gIGlmIChpc1VuZGVmaW5lZChkZWJ1Z0Vudmlyb24pKVxuICAgIGRlYnVnRW52aXJvbiA9IHByb2Nlc3MuZW52Lk5PREVfREVCVUcgfHwgJyc7XG4gIHNldCA9IHNldC50b1VwcGVyQ2FzZSgpO1xuICBpZiAoIWRlYnVnc1tzZXRdKSB7XG4gICAgaWYgKG5ldyBSZWdFeHAoJ1xcXFxiJyArIHNldCArICdcXFxcYicsICdpJykudGVzdChkZWJ1Z0Vudmlyb24pKSB7XG4gICAgICB2YXIgcGlkID0gcHJvY2Vzcy5waWQ7XG4gICAgICBkZWJ1Z3Nbc2V0XSA9IGZ1bmN0aW9uKCkge1xuICAgICAgICB2YXIgbXNnID0gZXhwb3J0cy5mb3JtYXQuYXBwbHkoZXhwb3J0cywgYXJndW1lbnRzKTtcbiAgICAgICAgY29uc29sZS5lcnJvcignJXMgJWQ6ICVzJywgc2V0LCBwaWQsIG1zZyk7XG4gICAgICB9O1xuICAgIH0gZWxzZSB7XG4gICAgICBkZWJ1Z3Nbc2V0XSA9IGZ1bmN0aW9uKCkge307XG4gICAgfVxuICB9XG4gIHJldHVybiBkZWJ1Z3Nbc2V0XTtcbn07XG5cblxuLyoqXG4gKiBFY2hvcyB0aGUgdmFsdWUgb2YgYSB2YWx1ZS4gVHJ5cyB0byBwcmludCB0aGUgdmFsdWUgb3V0XG4gKiBpbiB0aGUgYmVzdCB3YXkgcG9zc2libGUgZ2l2ZW4gdGhlIGRpZmZlcmVudCB0eXBlcy5cbiAqXG4gKiBAcGFyYW0ge09iamVjdH0gb2JqIFRoZSBvYmplY3QgdG8gcHJpbnQgb3V0LlxuICogQHBhcmFtIHtPYmplY3R9IG9wdHMgT3B0aW9uYWwgb3B0aW9ucyBvYmplY3QgdGhhdCBhbHRlcnMgdGhlIG91dHB1dC5cbiAqL1xuLyogbGVnYWN5OiBvYmosIHNob3dIaWRkZW4sIGRlcHRoLCBjb2xvcnMqL1xuZnVuY3Rpb24gaW5zcGVjdChvYmosIG9wdHMpIHtcbiAgLy8gZGVmYXVsdCBvcHRpb25zXG4gIHZhciBjdHggPSB7XG4gICAgc2VlbjogW10sXG4gICAgc3R5bGl6ZTogc3R5bGl6ZU5vQ29sb3JcbiAgfTtcbiAgLy8gbGVnYWN5Li4uXG4gIGlmIChhcmd1bWVudHMubGVuZ3RoID49IDMpIGN0eC5kZXB0aCA9IGFyZ3VtZW50c1syXTtcbiAgaWYgKGFyZ3VtZW50cy5sZW5ndGggPj0gNCkgY3R4LmNvbG9ycyA9IGFyZ3VtZW50c1szXTtcbiAgaWYgKGlzQm9vbGVhbihvcHRzKSkge1xuICAgIC8vIGxlZ2FjeS4uLlxuICAgIGN0eC5zaG93SGlkZGVuID0gb3B0cztcbiAgfSBlbHNlIGlmIChvcHRzKSB7XG4gICAgLy8gZ290IGFuIFwib3B0aW9uc1wiIG9iamVjdFxuICAgIGV4cG9ydHMuX2V4dGVuZChjdHgsIG9wdHMpO1xuICB9XG4gIC8vIHNldCBkZWZhdWx0IG9wdGlvbnNcbiAgaWYgKGlzVW5kZWZpbmVkKGN0eC5zaG93SGlkZGVuKSkgY3R4LnNob3dIaWRkZW4gPSBmYWxzZTtcbiAgaWYgKGlzVW5kZWZpbmVkKGN0eC5kZXB0aCkpIGN0eC5kZXB0aCA9IDI7XG4gIGlmIChpc1VuZGVmaW5lZChjdHguY29sb3JzKSkgY3R4LmNvbG9ycyA9IGZhbHNlO1xuICBpZiAoaXNVbmRlZmluZWQoY3R4LmN1c3RvbUluc3BlY3QpKSBjdHguY3VzdG9tSW5zcGVjdCA9IHRydWU7XG4gIGlmIChjdHguY29sb3JzKSBjdHguc3R5bGl6ZSA9IHN0eWxpemVXaXRoQ29sb3I7XG4gIHJldHVybiBmb3JtYXRWYWx1ZShjdHgsIG9iaiwgY3R4LmRlcHRoKTtcbn1cbmV4cG9ydHMuaW5zcGVjdCA9IGluc3BlY3Q7XG5cblxuLy8gaHR0cDovL2VuLndpa2lwZWRpYS5vcmcvd2lraS9BTlNJX2VzY2FwZV9jb2RlI2dyYXBoaWNzXG5pbnNwZWN0LmNvbG9ycyA9IHtcbiAgJ2JvbGQnIDogWzEsIDIyXSxcbiAgJ2l0YWxpYycgOiBbMywgMjNdLFxuICAndW5kZXJsaW5lJyA6IFs0LCAyNF0sXG4gICdpbnZlcnNlJyA6IFs3LCAyN10sXG4gICd3aGl0ZScgOiBbMzcsIDM5XSxcbiAgJ2dyZXknIDogWzkwLCAzOV0sXG4gICdibGFjaycgOiBbMzAsIDM5XSxcbiAgJ2JsdWUnIDogWzM0LCAzOV0sXG4gICdjeWFuJyA6IFszNiwgMzldLFxuICAnZ3JlZW4nIDogWzMyLCAzOV0sXG4gICdtYWdlbnRhJyA6IFszNSwgMzldLFxuICAncmVkJyA6IFszMSwgMzldLFxuICAneWVsbG93JyA6IFszMywgMzldXG59O1xuXG4vLyBEb24ndCB1c2UgJ2JsdWUnIG5vdCB2aXNpYmxlIG9uIGNtZC5leGVcbmluc3BlY3Quc3R5bGVzID0ge1xuICAnc3BlY2lhbCc6ICdjeWFuJyxcbiAgJ251bWJlcic6ICd5ZWxsb3cnLFxuICAnYm9vbGVhbic6ICd5ZWxsb3cnLFxuICAndW5kZWZpbmVkJzogJ2dyZXknLFxuICAnbnVsbCc6ICdib2xkJyxcbiAgJ3N0cmluZyc6ICdncmVlbicsXG4gICdkYXRlJzogJ21hZ2VudGEnLFxuICAvLyBcIm5hbWVcIjogaW50ZW50aW9uYWxseSBub3Qgc3R5bGluZ1xuICAncmVnZXhwJzogJ3JlZCdcbn07XG5cblxuZnVuY3Rpb24gc3R5bGl6ZVdpdGhDb2xvcihzdHIsIHN0eWxlVHlwZSkge1xuICB2YXIgc3R5bGUgPSBpbnNwZWN0LnN0eWxlc1tzdHlsZVR5cGVdO1xuXG4gIGlmIChzdHlsZSkge1xuICAgIHJldHVybiAnXFx1MDAxYlsnICsgaW5zcGVjdC5jb2xvcnNbc3R5bGVdWzBdICsgJ20nICsgc3RyICtcbiAgICAgICAgICAgJ1xcdTAwMWJbJyArIGluc3BlY3QuY29sb3JzW3N0eWxlXVsxXSArICdtJztcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gc3RyO1xuICB9XG59XG5cblxuZnVuY3Rpb24gc3R5bGl6ZU5vQ29sb3Ioc3RyLCBzdHlsZVR5cGUpIHtcbiAgcmV0dXJuIHN0cjtcbn1cblxuXG5mdW5jdGlvbiBhcnJheVRvSGFzaChhcnJheSkge1xuICB2YXIgaGFzaCA9IHt9O1xuXG4gIGFycmF5LmZvckVhY2goZnVuY3Rpb24odmFsLCBpZHgpIHtcbiAgICBoYXNoW3ZhbF0gPSB0cnVlO1xuICB9KTtcblxuICByZXR1cm4gaGFzaDtcbn1cblxuXG5mdW5jdGlvbiBmb3JtYXRWYWx1ZShjdHgsIHZhbHVlLCByZWN1cnNlVGltZXMpIHtcbiAgLy8gUHJvdmlkZSBhIGhvb2sgZm9yIHVzZXItc3BlY2lmaWVkIGluc3BlY3QgZnVuY3Rpb25zLlxuICAvLyBDaGVjayB0aGF0IHZhbHVlIGlzIGFuIG9iamVjdCB3aXRoIGFuIGluc3BlY3QgZnVuY3Rpb24gb24gaXRcbiAgaWYgKGN0eC5jdXN0b21JbnNwZWN0ICYmXG4gICAgICB2YWx1ZSAmJlxuICAgICAgaXNGdW5jdGlvbih2YWx1ZS5pbnNwZWN0KSAmJlxuICAgICAgLy8gRmlsdGVyIG91dCB0aGUgdXRpbCBtb2R1bGUsIGl0J3MgaW5zcGVjdCBmdW5jdGlvbiBpcyBzcGVjaWFsXG4gICAgICB2YWx1ZS5pbnNwZWN0ICE9PSBleHBvcnRzLmluc3BlY3QgJiZcbiAgICAgIC8vIEFsc28gZmlsdGVyIG91dCBhbnkgcHJvdG90eXBlIG9iamVjdHMgdXNpbmcgdGhlIGNpcmN1bGFyIGNoZWNrLlxuICAgICAgISh2YWx1ZS5jb25zdHJ1Y3RvciAmJiB2YWx1ZS5jb25zdHJ1Y3Rvci5wcm90b3R5cGUgPT09IHZhbHVlKSkge1xuICAgIHZhciByZXQgPSB2YWx1ZS5pbnNwZWN0KHJlY3Vyc2VUaW1lcywgY3R4KTtcbiAgICBpZiAoIWlzU3RyaW5nKHJldCkpIHtcbiAgICAgIHJldCA9IGZvcm1hdFZhbHVlKGN0eCwgcmV0LCByZWN1cnNlVGltZXMpO1xuICAgIH1cbiAgICByZXR1cm4gcmV0O1xuICB9XG5cbiAgLy8gUHJpbWl0aXZlIHR5cGVzIGNhbm5vdCBoYXZlIHByb3BlcnRpZXNcbiAgdmFyIHByaW1pdGl2ZSA9IGZvcm1hdFByaW1pdGl2ZShjdHgsIHZhbHVlKTtcbiAgaWYgKHByaW1pdGl2ZSkge1xuICAgIHJldHVybiBwcmltaXRpdmU7XG4gIH1cblxuICAvLyBMb29rIHVwIHRoZSBrZXlzIG9mIHRoZSBvYmplY3QuXG4gIHZhciBrZXlzID0gT2JqZWN0LmtleXModmFsdWUpO1xuICB2YXIgdmlzaWJsZUtleXMgPSBhcnJheVRvSGFzaChrZXlzKTtcblxuICBpZiAoY3R4LnNob3dIaWRkZW4pIHtcbiAgICBrZXlzID0gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXModmFsdWUpO1xuICB9XG5cbiAgLy8gSUUgZG9lc24ndCBtYWtlIGVycm9yIGZpZWxkcyBub24tZW51bWVyYWJsZVxuICAvLyBodHRwOi8vbXNkbi5taWNyb3NvZnQuY29tL2VuLXVzL2xpYnJhcnkvaWUvZHd3NTJzYnQodj12cy45NCkuYXNweFxuICBpZiAoaXNFcnJvcih2YWx1ZSlcbiAgICAgICYmIChrZXlzLmluZGV4T2YoJ21lc3NhZ2UnKSA+PSAwIHx8IGtleXMuaW5kZXhPZignZGVzY3JpcHRpb24nKSA+PSAwKSkge1xuICAgIHJldHVybiBmb3JtYXRFcnJvcih2YWx1ZSk7XG4gIH1cblxuICAvLyBTb21lIHR5cGUgb2Ygb2JqZWN0IHdpdGhvdXQgcHJvcGVydGllcyBjYW4gYmUgc2hvcnRjdXR0ZWQuXG4gIGlmIChrZXlzLmxlbmd0aCA9PT0gMCkge1xuICAgIGlmIChpc0Z1bmN0aW9uKHZhbHVlKSkge1xuICAgICAgdmFyIG5hbWUgPSB2YWx1ZS5uYW1lID8gJzogJyArIHZhbHVlLm5hbWUgOiAnJztcbiAgICAgIHJldHVybiBjdHguc3R5bGl6ZSgnW0Z1bmN0aW9uJyArIG5hbWUgKyAnXScsICdzcGVjaWFsJyk7XG4gICAgfVxuICAgIGlmIChpc1JlZ0V4cCh2YWx1ZSkpIHtcbiAgICAgIHJldHVybiBjdHguc3R5bGl6ZShSZWdFeHAucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwodmFsdWUpLCAncmVnZXhwJyk7XG4gICAgfVxuICAgIGlmIChpc0RhdGUodmFsdWUpKSB7XG4gICAgICByZXR1cm4gY3R4LnN0eWxpemUoRGF0ZS5wcm90b3R5cGUudG9TdHJpbmcuY2FsbCh2YWx1ZSksICdkYXRlJyk7XG4gICAgfVxuICAgIGlmIChpc0Vycm9yKHZhbHVlKSkge1xuICAgICAgcmV0dXJuIGZvcm1hdEVycm9yKHZhbHVlKTtcbiAgICB9XG4gIH1cblxuICB2YXIgYmFzZSA9ICcnLCBhcnJheSA9IGZhbHNlLCBicmFjZXMgPSBbJ3snLCAnfSddO1xuXG4gIC8vIE1ha2UgQXJyYXkgc2F5IHRoYXQgdGhleSBhcmUgQXJyYXlcbiAgaWYgKGlzQXJyYXkodmFsdWUpKSB7XG4gICAgYXJyYXkgPSB0cnVlO1xuICAgIGJyYWNlcyA9IFsnWycsICddJ107XG4gIH1cblxuICAvLyBNYWtlIGZ1bmN0aW9ucyBzYXkgdGhhdCB0aGV5IGFyZSBmdW5jdGlvbnNcbiAgaWYgKGlzRnVuY3Rpb24odmFsdWUpKSB7XG4gICAgdmFyIG4gPSB2YWx1ZS5uYW1lID8gJzogJyArIHZhbHVlLm5hbWUgOiAnJztcbiAgICBiYXNlID0gJyBbRnVuY3Rpb24nICsgbiArICddJztcbiAgfVxuXG4gIC8vIE1ha2UgUmVnRXhwcyBzYXkgdGhhdCB0aGV5IGFyZSBSZWdFeHBzXG4gIGlmIChpc1JlZ0V4cCh2YWx1ZSkpIHtcbiAgICBiYXNlID0gJyAnICsgUmVnRXhwLnByb3RvdHlwZS50b1N0cmluZy5jYWxsKHZhbHVlKTtcbiAgfVxuXG4gIC8vIE1ha2UgZGF0ZXMgd2l0aCBwcm9wZXJ0aWVzIGZpcnN0IHNheSB0aGUgZGF0ZVxuICBpZiAoaXNEYXRlKHZhbHVlKSkge1xuICAgIGJhc2UgPSAnICcgKyBEYXRlLnByb3RvdHlwZS50b1VUQ1N0cmluZy5jYWxsKHZhbHVlKTtcbiAgfVxuXG4gIC8vIE1ha2UgZXJyb3Igd2l0aCBtZXNzYWdlIGZpcnN0IHNheSB0aGUgZXJyb3JcbiAgaWYgKGlzRXJyb3IodmFsdWUpKSB7XG4gICAgYmFzZSA9ICcgJyArIGZvcm1hdEVycm9yKHZhbHVlKTtcbiAgfVxuXG4gIGlmIChrZXlzLmxlbmd0aCA9PT0gMCAmJiAoIWFycmF5IHx8IHZhbHVlLmxlbmd0aCA9PSAwKSkge1xuICAgIHJldHVybiBicmFjZXNbMF0gKyBiYXNlICsgYnJhY2VzWzFdO1xuICB9XG5cbiAgaWYgKHJlY3Vyc2VUaW1lcyA8IDApIHtcbiAgICBpZiAoaXNSZWdFeHAodmFsdWUpKSB7XG4gICAgICByZXR1cm4gY3R4LnN0eWxpemUoUmVnRXhwLnByb3RvdHlwZS50b1N0cmluZy5jYWxsKHZhbHVlKSwgJ3JlZ2V4cCcpO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gY3R4LnN0eWxpemUoJ1tPYmplY3RdJywgJ3NwZWNpYWwnKTtcbiAgICB9XG4gIH1cblxuICBjdHguc2Vlbi5wdXNoKHZhbHVlKTtcblxuICB2YXIgb3V0cHV0O1xuICBpZiAoYXJyYXkpIHtcbiAgICBvdXRwdXQgPSBmb3JtYXRBcnJheShjdHgsIHZhbHVlLCByZWN1cnNlVGltZXMsIHZpc2libGVLZXlzLCBrZXlzKTtcbiAgfSBlbHNlIHtcbiAgICBvdXRwdXQgPSBrZXlzLm1hcChmdW5jdGlvbihrZXkpIHtcbiAgICAgIHJldHVybiBmb3JtYXRQcm9wZXJ0eShjdHgsIHZhbHVlLCByZWN1cnNlVGltZXMsIHZpc2libGVLZXlzLCBrZXksIGFycmF5KTtcbiAgICB9KTtcbiAgfVxuXG4gIGN0eC5zZWVuLnBvcCgpO1xuXG4gIHJldHVybiByZWR1Y2VUb1NpbmdsZVN0cmluZyhvdXRwdXQsIGJhc2UsIGJyYWNlcyk7XG59XG5cblxuZnVuY3Rpb24gZm9ybWF0UHJpbWl0aXZlKGN0eCwgdmFsdWUpIHtcbiAgaWYgKGlzVW5kZWZpbmVkKHZhbHVlKSlcbiAgICByZXR1cm4gY3R4LnN0eWxpemUoJ3VuZGVmaW5lZCcsICd1bmRlZmluZWQnKTtcbiAgaWYgKGlzU3RyaW5nKHZhbHVlKSkge1xuICAgIHZhciBzaW1wbGUgPSAnXFwnJyArIEpTT04uc3RyaW5naWZ5KHZhbHVlKS5yZXBsYWNlKC9eXCJ8XCIkL2csICcnKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnJlcGxhY2UoLycvZywgXCJcXFxcJ1wiKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnJlcGxhY2UoL1xcXFxcIi9nLCAnXCInKSArICdcXCcnO1xuICAgIHJldHVybiBjdHguc3R5bGl6ZShzaW1wbGUsICdzdHJpbmcnKTtcbiAgfVxuICBpZiAoaXNOdW1iZXIodmFsdWUpKVxuICAgIHJldHVybiBjdHguc3R5bGl6ZSgnJyArIHZhbHVlLCAnbnVtYmVyJyk7XG4gIGlmIChpc0Jvb2xlYW4odmFsdWUpKVxuICAgIHJldHVybiBjdHguc3R5bGl6ZSgnJyArIHZhbHVlLCAnYm9vbGVhbicpO1xuICAvLyBGb3Igc29tZSByZWFzb24gdHlwZW9mIG51bGwgaXMgXCJvYmplY3RcIiwgc28gc3BlY2lhbCBjYXNlIGhlcmUuXG4gIGlmIChpc051bGwodmFsdWUpKVxuICAgIHJldHVybiBjdHguc3R5bGl6ZSgnbnVsbCcsICdudWxsJyk7XG59XG5cblxuZnVuY3Rpb24gZm9ybWF0RXJyb3IodmFsdWUpIHtcbiAgcmV0dXJuICdbJyArIEVycm9yLnByb3RvdHlwZS50b1N0cmluZy5jYWxsKHZhbHVlKSArICddJztcbn1cblxuXG5mdW5jdGlvbiBmb3JtYXRBcnJheShjdHgsIHZhbHVlLCByZWN1cnNlVGltZXMsIHZpc2libGVLZXlzLCBrZXlzKSB7XG4gIHZhciBvdXRwdXQgPSBbXTtcbiAgZm9yICh2YXIgaSA9IDAsIGwgPSB2YWx1ZS5sZW5ndGg7IGkgPCBsOyArK2kpIHtcbiAgICBpZiAoaGFzT3duUHJvcGVydHkodmFsdWUsIFN0cmluZyhpKSkpIHtcbiAgICAgIG91dHB1dC5wdXNoKGZvcm1hdFByb3BlcnR5KGN0eCwgdmFsdWUsIHJlY3Vyc2VUaW1lcywgdmlzaWJsZUtleXMsXG4gICAgICAgICAgU3RyaW5nKGkpLCB0cnVlKSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIG91dHB1dC5wdXNoKCcnKTtcbiAgICB9XG4gIH1cbiAga2V5cy5mb3JFYWNoKGZ1bmN0aW9uKGtleSkge1xuICAgIGlmICgha2V5Lm1hdGNoKC9eXFxkKyQvKSkge1xuICAgICAgb3V0cHV0LnB1c2goZm9ybWF0UHJvcGVydHkoY3R4LCB2YWx1ZSwgcmVjdXJzZVRpbWVzLCB2aXNpYmxlS2V5cyxcbiAgICAgICAgICBrZXksIHRydWUpKTtcbiAgICB9XG4gIH0pO1xuICByZXR1cm4gb3V0cHV0O1xufVxuXG5cbmZ1bmN0aW9uIGZvcm1hdFByb3BlcnR5KGN0eCwgdmFsdWUsIHJlY3Vyc2VUaW1lcywgdmlzaWJsZUtleXMsIGtleSwgYXJyYXkpIHtcbiAgdmFyIG5hbWUsIHN0ciwgZGVzYztcbiAgZGVzYyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IodmFsdWUsIGtleSkgfHwgeyB2YWx1ZTogdmFsdWVba2V5XSB9O1xuICBpZiAoZGVzYy5nZXQpIHtcbiAgICBpZiAoZGVzYy5zZXQpIHtcbiAgICAgIHN0ciA9IGN0eC5zdHlsaXplKCdbR2V0dGVyL1NldHRlcl0nLCAnc3BlY2lhbCcpO1xuICAgIH0gZWxzZSB7XG4gICAgICBzdHIgPSBjdHguc3R5bGl6ZSgnW0dldHRlcl0nLCAnc3BlY2lhbCcpO1xuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBpZiAoZGVzYy5zZXQpIHtcbiAgICAgIHN0ciA9IGN0eC5zdHlsaXplKCdbU2V0dGVyXScsICdzcGVjaWFsJyk7XG4gICAgfVxuICB9XG4gIGlmICghaGFzT3duUHJvcGVydHkodmlzaWJsZUtleXMsIGtleSkpIHtcbiAgICBuYW1lID0gJ1snICsga2V5ICsgJ10nO1xuICB9XG4gIGlmICghc3RyKSB7XG4gICAgaWYgKGN0eC5zZWVuLmluZGV4T2YoZGVzYy52YWx1ZSkgPCAwKSB7XG4gICAgICBpZiAoaXNOdWxsKHJlY3Vyc2VUaW1lcykpIHtcbiAgICAgICAgc3RyID0gZm9ybWF0VmFsdWUoY3R4LCBkZXNjLnZhbHVlLCBudWxsKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHN0ciA9IGZvcm1hdFZhbHVlKGN0eCwgZGVzYy52YWx1ZSwgcmVjdXJzZVRpbWVzIC0gMSk7XG4gICAgICB9XG4gICAgICBpZiAoc3RyLmluZGV4T2YoJ1xcbicpID4gLTEpIHtcbiAgICAgICAgaWYgKGFycmF5KSB7XG4gICAgICAgICAgc3RyID0gc3RyLnNwbGl0KCdcXG4nKS5tYXAoZnVuY3Rpb24obGluZSkge1xuICAgICAgICAgICAgcmV0dXJuICcgICcgKyBsaW5lO1xuICAgICAgICAgIH0pLmpvaW4oJ1xcbicpLnN1YnN0cigyKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBzdHIgPSAnXFxuJyArIHN0ci5zcGxpdCgnXFxuJykubWFwKGZ1bmN0aW9uKGxpbmUpIHtcbiAgICAgICAgICAgIHJldHVybiAnICAgJyArIGxpbmU7XG4gICAgICAgICAgfSkuam9pbignXFxuJyk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgc3RyID0gY3R4LnN0eWxpemUoJ1tDaXJjdWxhcl0nLCAnc3BlY2lhbCcpO1xuICAgIH1cbiAgfVxuICBpZiAoaXNVbmRlZmluZWQobmFtZSkpIHtcbiAgICBpZiAoYXJyYXkgJiYga2V5Lm1hdGNoKC9eXFxkKyQvKSkge1xuICAgICAgcmV0dXJuIHN0cjtcbiAgICB9XG4gICAgbmFtZSA9IEpTT04uc3RyaW5naWZ5KCcnICsga2V5KTtcbiAgICBpZiAobmFtZS5tYXRjaCgvXlwiKFthLXpBLVpfXVthLXpBLVpfMC05XSopXCIkLykpIHtcbiAgICAgIG5hbWUgPSBuYW1lLnN1YnN0cigxLCBuYW1lLmxlbmd0aCAtIDIpO1xuICAgICAgbmFtZSA9IGN0eC5zdHlsaXplKG5hbWUsICduYW1lJyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIG5hbWUgPSBuYW1lLnJlcGxhY2UoLycvZywgXCJcXFxcJ1wiKVxuICAgICAgICAgICAgICAgICAucmVwbGFjZSgvXFxcXFwiL2csICdcIicpXG4gICAgICAgICAgICAgICAgIC5yZXBsYWNlKC8oXlwifFwiJCkvZywgXCInXCIpO1xuICAgICAgbmFtZSA9IGN0eC5zdHlsaXplKG5hbWUsICdzdHJpbmcnKTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gbmFtZSArICc6ICcgKyBzdHI7XG59XG5cblxuZnVuY3Rpb24gcmVkdWNlVG9TaW5nbGVTdHJpbmcob3V0cHV0LCBiYXNlLCBicmFjZXMpIHtcbiAgdmFyIG51bUxpbmVzRXN0ID0gMDtcbiAgdmFyIGxlbmd0aCA9IG91dHB1dC5yZWR1Y2UoZnVuY3Rpb24ocHJldiwgY3VyKSB7XG4gICAgbnVtTGluZXNFc3QrKztcbiAgICBpZiAoY3VyLmluZGV4T2YoJ1xcbicpID49IDApIG51bUxpbmVzRXN0Kys7XG4gICAgcmV0dXJuIHByZXYgKyBjdXIucmVwbGFjZSgvXFx1MDAxYlxcW1xcZFxcZD9tL2csICcnKS5sZW5ndGggKyAxO1xuICB9LCAwKTtcblxuICBpZiAobGVuZ3RoID4gNjApIHtcbiAgICByZXR1cm4gYnJhY2VzWzBdICtcbiAgICAgICAgICAgKGJhc2UgPT09ICcnID8gJycgOiBiYXNlICsgJ1xcbiAnKSArXG4gICAgICAgICAgICcgJyArXG4gICAgICAgICAgIG91dHB1dC5qb2luKCcsXFxuICAnKSArXG4gICAgICAgICAgICcgJyArXG4gICAgICAgICAgIGJyYWNlc1sxXTtcbiAgfVxuXG4gIHJldHVybiBicmFjZXNbMF0gKyBiYXNlICsgJyAnICsgb3V0cHV0LmpvaW4oJywgJykgKyAnICcgKyBicmFjZXNbMV07XG59XG5cblxuLy8gTk9URTogVGhlc2UgdHlwZSBjaGVja2luZyBmdW5jdGlvbnMgaW50ZW50aW9uYWxseSBkb24ndCB1c2UgYGluc3RhbmNlb2ZgXG4vLyBiZWNhdXNlIGl0IGlzIGZyYWdpbGUgYW5kIGNhbiBiZSBlYXNpbHkgZmFrZWQgd2l0aCBgT2JqZWN0LmNyZWF0ZSgpYC5cbmZ1bmN0aW9uIGlzQXJyYXkoYXIpIHtcbiAgcmV0dXJuIEFycmF5LmlzQXJyYXkoYXIpO1xufVxuZXhwb3J0cy5pc0FycmF5ID0gaXNBcnJheTtcblxuZnVuY3Rpb24gaXNCb29sZWFuKGFyZykge1xuICByZXR1cm4gdHlwZW9mIGFyZyA9PT0gJ2Jvb2xlYW4nO1xufVxuZXhwb3J0cy5pc0Jvb2xlYW4gPSBpc0Jvb2xlYW47XG5cbmZ1bmN0aW9uIGlzTnVsbChhcmcpIHtcbiAgcmV0dXJuIGFyZyA9PT0gbnVsbDtcbn1cbmV4cG9ydHMuaXNOdWxsID0gaXNOdWxsO1xuXG5mdW5jdGlvbiBpc051bGxPclVuZGVmaW5lZChhcmcpIHtcbiAgcmV0dXJuIGFyZyA9PSBudWxsO1xufVxuZXhwb3J0cy5pc051bGxPclVuZGVmaW5lZCA9IGlzTnVsbE9yVW5kZWZpbmVkO1xuXG5mdW5jdGlvbiBpc051bWJlcihhcmcpIHtcbiAgcmV0dXJuIHR5cGVvZiBhcmcgPT09ICdudW1iZXInO1xufVxuZXhwb3J0cy5pc051bWJlciA9IGlzTnVtYmVyO1xuXG5mdW5jdGlvbiBpc1N0cmluZyhhcmcpIHtcbiAgcmV0dXJuIHR5cGVvZiBhcmcgPT09ICdzdHJpbmcnO1xufVxuZXhwb3J0cy5pc1N0cmluZyA9IGlzU3RyaW5nO1xuXG5mdW5jdGlvbiBpc1N5bWJvbChhcmcpIHtcbiAgcmV0dXJuIHR5cGVvZiBhcmcgPT09ICdzeW1ib2wnO1xufVxuZXhwb3J0cy5pc1N5bWJvbCA9IGlzU3ltYm9sO1xuXG5mdW5jdGlvbiBpc1VuZGVmaW5lZChhcmcpIHtcbiAgcmV0dXJuIGFyZyA9PT0gdm9pZCAwO1xufVxuZXhwb3J0cy5pc1VuZGVmaW5lZCA9IGlzVW5kZWZpbmVkO1xuXG5mdW5jdGlvbiBpc1JlZ0V4cChyZSkge1xuICByZXR1cm4gaXNPYmplY3QocmUpICYmIG9iamVjdFRvU3RyaW5nKHJlKSA9PT0gJ1tvYmplY3QgUmVnRXhwXSc7XG59XG5leHBvcnRzLmlzUmVnRXhwID0gaXNSZWdFeHA7XG5cbmZ1bmN0aW9uIGlzT2JqZWN0KGFyZykge1xuICByZXR1cm4gdHlwZW9mIGFyZyA9PT0gJ29iamVjdCcgJiYgYXJnICE9PSBudWxsO1xufVxuZXhwb3J0cy5pc09iamVjdCA9IGlzT2JqZWN0O1xuXG5mdW5jdGlvbiBpc0RhdGUoZCkge1xuICByZXR1cm4gaXNPYmplY3QoZCkgJiYgb2JqZWN0VG9TdHJpbmcoZCkgPT09ICdbb2JqZWN0IERhdGVdJztcbn1cbmV4cG9ydHMuaXNEYXRlID0gaXNEYXRlO1xuXG5mdW5jdGlvbiBpc0Vycm9yKGUpIHtcbiAgcmV0dXJuIGlzT2JqZWN0KGUpICYmXG4gICAgICAob2JqZWN0VG9TdHJpbmcoZSkgPT09ICdbb2JqZWN0IEVycm9yXScgfHwgZSBpbnN0YW5jZW9mIEVycm9yKTtcbn1cbmV4cG9ydHMuaXNFcnJvciA9IGlzRXJyb3I7XG5cbmZ1bmN0aW9uIGlzRnVuY3Rpb24oYXJnKSB7XG4gIHJldHVybiB0eXBlb2YgYXJnID09PSAnZnVuY3Rpb24nO1xufVxuZXhwb3J0cy5pc0Z1bmN0aW9uID0gaXNGdW5jdGlvbjtcblxuZnVuY3Rpb24gaXNQcmltaXRpdmUoYXJnKSB7XG4gIHJldHVybiBhcmcgPT09IG51bGwgfHxcbiAgICAgICAgIHR5cGVvZiBhcmcgPT09ICdib29sZWFuJyB8fFxuICAgICAgICAgdHlwZW9mIGFyZyA9PT0gJ251bWJlcicgfHxcbiAgICAgICAgIHR5cGVvZiBhcmcgPT09ICdzdHJpbmcnIHx8XG4gICAgICAgICB0eXBlb2YgYXJnID09PSAnc3ltYm9sJyB8fCAgLy8gRVM2IHN5bWJvbFxuICAgICAgICAgdHlwZW9mIGFyZyA9PT0gJ3VuZGVmaW5lZCc7XG59XG5leHBvcnRzLmlzUHJpbWl0aXZlID0gaXNQcmltaXRpdmU7XG5cbmV4cG9ydHMuaXNCdWZmZXIgPSByZXF1aXJlKCcuL3N1cHBvcnQvaXNCdWZmZXInKTtcblxuZnVuY3Rpb24gb2JqZWN0VG9TdHJpbmcobykge1xuICByZXR1cm4gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKG8pO1xufVxuXG5cbmZ1bmN0aW9uIHBhZChuKSB7XG4gIHJldHVybiBuIDwgMTAgPyAnMCcgKyBuLnRvU3RyaW5nKDEwKSA6IG4udG9TdHJpbmcoMTApO1xufVxuXG5cbnZhciBtb250aHMgPSBbJ0phbicsICdGZWInLCAnTWFyJywgJ0FwcicsICdNYXknLCAnSnVuJywgJ0p1bCcsICdBdWcnLCAnU2VwJyxcbiAgICAgICAgICAgICAgJ09jdCcsICdOb3YnLCAnRGVjJ107XG5cbi8vIDI2IEZlYiAxNjoxOTozNFxuZnVuY3Rpb24gdGltZXN0YW1wKCkge1xuICB2YXIgZCA9IG5ldyBEYXRlKCk7XG4gIHZhciB0aW1lID0gW3BhZChkLmdldEhvdXJzKCkpLFxuICAgICAgICAgICAgICBwYWQoZC5nZXRNaW51dGVzKCkpLFxuICAgICAgICAgICAgICBwYWQoZC5nZXRTZWNvbmRzKCkpXS5qb2luKCc6Jyk7XG4gIHJldHVybiBbZC5nZXREYXRlKCksIG1vbnRoc1tkLmdldE1vbnRoKCldLCB0aW1lXS5qb2luKCcgJyk7XG59XG5cblxuLy8gbG9nIGlzIGp1c3QgYSB0aGluIHdyYXBwZXIgdG8gY29uc29sZS5sb2cgdGhhdCBwcmVwZW5kcyBhIHRpbWVzdGFtcFxuZXhwb3J0cy5sb2cgPSBmdW5jdGlvbigpIHtcbiAgY29uc29sZS5sb2coJyVzIC0gJXMnLCB0aW1lc3RhbXAoKSwgZXhwb3J0cy5mb3JtYXQuYXBwbHkoZXhwb3J0cywgYXJndW1lbnRzKSk7XG59O1xuXG5cbi8qKlxuICogSW5oZXJpdCB0aGUgcHJvdG90eXBlIG1ldGhvZHMgZnJvbSBvbmUgY29uc3RydWN0b3IgaW50byBhbm90aGVyLlxuICpcbiAqIFRoZSBGdW5jdGlvbi5wcm90b3R5cGUuaW5oZXJpdHMgZnJvbSBsYW5nLmpzIHJld3JpdHRlbiBhcyBhIHN0YW5kYWxvbmVcbiAqIGZ1bmN0aW9uIChub3Qgb24gRnVuY3Rpb24ucHJvdG90eXBlKS4gTk9URTogSWYgdGhpcyBmaWxlIGlzIHRvIGJlIGxvYWRlZFxuICogZHVyaW5nIGJvb3RzdHJhcHBpbmcgdGhpcyBmdW5jdGlvbiBuZWVkcyB0byBiZSByZXdyaXR0ZW4gdXNpbmcgc29tZSBuYXRpdmVcbiAqIGZ1bmN0aW9ucyBhcyBwcm90b3R5cGUgc2V0dXAgdXNpbmcgbm9ybWFsIEphdmFTY3JpcHQgZG9lcyBub3Qgd29yayBhc1xuICogZXhwZWN0ZWQgZHVyaW5nIGJvb3RzdHJhcHBpbmcgKHNlZSBtaXJyb3IuanMgaW4gcjExNDkwMykuXG4gKlxuICogQHBhcmFtIHtmdW5jdGlvbn0gY3RvciBDb25zdHJ1Y3RvciBmdW5jdGlvbiB3aGljaCBuZWVkcyB0byBpbmhlcml0IHRoZVxuICogICAgIHByb3RvdHlwZS5cbiAqIEBwYXJhbSB7ZnVuY3Rpb259IHN1cGVyQ3RvciBDb25zdHJ1Y3RvciBmdW5jdGlvbiB0byBpbmhlcml0IHByb3RvdHlwZSBmcm9tLlxuICovXG5leHBvcnRzLmluaGVyaXRzID0gcmVxdWlyZSgnaW5oZXJpdHMnKTtcblxuZXhwb3J0cy5fZXh0ZW5kID0gZnVuY3Rpb24ob3JpZ2luLCBhZGQpIHtcbiAgLy8gRG9uJ3QgZG8gYW55dGhpbmcgaWYgYWRkIGlzbid0IGFuIG9iamVjdFxuICBpZiAoIWFkZCB8fCAhaXNPYmplY3QoYWRkKSkgcmV0dXJuIG9yaWdpbjtcblxuICB2YXIga2V5cyA9IE9iamVjdC5rZXlzKGFkZCk7XG4gIHZhciBpID0ga2V5cy5sZW5ndGg7XG4gIHdoaWxlIChpLS0pIHtcbiAgICBvcmlnaW5ba2V5c1tpXV0gPSBhZGRba2V5c1tpXV07XG4gIH1cbiAgcmV0dXJuIG9yaWdpbjtcbn07XG5cbmZ1bmN0aW9uIGhhc093blByb3BlcnR5KG9iaiwgcHJvcCkge1xuICByZXR1cm4gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iaiwgcHJvcCk7XG59XG5cbn0pLmNhbGwodGhpcyxyZXF1aXJlKCdfcHJvY2VzcycpLHR5cGVvZiBnbG9iYWwgIT09IFwidW5kZWZpbmVkXCIgPyBnbG9iYWwgOiB0eXBlb2Ygc2VsZiAhPT0gXCJ1bmRlZmluZWRcIiA/IHNlbGYgOiB0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiID8gd2luZG93IDoge30pIl19
