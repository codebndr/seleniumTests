/**
 * @fileOverview Handlers are functions that will send a methdod
 * request or create a connection with the host.
 * @name handlers.js
 * @author Chris Perivolaropoulos
 */

var MethodRequest = require('./requests.js').MethodRequest,
    ClientConnection = require('./clientconnection.js').ClientConnection,
    getKeepAliveConnection = require('./server.js').getKeepAliveConnection,
    messageApi = require('./server.js').messageApi,
    errhandle = require('./error.js'),
    adhocclient = require('./adhoc/client.js'),
    getConfig = require('./config.js').getConfig,
    log = new (require('./log.js').Log)('handlers');
require('./setimmediate.js');

function uncaughtError(err) {
  console.error(err);
}

var clientConnections = [];
function handlerFactory(path, config, withError) {
  var handler;

  // this bound to the connection.
  function unregisterConnection () {
    if (!this.closed) {
      this.close();
    }

    var self = this;
    clientConnections = clientConnections.filter(function (c) {
      return c !== self;
    });
  }

  function registerConnection (varArgs) {
    // Connection
    clientConnections.push(new ClientConnection(
      path, [].slice.call(arguments),
      config.reverseMethods[path],
      config.hostId, config.clientId,
      unregisterConnection, null, withError));
  }

  if (config.reverseMethods[path]) {
    return registerConnection;
  }

  var isReverter = Object
        .getOwnPropertyNames(config.reverseMethods)
        .some(function (k) {
          return config.reverseMethods[k].path == path;
        }),
      noCallback = (config.noCallbackMethods.indexOf(path) > -1);

  return function () {
    var mr = new MethodRequest(
      config.hostId, path, [].slice.call(arguments),
      isReverter, noCallback);
    mr.withError = withError;
    mr.send();
  };
}

/**
 * Populate an object to be used as an api. To add extra arguments or
 * to override modify the defaultConfig object before calling
 * this. Once the cb is called a connection with the host will also be
 * established.
 *
 * @param {Object} apiRoot The root of the api to populate with
 * handlers. Besides the usual this will have a .local object with a
 * config:
 *
 * - hostId: the id to contact the host with.
 * - clientId: the id assigned to this client by the host.
 * - getConnections(): a callback to get all the open ClientConnections.
 * - reverseMethods: A dictionary of the reversable methods
 * - token: the raw token returned by the KeepAliveConnection
 * - chromeApi: a reference to the chrome object just in case you
 *   have overriden it
 *
 * @param {Function} connectCb Called when the function is finished.
 * @param {Function} disconnectCb Called when the host is lost.
 * @param {Function} errorCb Called on an error.
 */
function setupClient(apiRoot, connectCb, disconnectCb, errorCb, timeout) {
  if (apiRoot.local && apiRoot.local.token) {
    if (errorCb) {
      errorCb('already_connected');
      return;
    }

    throw new Error("Tried to reconnect to a non disconnected api");
  }

  getConfig(function (config) {
    apiRoot.local = config;
    asApiClient(apiRoot);
    connectCb();
  }, disconnectCb, errorCb, timeout);
}

function asApiClient (apiRoot) {
  apiRoot.local.getConnections = function () {
    return clientConnections;
  };

  apiRoot.local.disconnect = function (done, silent) {
    // This refers to local.
    var self = this, evt = null;
    if (this.token && this.token.port) {
      this.token.port.disconnect();
      if (!silent) {
        evt = this.token.disconnectCb;
      }
      setImmediate(function () {
        if (evt) evt();
        if (done) done();
      });
    }

    this.token = null;
  };

  apiRoot.local.methods.forEach(function (path) {
    var names = path.split('.'),
        method = names.pop(),
        obj = names.reduce(function (ob, meth) {
          if (!ob[meth]) {
            ob[meth] = {};
          }
          return ob[meth];
        }, apiRoot);

    if (obj[method]) return;
    obj[method] = handlerFactory(path, apiRoot.local,
                                 errhandle.withError.bind(null, apiRoot));
  });
  if (!apiRoot.local.hostId) console.error("No host id during setup of api");
  adhocclient.setupAdHoc(apiRoot.local.hostId, apiRoot);
}

module.exports.getConfig = getConfig;
module.exports.handlerFactory = handlerFactory;
module.exports.setupClient = setupClient;
module.exports.uncaughtError = uncaughtError;
