module.exports.BurstRequest = require('./requests/burst.js').BurstRequest;
module.exports.GenericRequest = require('./requests/generic.js').GenericRequest;
module.exports.MethodRequest = require('./requests/method.js').MethodRequest;
