/**
 * @fileOverview Basic general purpose communication with a running
 * host to build upon for keepalives, connections, request etc. The
 * command that we request may be provided by any part of the host
 * side. Mainly look at adhoc host.
 * @name bootstrapclient.js
 * @author Chris Perivolaropoulos
 */
var messageApi = require('./messaging.js');

function BootStrapClient () {
  this.messageApi = messageApi;
}

BootStrapClient.prototype = {
  getState: function (hostId, cb, cfg) {
    messageApi.sendMessage(hostId, {
      legacy: true,
      method: "getManifestAsync",
      object: "runtime",
      args: {args: [{type: 'function'}]},
      callbackId: -1
    }, function clientStateResponse (resp) {
      // New and sexy response
      if (!resp || resp.version) {
        cb (resp);
        return;
      }

      // Old inefficient and hacky response
      var val = null;
      try {
        val = resp.args.args[0].val;
      } catch (e) {
        // Received bad responce from legacy
      }
      cb(val);
    });
  },


  /**
   * Get the host id and the state.
   * @param {Function(String,Object)} cb Callback with the id and the
   * manifest or state depending on the version. You can be sure that
   * the state argument will have a .version property though.
   * @param {Object} cfg keyword args to be passed to getState. You
   * can override tha id being tried by setting cfg.ids.
   */
  getHostId: function (cb, cfg) {
    cfg = cfg || {};
    var appIds = cfg.ids ||
          global.appIds ||
          ["jommgdhcpkjoikkjcnpafeofedlfphfb",
           "magknjdfniglanojbpadmpjlglepnlko",
           global.APP_ID],
        car = appIds[0], cdr = appIds.slice(1),
        self = this;

    if (!car) {
      cb();
      return;
    }


    // Getting manifest is done ad-hoc directly over chrome api
    // message passing.
    this.getState(car, function checkManifest (arg) {
      if (!arg) {
        cfg.ids = cdr;
        self.getHostId(cb, cfg);
        return;
      }

      cb(car, arg);
    }, cfg);
  },

  /**
   * A bit ounter intuitively named this is the true way to get the
   * manifest/state of the host.
   * @param {Function(manifest)} cb Get the manifest/state
   * @param {Object} cfg passed on to getHostId.
   */
  getManifest: function (cb, cfg) {
    this.getHostId(function (id, state) {
      if (state) state.hostId = id;
      cb(state);
    }, cfg);
  }
};

module.exports = new BootStrapClient();
