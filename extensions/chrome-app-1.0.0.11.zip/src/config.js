var bsc = require('./bootstrapclient.js'),
    s = require('./server.js');

global.defaultConfig = {
  clientId: -1,
  reverseMethods: {
    // Same arguments clean
    'serial.onReceive.addListener':
    {path: 'serial.onReceive.removeListener', type: 'callingArguments'},
    'serial.onReceiveError.addListener':
    {path: 'serial.onReceiveError.removeListener', type: 'callingArguments'},
    // Callback args clean
    'serial.connect': {path: 'serial.disconnect',
                       type: 'firstResponse',
                       firstArgPath: 'connectionId'},

    // Use directly the first argument
    'usb.openDevice': {path:'usb.closeDevice',
                       type: 'firstResponse',
                       firstArgPath: null}

    // XXX: this actually opens multiple connections. This can be
    // implemented whith a sort of multi-connection request.
    //
    // 'usb.findDevices': {path: 'usb.closeDevice', type: 'callingArguments'}
  },

  // All the methods we support. Don't autogenerate, it gets out of
  // hand.
  methods: [
    // Ad hoc
    'babelfish.getState',
    'runtime.getManifestAsync',
    'serial.onReceiveError.forceDispatch',

    // Runtime
    'runtime.getPlatformInfo',

    // Serial API
    'serial.getDevices',
    'serial.connect',
    'serial.update',
    'serial.disconnect',
    'serial.setPaused',
    'serial.getInfo',
    'serial.getConnections',
    'serial.send',
    'serial.flush',
    'serial.getControlSignals',
    'serial.setControlSignals',
    'serial.onReceive.addListener',
    'serial.onReceive.removeListener',
    'serial.onReceiveError.addListener',
    'serial.onReceiveError.removeListener',

    // USB API
    'usb.getDevices',
    'usb.getUserSelectedDevices',
    'usb.requestAccess',
    'usb.openDevice',
    'usb.findDevices',
    'usb.closeDevice',
    'usb.setConfiguration',
    'usb.getConfiguration',
    'usb.getConfigurations',
    'usb.listInterfaces',
    'usb.claimInterface',
    'usb.releaseInterface',
    'usb.setInterfaceAlternateSetting',
    'usb.controlTransfer',
    'usb.bulkTransfer',
    'usb.interruptTransfer',
    'usb.isochronousTransfer',
    'usb.resetDevice',
    'usb.onDeviceAdded.addListener',
    'usb.onDeviceAdded.removeListener',
    'usb.onDeviceRemoved.addListener',
    'usb.onDeviceRemoved.removeListener',
  ],

  noCallbackMethods: [
    'usb.onDeviceRemoved.removeListener',
    'usb.onDeviceAdded.removeListener',
    'serial.onReceiveError.removeListener',
    'serial.onReceive.removeListener',
    'serial.onReceive.forceDispatch'
  ]
};


/**
 * Initialize communication with the host and return an up to date
 * config.
 *
 * @param {Function} connectCb Called when connected
 * @param {Function} disconnectCb Called when host is lost.
 * @param {Function} errorCb Called when we failed to.
 */
function getConfig(connectCb, disconnectCb, errorCb, timeout) {
  var newConfig = JSON.parse(JSON.stringify(global.defaultConfig));
  function doGetConfig (state, config) {
    config.version = state.version;
    if (parseInt(state.version.split('.').shift()) < 1) {
      errorCb({badVersion: config.version});
      return;
    }


    s.getKeepAliveConnection(state.hostId, function (token) {
      config.token = token;
      config.chromeApi = chrome;
      config.hostId = state.hostId;
      config.clientId = config.token.clientId;
      connectCb(config);
    }, function (error) {
      if (disconnectCb && !error) {
        disconnectCb();
        return;
      };

      if (errorCb && error) {
        errorCb(error);
        return;
      }
    }, timeout);
  }

  bsc.getManifest(function (m) {
    if (!m) {disconnectCb(); return;}
    doGetConfig(m, newConfig);
  });
}

module.exports.getConfig = getConfig;
