module.exports.setupClient = require('./handlers.js').setupClient;
global.setupClient = module.exports.setupClient;
module.exports.extentionAvailable = true;
global.extentionAvailable = true;
console.log("Client can run setup...");
