function Notepad (arg) {

}
