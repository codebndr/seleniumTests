var messageApi = require('./../messaging.js');

function getState (hostId, cb) {
  messageApi.sendMessage(hostId, {
    legacy: true,
    method: "getManifestAsync",
    object: "runtime",
    callbackId: -1
  }, function clientStateResponse (resp) {
    if (resp.version) {
      cb (resp);
      return;
    }

    var val;
    try {
      val = resp.args.args[0].val;
      cb(resp.args.args[0].val);
    } catch (e) {
      // Received bad responce from legacy
      console.trace(resp);
    }
  });
}

function setupAdHoc (hostId, apiRoot) {
  apiRoot.runtime = apiRoot.runtime || {};
  apiRoot.runtime.getManifestAsync = function (cb) {
    return getState(hostId, cb);
  };
  apiRoot.runtime.setPlatformInfo = function (info, cb) {
    // Chrome can know the true platform info, no reason to set it.
    cb(false);
  };
}
module.exports.getState = getState;
module.exports.setupAdHoc = setupAdHoc;
