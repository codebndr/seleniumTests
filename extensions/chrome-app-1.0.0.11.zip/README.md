# BabelFish Chrome App

General purpose communication with the chrome API interface from a web
page.

## Error handling

The error handling mimics chrome's: If there is an error
chrome.runtime.lastError is set in the app side, on the client side
the callback is called with no arguments and the
chrome.runtime.lastError is set. However there is no error if
chrome.runtime.lastError is not checked. Also it's the client's
responsibility to clear lastError once it is handled.

If an error occurs on the app side and there is no callback on the
arguments on the client side for that call then you can set
chrome.runtime.onUncaughtError to handle it. By default this function
just throws an error. However you wont be able to catch that as it's
called on an asynchronous stack. It's best to always have a callback
in your arguments even if it does nothing on the app side though.

## Limitations/differences with the chrome api

Since message passing is an async procedure you can only communicate
asynchronously with the API. That means that calls like
chrome.runtime.getManifest are not supported in their original
form. You can however overcome this by defining:

    chrome.runtime.getManifestAsync = function (cb) {
        cb(chrome.runtime.getManifestAsync())
    }

You do not have any direct access to any API defined variables.

You can not use more than one callbacks in the argument list.

Silent or implicit event closes are not handled

## TODO

For now only pages from codebender.cc are supported. However with
message passing over iframes it is possible for the library to work
anywhere.

Transparently translate calls to connections and method requests.
