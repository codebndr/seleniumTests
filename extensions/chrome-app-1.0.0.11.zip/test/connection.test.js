var apiRoot = require("./dummyapi.js"),
    s = require('../src/server.js'),
    ClientConnection = require('../src/clientconnection.js').ClientConnection,
    MethodRequest = require('../src/requests.js').MethodRequest,
    getConfig = require('../src/handlers.js').getConfig,
    assert = require('assert'),
    conf = apiRoot.state,
    id = 0, openDevs = [];

describe("connection.test", function () {
  var ev = apiRoot.device.onReceive;
  var cleanUp;

  before(function () {
    cleanUp = s.HostServer(apiRoot);
  });

  after(function () {
    cleanUp();
  });

  beforeEach(function() {
    assert.equal(s.messageApi.onMessageExternal.listeners.length, 2,
                 s.messageApi.onMessageExternal.listeners.length);
    assert.equal(ev.listeners.length, apiRoot.messageApi.ports.length / 2);
    assert.equal(ev.listeners.length, 0);
  });

  it("Send event", function (done) {
    var received = [],
        hostEvents = 0,
        deviceMessage = "Received!!";

    assert.equal(ev.listeners.length, 0);
    conf.caller = function (cb) {
      cb(deviceMessage);
    };

    function greeted (msg) {
      received.push(msg);
      assert.equal(chrome.runtime.lastError, undefined);
      assert.equal(msg, deviceMessage, "Got bad message in " +
                   received.length + "th iteration(should finish at 4):" + msg);
      if (received.length == 4) {
        // Remove it now
        assert.equal(ev.listeners.length, 1,
                     "Make sure we are registered at this point");
        conf.caller = function () {};
        apiRoot.convRemoveListener(function() {}, function () {
          assert.equal(ev.listeners.length, 1,
                       "Removing an unregistered callback shouldn't even be calling the method.");

          apiRoot.convRemoveListener(greeted, function () {
            assert.equal(ev.listeners.length, 0,
                         "Didn't really remove callback " + greeted.id);
            done();
          });
        });
      }
    }

    apiRoot.convAddListener([greeted]);
  });

  it("Pausing", function (done) {
    conf.spamRate = 50;
    conf.hostEvents = 0;
    conf.clientEvents = 0;

    // Count host events
    conf.caller = function (cb) {
      if (ev.listeners.length  == 0) return;
      conf.hostEvents++;
      cb();
    };

    // Count client events
    function greeted (msg) {
      conf.clientEvents++;
    }
    assert.equal(ev.listeners.length, 0,
                 "No listeners should be left off.");

    var n = 20;
    // Flush the queue

    var con = apiRoot.convAddListener([greeted]);
    con.pause(true, function () {
      setTimeout(function () {
        // The host is ahead of the client.
        assert.notEqual(conf.hostEvents, 0,
                        "The host should have fired a few events");
        assert.equal(conf.clientEvents, 0,
                     "Paused clients shouldn't receive events");
        // Put the events on the queue
        var evtsOnUnpause = conf.hostEvents;
        con.pause(false, function () {
          con.pause(true, function () {
            // Make sure you received as many as were put on the queue.
            assert(conf.clientEvents >= evtsOnUnpause,
                   "The host event emitter failed to flush all events on unpause.");
            assert(conf.hostEvents >= conf.clientEvents,
                   "We repaused so the host should still be ahead except in sync mode.");
            apiRoot.convRemoveListener(greeted, function () {
              assert.equal(ev.listeners.length, 0);
              done();
            });
          });
        });
      }, conf.spamRate * n);
    });
  });

  it("Paused removal", function (done) {
    conf.spamRate = 50;
    conf.hostEvents = 0;
    conf.clientEvents = 0;

    // Count the host events
    conf.wrapper = function (cb) {
      conf.hostEvents++;
      cb();
    };

    // Count the client events
    function greeted (msg) {
      conf.clientEvents++;
    }

    // Create the connection paused
    var con = apiRoot.convAddListener([greeted]);
    con.pause(true, function () {

      apiRoot.convRemoveListener(greeted, function () {
        var closedHost = conf.hostEvents;
        // Wait a minute to see if the host is still running.
        setTimeout(function () {
          assert.equal(closedHost, conf.hostEvents,
                       "The listener was not killed.");
          assert.equal(ev.listeners.length, 0);
          done();
        }, conf.spamRate * 3);
      });
    });
  });

  it("Duplicate connections", function (done) {
    assert.equal(ev.listeners.length, 0);

    function greeted (){
    };
    apiRoot.convAddListener([greeted], null, null, function () {
      apiRoot.convAddListener([greeted], null, null, function () {
        assert.equal(ev.listeners.length, 2);
        apiRoot.convRemoveListener(greeted, function () {
          assert.equal(ev.listeners.length, 0);
          done();
        });
      });
    });
  });

  it("Multiple connections", function (done) {
    assert.equal(ev.listeners.length, 0);
    function greeted1 (){
    };
    function greeted3 (){
    };
    function greeted2 (){
    };
    // + 1
    apiRoot.convAddListener([greeted1], null, null, function () {
      // + 2
      apiRoot.convAddListener([greeted2], null, null, function () {
        assert.equal(ev.listeners.length, 2);
        // -1
        apiRoot.convRemoveListener(greeted1, function () {
          assert.equal(ev.listeners.length, 1);
          // +3
          apiRoot.convAddListener([greeted3], null, null, function () {
            assert.equal(ev.listeners.length, 2);
            assert.equal(ev.listeners.length, apiRoot.messageApi.ports.length / 2);
            // -1 (no effect)
            apiRoot.convRemoveListener(greeted1, function () {
              assert.equal(ev.listeners.length, 2);
              // -3
              apiRoot.convRemoveListener(greeted3, function () {
                assert.equal(ev.listeners.length, 1);
                // -2
                apiRoot.convRemoveListener(greeted2, function () {
                  assert.equal(ev.listeners.length, 0);
                  done();
                });
              });
            });
          });
        });
      });
    });
  });

  it("Open/close style cleanups (based on first response)", function (done) {
    assert.equal(apiRoot.messageApi.ports.length / 2, 0);

    function afterOpen (ret) {
      assert.equal(apiRoot.messageApi.ports.length / 2, 1);
      assert.deepEqual(ret, {connectionId: 'hello'});
      var mr = new MethodRequest(
        'fakehostid',
        'device.close',
        [ret.connectionId, function (ret) {
          assert.equal(apiRoot.messageApi.ports.length / 2, 0);
          assert.equal(ret, true);
          done();
        }], true);
      mr.send(function (err) {
        assert(!err);
      });
    }
    var rev = {path: "device.close",
               type: "firstResponse", firstArgPath: 'connectionId'};
    var cli = new ClientConnection(
      "device.open", ["hello", afterOpen],
      rev,
      "fakehostid", 3,
      function (err) {
        assert(!err, err);
      });
  });

  it("Erroring connection", function (done) {
    var rev = {path: "device.close",
               type: "firstResponse",
               firstArgPath: 'connectionId'}, errored = false;
    var cli = new ClientConnection(
      "device.open", ["erroringDevice", function () {
        assert.equal([].slice.call(arguments).length, 0);
        assert(errored);
        done();
      }], rev, "fakehostid", 3,
      function (err) {
        assert(!err);
      }, null, function withError (err, cb) {
        errored = err; cb();
      });
  });
});
