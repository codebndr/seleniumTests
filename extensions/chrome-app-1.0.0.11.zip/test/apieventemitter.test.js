global.MESSAGING_METHOD = 'test';
var ApiEventEmitter = require('./../src/apieventemitter.js').ApiEventEmitter,
    Arguments = require('./../src/arguments.js').Arguments,
    ArgsResponse = require('./../src/responses.js').ArgsResponse,
    MethodRequest = require('./../src/requests.js').MethodRequest,
    assert = require('assert');

describe("Api event emitter", function() {
  var hostApi, methodCalled, rmethodCalled;

  beforeEach(function () {
    hostApi = {
      listener: null,
      setListener: function (cb) {
        assert(!this.listener);
        this.listener = cb;
      },
      unsetListener: function (cb) {
        assert(cb === this.listener, "Called with:" + cb +
               ".\nlistener is:" + this.listener);
        this.listener = "unset";
      },

      test: {
        method: function (hello, cb) {
          assert.equal(hello, "hello");
          methodCalled ++;
          for (var i = 0; i < 2; i++) {
            var resp = new ArgsResponse(new Arguments([{
              connectionId: 0xc0ffee + i
            }])).forSending();
            cb(resp);
            //setTimeout(cb.bind(null, resp), i * 50);
          }
        },
        rmethod: function (id, cb) {
          assert.equal(id, 0xc0ffee);
          rmethodCalled++;
        }
      }};
    methodCalled = 0;
    rmethodCalled = 0;
  });

  it("Base usage", function(done) {
    var callbackCalled = 0;
    function cont (id) {
      assert.equal(id.args[0].connectionId, 0xc0ffee + callbackCalled);
      if (++callbackCalled == 2) {
        aee.destroy();
        return;
      }

      assert(callbackCalled < 2,
             "Callback shouldn't be called more then twice" + callbackCalled);
    }
    var mr = {method: "test.method",
              args: new Arguments(['hello', cont]),
              forSending: function() {
                return "For teh luls";
              },
              call: function(send, hapi) {
                assert(hapi === aee.hostApi);
                assert(hapi.test.method, JSON.stringify(hapi));
                assert(hapi.test.rmethod, JSON.stringify(hapi));
                assert(this === mr);
                hapi.test.method.apply(hapi, this.args.forCalling());
              }},
        normalReverser = {path: 'test.rmethod',
                          type: 'firstResponse',
                          firstArgPath: 'connectionId'},
        aee = new ApiEventEmitter(mr, normalReverser, hostApi, function() {
          assert.deepEqual(aee.firstResponseMsg.args[0],
                           {connectionId: 0xc0ffee});
          assert.equal(methodCalled,1);
          assert.equal(callbackCalled,2);
          assert.equal(rmethodCalled,1);
          done();
        });

    assert(aee.hostApi === hostApi);
    assert(aee.hostApi.test);
    aee.fire();
  });

  it("correct callbacks", function (done) {
    function listener () {
      assert.equal(false);
    }

    function finalize () {
      assert.equal(hostApi.listener, "unset");
      done();
    }

    var mr = new MethodRequest.fromMessage(
          "testid",
          {method: 'setListener',
           args: [listener]},
          function () {
            assert(false, "Already called.");
          }),
        reverser = {path: 'unsetListener', type: 'callingArguments'},
        aee = new ApiEventEmitter(mr, reverser, hostApi, finalize);
    aee.fire();
    aee.destroy();
  });

});
