var dummy = require('../src/messaging/dummy.js'),
    apiRoot = require("./dummyapi.js"),
    s = require('../src/server.js'),
    c = require('../src/handlers.js'),
    assert = require('assert'),
    conf = apiRoot.state;

global.appIds = [APP_ID];

// var listeners = [], time = 100,
//     _to = setTimeout(function __toCb () {
//       listeners.forEach(function (l) {
//         l("hello listener called");
//       });
//       _to = setTimeout(__toCb, time);
//     }, time);


// chrome.test.listen = function (cb) {
//   listeners.push(cb);
// };
defaultConfig.methods.push("test.listen");
defaultConfig.reverseMethods['test.listen'] = {
  path: 'test.dontListen', type: 'callingArguments'
};

// chrome.test.dontListen = function (cb) {
//   listeners = listeners.filter(function (l) {
//     return l != cb;
//   });
// };
defaultConfig.methods.push("test.dontListen");

describe("Frontend handlers", function () {
  var api = {},
      connected = false,
      cleanUp;
  before(function (done) {
    apiRoot.runtime.getManifest = function () {return {version: '1.x.x.x'};};
    cleanUp = s.HostServer(apiRoot);
    c.setupClient(api, function () {
      connected = true;
      done();
    }, function () {
      assert(connected, "Should be able to connect.");
    }, function (err) {
      assert(false, "Should not be finding error:" + err);
    });
  });

  after(function () {
    cleanUp();
  });

  it("Second connection on same object", function (done) {
    var disconnected = false, connected = false;

    assert(api.local.token);
    c.setupClient(api, function () {
      assert(false, "Reconnecting should definitely not succeed");
    }, function () {
      assert(false, "Should get error before even trying.");
    }, function () {
      api.local.disconnect();
      assert(!api.local.token);
      c.setupClient(api, done);
    });
  });

  it("Natively make an API call.", function (done) {
    api.device.hello(function (str) {
      assert.equal(str, "test.hello called");
      api.device.hello(function (str) {
        assert.equal(str, "test.hello called");
        done();
      });
    });
  });

  it("Natively make an API call that connects.", function (done) {
    var cnt = 0;

    assert.equal(api.local.token.port.onDisconnect.listeners.length,
                 1);
    function counter (msg) {
      assert.equal(msg, "hello listener called");
      assert(cnt <= 4, "Did extra stuff" + cnt);
      if (cnt < 4) {
        assert.equal(api.local.getConnections().length, 1);
        assert(apiRoot.device.onReceive
               .listeners.some(function (l) {return counter.id == l.id;}));
      }

      if (cnt++ == 4) {
        conf.caller = function (cb) {};
        api.device.onReceive.removeListener(counter);
        // When you're done
        setTimeout(function () {
          assert(!apiRoot.device.onReceive
                 .listeners.some(function (l) {return l.id == counter.id;}));
          assert.equal(api.local.getConnections().length, 0);
          done();
        }, 200);
      }
    }

    api.device.onReceive.addListener(counter);
    conf.caller = function (cb) {
      cb("hello listener called");
    };
  });

  it("Api call that throws", function (done) {
    api.test.myThrowingMethod(function (arg) {
      assert(!arg);
      assert(api.runtime.lastError);
      done();
    });
  });

  it("Api call that sets lastError", function (done) {
    api.test.myErroringMethod(function (arg) {
      assert(!arg);
      assert(api.runtime.lastError);
      done();
    });
  });

  it("Setup client timeout", function (done) {
    var oldPost = dummy.Port.prototype.postMessage;
    dummy.Port.prototype.postMessage = function () {};

    var api = {};
    c.setupClient(api, function () {
      assert(false, "Should not connect");
    }, function() {
      assert(false, "Don't raise both error and disconnect.");
    }, function(err) {
      assert.equal(err, "timeout");
      dummy.Port.prototype.postMessage = oldPost;
      done();
    }, 10);
  });
});
