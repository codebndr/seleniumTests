global.MESSAGING_METHOD = 'test';

var r = require('../src/responses.js'),
    Arguments = require('../src/arguments.js').Arguments,
    MethodRequest = require('../src/requests.js').MethodRequest,
    util = require('../src/util.js'),
    assert = require('assert');

describe("Responses", function(done) {
  it("ACK", function() {
    var resp = new r.AckResponse();
    assert.deepEqual(resp.forSending(), {responseType: "AckResponse"});
    r.AckResponse(resp.forSending(), null, done);
  });

  it("arguments priori", function(done) {
    function cb () {
    }
    cb.id = 0xc0ffee;
    var resp = new r.ArgsResponse(new Arguments(["hello", cb]));
    assert.deepEqual(resp.forSending(), {
      responseType: 'ArgsResponse',
      args: [ 'hello', { id: 0xc0ffee, isCallback: true } ] });

    var cbCalled = false;
    r.ArgsResponse.maybeHandle(
      resp.forSending(),
      {
        getCallback: function () {
          cbCalled = true;
        }},
      function() {
        assert(cbCalled);
        done();
      });
  });

  it("arguments posteriori", function (done) {
    var mr = {call: function (cb, api) {
      assert.equal(api, "api");
      cb('args to pass to sendCb');
    }};
    var api = "api";
    var resp = new r.ArgsResponse.async(mr, api);

    mr.send = function () {
      assert(arguments);
    };

    resp.send(function sendCb (args) {
      assert.deepEqual(args, 'args to pass to sendCb');
      done();
    });
  });

  it("arguments databuffer", function(done) {
    r.ArgsResponse.maybeHandle(
      {"responseType":"ArgsResponse",
       "args":[
         {"data":{
           "data":[1,2,3],
           "isArrayBuffer":true}}
       ]}, {getCallback: function () {return function(arg) {
         assert(arg.data instanceof ArrayBuffer);
         assert.deepEqual(util.bufToArr(arg.data), [1,2,3]);
         done();
       }}});
  });

  it("Burst", function(done) {
    var argArray = [1,2,3];
    function cb (arg) {
      assert.equal(arg, argArray.shift());
      if (argArray.length == 0) done();
    }
    var argsBurst = argArray.map(function(a) {
      return new r.ArgsResponse(new Arguments([a])).forSending();
    });
    var resp = new r.BurstResponse(argsBurst, 2);
    r.BurstResponse.maybeHandle(
      resp.forSending(), {closed: false, getCallback: function() {
        return cb;
      }}, function () {});
  });

  it("Burst data", function(done) {
    var argArray = [[1],[2],[3]], called = false;
    function cb (arg) {
      assert(arg.data instanceof ArrayBuffer);
      assert.deepEqual(util.bufToArr(arg.data), [1,2,3]);
      assert(!called);
      called = true;
      setTimeout(done, 50);
    }
    var argsBurst = argArray.map(function(a) {
      var da = {data: util.arrToBuf(a)};
      return new r.ArgsResponse(new Arguments([da])).forSending();
    });
    var resp = new r.BurstResponse(argsBurst, 2);
    r.BurstResponse.maybeHandle(
      resp.forSending(), {closed: false, getCallback: function() {
        return cb;
      }}, function () {});
  });
});
