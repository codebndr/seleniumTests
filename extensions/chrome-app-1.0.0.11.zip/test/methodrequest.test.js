var apiRoot = require("./dummyapi.js"),
    MethodRequest = require('../src/requests.js').MethodRequest,
    HostServer = require('../src/server.js').HostServer,
    getConfig = require('../src/config.js').getConfig,
    assert = require('assert');

var buffer = new ArrayBuffer(8),
    view = new Int32Array(buffer);
view[0] = 100;

assert.bufferEqual = function (b1, b2, message) {
  var v1 = new Int32Array(b1),
      v2 = new Int32Array(b1);

  [].forEach.call(v1, function (v, i) {
    assert.equal(v, v2[i], "Unequal buffers:" + v1 + " != " + v2 +
                 "(index: " + i + ")");
  });
};

chrome.test = {};

describe("Method request", function () {
  var doneCb = null;
  function func (snull, shello, sundef, sbuffer) {
    assert.equal(snull, null);
    assert.equal(shello, "callback argument");
    doneCb();
  }

  var args = [null, "method argument", true, 17, func, buffer],
      fakeid = "fakehostid",
      mr = new MethodRequest(fakeid, "test.myMethod", args);

  var cleanUp;
  before(function () {
    cleanUp = HostServer(apiRoot);
  });

  after(function () {
    cleanUp();
  });
  it("Basic method calling", function (done) {
    doneCb = done;
    var forsend = mr.forSending();
    assert.deepEqual(JSON.parse(JSON.stringify(forsend)),
                     forsend, "Lossy methodrequest serialization");
    assert.strictEqual(mr.args.getCallback(), func);
    assert.strictEqual(mr.getCallback(), func);
    mr.send();
  });

  it("Creating from message shallow", function (done) {
    doneCb = assert.bind(null, false, "Shallow method requests have no callback");
    var shallowMr = MethodRequest.fromMessage("fakehostid", mr.forSending());
    assert.deepEqual(shallowMr.forSending(), mr.forSending());
    assert.notStrictEqual(
      shallowMr.args.getCallback(), func,
      "A true function was passed when we created from a serialized message.");

    shallowMr.send(function (err) {
      assert.equal(err.message, "No real callback provided on the client.");
      done();
    });
  });

  it("Creating from message with substitute", function (done) {
    doneCb = done;
    var realMr = MethodRequest.fromMessage(mr.hostId, mr.forSending(), func);
    assert.deepEqual(realMr.forSending(), mr.forSending());
    assert.strictEqual(
      realMr.getCallback(), func,
      "The method request was not passed the callback function correctlu.");

    realMr.send(function (err) {
      assert(
        !err,
        "Method requests from messages that are provided a cb shouldn't fail");
    });
  });

  it("Nonexistent method", function (done) {
    var errMr = new MethodRequest(fakeid, "test.nonexistentmethod", []);
    errMr.send(function (err) {
      assert.equal(err, "Method test.nonexistentmethod not found.");
      done();
    });
  });

  it("chrome.runtime.lastError", function (done) {
    var runtime = {lastError: null};
    function errHandle (arg) {
      assert(!arg, "Erroring function called args");
      assert.equal(chrome.runtime.lastError,
                   'Yo mama\'s fat ass is blocking the serial.');
      done();
    }
    var errMr = new MethodRequest(fakeid, "test.myErroringMethod", [errHandle],
                                  null);
    errMr.send(function (err) {
      runtime.lastError = err;
    });
  });

  it("More than one callbacks", function () {
    assert.throws(function () {
      new MethodRequest(fakeid, "test.doesntMatter",
                        [function () {}, function () {}],
                        null);
    });
  });

  it("With error method", function(done) {
    function withError (err, cb) {
      assert.equal(err, 'Method test.nonexistentmethod not found.');
      cb();
    }
    var mr = new MethodRequest (fakeid, "test.nonexistentmethod", [done], null, null, withError);
    mr.send();
  });

  it("Non-responsive app", function (done) {
    global.blockMessaging = true;
    function withError (err, cb) {
      assert.equal(err, 'Undefined message, probably host is disconnected.');
      cb();
    }

    function cb() {
      assert.deepEqual([].slice.call(arguments), []);
      global.blockMessaging = false;
      done();
    }
    new MethodRequest(fakeid, "test.doesntMatter", [cb], null, null, withError).send();
  });
});
