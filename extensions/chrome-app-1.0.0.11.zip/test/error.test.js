var e = require('./../src/error.js'),
    assert = require('assert');

describe("Error handling", function () {
  var apiRoot = {};
  afterEach(function () {
    assert.equal(typeof apiRoot.runtime.lastError, 'undefined');
  });

  it("lastError disappears", function () {
    e.withError(apiRoot, "a bad error", function () {
      assert.equal(apiRoot.runtime.lastError, "a bad error");
    });
  });

  it("No error", function () {
    e.withError(apiRoot, null, function () {
      assert.equal(apiRoot.runtime.lastError, null);
    });
  });

  it("Unchecked non error", function () {
    e.withError(apiRoot, null, function () {
    });
  });
});
