var assert = require('assert'),
    config = require('../src/config.js'),
    bsc = require('../src/bootstrapclient.js'),
    s = require('../src/server.js'),
    oldManifest, version = '0.1.2';

global.appIds = [global.APP_ID];
describe("config.test", function () {
  before(function () {
    oldManifest = bsc.getManifest;
    bsc.getManifest = function (cb) {
      cb({
        version: version,
        hostId: global.APP_ID
      });
    };
  });

  after(function () {
    bsc.getManifest = oldManifest;
  });

  it("good version", function (done) {
    // We are getting through the version checks (but noone is
    // listening)
    version = '1.xx.xx';
    config.getConfig(function () {
      assert(false, "We are not running a server so we shouldn't connect.");
    }, function () {
      assert(false, "The dummy api should accept the id so we shouldn't disconnect");
    }, function (err) {
      assert.equal(err, 'timeout', "There is nobody to respond really.");
      done();
    }, 0);
  });

  it("Bad version", function (done) {
    // We are failing the version check.
    version = '0.xx.xx';
    config.getConfig(function () {
      assert(false, "We are not running a server so we shouldn't connect.");
    }, function () {
      assert(false, "The dummy api should accept the id so we shouldn't disconnect");
    }, function (err) {
      assert.equal(err.badVersion, version, "There is nobody to respond really.");
      done();
    }, 0);
  });

  it("Smooth working", function (done) {
    version = '1.xx.xx';
    var hapi = {}, cleaning = false;
    var clean = s.HostServer(hapi);
    config.getConfig(function (config) {
      assert.equal(config.clientId, 0);
      assert.equal(config.hostId, global.APP_ID);
      assert.equal(config.version, version);
      assert(config.token.port);
      cleaning = true;
      clean();
      done();
    }, function () {
      assert(cleaning,
             "The dummy api should accept the id so we shouldn't disconnect");
    }, function (err) {
      assert(false, "We should be getting through:" + err);
    });
  });
});
