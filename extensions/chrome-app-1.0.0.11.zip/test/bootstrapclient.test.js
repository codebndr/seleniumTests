global.appIds = [global.APP_ID];
var assert = require('assert'),
    bsc = require('../src/bootstrapclient.js'),
    s = require('../src/server.js') ;


describe("bootstrapclient.test", function () {
  var cleanup, apiRoot;
  before(function () {
    apiRoot = {runtime: {getManifest: function () {
      return {version: '0.1'};
    }}};
    cleanup = s.HostServer(apiRoot);
  });
  after(function () {
    cleanup();
  });

  it('getState', function (done) {
    assert(apiRoot.babelfish.getState);
    assert.equal(bsc.messageApi.id, global.APP_ID);
    bsc.getState(global.APP_ID, function (state) {
      assert.deepEqual(state.connections, [], "No connections created");
      assert.deepEqual(state.keepalives, [], "No connections created");
      done();
    });
  });

  it('getState mock old app', function (done) {
    var tmp = s.messageApi.sendMessage;
    s.messageApi.sendMessage = function (id, msg, cb) {
      s.messageApi.sendMessage = tmp;
      assert.equal(id, global.APP_ID);
      assert.equal(msg.object, 'runtime');
      assert.equal(msg.method, 'getManifestAsync');
      cb({args: {args: [{val: "hello"}]}});
    };

    // Getstate can communicate with both old and new apps. Old apps
    // will just provide the manifest.
    bsc.getState(global.APP_ID, function (msg) {
      assert.equal(msg, "hello");
      done();
    });

  });

  it('getState over raw message', function (done) {
    assert.equal(global.APP_ID, s.messageApi.id);
    s.messageApi.sendMessage(global.APP_ID, {method: 'getState'}, function (resp) {
      assert.equal(resp.version, '0.1');
      done();
    });
  });

  it('getHostId', function (done) {
    global.appIds = ['hello', 'there'];
    bsc.getHostId(function (id, state) {
      assert(typeof id === 'undefined');
      assert(typeof state === 'undefined');
      global.appIds = ['hello', 'there', global.APP_ID];
      assert.equal(global.APP_ID, bsc.messageApi.id);

      bsc.getHostId(function (id, state) {
        assert(global.appIds.indexOf(global.APP_ID) != -1,
               global.APP_ID + " not in " + global.appIds);
        assert.equal(id, global.APP_ID);
        assert.equal(state.version, '0.1');
        done();
      });
    });
  });

  it("getManifest", function (done) {
    bsc.getManifest(function (m) {
      assert.deepEqual(m, { version: '0.1', connections: [], keepalives: [], hostId: global.APP_ID });
      done();
    });
  });
});
