global.MESSAGING_METHOD = 'test';
var messageApi = require("./../src/messaging.js"),
    assert = require('assert');

describe("Dummy message api", function () {
  afterEach(function () {
    messageApi.onConnectExternal.listeners = [];
    messageApi.onMessageExternal.listeners = [];
    messageApi.ports = [];
    assert(!global.blockMessaging);
  });

  it("Port disconnect on unavailability", function (done) {
    var port;

    // When the port is connected
    messageApi.onConnectExternal.addListener(function () {
      // Register disconnect condition for host
      port.otherPort.onDisconnect.addListener(function () {
        setTimeout(done, 50);
      });
      // Disconnect
      port.disconnect();
    });

    port = messageApi.connect(global.APP_ID, {name: 'port'});

    // Should never ondisconnect on the clinet.
    port.onDisconnect.addListener(function () {
      assert(false);
    });
  });

  it("Block messaging", function (done) {
    global.blockMessaging = true;
    var port = messageApi.connect(global.APP_ID, {name: 'port'});
    port.onDisconnect.addListener(function (dport) {
      assert(port === dport);
      global.blockMessaging = false;
      done();
    });
  });

  it("Block message handlers on false return", function (done) {
    var firstCall = 0;
    messageApi.onMessageExternal.addListener(function (msg, sender, resp) {
      assert.equal(msg, 'something');
      firstCall++;
      return true;
    });
    messageApi.onMessageExternal.addListener(function (msg, sender, resp) {
      assert.equal(firstCall, 1);
      assert.equal(msg, 'something');
      resp('second');
      return false;
    });
    messageApi.onMessageExternal.addListener(function (msg, sender, resp) {
      assert(false, "The previous listener returned false.");
    });
    messageApi.sendMessage(global.APP_ID, 'something', function (resp) {
      assert.equal(resp, 'second');
      done();
    });
  });
});
