var assert = require('assert'),
    messageApi = require('../src/messaging.js'),
    b = require('../src/bootstraphost.js');

describe("bootstraphost.test", function () {
  var bsh;
  beforeEach(function () {
    bsh = new b.BootstrapHost();
  });

  afterEach(function () {
    bsh.cleanup();
  });

  it("Listen on command", function (done) {
    bsh.commands.push(function (msg, respcb) {
      assert.equal(msg, "hello there");
      respcb('hi');
    });

    messageApi.sendMessage(global.APP_ID, "hello there", function (resp) {
      assert.deepEqual(resp, 'hi');
      done();
    });
  });

  it("Command priority", function (done) {
    bsh.commands.push(function (msg, respcb) {
      assert.equal(msg, "hello there");
      respcb('hi');
      // Block
      return false;
    });
    bsh.commands.push(function (msg, respcb) {
      assert(false);
    });

    messageApi.sendMessage(global.APP_ID, "hello there", function (resp) {
      assert.deepEqual(resp, 'hi');
      setTimeout(done);
    });
  });
});
