var Arguments = require('../src/arguments.js').Arguments,
    remoteApi = require("./dummyapi.js"),
    argumentFactory = require('../src/arguments.js').argumentFactory,
    assert = require('assert');

assert.bufferEqual = function (b1, b2) {
  function equal (buf1, buf2)
  {
    if (buf1.byteLength != buf2.byteLength) return false;
    var dv1 = new Int8Array(buf1);
    var dv2 = new Int8Array(buf2);
    for (var i = 0 ; i != buf1.byteLength ; i++)
    {
      if (dv1[i] != dv2[i]) return false;
    }
    return true;
  }

  assert(equal(b1, b2), "Buffers are not equal");
}

describe('Arguments', function () {
  function func () {
  }
  var args,
      buffer = new ArrayBuffer(8),
      rawArgs = [true, buffer, "hello", func];

  before(function () {
    var view = new Int32Array(buffer);
    view[0] = 0xdeadbeef;
    args = new Arguments(rawArgs);
  });

  it('Argument factory', function () {
    var funcArg = argumentFactory(func);
    assert.equal(funcArg.callback, func);
  });

  it('Serialization/deserialization', function () {

    function replace () {}
    var serialized = args.forSending(),
        newArgs = new Arguments(serialized, replace),
        reconstruct = newArgs.forCalling();

    serialized.forEach(function (a, i) {
      assert(a, "Undefined member " + i + " of " + serialized);
    });

    // Check that we can get elements one by one
    assert.strictEqual(args.getCallback(), func,
                       "Retrieved bad callback:" +
                       JSON.stringify(args.arguments[3].callback));
    assert.strictEqual(newArgs.getCallback(), replace,
                       "Retrieved bad callback:" +
                       JSON.stringify(newArgs.arguments[3].callback));

    // Check the reconstruction elements
    assert.equal(reconstruct[0], true,
                 "Failed reconstruction of arguments: " +
                 JSON.stringify(reconstruct));
    assert.bufferEqual(reconstruct[1], buffer,
                       "Failed reconstruction of arguments: " +
                       JSON.stringify(reconstruct));
    assert.equal(reconstruct[2], "hello",
                 "Failed reconstruction of arguments: " +
                 JSON.stringify(reconstruct));
    assert.strictEqual(reconstruct[3], replace,
                       "Failed reconstruction of arguments: " +
                       JSON.stringify(reconstruct));

    // Check that serialized is not cheating
    assert.deepEqual(JSON.parse(JSON.stringify(serialized)), serialized,
                     "Serialization is not real.");
  });

  it("Function ids", function () {
    function a () {}
    function b () {}

    assert.deepEqual(new Arguments([a]).forSending(),
                     new Arguments([a]).forSending());
    assert.notDeepEqual(new Arguments([b]).forSending(),
                        new Arguments([a]).forSending());
  });

  it("Advice", function() {
    var tokenCb = function () {};
    var args = new Arguments([tokenCb]);
    assert(args.forCalling()[0] === tokenCb);
    assert(args.getCallback() === tokenCb);
    args.setLens(function () {return "hello";});
    assert.deepEqual(args.forCalling(), ['hello']);
    assert(args.getCallback(), ['hello']);

  });
});
