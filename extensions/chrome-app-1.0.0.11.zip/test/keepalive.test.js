var dummy = require('../src/messaging/dummy.js'),
    apiRoot = require("./dummyapi.js"),
    MethodRequest = require('../src/requests.js').MethodRequest,
    s = require('../src/server.js'),
    getConfig = require('../src/config.js').getConfig,
    assert = require('assert');


describe("keepalive.test", function () {
  var cleanup;
  before(function () {
    assert.deepEqual(s.state.connections, []);
    assert.deepEqual(s.state.keepalives, []);
    s.state.uniqueId = 0;
    cleanup = s.HostServer(apiRoot);
  });

  after(function() {
    cleanup();
  });

  it("Create clients", function (done) {
    var testDone = false;
    function badDisconnect() {
      // Disconnect is called from cleanup
      assert(false, "disconnect callled from client should not trigger events");
    }

    s.getKeepAliveConnection("fakehostid", function (token1) {
      assert.equal(token1.clientId, 0);
      assert.equal(apiRoot.messageApi.ports.length/2, 1);
      s.getKeepAliveConnection("fakehostid", function (token2) {
        assert.equal(token2.clientId, 1);
        assert.equal(apiRoot.messageApi.ports.length/2, 2);
        s.getKeepAliveConnection("fakehostid", function (token3) {
          assert.equal(token3.clientId, 2);
          assert.equal(token3.port.onMessage.listeners.length, 0);
          assert.equal(token3.port.onDisconnect.listeners.length, 1);
          assert.equal(apiRoot.messageApi.ports.length/2, 3);

          // disconnecting does not trigger event on the same side it
          // was called.
          console.log("Disconnecting");
          token1.port.disconnect();
          token2.port.disconnect();
          token3.port.disconnect();
          done();
        }, badDisconnect);
      }, badDisconnect);
    }, badDisconnect);
  });

  it("Bad version", function (done) {
    var oldVersion = s.state.version;
    s.state.version = '0.200.1';
    s.getKeepAliveConnection("fakehostid", function () {
      assert(false, "Shouldn't connect with a bad ID at all");
    }, function (err) {
      assert.equal(err, "bad_version");
      s.state.version = oldVersion;
      done();
    });
  });

  it("Timeout", function (done) {
    var oldPost = dummy.Port.prototype.postMessage;
    dummy.Port.prototype.postMessage = function () {};

    s.getKeepAliveConnection("fakehostid", function () {
      assert(false, "Shouldn't connect with a bad ID at all");
    }, function (err) {
      assert.equal(err, "timeout");
      dummy.Port.prototype.postMessage = oldPost;
      setTimeout(function() {
        assert.deepEqual(s.state.keepalives, []);
        done();
      }, 10);
    }, 100);
  });
});
