global.MESSAGING_METHOD = 'test';

var messageApi = require('../src/messaging.js'),
    dummy = require('./../src/messaging/dummy.js'),
    assert = require('assert'),
    handlers = require('../src/handlers.js'),
    config = require('../src/config.js'),
    ClientConnection = require('./../src/clientconnection.js').ClientConnection,
    MethodRequest = require('./../src/requests.js').MethodRequest,
    state = {
      caller: function (cb) {
      },
      spamRate: 100
    };
defaultConfig.methods.push("test.myMethod");
defaultConfig.methods.push("test.myErroringMethod");
defaultConfig.methods.push("test.myThrowingMethod");
defaultConfig.methods.push("device.hello");
defaultConfig.methods.push("device.open");
defaultConfig.methods.push("device.close");
// defaultConfig.reverseMethods['serial.open'] =
//   {path: 'device.close', type: 'serial'},

// XXX: set config cleaners.
defaultConfig.methods.push("device.onReceive.removeListener");
defaultConfig.methods.push("device.onReceive.addListener");
defaultConfig.reverseMethods['device.onReceive.addListener'] =
  {path: 'device.onReceive.removeListener', type: 'callingArguments'},

defaultConfig.methods.push("device.onReceive.addErroringListener");
defaultConfig.methods.push("device.onReceiveError.addListener");
defaultConfig.methods.push("device.onReceiveError.removeListener");


function binToBuf(hex) {
  if (hex instanceof ArrayBuffer)
    return hex;

  var buffer = new ArrayBuffer(hex.length);
  var bufferView = new Uint8Array(buffer);
  for (var i = 0; i < hex.length; i++) {
    bufferView[i] = hex[i];
  }

  return buffer;
}

function bufToBin(buf) {
  if (!buf instanceof ArrayBuffer)
    return buf;

  var bufferView = new Uint8Array(buf);
  var hexes = [];
  for (var i = 0; i < bufferView.length; ++i) {
    hexes.push(bufferView[i]);
  }

  return hexes;
}

assert.bufferEqual = function (buf1, buf2) {
  assert.deepEqual(bufToBin(buf1), bufToBin(buf2));
};

function Device () {
  console.log("Creating device...");
  this.onReceiveError = new dummy.Event(false, 'device.onReceiveError');

  // Setup onreceive
  this.onReceive = new dummy.Event(false, 'device.onReceive');;
  this.onReceive.addErroringListener = function (cb) {
    throw new Error("A predictable error");
  };

  var self = this;
  setInterval(function () {
    state.caller(
      self.onReceive.trigger.bind(self.onReceive));
  }, state.spamRate);

  this.deviceInterval = null;
  this.openDevs = [];
};

Device.prototype = {
  open: function (device, cb) {
    if (device == 'erroringDevice') {
      throw Error('Opened erroring device');
    }

    var h = {connectionId: device};
    this.openDevs.push(h);
    cb(h);
  },

  close: function (id, cb) {
    var ret = !!this.openDevs.filter(function (d) {
      return d.connectionId != id;
    });
    this.openDevs = this.openDevs.filter(function (d) {
      return d.connectionId == id;
    });
    cb(ret);
  },

  hello: function (cb) {
    cb("test.hello called");
  }
};

function TestApi () {
  this.expectedBuffer = binToBuf([1,2,3]);
}
TestApi.prototype = {
  myThrowingMethod: function (cb) {
    throw new Error("This error was thrown");
    cb("Args should not reach the end");
  },

  myErroringMethod: function (cb) {
    chrome.runtime.lastError = "Yo mama's fat ass is blocking the serial.";
    cb("should not reach the end.");
  },

  myMethod: function( snull, shello, strue, s17, sfunc, sbuffer) {
    assert.equal(arguments.length, 6, "Argument number was wrong for API method call.");
    assert.equal(shello, "method argument");
    assert.equal(strue, true);
    assert.equal(snull, null);
    assert.equal(s17, 17);
    assert.bufferEqual(sbuffer, this.expectedBuffer);
    sfunc(null, "callback argument", undefined, sbuffer);
  }
};

function DummyApi () {
  console.log("Creating chrome mock instance.");
  this.device = new Device();
  this.test = new TestApi();

  // The ad-hoc methods.
  this.runtime = {};
  this.serial = {onReceiveError: {}};
  this.messageApi = messageApi;

  // State

  this.state = state;
}

DummyApi.prototype = {
  // Convenience methods
  convAddListener: function (args, path, reverser, done) {
    var defReverser = {path: "device.onReceive.removeListener",
                       type: "callingArguments"};
    return new ClientConnection(
      path || "device.onReceive.addListener", args,
      reverser || defReverser,
      global.APP_ID, 3,
      function (err) {
        assert(!err, err);
      }, done);
  },

  convRemoveListener: function (greeted, done) {
    var mr = new MethodRequest('fakehostid',
                               'device.onReceive.removeListener',
                               [greeted], true, true);
    mr.send(done);
  }
};

module.exports = new DummyApi();
