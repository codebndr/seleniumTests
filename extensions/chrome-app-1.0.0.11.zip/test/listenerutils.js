var assert = require('assert'),
    ClientConnection = require('../src/clientconnection.js').ClientConnection,
    MethodRequest = require('./../src/methodrequest.js').MethodRequest;

chrome.serial = {};
chrome.serial.onReceive = {};
chrome.serial.onReceive.addListener = function (cb) {
  status.listeners.push(cb.id);
  assert(cb instanceof Function, "Api event method called without arguments.");

  status.int = setInterval(function () {
    status.wrapper(cb);
  }, status.spamRate);
};

chrome.serial.onReceive.addErroringListener = function (cb) {
  throw new Error("A predictable error");
};

chrome.serial.onReceive.removeListener = function (cb) {
  status.listeners = status.listeners.filter(function (id) {return id != cb.id;});
  clearInterval(status.int);
};

chrome.serial.close = function (device, cb) {
  var h = {dev: device};
  chrome.serial.openDevs.push(h);
  cb(h);
};

chrome.serial.open = function (device, cb) {
  var h = {dev: device};
  chrome.serial.openDevs.push(h);
  cb(h);
};

function addListener (args, path, reverser, done) {
  var defReverser = {path: "serial.onReceive.removeListener",
                     type: "callingArguments"};
  return new ClientConnection(
    path || "serial.onReceive.addListener", args,
    reverser || defReverser,
    "fakehostid", 3,
    function (err) {
      assert(!err, err);
    }, done);
}

function removeListener (greeted, done) {
  var mr = new MethodRequest('fakehostid',
                             'serial.onReceive.removeListener',
                             [greeted], true);
  mr.send(function (err) {
    assert(!err);
    done();
  });
}
module.exports.addListener = addListener;
module.exports.removeListener = removeListener;
