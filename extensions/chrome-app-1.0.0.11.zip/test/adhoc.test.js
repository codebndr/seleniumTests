var assert = require('assert'),
    adhoc = require('../src/adhoc/host.js'), mockstate;

describe("Adhoc Methods", function () {
  before(function () {
    mockstate = {
      apiRoot: {
        runtime: {getManifest: function () {return {version: "1.0"};}}
      },

      bootstrapHost: {commands: []},

      connections: [{bufferLength: 10, portConf: {}, id: 10, closed: false}],
      keepalives: [{clientId: 10, portConf: {}, closed: false}]
    };
  });

  it("getState", function (done) {
    adhoc.setupAdHoc(mockstate);
    assert(mockstate.apiRoot.babelfish.getState);
    assert.deepEqual(mockstate.bootstrapHost.commands.length, 1);

    var command = mockstate.bootstrapHost.commands[0];
    command("hello", function () {
      assert(false, "Should not respond to anything but the expected stuff");
    });

    command({method: "getState", test: 123}, function (resp) {
      assert.equal(resp.version, '1.0');
      assert.equal(resp.connections.length, 1);
      done();
    });
  });
});
