(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
var server = require('./server.js'),
    srv = new server.HostServer(chrome);
window.api = server;
console.log("Serving...");

},{"./server.js":27}],2:[function(require,module,exports){
function isOldstyleGetManifest (message) {
  // Here is an exemplary oldstyle message:
  //
  // {
  //     timestamp: 1435930180385,
  //     object: "runtime",
  //     method: "getManifestAsync",
  //     args: {
  //       args: [{
  //         type: "function"
  //       }]
  //     },
  //     error: null,
  //     callbackId: 1435930180385,
  //     sender: 1435930180385
  //   }

  return message &&
    message.method == "getManifestAsync" &&
    message.object == "runtime" &&
    message.callbackId;
}


function getState (apiRoot, state, cb) {
  var formattedState = apiRoot.runtime.getManifest();
  formattedState.connections = state.connections.map(function (c) {
    return c && {
      bufferLength: c.bufferLength,
      conf: c.portConf,
      id: c.id,
      closed: c.closed
    };
  }),

  formattedState.keepalives = state.keepalives.map(function (k) {
    return k && {
      clientId: k.clientId,
      conf: k.portConf,
      closed: k.closed
    };
  }),

  cb(formattedState);
};

function setupAdHoc (state) {
  var apiRoot = state.apiRoot;

  // Remember to add these to the client configuration.
  if (apiRoot.runtime) {
    if (!apiRoot.babelfish) apiRoot.babelfish = {};
    apiRoot.babelfish.getState =
      apiRoot.runtime.getManifestAsync =
      getState.bind(null, apiRoot, state);


    // Listen for get state to non-babelfish or early babelfish.
    function provideState (msg, sendResp) {
      if (msg && (msg.method == "getState" || isOldstyleGetManifest(msg))) {
        apiRoot.babelfish.getState(sendResp);
        return false;
      }

      return true;
    };

    state.bootstrapHost.commands.push(provideState);
  }

  if (apiRoot.serial) {
    apiRoot.serial.onReceiveError.forceDispatch = function (info) {
      state.connections.forEach(function (c) {
        if (c.apiEvent.methodName == 'serial.onReceiveError.addListener') {
          c.apiEvent.methodRequest.realCallback().call(null, info);
        }
      });
    };
  }
}

module.exports.setupAdHoc = setupAdHoc;

},{}],3:[function(require,module,exports){
/**
 * @fileOverview A wrapper around a chrome api event or non-pure call
 * that needs cleaning up. Understands the currency of MethodRequests
 * for cleaning up and managing state and provides a unified interface
 * for cleaning any call based on client's instructions upon
 * connection.
 *
 * Due to usb.findDevices which opens multiple devices at once we may
 * need more than one cleanup methods to actually close the event
 * emitter.
 *
 * @name apieventemitter.js
 * @author Chris Perivolaropoulos
 */
var util = require("./util"),
    AckResponse = require('./responses.js').AckResponse,
    ArgsResponse = require('./responses.js').ArgsResponse,
    MethodRequest = require('./requests.js').MethodRequest,
    Arguments = require('./arguments.js').Arguments,
    log = new (require('./log.js').Log)('apieventemitter');


/**
 * Response methods to inject in an api depending on the closing type.
 */
var closingResponses = {
  callingArguments: function (closingRequest) {
    var method = util.path2callable(this.hostApi, this.reverser.path),
        args = this.methodRequest.args.forCalling();
    if (!closingRequest) {
      method.apply(null, args);
      return null;
    }

    if (this.reverser.path == closingRequest.method &&
        JSON.stringify(closingRequest.args.forSending()) ==
        JSON.stringify(this.methodRequest.args.forSending())) {
      method.apply(null, args);
      this.destroy(true);
      return new AckResponse();
    }

    return null;
  },

  /**
   * Maybe cleanup based on the arguments of the first callback.
   *
   * @param {undefined|MethodReqest} closingRequest A method request
   * that is supposed to close. If not provided make sure we are
   * destroyed as there is noone to report to.
   * @returns {null|ArgsResponse} The response to be sent after the cleanup.
   */
  firstResponse: function (closingRequest) {
    var fr = this.firstResponseMsg;
    if (!fr || fr.responseType != 'ArgsResponse') {
      return null;
    }

    var closingArg = fr.args[0];
    if (this.reverser.firstArgPath) {
      closingArg = closingArg[this.reverser.firstArgPath];
    }

    if (!closingRequest) {
      // Just do your best.
      var mr = new MethodRequest(null, this.reverser.path,
                                 new Arguments([closingArg, function () {}]));
      mr.call(null, this.hostApi);
      return null;
    }

    if (JSON.stringify(closingArg) ==
        JSON.stringify(closingRequest.args.forSending()[0]) &&
        closingRequest.method == this.reverser.path) {
      this.destroy(true);
      // The request will be called and will call an actual callback.
      return ArgsResponse.async(closingRequest, this.hostApi);
    }

    return null;
  },

  // Backwards compatible
  serial: function (closingRequest) {
    var oldfap = this.reverser.firstArgPath = 'connectionId';
    return closingResponses.firstResponse(closingRequest);
    this.reverser.firstArgPath = oldfap;
  },

  default: function (closingRequest) {
    return closingResponses.serial(closingRequest) ||
      closingResponses.firstResponse(closingRequest) ||
      closingResponses.callingArguments(closingRequest);
  }
};


/**
 * An Api event emitter or a method with side effects that need
 * cleaning up.
 *
 * @param {MethodRequest} methodRequest the information on how to call
 * the emitter
 * @param {ReverserObject} reverser a {path, type} reverser object.
 * @param {Object} hostApi The root of the host api.
 * @param {Function} closeCb Call this when closed
 */
function ApiEventEmitter (methodRequest, reverser, hostApi, closeCb) {
  var self = this;
  this.methodName = methodRequest.method;
  this.reverser = reverser;
  this.hostApi = hostApi;
  this.calledClosingRequests = [];

  // Remember the first response
  this.methodRequest = methodRequest;
  this.methodRequest.args.setLens(function (cb) {
    return function () {
      var args = [].slice.call(arguments);
      self.firstResponseMsg = self.firstResponseMsg || args[0];
      cb.apply(null, args);
    };
  });
  this.methodRequest.args.setLens = null;

  this.maybeRunCloser = function (closingRequest) {
    if (self.closed) {
      console.error("Trying to close a closed event emitter");
      return null;                 //THis shouldn;t happen
    }

    // Default to *some* way of handling responses.
    var closingResponseFactory = closingResponses[self.reverser.type] ||
          closingResponses.default,
        ret = closingResponseFactory.call(self, closingRequest);

    if (ret) {
      log.log("Closing[" + self.reverser.type + "]:", ret,
              "with", closingRequest);
    }
    return ret;
  };

  // Actually trigger the event.
  this.closeCb = closeCb;
}

ApiEventEmitter.prototype = {
  /**
   * Actually run the api event emitter.
   */
  fire: function () {
    this.methodRequest.call(null, this.hostApi);
  },

  /**
   * Call all the closing requests to close this event.
   * @param {Boolean} shallow True means the API part of destroying
   * has been handled.
   */
  destroy: function (shallow) {
    var self = this;
    // Closing this and the connection will create a loop so don't omit this.
    if (this.closed) return;
    if (!shallow) this.maybeRunCloser();
    this.closed = true;
    this.closeCb();
    log.log("Disconected:", this.methodRequest.forSending());
  },

  missingReverseCb: function () {
    throw new Error("No such method as " + this.methodName);
  },

  missingMethodCb: function () {
    throw new Error("No reverse method for " + this.methodName);
  }
};

module.exports.ApiEventEmitter = ApiEventEmitter;

},{"./arguments.js":4,"./log.js":13,"./requests.js":17,"./responses.js":21,"./util":29}],4:[function(require,module,exports){
/**
 * @fileOverview Abstractions for handling argument transformation for
 * transportation between host-client.
 * @name arguments.js
 * @author Chris Perivolaroulos
 */

// The sorting below will be reflected.
module.exports.CallbackArgument = require('./arguments/callback.js');
module.exports.DataArgument = require('./arguments/data.js');
module.exports.DatabufferArgument = require('./arguments/databuffer.js');
module.exports.BasicArgument = require('./arguments/basic.js');
module.exports.Arguments = require('./arguments/container.js');
module.exports.argumentFactory = require('./arguments/factory.js').argumentFactory;
module.exports.argumentClasses = require('./arguments/factory.js').argumentClasses;

},{"./arguments/basic.js":5,"./arguments/callback.js":6,"./arguments/container.js":7,"./arguments/data.js":8,"./arguments/databuffer.js":9,"./arguments/factory.js":10}],5:[function(require,module,exports){
var argumentClasses = require('./factory.js').argumentClasses;

/**
 * An already serializable argument boxer.
 * @param {argument} arg
 */
function BasicArgument(arg) {
  this.value = arg;
}
/**
 * Wether we can wrap. We assume we always can.
 * @param {anything} arg
 * @returns {Boolean} Always true.
 */
BasicArgument.canWrap = function (arg) {
  return true;
};

BasicArgument.prototype = {
  /**
   * @returns {anything} Just return the value.
   */
  forCalling: function () {
    return this.value;
  },

  /**
   * @returns {anything} Just return the value.
   */
  forSending: function () {
    return this.value;
  }
};
argumentClasses.push(BasicArgument);
module.exports = BasicArgument;

},{"./factory.js":10}],6:[function(require,module,exports){
var argumentClasses = require('./factory.js').argumentClasses;

/**
 * Wrap a callback. The callback will get an id. The arg's id (wether
 * function or object) preceeds the replaceCb id.
 *
 * @param {Function|Object} arg a serialized CallbackArgument or the
 * callback itself.
 * @param {Function} replaceCb if the provided arg was serialized
 * substitute it with this when asked for a callable.
 */
function CallbackArgument(arg, replaceCb) {
  if (!CallbackArgument.canWrap(arg)) {
    throw Error("Cant wrap argument " + arg + "as a function");
  }

  this.replaceCb = replaceCb || null;
  this.id = arg.id ||
    (this.replaceCb && this.replaceCb.id) ||
    Date.now() + Math.random();
  this.callback = arg instanceof Function ? arg : replaceCb;

  if (this.callback) {
    this.callback.id = this.id;
  }

  this.placeholder = {id: this.id, isCallback: true};
}

/**
 * Check if the argument is suitable for wrapping.
 *
 * @param {anything} arg
 * @returns {Boolean} True if it's safe to box with this type.
 */
CallbackArgument.canWrap = function (arg) {
  return arg && (arg instanceof Function || arg.isCallback);
};

CallbackArgument.prototype = {
  /**
   * @returns {Function } A callable that will either do the job on
   * the client, or send a message.
   */
  forCalling: function () {
    return this.lens ? this.lens(this.callback) : this.callback;
  },

  /**
   * @returns {Object} A serializable object.
   */
  forSending: function () {
    return this.placeholder;
  },

  setLens: function (lens) {
    this.lens = lens;
  }
};
argumentClasses.push(CallbackArgument);
module.exports = CallbackArgument;

},{"./factory.js":10}],7:[function(require,module,exports){
/**
 * @fileOverview Abstractions for handling argument transformation for
 * transportation between host-client.
 * @name container.js
 * @author Chris Perivolaroulos
 */

var CallbackArgument = require('./callback.js'),
    argumentFactory = require('./factory.js').argumentFactory;

/**
 * An wrapper around an arguments list that abstracts all
 * trasformations to serialize them, convert them to a callable state,
 * substitute callbacks with 'send response' callbakcs etc. We support
 * only one callback per Arguments object. This object will do the
 * right thing depending on whether weare on the host or the client.
 *
 * @param {Array} arguments An array of arguments either serialized or
 * not. The elements will be handled by argument types.
 * @param {Function} replaceCb The 'send request' callback typically
 * to substitute the callback in the arguments.
 */
function Arguments (arguments, replaceCb) {
  this.arguments = arguments.map(function (a) {
    return argumentFactory(a, replaceCb);
  });
}

Arguments.prototype = {
  /**
   * The argument list suitable for passing to an api method.
   * @returns {Array} An array of arguments as expected by the API
   */
  forCalling: function () {
    return this.arguments.map(function (a) {return a.forCalling();});
  },

  /**
   * The argument list suitable for sending over the message passing
   * api of chrome.
   * @returns {Array} The argument array serialized.
   */
  forSending: function () {
    return this.arguments.map(function (a) {
      return a.forSending();
    });
  },

  /**
   * Depending on wether we are on the client or the host get the
   * callback found in the arguments.
   *
   * @returns {Function} Either the 'send response' callback, or the
   * actual callback.
   */
  getCallback: function () {
    var cbArg = this.arguments.filter(function (a) {
      return a instanceof CallbackArgument;
    })[0],
        ret = cbArg ? cbArg.forCalling() : this.replaceCb;

    return ret;
  },

  setLens: function(lens) {
    if (this.replaceCb) {
      this.replaceCb = lens(this.replaceCb);
    }

    this.arguments.forEach(function(a) {
      if (a.setLens) a.setLens(lens);
    });
  }
};

module.exports = Arguments;

},{"./callback.js":6,"./factory.js":10}],8:[function(require,module,exports){
var argumentClasses = require('./factory.js').argumentClasses,
    DatabufferArgument = require('./databuffer.js');

function DataArgument(arg) {
  if (!DataArgument.canWrap(arg)) {
    throw new Error("Expected object like {data: ArrayBuffer}, got: ", arg);
  }
  this.arg = arg;
  this.data = new DatabufferArgument(arg.data);
}

DataArgument.canWrap = function (arg) {
  return arg instanceof Object &&
    DatabufferArgument.canWrap(arg.data);
};

DataArgument.prototype = {
  argCopy: function () {
    var ret = {}, self = this;
    Object.getOwnPropertyNames(this.arg).forEach(function (k) {
      ret[k] = self.arg[k];
    });

    return ret;
  },

  /**
   * @returns {Object} What the API expects or what is expected by
   * the API.
   */
  forCalling: function () {
    var ret = this.argCopy();
    ret.data = this.data.forCalling();
    return ret;
  },

  /**
   * @returns {Object} An serializable object that we can turn back
   * into a databuffer container.
   */
  forSending: function () {
    var ret = this.argCopy();
    ret.data = this.data.forSending();
    return ret;
  },

  concat: function (msg) {
    if (!msg.data || !msg.data.isArrayBuffer) return this;
    var ret = this.forSending();
    ret.data = this.data.concat(msg.data).forSending();
    return new DataArgument(ret);
  }
};
argumentClasses.push(DataArgument);
module.exports = DataArgument;

},{"./databuffer.js":9,"./factory.js":10}],9:[function(require,module,exports){
var argumentClasses = require('./factory.js').argumentClasses,
    util = require('../util.js');
/**
 * Boxing for databuffers.
 *
 * @param {DataBuffer|Object} arg Either a databuffer or a serialized
 * databuffer object.
 * @throws {Error} Protects you in case you forgot to call canWrap
 */
function DatabufferArgument(arg) {
  if (!DatabufferArgument.canWrap(arg)) {
    throw Error("Cant wrap argument " + arg + " as a databuffer");
  }

  this.buffer = arg instanceof ArrayBuffer ? arg : null;
  this.obj = arg.isArrayBuffer ? arg : null;
}

/**
 * Check if the object is eithe a databuffer or a serialized databuffer
 *
 * @param {anything} arg The object to check
 * @returns {Boolean} True if we can wrap.
 */
DatabufferArgument.canWrap = function (arg) {
  return arg && ((arg instanceof ArrayBuffer) || arg.isArrayBuffer);
};

DatabufferArgument.prototype = {
  /**
   * @returns {DataBuffer} What the API expects or what is expected by
   * the API.
   */
  forCalling: function () {
    return this.buffer || util.arrToBuf(this.obj.data);
  },

  /**
   * @returns {Object} An serializable object that we can turn back
   * into a DataBuffer.
   */
  forSending: function () {
    return this.obj || {data: util.bufToArr(this.buffer),
                        isArrayBuffer: true};
  },

  concat: function (msg) {
    if (!msg.isArrayBuffer) return this;
    var ret = this.forSending();
    ret.data = ret.data.concat(msg.data);
    return new DatabufferArgument(ret);
  }
};
argumentClasses.push(DatabufferArgument);
module.exports = DatabufferArgument;

},{"../util.js":29,"./factory.js":10}],10:[function(require,module,exports){
var argumentClasses = [];

/**
 * Choose the right *Argument type and create it for arg.
 * @param {anything} arg The raw argument
 * @param {Function} replacingCb A callback to replace arg if it is
 * serialized CallbackArgument.
 * @returns {*Argument} An argument in argumentClasses
 */
function argumentFactory(arg, replacingCb) {
  var classes = argumentClasses.filter(function (ac) {
    return ac.canWrap(arg);
  });

  // At least basic argument will be able to do this.
  return new classes[0](arg, replacingCb);
}

module.exports.argumentFactory = argumentFactory;
module.exports.argumentClasses = argumentClasses;

},{}],11:[function(require,module,exports){
var messageApi = require('./messaging.js');

function BootstrapHost () {
  this.commands = [];
  this.listener = null;
  this.listen();
}
BootstrapHost.prototype = {
  listen: function () {
    var self = this;
    this.listener = function (req, sender, sendResp) {
      // Block if a command sais false ->
      // Say false if some command sais false
      return self.commands.length == 0 || !self.commands.some(function (c) {
        return !c(req, sendResp);
      });
    };

    messageApi.onMessageExternal.addListener(this.listener);
  },

  cleanup: function () {
    messageApi.onMessageExternal.removeListener(this.listener);
  }
};
module.exports.BootstrapHost = BootstrapHost;

},{"./messaging.js":14}],12:[function(require,module,exports){
/**
 * @fileOverview Know when the client closes and also close if
 * orphaned.
 *
 * Common operations:
 * - closeMessage -> closeCall
 * - closeFn(openFn) = closefn
 *
 * Parameterized operation:
 * - closeArgs(closeFn, openArgs, callbackArgs)
 *
 * On connection open:
 * fromOpen(openFn, openArgs, callbackArgs) =
 *     fromClose(closeFn(openFn), closeArgs(closeFn, openArgs, callbackArgs)) =
 *     closeMessage -> closeCall
 *
 * On method:
 * fromClose(closeFn, closeArgs) = closeMessage -> closeCall
 * @name hostconnection.js
 * @author
 * @license
 */

var Arguments = require('./arguments.js').Arguments,
    MethodRequest = require('./requests.js').MethodRequest,
    ApiEventEmitter = require("./apieventemitter.js").ApiEventEmitter,
    r = require("./responses.js"),
    util = require("./util.js"),
    closed = [],
    log = new (require('./log.js').Log)('hostconnection');
require('./setimmediate.js');

/**
 * Method gets the args from the connection. Reverse just gets the
 * provided callback. There is one connection per event per callback
 * per client.
 *
 * There are 3 stages in the lifecycle of a connection
 *
 * - Init where the connection is initiated and the app event is
 *   triggered. Handled by the constructor and init.
 *
 * - Communication where the host pokes the client with a data ready
 *   (DTR) signal that there is data available, and the client requests
 *   for the available data with a separate one time request
 *
 * - Close where the DTR connection is closed and the listener is
 *   removed. Handled by close.
 *
 * @param {Port} port The port returned from onConnectExternal. The
 * name should be a json encoded object with
 *
 * - id: the connection id
 * - clientId: the id of the tab, generated by a KeepAliveConnetion
 * - methodRequest: An object called from MethodRequest.forSending
 * - reverse: A {path, type} object describing the reverser.
 *
 * @param {Function} closeCb Optionally a callback when the connection
 * closes. This should handle the cleanup of the connection for
 * external resources.
 */
function HostConnection (port, hostApi, closeCb) {
  var self = this;
  this.buffer = [];
  this.port = port;
  this.portConf = JSON.parse(port.name);
  this.id = this.portConf.id;
  this.closeCb = closeCb.bind(this);
  this.closed = false;

  // Will not be sent.
  var sendRaw = function (msg) {
    self.pushRequest(msg);
  };
  this.methodRequest = MethodRequest.fromMessage(
    null, this.portConf.methodRequestMsg, sendRaw);

  log.log("Opening connection:", this.repr());
  this.apiEvent = new ApiEventEmitter(this.methodRequest,
                                      this.portConf.reverser,
                                      hostApi,
                                      this.close.bind(this));
  this.port.onMessage.addListener(function (msg) {
    if (msg == "client created") {
      self.port.postMessage("ack");
      self.apiEvent.fire();
    }
  });
  log.log("Registering server side ondisconnect for method connection");
  this.port.onDisconnect.addListener(this.close.bind(this));
}

HostConnection.prototype = {
  repr: function () {
    return this.id +  " ( " + this.methodRequest.method + " )";
  },

  /**
   * Close the connection gracefully.
   */
  close: function () {
    if (this.closed) return;
    log.log("Closing connection:", this.repr());
    this.closed = true;
    this.port.disconnect();
    this.apiEvent.destroy();
    this.port = null;
    this.closeCb();
  },

  /**
   * Send an error message to the client over the connection port.
   *
   * @param {String} message The contents of the error.
   */
  sendError: function (message) {
    if (this.closed) return;

    this.port.postMessage(new r.ErrResponse(message).forSending());
    this.close();
  },

  /**
   * @param {Message} reqMsg A message that was to be called is
   * instead buffered.
   */
  pushRequest: function (reqMsg) {
    if (this.closed) return;

    if (reqMsg.responseType == "ErrResponse") {
      this.sendError(reqMsg.err);
    }

    // We expect they wont contain a function.
    if (!this.apiEvent.firstResponseMsg){
      this.apiEvent.firstResponseMsg = reqMsg;
    }

    if (this.buffer.length == 0){
      // To the end of the queue.
      setImmediate(this.setDtr.bind(this));
    }

    this.buffer.push(reqMsg);
    this.buffer.timestamp = Date.now();
  },

  /**
   * Notify the client that there is data to be read.
   */
  setDtr: function () {
    // This might be lef over on the queue.
    if (this.port)
      this.port.postMessage({timestamp: this.buffer.timestamp,
                             connection: this.id});
  },

  /**
   * Send the list of arguments accumulated.
   *
   * @param {Function} callback callback to accept the buffer of
   * Arguments objects.
   */
  flushBuffer: function (callback) {
    callback(this.buffer);
    this.buffer = [];
  },

  /**
   * Let the connection decide if it wants to apply a closing request
   * on itself.
   *
   * @param {MethodRequest|MethodRequestMessage} closingRequest the
   * request from the client that may be called.
   * @returns {null|AckResponse|ArgsResponse} True if we actually
   * called the request. We may still be open if we need more closing
   * requests to teminate. If the event emitter can call a callback
   * this is an ArgsResponse.
   */
  tryClosing: function (closingRequest) {
    if (this.closed) return false;
    var ret = this.apiEvent.maybeRunCloser(closingRequest);
    if (this.apiEvent.closed) {
      this.close();
    }
    return ret;
  }
};

module.exports.HostConnection = HostConnection;

},{"./apieventemitter.js":3,"./arguments.js":4,"./log.js":13,"./requests.js":17,"./responses.js":21,"./setimmediate.js":28,"./util.js":29}],13:[function(require,module,exports){
(function (global){
var timeOffset = Date.now();
global.debugBabelfish = false;

function zeroFill( number, width )
{
  width -= number.toString().length;
  if ( width > 0 )
  {
    return new Array( width + (/\./.test( number ) ? 2 : 1) ).join( '0' ) + number;
  }
  return number + ""; // always return a string
}

function Log (name, verbosity) {
  this.verbosity = verbosity || 1;
  this.name = name;
  this.resetTimeOffset();

  this.showTimes = false;
  this.error = this.console_('error', 0);
  this.warn = this.console_('warn', 1);
  this.info = this.console_('log', 2);
  this.log =  this.console_('log', 3);
}

Log.prototype = {
  timestampString: function () {
    var now = new Date(new Date() - timeOffset +
                       timeOffset.getTimezoneOffset() * 60000);
    var pad = function (n) {
      if (n < 10) { return "0" + n; }
      return n;
    };
    return pad(now.getHours()) + ":" + pad(now.getMinutes())
      + ":" + pad(now.getSeconds()) + "." + zeroFill(now.getMilliseconds(), 3);
  },

  resetTimeOffset: function () {
    timeOffset = new Date();
  },


  console_: function (type, verbosity) {
    var self = this;
    if (this.showTimes) {
      return function () {
        if (self.verbosity > verbosity || global.debugBabelfish) {
          return console[type].apply(console,
                                     [self.prefix()].concat(arguments));
        }
      };
    }
    if (this.verbosity > verbosity || global.debugBabelfish) {
      return console[type].bind(console, this.prefix());
    }
    return function () {};
  },


  prefix: function () {
    if (this.showTimes)
      return "[" + this.timestampString() +  " : " + this.name + "]";

    return "[" +this.name + "] ";
  }
};
module.exports.Log = Log;

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
//# sourceMappingURL=data:application/json;charset:utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxvZy5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsImZpbGUiOiJnZW5lcmF0ZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsidmFyIHRpbWVPZmZzZXQgPSBEYXRlLm5vdygpO1xuZ2xvYmFsLmRlYnVnQmFiZWxmaXNoID0gZmFsc2U7XG5cbmZ1bmN0aW9uIHplcm9GaWxsKCBudW1iZXIsIHdpZHRoIClcbntcbiAgd2lkdGggLT0gbnVtYmVyLnRvU3RyaW5nKCkubGVuZ3RoO1xuICBpZiAoIHdpZHRoID4gMCApXG4gIHtcbiAgICByZXR1cm4gbmV3IEFycmF5KCB3aWR0aCArICgvXFwuLy50ZXN0KCBudW1iZXIgKSA/IDIgOiAxKSApLmpvaW4oICcwJyApICsgbnVtYmVyO1xuICB9XG4gIHJldHVybiBudW1iZXIgKyBcIlwiOyAvLyBhbHdheXMgcmV0dXJuIGEgc3RyaW5nXG59XG5cbmZ1bmN0aW9uIExvZyAobmFtZSwgdmVyYm9zaXR5KSB7XG4gIHRoaXMudmVyYm9zaXR5ID0gdmVyYm9zaXR5IHx8IDE7XG4gIHRoaXMubmFtZSA9IG5hbWU7XG4gIHRoaXMucmVzZXRUaW1lT2Zmc2V0KCk7XG5cbiAgdGhpcy5zaG93VGltZXMgPSBmYWxzZTtcbiAgdGhpcy5lcnJvciA9IHRoaXMuY29uc29sZV8oJ2Vycm9yJywgMCk7XG4gIHRoaXMud2FybiA9IHRoaXMuY29uc29sZV8oJ3dhcm4nLCAxKTtcbiAgdGhpcy5pbmZvID0gdGhpcy5jb25zb2xlXygnbG9nJywgMik7XG4gIHRoaXMubG9nID0gIHRoaXMuY29uc29sZV8oJ2xvZycsIDMpO1xufVxuXG5Mb2cucHJvdG90eXBlID0ge1xuICB0aW1lc3RhbXBTdHJpbmc6IGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgbm93ID0gbmV3IERhdGUobmV3IERhdGUoKSAtIHRpbWVPZmZzZXQgK1xuICAgICAgICAgICAgICAgICAgICAgICB0aW1lT2Zmc2V0LmdldFRpbWV6b25lT2Zmc2V0KCkgKiA2MDAwMCk7XG4gICAgdmFyIHBhZCA9IGZ1bmN0aW9uIChuKSB7XG4gICAgICBpZiAobiA8IDEwKSB7IHJldHVybiBcIjBcIiArIG47IH1cbiAgICAgIHJldHVybiBuO1xuICAgIH07XG4gICAgcmV0dXJuIHBhZChub3cuZ2V0SG91cnMoKSkgKyBcIjpcIiArIHBhZChub3cuZ2V0TWludXRlcygpKVxuICAgICAgKyBcIjpcIiArIHBhZChub3cuZ2V0U2Vjb25kcygpKSArIFwiLlwiICsgemVyb0ZpbGwobm93LmdldE1pbGxpc2Vjb25kcygpLCAzKTtcbiAgfSxcblxuICByZXNldFRpbWVPZmZzZXQ6IGZ1bmN0aW9uICgpIHtcbiAgICB0aW1lT2Zmc2V0ID0gbmV3IERhdGUoKTtcbiAgfSxcblxuXG4gIGNvbnNvbGVfOiBmdW5jdGlvbiAodHlwZSwgdmVyYm9zaXR5KSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgIGlmICh0aGlzLnNob3dUaW1lcykge1xuICAgICAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgaWYgKHNlbGYudmVyYm9zaXR5ID4gdmVyYm9zaXR5IHx8IGdsb2JhbC5kZWJ1Z0JhYmVsZmlzaCkge1xuICAgICAgICAgIHJldHVybiBjb25zb2xlW3R5cGVdLmFwcGx5KGNvbnNvbGUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW3NlbGYucHJlZml4KCldLmNvbmNhdChhcmd1bWVudHMpKTtcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICB9XG4gICAgaWYgKHRoaXMudmVyYm9zaXR5ID4gdmVyYm9zaXR5IHx8IGdsb2JhbC5kZWJ1Z0JhYmVsZmlzaCkge1xuICAgICAgcmV0dXJuIGNvbnNvbGVbdHlwZV0uYmluZChjb25zb2xlLCB0aGlzLnByZWZpeCgpKTtcbiAgICB9XG4gICAgcmV0dXJuIGZ1bmN0aW9uICgpIHt9O1xuICB9LFxuXG5cbiAgcHJlZml4OiBmdW5jdGlvbiAoKSB7XG4gICAgaWYgKHRoaXMuc2hvd1RpbWVzKVxuICAgICAgcmV0dXJuIFwiW1wiICsgdGhpcy50aW1lc3RhbXBTdHJpbmcoKSArICBcIiA6IFwiICsgdGhpcy5uYW1lICsgXCJdXCI7XG5cbiAgICByZXR1cm4gXCJbXCIgK3RoaXMubmFtZSArIFwiXSBcIjtcbiAgfVxufTtcbm1vZHVsZS5leHBvcnRzLkxvZyA9IExvZztcbiJdfQ==
},{}],14:[function(require,module,exports){
(function (global){
var DummyRuntime = require('./messaging/dummy.js').DummyRuntime,
    ChromeMessaging = require('./messaging/chrome.js').ChromeMessaging;

/**
 * The messaging intefaces should implement
 *
 * - onConnectExternal
 * - onMessageExternal
 * - sendMessage
 * - connect
 *
 * That behave like tha chrome runtime messaging interface.
 */
var interfaces = {
  chrome: ChromeMessaging,
  test: DummyRuntime
};

if (!global.chrome ||
    !global.chrome.runtime ||
    !global.chrome.runtime.sendMessage) {
  global.MESSAGING_METHOD = 'test';
}

module.exports = new (interfaces[global.MESSAGING_METHOD || 'chrome'])();

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
//# sourceMappingURL=data:application/json;charset:utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1lc3NhZ2luZy5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsImZpbGUiOiJnZW5lcmF0ZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsidmFyIER1bW15UnVudGltZSA9IHJlcXVpcmUoJy4vbWVzc2FnaW5nL2R1bW15LmpzJykuRHVtbXlSdW50aW1lLFxuICAgIENocm9tZU1lc3NhZ2luZyA9IHJlcXVpcmUoJy4vbWVzc2FnaW5nL2Nocm9tZS5qcycpLkNocm9tZU1lc3NhZ2luZztcblxuLyoqXG4gKiBUaGUgbWVzc2FnaW5nIGludGVmYWNlcyBzaG91bGQgaW1wbGVtZW50XG4gKlxuICogLSBvbkNvbm5lY3RFeHRlcm5hbFxuICogLSBvbk1lc3NhZ2VFeHRlcm5hbFxuICogLSBzZW5kTWVzc2FnZVxuICogLSBjb25uZWN0XG4gKlxuICogVGhhdCBiZWhhdmUgbGlrZSB0aGEgY2hyb21lIHJ1bnRpbWUgbWVzc2FnaW5nIGludGVyZmFjZS5cbiAqL1xudmFyIGludGVyZmFjZXMgPSB7XG4gIGNocm9tZTogQ2hyb21lTWVzc2FnaW5nLFxuICB0ZXN0OiBEdW1teVJ1bnRpbWVcbn07XG5cbmlmICghZ2xvYmFsLmNocm9tZSB8fFxuICAgICFnbG9iYWwuY2hyb21lLnJ1bnRpbWUgfHxcbiAgICAhZ2xvYmFsLmNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKSB7XG4gIGdsb2JhbC5NRVNTQUdJTkdfTUVUSE9EID0gJ3Rlc3QnO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IG5ldyAoaW50ZXJmYWNlc1tnbG9iYWwuTUVTU0FHSU5HX01FVEhPRCB8fCAnY2hyb21lJ10pKCk7XG4iXX0=
},{"./messaging/chrome.js":15,"./messaging/dummy.js":16}],15:[function(require,module,exports){
/**
 * @fileOverview The chrome API message passing method.
 * @name chrome.js
 * @author Chris Perivolaropoulos
 */

function ChromeMessaging () {
  this.version = chrome.runtime.getManifest ?
    chrome.runtime.getManifest().version : "1" ;
  this.onConnectExternal = chrome.runtime.onConnectExternal;
  this.onMessageExternal = chrome.runtime.onMessageExternal;
  this.sendMessage = chrome.runtime.sendMessage.bind(chrome.runtime);
  this.connect = chrome.runtime.connect.bind(chrome.runtime);
}
module.exports.ChromeMessaging = ChromeMessaging;

},{}],16:[function(require,module,exports){
(function (global){
// XXX: If disconnect is too soon after the connect the actual
// connection may happen before disconnect.

/**
 * @fileOverview A loopback method mirroring chrome api.
 * @name dummy.js
 * @author Chris Perivolaropoulos
 */

global.APP_ID = global.APP_ID || "fakehostid";
// DEBUG: debug messages
// stackDebug: non async messaging.
var DEBUG = false, stackDebug = false;
var assert = require('assert'),
    maybeAsync = stackDebug ? function (cb) {cb();} : function (cb) {
      var err = new Error("Stack before async message");
      setTimeout(function () {
        try{
          cb();
        } catch (e) {
          console.log(e.stack);
          console.log(err.stack);
          throw err;
        }
      });
    },
    dbg = function () {};
if (DEBUG) {
  dbg = console.log.bind(console, '[dummy messager]');
}

function validateMessage(msg) {
  if (!msg || JSON.stringify(msg) == "{}") {
    throw new Error("Message should be something. Got:" + msg);
  }
}

function Event (jsonOnly, name, buffered) {
  this.listeners = [];
  this.removed = [];
  this.name = name;

  if (buffered) {
    this.buffer = [];
  }

  if (jsonOnly) {
    this.wrap = function (args) {
      return JSON.parse(JSON.stringify(args));
    };
  } else {
    this.wrap = function (a) {return a;};
  }
}

Event.prototype = {
  addListener: function (cb) {
    dbg('Adding listner: ' + cb.id + " to " + this.name);
    var self = this;
    this.listeners = this.listeners.concat([cb]);

    (this.buffer||[]).forEach(function (args) {
      maybeAsync(function () {
        self.listeners.some(function (l) {
          return !l.apply(null, args);
        });
      });
    });
  },

  removeListener: function (cb) {
    dbg('Removing listner: ' + cb.id + " from " + this.name +
        " (" + this.listeners.map(function (l) {return l.id;}) + " - " +
        this.removed + " )");
    this.listeners = this.listeners.filter(function (l) {
      var same = cb === l,
          sameIds = (cb.id && l.id && cb.id == l.id);
      return !(same || sameIds);
    });
  },

  trigger: function (varArgs) {
    var args = [].slice.call(arguments),
        self = this,
        listeners = this.listeners; //Make sure async does't fuck with listeners
    dbg('Triggering[' + this.listeners.length + ']: ' + this.name + "|" +
        ((args[0] instanceof Port) ? "<port>" : JSON.stringify(args)));

    if (this.buffer && this.listeners.length == 0) {
      this.buffer.push(args);
      return;
    }

    maybeAsync(function () {
      var tok = Math.random();
      listeners.some(function (l, i) {
        return l.apply(null, args) === false;
      });
    });

  }
};

function Runtime () {
  dbg('Creating runtime...');
  this.id = global.APP_ID;
  this.onConnectExternal = new Event(false, "onConnectExternal");
  this.onMessageExternal = new Event(true, "onMessageExternal");
  this.ports = [];
  this.version = "1.0";
}

Runtime.prototype = {
  sendMessage: function (hostId, message, cb) {
    var sender = null;

    validateMessage(message);
    assert(message);
    assert(hostId);
    if (hostId != this.id || global.blockMessaging) {
      maybeAsync(cb);
      return;
    }

    this.onMessageExternal.trigger(message, sender, cb);
  },

  connect: function (hostId, connectInfo) {
    var clientPort = new Port(connectInfo.name, this),
        self = this;
    assert.equal(hostId, this.id);

    if (global.blockMessaging) {
      setImmediate( function () {
        clientPort.onDisconnect.trigger(clientPort);
      });
      return clientPort;
    }

    maybeAsync(function () {
      self.onConnectExternal.trigger(clientPort.otherPort);
    });
    return clientPort;
  }
};

function Port (name, runtime, otherPort) {
  this.name = name;
  this.runtime = runtime;
  runtime.ports = runtime.ports.concat([this]);
  this.prefix = "Port" + (!otherPort ? "<client>" : "<host>");
  this.onDisconnect = new Event(false, this.prefix + ".onDisconnect");
  this.onMessage = new Event(true, this.prefix + ".onMessage", true);

  this.otherPort = otherPort || new Port(name, runtime, this);
  this.connected = true;
}

Port.prototype = {
  postMessage: function (msg) {
    validateMessage(msg);
    this.otherPort.onMessage.trigger(msg);
  },

  disconnect: function (forceListeners) {
    if (this.connected) {
      var self = this;
      this.runtime.ports = this.runtime.ports.filter(function (p) {
        return p !== self;
      });

      this.connected = false;
      this.onMessage.listeners = [];
      if (forceListeners){
        this.onDisconnect.trigger();
      }
      this.onDisconnect.listeners = [];
      this.otherPort.disconnect(true);
    }
  }
};

global.chrome = global.chrome || {runtime: {id: APP_ID}};

module.exports.DummyRuntime = Runtime;
module.exports.Event = Event;
module.exports.Port = Port;

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
//# sourceMappingURL=data:application/json;charset:utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1lc3NhZ2luZy9kdW1teS5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsImZpbGUiOiJnZW5lcmF0ZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsiLy8gWFhYOiBJZiBkaXNjb25uZWN0IGlzIHRvbyBzb29uIGFmdGVyIHRoZSBjb25uZWN0IHRoZSBhY3R1YWxcbi8vIGNvbm5lY3Rpb24gbWF5IGhhcHBlbiBiZWZvcmUgZGlzY29ubmVjdC5cblxuLyoqXG4gKiBAZmlsZU92ZXJ2aWV3IEEgbG9vcGJhY2sgbWV0aG9kIG1pcnJvcmluZyBjaHJvbWUgYXBpLlxuICogQG5hbWUgZHVtbXkuanNcbiAqIEBhdXRob3IgQ2hyaXMgUGVyaXZvbGFyb3BvdWxvc1xuICovXG5cbmdsb2JhbC5BUFBfSUQgPSBnbG9iYWwuQVBQX0lEIHx8IFwiZmFrZWhvc3RpZFwiO1xuLy8gREVCVUc6IGRlYnVnIG1lc3NhZ2VzXG4vLyBzdGFja0RlYnVnOiBub24gYXN5bmMgbWVzc2FnaW5nLlxudmFyIERFQlVHID0gZmFsc2UsIHN0YWNrRGVidWcgPSBmYWxzZTtcbnZhciBhc3NlcnQgPSByZXF1aXJlKCdhc3NlcnQnKSxcbiAgICBtYXliZUFzeW5jID0gc3RhY2tEZWJ1ZyA/IGZ1bmN0aW9uIChjYikge2NiKCk7fSA6IGZ1bmN0aW9uIChjYikge1xuICAgICAgdmFyIGVyciA9IG5ldyBFcnJvcihcIlN0YWNrIGJlZm9yZSBhc3luYyBtZXNzYWdlXCIpO1xuICAgICAgc2V0VGltZW91dChmdW5jdGlvbiAoKSB7XG4gICAgICAgIHRyeXtcbiAgICAgICAgICBjYigpO1xuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgY29uc29sZS5sb2coZS5zdGFjayk7XG4gICAgICAgICAgY29uc29sZS5sb2coZXJyLnN0YWNrKTtcbiAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0sXG4gICAgZGJnID0gZnVuY3Rpb24gKCkge307XG5pZiAoREVCVUcpIHtcbiAgZGJnID0gY29uc29sZS5sb2cuYmluZChjb25zb2xlLCAnW2R1bW15IG1lc3NhZ2VyXScpO1xufVxuXG5mdW5jdGlvbiB2YWxpZGF0ZU1lc3NhZ2UobXNnKSB7XG4gIGlmICghbXNnIHx8IEpTT04uc3RyaW5naWZ5KG1zZykgPT0gXCJ7fVwiKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiTWVzc2FnZSBzaG91bGQgYmUgc29tZXRoaW5nLiBHb3Q6XCIgKyBtc2cpO1xuICB9XG59XG5cbmZ1bmN0aW9uIEV2ZW50IChqc29uT25seSwgbmFtZSwgYnVmZmVyZWQpIHtcbiAgdGhpcy5saXN0ZW5lcnMgPSBbXTtcbiAgdGhpcy5yZW1vdmVkID0gW107XG4gIHRoaXMubmFtZSA9IG5hbWU7XG5cbiAgaWYgKGJ1ZmZlcmVkKSB7XG4gICAgdGhpcy5idWZmZXIgPSBbXTtcbiAgfVxuXG4gIGlmIChqc29uT25seSkge1xuICAgIHRoaXMud3JhcCA9IGZ1bmN0aW9uIChhcmdzKSB7XG4gICAgICByZXR1cm4gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShhcmdzKSk7XG4gICAgfTtcbiAgfSBlbHNlIHtcbiAgICB0aGlzLndyYXAgPSBmdW5jdGlvbiAoYSkge3JldHVybiBhO307XG4gIH1cbn1cblxuRXZlbnQucHJvdG90eXBlID0ge1xuICBhZGRMaXN0ZW5lcjogZnVuY3Rpb24gKGNiKSB7XG4gICAgZGJnKCdBZGRpbmcgbGlzdG5lcjogJyArIGNiLmlkICsgXCIgdG8gXCIgKyB0aGlzLm5hbWUpO1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICB0aGlzLmxpc3RlbmVycyA9IHRoaXMubGlzdGVuZXJzLmNvbmNhdChbY2JdKTtcblxuICAgICh0aGlzLmJ1ZmZlcnx8W10pLmZvckVhY2goZnVuY3Rpb24gKGFyZ3MpIHtcbiAgICAgIG1heWJlQXN5bmMoZnVuY3Rpb24gKCkge1xuICAgICAgICBzZWxmLmxpc3RlbmVycy5zb21lKGZ1bmN0aW9uIChsKSB7XG4gICAgICAgICAgcmV0dXJuICFsLmFwcGx5KG51bGwsIGFyZ3MpO1xuICAgICAgICB9KTtcbiAgICAgIH0pO1xuICAgIH0pO1xuICB9LFxuXG4gIHJlbW92ZUxpc3RlbmVyOiBmdW5jdGlvbiAoY2IpIHtcbiAgICBkYmcoJ1JlbW92aW5nIGxpc3RuZXI6ICcgKyBjYi5pZCArIFwiIGZyb20gXCIgKyB0aGlzLm5hbWUgK1xuICAgICAgICBcIiAoXCIgKyB0aGlzLmxpc3RlbmVycy5tYXAoZnVuY3Rpb24gKGwpIHtyZXR1cm4gbC5pZDt9KSArIFwiIC0gXCIgK1xuICAgICAgICB0aGlzLnJlbW92ZWQgKyBcIiApXCIpO1xuICAgIHRoaXMubGlzdGVuZXJzID0gdGhpcy5saXN0ZW5lcnMuZmlsdGVyKGZ1bmN0aW9uIChsKSB7XG4gICAgICB2YXIgc2FtZSA9IGNiID09PSBsLFxuICAgICAgICAgIHNhbWVJZHMgPSAoY2IuaWQgJiYgbC5pZCAmJiBjYi5pZCA9PSBsLmlkKTtcbiAgICAgIHJldHVybiAhKHNhbWUgfHwgc2FtZUlkcyk7XG4gICAgfSk7XG4gIH0sXG5cbiAgdHJpZ2dlcjogZnVuY3Rpb24gKHZhckFyZ3MpIHtcbiAgICB2YXIgYXJncyA9IFtdLnNsaWNlLmNhbGwoYXJndW1lbnRzKSxcbiAgICAgICAgc2VsZiA9IHRoaXMsXG4gICAgICAgIGxpc3RlbmVycyA9IHRoaXMubGlzdGVuZXJzOyAvL01ha2Ugc3VyZSBhc3luYyBkb2VzJ3QgZnVjayB3aXRoIGxpc3RlbmVyc1xuICAgIGRiZygnVHJpZ2dlcmluZ1snICsgdGhpcy5saXN0ZW5lcnMubGVuZ3RoICsgJ106ICcgKyB0aGlzLm5hbWUgKyBcInxcIiArXG4gICAgICAgICgoYXJnc1swXSBpbnN0YW5jZW9mIFBvcnQpID8gXCI8cG9ydD5cIiA6IEpTT04uc3RyaW5naWZ5KGFyZ3MpKSk7XG5cbiAgICBpZiAodGhpcy5idWZmZXIgJiYgdGhpcy5saXN0ZW5lcnMubGVuZ3RoID09IDApIHtcbiAgICAgIHRoaXMuYnVmZmVyLnB1c2goYXJncyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgbWF5YmVBc3luYyhmdW5jdGlvbiAoKSB7XG4gICAgICB2YXIgdG9rID0gTWF0aC5yYW5kb20oKTtcbiAgICAgIGxpc3RlbmVycy5zb21lKGZ1bmN0aW9uIChsLCBpKSB7XG4gICAgICAgIHJldHVybiBsLmFwcGx5KG51bGwsIGFyZ3MpID09PSBmYWxzZTtcbiAgICAgIH0pO1xuICAgIH0pO1xuXG4gIH1cbn07XG5cbmZ1bmN0aW9uIFJ1bnRpbWUgKCkge1xuICBkYmcoJ0NyZWF0aW5nIHJ1bnRpbWUuLi4nKTtcbiAgdGhpcy5pZCA9IGdsb2JhbC5BUFBfSUQ7XG4gIHRoaXMub25Db25uZWN0RXh0ZXJuYWwgPSBuZXcgRXZlbnQoZmFsc2UsIFwib25Db25uZWN0RXh0ZXJuYWxcIik7XG4gIHRoaXMub25NZXNzYWdlRXh0ZXJuYWwgPSBuZXcgRXZlbnQodHJ1ZSwgXCJvbk1lc3NhZ2VFeHRlcm5hbFwiKTtcbiAgdGhpcy5wb3J0cyA9IFtdO1xuICB0aGlzLnZlcnNpb24gPSBcIjEuMFwiO1xufVxuXG5SdW50aW1lLnByb3RvdHlwZSA9IHtcbiAgc2VuZE1lc3NhZ2U6IGZ1bmN0aW9uIChob3N0SWQsIG1lc3NhZ2UsIGNiKSB7XG4gICAgdmFyIHNlbmRlciA9IG51bGw7XG5cbiAgICB2YWxpZGF0ZU1lc3NhZ2UobWVzc2FnZSk7XG4gICAgYXNzZXJ0KG1lc3NhZ2UpO1xuICAgIGFzc2VydChob3N0SWQpO1xuICAgIGlmIChob3N0SWQgIT0gdGhpcy5pZCB8fCBnbG9iYWwuYmxvY2tNZXNzYWdpbmcpIHtcbiAgICAgIG1heWJlQXN5bmMoY2IpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHRoaXMub25NZXNzYWdlRXh0ZXJuYWwudHJpZ2dlcihtZXNzYWdlLCBzZW5kZXIsIGNiKTtcbiAgfSxcblxuICBjb25uZWN0OiBmdW5jdGlvbiAoaG9zdElkLCBjb25uZWN0SW5mbykge1xuICAgIHZhciBjbGllbnRQb3J0ID0gbmV3IFBvcnQoY29ubmVjdEluZm8ubmFtZSwgdGhpcyksXG4gICAgICAgIHNlbGYgPSB0aGlzO1xuICAgIGFzc2VydC5lcXVhbChob3N0SWQsIHRoaXMuaWQpO1xuXG4gICAgaWYgKGdsb2JhbC5ibG9ja01lc3NhZ2luZykge1xuICAgICAgc2V0SW1tZWRpYXRlKCBmdW5jdGlvbiAoKSB7XG4gICAgICAgIGNsaWVudFBvcnQub25EaXNjb25uZWN0LnRyaWdnZXIoY2xpZW50UG9ydCk7XG4gICAgICB9KTtcbiAgICAgIHJldHVybiBjbGllbnRQb3J0O1xuICAgIH1cblxuICAgIG1heWJlQXN5bmMoZnVuY3Rpb24gKCkge1xuICAgICAgc2VsZi5vbkNvbm5lY3RFeHRlcm5hbC50cmlnZ2VyKGNsaWVudFBvcnQub3RoZXJQb3J0KTtcbiAgICB9KTtcbiAgICByZXR1cm4gY2xpZW50UG9ydDtcbiAgfVxufTtcblxuZnVuY3Rpb24gUG9ydCAobmFtZSwgcnVudGltZSwgb3RoZXJQb3J0KSB7XG4gIHRoaXMubmFtZSA9IG5hbWU7XG4gIHRoaXMucnVudGltZSA9IHJ1bnRpbWU7XG4gIHJ1bnRpbWUucG9ydHMgPSBydW50aW1lLnBvcnRzLmNvbmNhdChbdGhpc10pO1xuICB0aGlzLnByZWZpeCA9IFwiUG9ydFwiICsgKCFvdGhlclBvcnQgPyBcIjxjbGllbnQ+XCIgOiBcIjxob3N0PlwiKTtcbiAgdGhpcy5vbkRpc2Nvbm5lY3QgPSBuZXcgRXZlbnQoZmFsc2UsIHRoaXMucHJlZml4ICsgXCIub25EaXNjb25uZWN0XCIpO1xuICB0aGlzLm9uTWVzc2FnZSA9IG5ldyBFdmVudCh0cnVlLCB0aGlzLnByZWZpeCArIFwiLm9uTWVzc2FnZVwiLCB0cnVlKTtcblxuICB0aGlzLm90aGVyUG9ydCA9IG90aGVyUG9ydCB8fCBuZXcgUG9ydChuYW1lLCBydW50aW1lLCB0aGlzKTtcbiAgdGhpcy5jb25uZWN0ZWQgPSB0cnVlO1xufVxuXG5Qb3J0LnByb3RvdHlwZSA9IHtcbiAgcG9zdE1lc3NhZ2U6IGZ1bmN0aW9uIChtc2cpIHtcbiAgICB2YWxpZGF0ZU1lc3NhZ2UobXNnKTtcbiAgICB0aGlzLm90aGVyUG9ydC5vbk1lc3NhZ2UudHJpZ2dlcihtc2cpO1xuICB9LFxuXG4gIGRpc2Nvbm5lY3Q6IGZ1bmN0aW9uIChmb3JjZUxpc3RlbmVycykge1xuICAgIGlmICh0aGlzLmNvbm5lY3RlZCkge1xuICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgICAgdGhpcy5ydW50aW1lLnBvcnRzID0gdGhpcy5ydW50aW1lLnBvcnRzLmZpbHRlcihmdW5jdGlvbiAocCkge1xuICAgICAgICByZXR1cm4gcCAhPT0gc2VsZjtcbiAgICAgIH0pO1xuXG4gICAgICB0aGlzLmNvbm5lY3RlZCA9IGZhbHNlO1xuICAgICAgdGhpcy5vbk1lc3NhZ2UubGlzdGVuZXJzID0gW107XG4gICAgICBpZiAoZm9yY2VMaXN0ZW5lcnMpe1xuICAgICAgICB0aGlzLm9uRGlzY29ubmVjdC50cmlnZ2VyKCk7XG4gICAgICB9XG4gICAgICB0aGlzLm9uRGlzY29ubmVjdC5saXN0ZW5lcnMgPSBbXTtcbiAgICAgIHRoaXMub3RoZXJQb3J0LmRpc2Nvbm5lY3QodHJ1ZSk7XG4gICAgfVxuICB9XG59O1xuXG5nbG9iYWwuY2hyb21lID0gZ2xvYmFsLmNocm9tZSB8fCB7cnVudGltZToge2lkOiBBUFBfSUR9fTtcblxubW9kdWxlLmV4cG9ydHMuRHVtbXlSdW50aW1lID0gUnVudGltZTtcbm1vZHVsZS5leHBvcnRzLkV2ZW50ID0gRXZlbnQ7XG5tb2R1bGUuZXhwb3J0cy5Qb3J0ID0gUG9ydDtcbiJdfQ==
},{"assert":30}],17:[function(require,module,exports){
module.exports.BurstRequest = require('./requests/burst.js').BurstRequest;
module.exports.GenericRequest = require('./requests/generic.js').GenericRequest;
module.exports.MethodRequest = require('./requests/method.js').MethodRequest;

},{"./requests/burst.js":18,"./requests/generic.js":19,"./requests/method.js":20}],18:[function(require,module,exports){
/**
 * @fileOverview A request by the client to receive a burst of
 * requests from an api emitter. This is initially triggered by a data
 * ready signal via a connection from the host. When the client
 * receives it they send a BurstRequest when they are ready to receive
 * the data. The main reason for this is that sending messages is
 * quite expensive and we want to bundle them together as much as
 * possible when an event emmitter spams.
 * @name burstrequest.js
 * @author Chris Perivolaropoulos
 */
var Arguments = require('./../arguments.js').Arguements,
    log = new (require('./../log.js').Log)('burstrequest'),
    GenericRequest = require('./generic.js').GenericRequest,
    ErrResponse = require('./../responses.js').ErrResponse,
    BurstResponse = require('./../responses.js').BurstResponse;

/**
 * A request for a burst of callbacks that are destined for the
 * client from a connection.
 *
 * @param {String} hostId The chrome app id.
 * @param {ClientConnection} connection the connection that holds the
 * callback arguments.
 * @param {Function} callback The event callback raw.
 */
function BurstRequest (hostId, connection, callback) {
  this.hostId = hostId;
  this.connection = connection;
  this.callback = callback;
  this.blocked = false;
}

/**
 * Handle a request for a burst on the server. If the message doesn't
 * seem valid, disregard it.
 *
 * @param {ApiMessage} msg The message as taken from the send
 * function, ie the forSending method.
 * @param {Array(HostConnections)} connections An array of connections
 * @param {Function(msg, sender, sendResp)} sendRespRaw callback to
 * send response.
 * @return {Boolean} True if we handled it.
 */
BurstRequest.maybeHandle = function (msg, connections, sendRespRaw) {
  if (msg.requestType !=  "BurstRequest") {
    return false;
  };
  var usefulCons = connections.filter(function (c) {
    return msg.connId == c.id;
  });

  if (usefulCons.length != 1) {
    var errMsg = "Burst request for connection " + msg.connId + " corresponds to " +
          usefulCons.length + " connections",
        errResp = new ErrResponse(errMsg);
    errResp.send(sendRespRaw);
    return true;
  }

  function sendBuffer (buf) {
    var br = new BurstResponse(buf, msg);
    br.send(sendRespRaw);
  }

  usefulCons[0].flushBuffer(sendBuffer);
  return true;
};

BurstRequest.prototype = Object.create(GenericRequest.prototype);

/**
 * Create a serializable object to send over the API.
 * @returns {Message} a serialized messae
 */
BurstRequest.prototype.forSending = function () {
  return {requestType: "BurstRequest",
          connId: this.connection.id};
};

/**
 * Get the callback from the arguments. Will only work on the client
 *
 * @returns {Function} the callback or undefined.
 */
BurstRequest.prototype.getCallback = function () {
  return this.callback;
};

module.exports.BurstRequest = BurstRequest;

},{"./../arguments.js":4,"./../log.js":13,"./../responses.js":21,"./generic.js":19}],19:[function(require,module,exports){
var genericRespHandler = require('./../responses.js').genericRespHandler,
    messageApi = require("./../messaging.js"),
    log = new (require('./../log.js').Log)('genericrequest');

/**
 * A generic request to inherit new ones from. Make sure you define
 * hostId property in your classes and also define a forSending.
 */
function GenericRequest() {};

GenericRequest.prototype = {
  /**
   * Create a serializable object to send over the API.
   * @returns {Message} a serialized messae
   */
  forSending: function () {
    throw Error("forSending not implemented.");
  },

  /**
   * Send the request and handle the response.
   * @param {Function} cb Called when handling is finished. No
   * arguments in case it succeeds, an error object if it failes
   */
  send: function (cb, errorCb) {
    var self = this,
        msg = this.forSending(),
        hostId = this.hostId;

    messageApi.sendMessage(
      hostId, msg, function (resp) {
        genericRespHandler(resp, self,
                           cb || function (err) {
                             if (err) {
                               throw err;
                             };
                           });
      });
  }
};
module.exports.GenericRequest = GenericRequest;

},{"./../log.js":13,"./../messaging.js":14,"./../responses.js":21}],20:[function(require,module,exports){
var Arguments = require("./../arguments.js").Arguments,
    GenericRequest = require('./generic.js').GenericRequest,
    util = require("./../util"),
    ArgsResponse = require("./../responses.js").ArgsResponse,
    ErrResponse = require("./../responses.js").ErrResponse,
    AckResponse = require("./../responses.js").AckResponse,
    log = new (require('./../log.js').Log)('methodrequest');


function isNode () {
  if (typeof window === 'undefined') return true;

  var backup = window,
      window_can_be_deleted = delete window;
  window = backup; // Restoring from backup

  return window_can_be_deleted;
}

/**
 * A request from the client to resolve a method call. Also handles
 * the response.
 *
 * @param {String} hostId The app id. Could be null if you dont intend
 * to send it.
 * @param {String} method The method to be called.
 * @param {Array|Arguments} args The real argument list or a wrapped
 * arguments object.
 * @param {Boolean} isReverser Wether this method request is supposed
 * to revert the side effects of a previous request.
 * @param {Boolean} noCallback true means that host should reply with
 * AckResponse.
 * @param {Function} withError Wrapper to handle errors.
 */
function MethodRequest (hostId, method, args, isReverser, noCallback, withError) {
  this.method = method;
  this.args = args instanceof Arguments ? args :
    new Arguments(args);
  this.hostId = hostId;
  this.isReverser = isReverser || false;
  this.noCallback = noCallback || false;
  this.withError = withError;
  // Node seems to display errors even if we don't throw them and it
  // gets really annoying
  if (!isNode()) {
    this.trace = (new Error()).stack;
  }

  if (this.args.forSending().filter(function (a) {
    return !!(a && a.isCallback);
  }).length > 1) {
    throw Error("We do not support more than one callback in arguments.");
  }
}

MethodRequest.prototype = Object.create(GenericRequest.prototype);

/**
 * Create a method request from a message. When a callback is provided
 * it will be used.
 *
 * @param {String} hostId The host to send the requset. Set this to
 * null if it's just for comparing or for invoking it's callback
 * (generally if you are on the host side.)
 * @param {Message} msg A message as generated by forSending()
 * @param {Function} respCb Raw send response callback.
 * @returns {MethodRequest} A method request.
 */
MethodRequest.fromMessage = function (hostId, msg, respCb) {
  var args = new Arguments(msg.args, respCb);
  return new MethodRequest(hostId, msg.method, args);
};

/**
 * If the message is a request to close a connection (reverser)
 *
 * @param {Message} msg A message generated by a MethodRequest.
 * @param {Array(HostConnection)} connections a list of open connections.
 * @param {Function} sendRespRaw Callback to send a raw message.
 * @param {Boolean} force This is a reverser even if id doesn't look
 * like it.
 * @returns {Boolean} True if we handled it.
 */
function handleReverser (msg, connections, hostApi) {
  if (!connections && !msg.isReverser) return false;
  var req = MethodRequest.fromMessage(null, msg),
      response = connections
        .map(function (c) {
          return c.tryClosing(req);
        }).reduce(function (a, b) {
          return a || b;
        }, false);

  // We won't get a response for args that don't raise a callback.
  if (msg.isReverser && !response) {
    console.warn(
      "You told me " + JSON.stringify(msg) +
        " was a reverser but i found nothing to reverse.");
    if (msg.noCallback) {
      // Trust the user knows what they are doing
      req.call(null, hostApi);
      return new ErrResponse("Tried to clean with " + msg.method + " but failed.",
                             "warning");
    }

    // There may be a callback waiting.
    return ArgsResponse.async(req, hostApi);
  }

  return response;
}

/**
 * Handle the request on the server. Try to run the method and
 * generate a *Response, serialize it and send it over the
 * sendRespApi. If the message doesn't seem valid, disregard it.
 *
 * @param {Message} msg A message generated by a MethodRequest.
 * @param {Array(HostConnection)} connections a list of open connections.
 * @param {hostApiObject} hostApi chrome API likae object where the
 * requrest method is based.
 * @param {Function} sendRespRaw Callback to send a raw message.
 * @returns {Boolean} True if we handled it.
 */
var messagesReceived = 0;
MethodRequest.maybeHandle = function (msg, hostApi, sendRespRaw, kw) {
  kw = kw || {};
  var _sendRespRaw = function (sendMsg) {
    if ((++messagesReceived) % 1000 == 0) {
      log.log("Sending 1000 messages");
    }

    if (sendMsg.responseType == "ErrResponse") {
      console.error(msg, "->", sendMsg);
    }

    sendRespRaw(sendMsg);
  };

  if (msg.requestType != "MethodRequest") {
    return false;
  }

  var resp = handleReverser(msg, kw.connections, hostApi);
  if (resp) {
    resp.send(_sendRespRaw);
    return true;
  }

  sendRespRaw = sendRespRaw || function () {};
  var sendArgsAsResponse = function (varArgs) {
    var argsArr = [].slice.call(arguments),
        cbArgs = new Arguments(argsArr),
        argsResp = new ArgsResponse(cbArgs);

    // Internal api error
    if (chrome &&
        chrome.runtime &&
        chrome.runtime.lastError &&
        argsArr.length == 0) {
      new ErrResponse(chrome.runtime.lastError,
                      'chrome.runtime.lastError')
        .send(_sendRespRaw);
      return true;
    }

    // Everything went well.
    argsResp.send(_sendRespRaw);
  }, methodArgs = new Arguments(msg.args, sendArgsAsResponse),
      methodCb = util.path2callable(hostApi, msg.method);

  // Bad path received.
  if (!methodCb) {
    resp = new ErrResponse("Method " + msg.method + " not found.");
    resp.send(_sendRespRaw);
    return true;
  }

  try {
    // All went well
    if (kw.updateArgs) kw.updateArgs(methodArgs);
    methodCb.apply(null, methodArgs.forCalling());
    return true;
  } catch (e) {
    resp = new ErrResponse({message: "Error on calling " + msg.method + ":"
                            + e.message,
                            stack: e.stack},
                           'chrome.runtime.lastError');
    resp.send(_sendRespRaw);
    return true;
  }

  // We know this method wont bring up a callback.
  if (msg.noCallback) {
    new AckResponse().send(_sendRespRaw);
    return true;
  }
};

/**
 * @returns {Object} Serializable object to communicate with the server.
 */
MethodRequest.prototype.forSending = function () {
  var ret = {requestType: "MethodRequest",
             method: this.method,
             args: this.args.forSending(),
             noCallback: this.noCallback,
             isReverser: this.isReverser
            };
  return ret;

};

/**
 * Run this method request. This will not handle reversers.
 */
MethodRequest.prototype.call = function (sendResp, hostApi) {
  var self = this;
  function updateArgs (args) {
    self.args = args;
  }
  MethodRequest.maybeHandle(this.forSending(),
                            hostApi,
                            sendResp || this.getCallback(),
                            {updateArgs: updateArgs});
};

/**
 * Get the callback from the arguments. On the server this is a
 * function accepting a response type.
 *
 * @returns {Function} the callback or undefined.
 */
MethodRequest.prototype.getCallback = function () {
  return this.args.getCallback();
};


/**
 * Get the callback from the arguments. A usable one.
 *
 * @returns {Function} the callback or undefined.
 */
MethodRequest.prototype.realCallback = function () {
  var self = this, callback = self.args.getCallback();
  return function () {
    var args = new Arguments([].slice.call(arguments)),
        resp = new ArgsResponse(args);
    callback.call(null, resp.forSending());
  };
};



module.exports.MethodRequest = MethodRequest;

},{"./../arguments.js":4,"./../log.js":13,"./../responses.js":21,"./../util":29,"./generic.js":19}],21:[function(require,module,exports){
/**
 * @fileOverview Responses that can be generated by the host.  Each
 * response is generated ad-hoc so the signature of their constructor
 * is arbitrary but each _type_ has it's own handle method that is
 * executed on the client and accepts the received message, the
 * request generating the response and a callback when we are done
 * handling it.
 * @name responses.js
 * @author Chris Perivolaropulos
 */

module.exports.ErrResponse = require('./responses/error.js');
module.exports.BurstResponse = require('./responses/burst.js');
module.exports.ArgsResponse = require('./responses/arguments.js');
module.exports.AckResponse = require('./responses/ack.js');
module.exports.genericRespHandler =
  require('./responses/generic.js').genericRespHandler;

},{"./responses/ack.js":22,"./responses/arguments.js":23,"./responses/burst.js":24,"./responses/error.js":25,"./responses/generic.js":26}],22:[function(require,module,exports){
var GenericResponse = require('./generic.js').GenericResponse;
require('./../setimmediate.js');

/**
 * The request wasn't supposed to yield any result but was
 * successful.
 */
function AckResponse () {
};

/**
 * Handle the response on the client side if it is of the correct
 * type.
 *
 * @param {Message} msg the raw message received by the server
 * @param {Request} request the request object that msg is a response
 * to.
 * @param {Function} doneCb Call this when you are done. It will be
 * called with no arguments on succes or an error object on error.
 * @return {Boolean} true if we handled it.
 */
AckResponse.maybeHandle = function (msg, request, doneCb) {
  if (msg.responseType != "AckResponse") return false;
  setImmediate(doneCb);
  return true;
};

AckResponse.prototype = Object.create(GenericResponse.prototype);

/**
 * Serialized response that also can be recognized as a response.
 *
 * @returns {Object} the object to be put through the API.
 */
AckResponse.prototype.forSending = function () {
  return {responseType: "AckResponse"};
};
module.exports = AckResponse;

},{"./../setimmediate.js":28,"./generic.js":26}],23:[function(require,module,exports){
var Arguments = require("./../arguments.js").Arguments,
    GenericResponse = require('./generic.js').GenericResponse;
require('./../setimmediate.js');

/**
 * The request yielded by a single callback that is to be called by
 * the client.
 *
 * @param {Arguments} args The callback arguments or a serialized
 * object generated by a server side ArgsResponse. Since these are
 * callback arguments they should contain no callback
 * themselves.
 */
function ArgsResponse (args) {
  this.cbArgs = args;
}

ArgsResponse.async = function (mr, hostApi) {
  var resp = new ArgsResponse();
  resp.mr = mr;
  resp.hostApi = hostApi;
  return resp;
};

/**
 * Handle the response on the client side if it is of the correct
 * type.
 *
 * @param {Message} msg the raw message received by the server
 * @param {Request} request the request object that msg is a response
 * to.
 * @param {Function} doneCb Call this when you are done. It will be
 * called with no arguments on succes or an error object on error.
 * @return {Boolean} true if we handled it.
 */
ArgsResponse.maybeHandle = function (msg, request, doneCb) {
  if (msg.responseType != "ArgsResponse") return false;
  if (!request.getCallback()) {
    doneCb(new Error("No real callback provided on the client."));
    return true;
  }
  var cbArgs = new Arguments(msg.args),
      callArgs = cbArgs.forCalling(),
      callback = request.getCallback();

  // log.log("Received:", cbArgs.forSending(), "for", {fn: String(callback)});
  callback.apply(null, callArgs);
  doneCb && setImmediate(doneCb);
  return true;
};

ArgsResponse.prototype = Object.create(GenericResponse.prototype);

/**
 * The callback arguments serialized.
 *
 * @returns {Object} the object to be put through the API.
 */
ArgsResponse.prototype.forSending = function () {
  return {responseType: "ArgsResponse",
          args: this.cbArgs.forSending()};
};

ArgsResponse.prototype.send = function (sendCb) {
  if (this.mr) {
    // NOTE: ArgsRepsonse for connection cleanups are lazy. The
    // callback of the api call does the actual work of sending the
    // respinse.
    this.mr.call(sendCb, this.hostApi);
    return;
  }

  sendCb(this.forSending());
};
module.exports = ArgsResponse;

},{"./../arguments.js":4,"./../setimmediate.js":28,"./generic.js":26}],24:[function(require,module,exports){
var Arguments = require("./../arguments.js").Arguments,
    DataArgument = require("./../arguments.js").DataArgument,
    log = new (require('./../log.js').Log)('burstresponse'),
    GenericResponse = require('./generic.js').GenericResponse,
    ArgsResponse = require('./arguments.js'),
    genericRespHandler = require('./generic.js').genericRespHandler;
require('./../setimmediate.js');

/**
 * Serving a burst response.
 *
 * @param {Array(Arguments)} cbArgsArr an array the arguments of calls
 * to a callback. We trust these contain no callbacks since they are
 * responses to the client.
 * @param {Message} reqMessage The message generated by BurstRequest.
 */
function BurstResponse (cbArgsArr, reqMessage) {
  this.cbArgsArr = cbArgsArr;
  this.callbackId = reqMessage.callbackId;
};

/**
 * Handle the response on the client side if it is of the correct
 * type.
 *
 * @param {Message} msg the raw message received by the server
 * @param {BurstRequest} request the request object that msg is a response
 * to.
 * @param {Function} doneCb Call this when you are done. It will be
 * called with no arguments on succes or an error object on error.
 * @return {Boolean} true if we handled it.
 */
var servedBurstMetrics = [];
BurstResponse.maybeHandle = function (msg, request, doneCb) {
  if (msg.responseType != "BurstResponse") return false;
  // Throw each response in the queue when the previous one is
  // finished. Before serving check if they are zombified by the
  // request.
  function arrInQueue(responses, err) {
    if (err) {
      doneCb(err);
      return;
    }

    if (responses.length == 0) {
      doneCb();
      return;
    }

    setImmediate(function () {
      var car = responses[0], cdr = responses.slice(1);

      if (!request.closed) {
        genericRespHandler(car, request, arrInQueue.bind(null, cdr));
        return;
      }
      doneCb();
      // Allow the generic handler to throw at least some stuff in the
      // queue.
    });
  }

  // It is assumed that the ordering of data from different sources
  // and the size of the packets does not matter. Concat together
  // packets that have everything in common except the data field.
  function maybeConcatData(msgs) {
    var dataSources = {},
        concatArg = msgs.forEach(function (m, i) {
          // Just keep this one as is
          if (!(m.args && DataArgument.canWrap(m.args[0]) && m.args.length == 1)) {
            dataSources[i] = m;
            return;
          }

          // Mask the data to make a source-unique token.
          var arg = m.args[0], backup = arg.data;
          arg.data = null;
          var token = JSON.stringify(arg);
          arg.data = backup;
          var ret = dataSources[token];
          if (ret) {
            dataSources[token] = ret.concat(arg);
            return;
          }

          dataSources[token] = new DataArgument(arg);
        });

    return Object.getOwnPropertyNames(dataSources).map(function (k) {
      var concatArg = dataSources[k];
      if (concatArg instanceof DataArgument) {
        return new ArgsResponse(
          new Arguments([concatArg.forSending()])).forSending();
      }

      return concatArg;
    });
  }

  // Some debugging information
  if (0) {
    servedBurstMetrics.push({time: Date.now(), length: msg.cbArgsArr.length});
    var totalRequests = servedBurstMetrics.reduce(function (sum, m) {
      return sum + m.length;
    }, 0);
    log.log("Burst summary:", {
      requestPerSec: totalRequests * 1000 /
        (Date.now() - servedBurstMetrics[0].time),
      totalRequests: totalRequests,
      currentRequests: msg.cbArgsArr.length
    });
  }
  arrInQueue(maybeConcatData(msg.cbArgsArr));

  return true;
};
BurstResponse.prototype = Object.create(GenericResponse.prototype);

/**
 * Serialized response that also can be recognized as a response.
 *
 * @returns {Object} the object to be put through the API.
 */
BurstResponse.prototype.forSending = function () {
  return {responseType: "BurstResponse",
          cbArgsArr: this.cbArgsArr,
          callbackId: this.callbackId};
};
module.exports = BurstResponse;

},{"./../arguments.js":4,"./../log.js":13,"./../setimmediate.js":28,"./arguments.js":23,"./generic.js":26}],25:[function(require,module,exports){
var GenericResponse = require('./generic.js').GenericResponse;

/**
 * An error occured serving the request.
 *
 * @param {String} error The error message.
 * @param {Boolean} isUncaught True if we want to raise an uncaught
 * error when this happens and false if it should be passed to
 * chrome.runtime.lastError
 */
function ErrResponse (error, type) {
  this.error = error;
  this.type = type;
};

/**
 * Handle the response on the client side if it is of the correct
 * type. This will also handle messages that are undefined messages.
 *
 * @param {Message|undefined} msg the raw message received by the server
 * @param {Request} request the request object that msg is a response
 * to.
 * @param {Function} doneCb Call this when you are done. It will be
 * called with no arguments on succes or an error object on error.
 * @return {Boolean} true if we handled it.
 */
ErrResponse.maybeHandle = function (msg, request, doneCb) {
  if (msg && msg.responseType != "ErrResponse") return false;

  var rawError = msg ? msg.err : "Undefined message, probably host is disconnected.";
  if (request.trace) {
    console.warn("Received error:", msg.err);
    console.warn(request.trace);
  };

  var withError = function (err, cb) {
    cb();

    if (err){
      console.error("Uncaught:", err);
    }
  };

  if (request.getCallback()) {
    (request.withError || withError)(rawError, request.getCallback());
    doneCb();
    return true;
  }

  doneCb(rawError);
  return true;
};

ErrResponse.prototype = new GenericResponse();

/**
 * Serialized response that also can be recognized as a response.
 *
 * @returns {Object} the object to be put through the API.
 */
ErrResponse.prototype.forSending = function () {
  return {responseType: "ErrResponse",
          err: this.error,
          type: this.type
         };
};
module.exports = ErrResponse;

},{"./generic.js":26}],26:[function(require,module,exports){
/**
 * @fileOverview The interface that all response types need to be
 * implementing
 * @name generic.js
 * @author Chris Perivolaropoulos
 */

function GenericResponse () {}
GenericResponse.prototype = {
  send: function (sendCb) {
    return sendCb(this.forSending());
  },

  forSending: function () {
    throw new Error("Not implemented");
  }
};



/**
 * Iterate over the response handlers and coose the correct one to
 * handle an incoming message on the clients.
 *
 * @param {Message} msg the raw message received by the server
 * @param {Request} request the request object that msg is a response
 * to.
 * @param {Function} done Call this when you are done. It will be
 * called with no arguments on succes or an error object on error.
 */

function genericRespHandler (msg, request, done) {
  // Be sure to throw done in the queue.
  function doneCb (err) {
    done(err);
  }

  var responseTypesArr = [
    require('./error.js'),                  //Catch the errors first
    require('./burst.js'),
    require('./arguments.js'),
    require('./ack.js'),
  ];

  if (!responseTypesArr.some(function (RT) {
    return RT.maybeHandle(msg, request, doneCb);
  })) {
    done(new Error("Couldn't handle message: " + JSON.stringify(msg)));
  }
}
module.exports.GenericResponse = GenericResponse;
module.exports.genericRespHandler = genericRespHandler;

},{"./ack.js":22,"./arguments.js":23,"./burst.js":24,"./error.js":25}],27:[function(require,module,exports){
/**
 * @fileOverview Initialize and handle requests and connections.
 * @name server.js
 * @author Chris Perivolaropoulos
 */
var HostConnection = require("./hostconnection.js").HostConnection,
    MethodRequest = require("./requests.js").MethodRequest,
    BurstRequest = require("./requests.js").BurstRequest,
    ErrResponse = require("./responses.js").ErrResponse,
    AckResponse = require("./responses.js").AckResponse,
    log = new (require('./log.js').Log)('server'),
    messageApi = require('./messaging.js'),
    BootstrapHost = require('./bootstraphost.js').BootstrapHost;
require('./setimmediate.js');

var state = {connections: [],
             keepalives: [],
             uniqueId: 0,
             version: messageApi.version};

/**
 * A port to keep track of a client. It also sets the id of the client;
 * @param {Port} port
 * @param {Function} dieCb Called when the client dies.
 */
function HostKeepAliveConnection (port, closeCb) {
  log.log("Creating host keepalive");
  var self = this;
  this.port = port;
  port.onDisconnect.addListener(this.close.bind(this));
  this.closeCb = closeCb.bind(null, this);
  this.clientId = state.uniqueId++;
  this.portConf = JSON.parse(port.name);

  // Set the clientId
  port.onDisconnect.addListener(function () {
    log.log("Client disconnected:" + self.clientId);
  });
  port.postMessage({
    clientId: self.clientId,
    version: state.version});
  log.log("Client connected:" + self.clientId);
  this.closed = false;
}

HostKeepAliveConnection.is = function (port) {
  return JSON.parse(port.name).type == "KeepAliveConnection";
};

HostKeepAliveConnection.prototype = {
  maybeClose: function (c) {

    if (c.clientId == this.clientId) {
      c.close();
    }
  },

  close: function () {
    if (this.closed) return;
    // Cleaning up may require the port.
    this.closed = true;
    this.closeCb();
    this.port.disconnect();
    this.port = null;
  }
};

/**
 * Get a keep alive connection token for the client. The object is
 * {port, clientId}.
 *
 * @param {String} hostId The ide of the host to connect to.
 * @param {Function} connectCb The callback to be called when the
 * connection is successful.
 * @param {Function} diconnectCb Will be called when the host
 * disconencts. Will be called immediately if the connection fails.
 */
function getKeepAliveConnection (hostId, connectCb, disconnectCb, timeout) {
  messageApi = require("./messaging.js");

  var portName = JSON.stringify({type:"KeepAliveConnection"}),
      port = messageApi.connect(hostId, {name: portName});
  if (disconnectCb) {
    log.log("Detected disconnect cb on client keepalive");
    port.onDisconnect.addListener(function () {disconnectCb();});
  }

  var gotToken = false;
  port.onMessage.addListener(function tokenizer (msg) {
    port.onMessage.removeListener(tokenizer);
    gotToken = true;

    if (!msg) {
      log.warn("Empty message came on keepalive port.");
      disconnectCb("no_host");
      port.disconnect();
      return true;
    }

    // Only matching major version numbers can communicate.
    if (msg && msg.version &&
        msg.version.split('.')[0] != messageApi.version.split('.')[0]) {
      log.warn("Received bad app version:", msg.version);
      disconnectCb("bad_version");
      port.disconnect();
      return true;
    }


    if (typeof msg.clientId !== 'number') {
      return false;
    }

    var token = {
      port: port,
      version: msg.version,
      clientId: msg.clientId,
      disconnectCb: disconnectCb
    };
    setImmediate(connectCb.bind(null, token));
  });

  if (typeof timeout !== 'undefined') {
    setTimeout(function() {
      if (gotToken) return;
      log.warn("Host keepalive connection was silent for too long.");
      disconnectCb("timeout");
      port.disconnect();
      return true;
    }, timeout);
  }
}


/**
 * Handle (or delegate) connections and messages from any client. Also
 * keep track of open connections and clean them up if the user asks
 * for it.
 *
 * @param {Object} apiRoot the root of the api to serve.
 */
function HostServer (apiRoot) {
  if (state.apiRoot === apiRoot) {
    throw Error("You are trying to host a second server on the same api.");
  }

  var adhoc = require("./adhoc/host.js");
  apiRoot.messageApi = messageApi;
  apiRoot.serverId = Math.random();
  state.apiRoot = apiRoot;
  state.bootstrapHost = new BootstrapHost();
  adhoc.setupAdHoc(state);

  function closeCb (connection) {
    var len = state.connections.length;
    state.connections = state.connections.filter(function (c) {
      return c !== connection;
    });
    log.log("Cleanined:", connection.repr(), '(before: ', len,'after: ',
            state.connections.length, ')');
  };

  function tabDiedCb (keepalive) {
    // Keep only one reference to each connection, ie don't register
    // them to keepalives or whatever.
    state.connections.forEach(function (c) {
      keepalive.maybeClose(c);
    });
    state.keepalives = state.keepalives.filter(function (ka) {
      return !ka.closed;
    });
  }

  function messageHandle (message, sender, sendResp) {
    return (
      MethodRequest.maybeHandle(message, apiRoot, sendResp,
                                {connections: state.connections}) ||
        BurstRequest.maybeHandle(message, state.connections, sendResp) ||
        (new ErrResponse("Nothing to do for message." +
                         JSON.stringify(message), false)
         .send(sendResp)));
  }

  function connectHandle (port) {
    if (HostKeepAliveConnection.is(port)) {
      var keepalive = new HostKeepAliveConnection(port, tabDiedCb);
      state.keepalives.push(keepalive);
      return;
    }

    var conn = new HostConnection(port, apiRoot, function () {
      closeCb(conn);
    });
    state.connections.push(conn);
  }

  messageApi.onConnectExternal.addListener(connectHandle);
  log.log("Listening on connections...");
  messageApi.onMessageExternal.addListener(messageHandle);
  log.log("Listening on messages...");

  function cleanUp () {
    log.log("Cleaning connect");
    messageApi.onConnectExternal.removeListener(connectHandle);
    log.log("Cleaning message");
    messageApi.onMessageExternal.removeListener(messageHandle);

    state.connections.forEach(function(c) {
      c.close();
    });

    state.keepalives.forEach(function(k) {
      k.close();
    });

    state.bootstrapHost.cleanup();
    state.apiRoot = null;
  }

  return cleanUp;
}

module.exports.state = state;
module.exports.HostServer = HostServer;
module.exports.getKeepAliveConnection = getKeepAliveConnection;
module.exports.messageApi = messageApi;

},{"./adhoc/host.js":2,"./bootstraphost.js":11,"./hostconnection.js":12,"./log.js":13,"./messaging.js":14,"./requests.js":17,"./responses.js":21,"./setimmediate.js":28}],28:[function(require,module,exports){
(function (global){
// setTimeout is clamped to 1000ms min time for background tabs.

// Check wether we are in the app context.
function isApp () {
  // getManifest resturns a value and thus is not available to the
  // client
  return !!chrome.runtime.getManifest;
};

// Not in a browser makes it ok to use setTimeout
if (!(global.postMessage && global.addEventListener) || isApp()) {
  global.setImmediate = global.setTimeout.bind(global);
  global.clearTimeout = global.clearTimeout.bind(global);
} else {
  (function () {
    "use strict";
    var i = 0;
    var timeouts = {};
    var messageName = "setImmediate" + new Date().getTime();

    function post(fn) {
      if (i === 0x100000000) // max queue size
        i = 0;
      if (++i in timeouts)
        throw new Error("setImmediate queue overflow.");
      timeouts[i] = fn;
      global.postMessage({ type: messageName, id: i }, "*");
      return i;
    }

    function receive(ev) {
      if (ev.source !== window)
        return;
      var data = ev.data;
      if (data && data instanceof Object && data.type === messageName) {
        ev.stopPropagation();
        var id = ev.data.id;
        var fn = timeouts[id];
        if (fn) {
          delete timeouts[id];
          fn();
        }
      }
    }

    function clear(id) {
      delete timeouts[id];
    }

    global.addEventListener("message", receive, true);
    global.setImmediate = post;
    global.clearImmediate = clear;
  })();
}

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
//# sourceMappingURL=data:application/json;charset:utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNldGltbWVkaWF0ZS5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJmaWxlIjoiZ2VuZXJhdGVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXNDb250ZW50IjpbIi8vIHNldFRpbWVvdXQgaXMgY2xhbXBlZCB0byAxMDAwbXMgbWluIHRpbWUgZm9yIGJhY2tncm91bmQgdGFicy5cblxuLy8gQ2hlY2sgd2V0aGVyIHdlIGFyZSBpbiB0aGUgYXBwIGNvbnRleHQuXG5mdW5jdGlvbiBpc0FwcCAoKSB7XG4gIC8vIGdldE1hbmlmZXN0IHJlc3R1cm5zIGEgdmFsdWUgYW5kIHRodXMgaXMgbm90IGF2YWlsYWJsZSB0byB0aGVcbiAgLy8gY2xpZW50XG4gIHJldHVybiAhIWNocm9tZS5ydW50aW1lLmdldE1hbmlmZXN0O1xufTtcblxuLy8gTm90IGluIGEgYnJvd3NlciBtYWtlcyBpdCBvayB0byB1c2Ugc2V0VGltZW91dFxuaWYgKCEoZ2xvYmFsLnBvc3RNZXNzYWdlICYmIGdsb2JhbC5hZGRFdmVudExpc3RlbmVyKSB8fCBpc0FwcCgpKSB7XG4gIGdsb2JhbC5zZXRJbW1lZGlhdGUgPSBnbG9iYWwuc2V0VGltZW91dC5iaW5kKGdsb2JhbCk7XG4gIGdsb2JhbC5jbGVhclRpbWVvdXQgPSBnbG9iYWwuY2xlYXJUaW1lb3V0LmJpbmQoZ2xvYmFsKTtcbn0gZWxzZSB7XG4gIChmdW5jdGlvbiAoKSB7XG4gICAgXCJ1c2Ugc3RyaWN0XCI7XG4gICAgdmFyIGkgPSAwO1xuICAgIHZhciB0aW1lb3V0cyA9IHt9O1xuICAgIHZhciBtZXNzYWdlTmFtZSA9IFwic2V0SW1tZWRpYXRlXCIgKyBuZXcgRGF0ZSgpLmdldFRpbWUoKTtcblxuICAgIGZ1bmN0aW9uIHBvc3QoZm4pIHtcbiAgICAgIGlmIChpID09PSAweDEwMDAwMDAwMCkgLy8gbWF4IHF1ZXVlIHNpemVcbiAgICAgICAgaSA9IDA7XG4gICAgICBpZiAoKytpIGluIHRpbWVvdXRzKVxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJzZXRJbW1lZGlhdGUgcXVldWUgb3ZlcmZsb3cuXCIpO1xuICAgICAgdGltZW91dHNbaV0gPSBmbjtcbiAgICAgIGdsb2JhbC5wb3N0TWVzc2FnZSh7IHR5cGU6IG1lc3NhZ2VOYW1lLCBpZDogaSB9LCBcIipcIik7XG4gICAgICByZXR1cm4gaTtcbiAgICB9XG5cbiAgICBmdW5jdGlvbiByZWNlaXZlKGV2KSB7XG4gICAgICBpZiAoZXYuc291cmNlICE9PSB3aW5kb3cpXG4gICAgICAgIHJldHVybjtcbiAgICAgIHZhciBkYXRhID0gZXYuZGF0YTtcbiAgICAgIGlmIChkYXRhICYmIGRhdGEgaW5zdGFuY2VvZiBPYmplY3QgJiYgZGF0YS50eXBlID09PSBtZXNzYWdlTmFtZSkge1xuICAgICAgICBldi5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgdmFyIGlkID0gZXYuZGF0YS5pZDtcbiAgICAgICAgdmFyIGZuID0gdGltZW91dHNbaWRdO1xuICAgICAgICBpZiAoZm4pIHtcbiAgICAgICAgICBkZWxldGUgdGltZW91dHNbaWRdO1xuICAgICAgICAgIGZuKCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICBmdW5jdGlvbiBjbGVhcihpZCkge1xuICAgICAgZGVsZXRlIHRpbWVvdXRzW2lkXTtcbiAgICB9XG5cbiAgICBnbG9iYWwuYWRkRXZlbnRMaXN0ZW5lcihcIm1lc3NhZ2VcIiwgcmVjZWl2ZSwgdHJ1ZSk7XG4gICAgZ2xvYmFsLnNldEltbWVkaWF0ZSA9IHBvc3Q7XG4gICAgZ2xvYmFsLmNsZWFySW1tZWRpYXRlID0gY2xlYXI7XG4gIH0pKCk7XG59XG4iXX0=
},{}],29:[function(require,module,exports){
function errorThrower (name) {
  return function () {
    throw new Error("No such method: " + name);
  };
}

function arrToBuf(hex) {
  var buffer = new ArrayBuffer(hex.length);
  var bufferView = new Uint8Array(buffer);
  for (var i = 0; i < hex.length; i++) {
    bufferView[i] = hex[i];
  }

  return buffer;
}
module.exports.arrToBuf = arrToBuf;

function bufToArr(bin) {
  var bufferView = new Uint8Array(bin);
  var hexes = [];
  for (var i = 0; i < bufferView.length; ++i) {
    hexes.push(bufferView[i]);
  }
  return hexes;
}
module.exports.bufToArr = bufToArr;

// Get a callable member of this.obj given the name. Dot paths are
// supported.
function path2callable (object, name, callable) {
  var names = name.split('.'),
      method = names.pop(),
      obj = (names.reduce(function (ob, meth) {return ob[meth];}, object)
             || object),
      self = this;

  if (!obj[method]) {
    console.warn("Tried to resolve bad object path: " + name);
    console.warn("Server:", object);
    return null; // errorThrower(name);
  }

  return obj[method].bind(obj);
};
module.exports.path2callable = path2callable;

},{}],30:[function(require,module,exports){
// http://wiki.commonjs.org/wiki/Unit_Testing/1.0
//
// THIS IS NOT TESTED NOR LIKELY TO WORK OUTSIDE V8!
//
// Originally from narwhal.js (http://narwhaljs.org)
// Copyright (c) 2009 Thomas Robinson <280north.com>
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the 'Software'), to
// deal in the Software without restriction, including without limitation the
// rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
// sell copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED 'AS IS', WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
// ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
// WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

// when used in node, this will actually load the util module we depend on
// versus loading the builtin util module as happens otherwise
// this is a bug in node module loading as far as I am concerned
var util = require('util/');

var pSlice = Array.prototype.slice;
var hasOwn = Object.prototype.hasOwnProperty;

// 1. The assert module provides functions that throw
// AssertionError's when particular conditions are not met. The
// assert module must conform to the following interface.

var assert = module.exports = ok;

// 2. The AssertionError is defined in assert.
// new assert.AssertionError({ message: message,
//                             actual: actual,
//                             expected: expected })

assert.AssertionError = function AssertionError(options) {
  this.name = 'AssertionError';
  this.actual = options.actual;
  this.expected = options.expected;
  this.operator = options.operator;
  if (options.message) {
    this.message = options.message;
    this.generatedMessage = false;
  } else {
    this.message = getMessage(this);
    this.generatedMessage = true;
  }
  var stackStartFunction = options.stackStartFunction || fail;

  if (Error.captureStackTrace) {
    Error.captureStackTrace(this, stackStartFunction);
  }
  else {
    // non v8 browsers so we can have a stacktrace
    var err = new Error();
    if (err.stack) {
      var out = err.stack;

      // try to strip useless frames
      var fn_name = stackStartFunction.name;
      var idx = out.indexOf('\n' + fn_name);
      if (idx >= 0) {
        // once we have located the function frame
        // we need to strip out everything before it (and its line)
        var next_line = out.indexOf('\n', idx + 1);
        out = out.substring(next_line + 1);
      }

      this.stack = out;
    }
  }
};

// assert.AssertionError instanceof Error
util.inherits(assert.AssertionError, Error);

function replacer(key, value) {
  if (util.isUndefined(value)) {
    return '' + value;
  }
  if (util.isNumber(value) && (isNaN(value) || !isFinite(value))) {
    return value.toString();
  }
  if (util.isFunction(value) || util.isRegExp(value)) {
    return value.toString();
  }
  return value;
}

function truncate(s, n) {
  if (util.isString(s)) {
    return s.length < n ? s : s.slice(0, n);
  } else {
    return s;
  }
}

function getMessage(self) {
  return truncate(JSON.stringify(self.actual, replacer), 128) + ' ' +
         self.operator + ' ' +
         truncate(JSON.stringify(self.expected, replacer), 128);
}

// At present only the three keys mentioned above are used and
// understood by the spec. Implementations or sub modules can pass
// other keys to the AssertionError's constructor - they will be
// ignored.

// 3. All of the following functions must throw an AssertionError
// when a corresponding condition is not met, with a message that
// may be undefined if not provided.  All assertion methods provide
// both the actual and expected values to the assertion error for
// display purposes.

function fail(actual, expected, message, operator, stackStartFunction) {
  throw new assert.AssertionError({
    message: message,
    actual: actual,
    expected: expected,
    operator: operator,
    stackStartFunction: stackStartFunction
  });
}

// EXTENSION! allows for well behaved errors defined elsewhere.
assert.fail = fail;

// 4. Pure assertion tests whether a value is truthy, as determined
// by !!guard.
// assert.ok(guard, message_opt);
// This statement is equivalent to assert.equal(true, !!guard,
// message_opt);. To test strictly for the value true, use
// assert.strictEqual(true, guard, message_opt);.

function ok(value, message) {
  if (!value) fail(value, true, message, '==', assert.ok);
}
assert.ok = ok;

// 5. The equality assertion tests shallow, coercive equality with
// ==.
// assert.equal(actual, expected, message_opt);

assert.equal = function equal(actual, expected, message) {
  if (actual != expected) fail(actual, expected, message, '==', assert.equal);
};

// 6. The non-equality assertion tests for whether two objects are not equal
// with != assert.notEqual(actual, expected, message_opt);

assert.notEqual = function notEqual(actual, expected, message) {
  if (actual == expected) {
    fail(actual, expected, message, '!=', assert.notEqual);
  }
};

// 7. The equivalence assertion tests a deep equality relation.
// assert.deepEqual(actual, expected, message_opt);

assert.deepEqual = function deepEqual(actual, expected, message) {
  if (!_deepEqual(actual, expected)) {
    fail(actual, expected, message, 'deepEqual', assert.deepEqual);
  }
};

function _deepEqual(actual, expected) {
  // 7.1. All identical values are equivalent, as determined by ===.
  if (actual === expected) {
    return true;

  } else if (util.isBuffer(actual) && util.isBuffer(expected)) {
    if (actual.length != expected.length) return false;

    for (var i = 0; i < actual.length; i++) {
      if (actual[i] !== expected[i]) return false;
    }

    return true;

  // 7.2. If the expected value is a Date object, the actual value is
  // equivalent if it is also a Date object that refers to the same time.
  } else if (util.isDate(actual) && util.isDate(expected)) {
    return actual.getTime() === expected.getTime();

  // 7.3 If the expected value is a RegExp object, the actual value is
  // equivalent if it is also a RegExp object with the same source and
  // properties (`global`, `multiline`, `lastIndex`, `ignoreCase`).
  } else if (util.isRegExp(actual) && util.isRegExp(expected)) {
    return actual.source === expected.source &&
           actual.global === expected.global &&
           actual.multiline === expected.multiline &&
           actual.lastIndex === expected.lastIndex &&
           actual.ignoreCase === expected.ignoreCase;

  // 7.4. Other pairs that do not both pass typeof value == 'object',
  // equivalence is determined by ==.
  } else if (!util.isObject(actual) && !util.isObject(expected)) {
    return actual == expected;

  // 7.5 For all other Object pairs, including Array objects, equivalence is
  // determined by having the same number of owned properties (as verified
  // with Object.prototype.hasOwnProperty.call), the same set of keys
  // (although not necessarily the same order), equivalent values for every
  // corresponding key, and an identical 'prototype' property. Note: this
  // accounts for both named and indexed properties on Arrays.
  } else {
    return objEquiv(actual, expected);
  }
}

function isArguments(object) {
  return Object.prototype.toString.call(object) == '[object Arguments]';
}

function objEquiv(a, b) {
  if (util.isNullOrUndefined(a) || util.isNullOrUndefined(b))
    return false;
  // an identical 'prototype' property.
  if (a.prototype !== b.prototype) return false;
  //~~~I've managed to break Object.keys through screwy arguments passing.
  //   Converting to array solves the problem.
  if (isArguments(a)) {
    if (!isArguments(b)) {
      return false;
    }
    a = pSlice.call(a);
    b = pSlice.call(b);
    return _deepEqual(a, b);
  }
  try {
    var ka = objectKeys(a),
        kb = objectKeys(b),
        key, i;
  } catch (e) {//happens when one is a string literal and the other isn't
    return false;
  }
  // having the same number of owned properties (keys incorporates
  // hasOwnProperty)
  if (ka.length != kb.length)
    return false;
  //the same set of keys (although not necessarily the same order),
  ka.sort();
  kb.sort();
  //~~~cheap key test
  for (i = ka.length - 1; i >= 0; i--) {
    if (ka[i] != kb[i])
      return false;
  }
  //equivalent values for every corresponding key, and
  //~~~possibly expensive deep test
  for (i = ka.length - 1; i >= 0; i--) {
    key = ka[i];
    if (!_deepEqual(a[key], b[key])) return false;
  }
  return true;
}

// 8. The non-equivalence assertion tests for any deep inequality.
// assert.notDeepEqual(actual, expected, message_opt);

assert.notDeepEqual = function notDeepEqual(actual, expected, message) {
  if (_deepEqual(actual, expected)) {
    fail(actual, expected, message, 'notDeepEqual', assert.notDeepEqual);
  }
};

// 9. The strict equality assertion tests strict equality, as determined by ===.
// assert.strictEqual(actual, expected, message_opt);

assert.strictEqual = function strictEqual(actual, expected, message) {
  if (actual !== expected) {
    fail(actual, expected, message, '===', assert.strictEqual);
  }
};

// 10. The strict non-equality assertion tests for strict inequality, as
// determined by !==.  assert.notStrictEqual(actual, expected, message_opt);

assert.notStrictEqual = function notStrictEqual(actual, expected, message) {
  if (actual === expected) {
    fail(actual, expected, message, '!==', assert.notStrictEqual);
  }
};

function expectedException(actual, expected) {
  if (!actual || !expected) {
    return false;
  }

  if (Object.prototype.toString.call(expected) == '[object RegExp]') {
    return expected.test(actual);
  } else if (actual instanceof expected) {
    return true;
  } else if (expected.call({}, actual) === true) {
    return true;
  }

  return false;
}

function _throws(shouldThrow, block, expected, message) {
  var actual;

  if (util.isString(expected)) {
    message = expected;
    expected = null;
  }

  try {
    block();
  } catch (e) {
    actual = e;
  }

  message = (expected && expected.name ? ' (' + expected.name + ').' : '.') +
            (message ? ' ' + message : '.');

  if (shouldThrow && !actual) {
    fail(actual, expected, 'Missing expected exception' + message);
  }

  if (!shouldThrow && expectedException(actual, expected)) {
    fail(actual, expected, 'Got unwanted exception' + message);
  }

  if ((shouldThrow && actual && expected &&
      !expectedException(actual, expected)) || (!shouldThrow && actual)) {
    throw actual;
  }
}

// 11. Expected to throw an error:
// assert.throws(block, Error_opt, message_opt);

assert.throws = function(block, /*optional*/error, /*optional*/message) {
  _throws.apply(this, [true].concat(pSlice.call(arguments)));
};

// EXTENSION! This is annoying to write outside this module.
assert.doesNotThrow = function(block, /*optional*/message) {
  _throws.apply(this, [false].concat(pSlice.call(arguments)));
};

assert.ifError = function(err) { if (err) {throw err;}};

var objectKeys = Object.keys || function (obj) {
  var keys = [];
  for (var key in obj) {
    if (hasOwn.call(obj, key)) keys.push(key);
  }
  return keys;
};

},{"util/":34}],31:[function(require,module,exports){
if (typeof Object.create === 'function') {
  // implementation from standard node.js 'util' module
  module.exports = function inherits(ctor, superCtor) {
    ctor.super_ = superCtor
    ctor.prototype = Object.create(superCtor.prototype, {
      constructor: {
        value: ctor,
        enumerable: false,
        writable: true,
        configurable: true
      }
    });
  };
} else {
  // old school shim for old browsers
  module.exports = function inherits(ctor, superCtor) {
    ctor.super_ = superCtor
    var TempCtor = function () {}
    TempCtor.prototype = superCtor.prototype
    ctor.prototype = new TempCtor()
    ctor.prototype.constructor = ctor
  }
}

},{}],32:[function(require,module,exports){
// shim for using process in browser

var process = module.exports = {};

process.nextTick = (function () {
    var canSetImmediate = typeof window !== 'undefined'
    && window.setImmediate;
    var canMutationObserver = typeof window !== 'undefined'
    && window.MutationObserver;
    var canPost = typeof window !== 'undefined'
    && window.postMessage && window.addEventListener
    ;

    if (canSetImmediate) {
        return function (f) { return window.setImmediate(f) };
    }

    var queue = [];

    if (canMutationObserver) {
        var hiddenDiv = document.createElement("div");
        var observer = new MutationObserver(function () {
            var queueList = queue.slice();
            queue.length = 0;
            queueList.forEach(function (fn) {
                fn();
            });
        });

        observer.observe(hiddenDiv, { attributes: true });

        return function nextTick(fn) {
            if (!queue.length) {
                hiddenDiv.setAttribute('yes', 'no');
            }
            queue.push(fn);
        };
    }

    if (canPost) {
        window.addEventListener('message', function (ev) {
            var source = ev.source;
            if ((source === window || source === null) && ev.data === 'process-tick') {
                ev.stopPropagation();
                if (queue.length > 0) {
                    var fn = queue.shift();
                    fn();
                }
            }
        }, true);

        return function nextTick(fn) {
            queue.push(fn);
            window.postMessage('process-tick', '*');
        };
    }

    return function nextTick(fn) {
        setTimeout(fn, 0);
    };
})();

process.title = 'browser';
process.browser = true;
process.env = {};
process.argv = [];

function noop() {}

process.on = noop;
process.addListener = noop;
process.once = noop;
process.off = noop;
process.removeListener = noop;
process.removeAllListeners = noop;
process.emit = noop;

process.binding = function (name) {
    throw new Error('process.binding is not supported');
};

// TODO(shtylman)
process.cwd = function () { return '/' };
process.chdir = function (dir) {
    throw new Error('process.chdir is not supported');
};

},{}],33:[function(require,module,exports){
module.exports = function isBuffer(arg) {
  return arg && typeof arg === 'object'
    && typeof arg.copy === 'function'
    && typeof arg.fill === 'function'
    && typeof arg.readUInt8 === 'function';
}
},{}],34:[function(require,module,exports){
(function (process,global){
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.

var formatRegExp = /%[sdj%]/g;
exports.format = function(f) {
  if (!isString(f)) {
    var objects = [];
    for (var i = 0; i < arguments.length; i++) {
      objects.push(inspect(arguments[i]));
    }
    return objects.join(' ');
  }

  var i = 1;
  var args = arguments;
  var len = args.length;
  var str = String(f).replace(formatRegExp, function(x) {
    if (x === '%%') return '%';
    if (i >= len) return x;
    switch (x) {
      case '%s': return String(args[i++]);
      case '%d': return Number(args[i++]);
      case '%j':
        try {
          return JSON.stringify(args[i++]);
        } catch (_) {
          return '[Circular]';
        }
      default:
        return x;
    }
  });
  for (var x = args[i]; i < len; x = args[++i]) {
    if (isNull(x) || !isObject(x)) {
      str += ' ' + x;
    } else {
      str += ' ' + inspect(x);
    }
  }
  return str;
};


// Mark that a method should not be used.
// Returns a modified function which warns once by default.
// If --no-deprecation is set, then it is a no-op.
exports.deprecate = function(fn, msg) {
  // Allow for deprecating things in the process of starting up.
  if (isUndefined(global.process)) {
    return function() {
      return exports.deprecate(fn, msg).apply(this, arguments);
    };
  }

  if (process.noDeprecation === true) {
    return fn;
  }

  var warned = false;
  function deprecated() {
    if (!warned) {
      if (process.throwDeprecation) {
        throw new Error(msg);
      } else if (process.traceDeprecation) {
        console.trace(msg);
      } else {
        console.error(msg);
      }
      warned = true;
    }
    return fn.apply(this, arguments);
  }

  return deprecated;
};


var debugs = {};
var debugEnviron;
exports.debuglog = function(set) {
  if (isUndefined(debugEnviron))
    debugEnviron = process.env.NODE_DEBUG || '';
  set = set.toUpperCase();
  if (!debugs[set]) {
    if (new RegExp('\\b' + set + '\\b', 'i').test(debugEnviron)) {
      var pid = process.pid;
      debugs[set] = function() {
        var msg = exports.format.apply(exports, arguments);
        console.error('%s %d: %s', set, pid, msg);
      };
    } else {
      debugs[set] = function() {};
    }
  }
  return debugs[set];
};


/**
 * Echos the value of a value. Trys to print the value out
 * in the best way possible given the different types.
 *
 * @param {Object} obj The object to print out.
 * @param {Object} opts Optional options object that alters the output.
 */
/* legacy: obj, showHidden, depth, colors*/
function inspect(obj, opts) {
  // default options
  var ctx = {
    seen: [],
    stylize: stylizeNoColor
  };
  // legacy...
  if (arguments.length >= 3) ctx.depth = arguments[2];
  if (arguments.length >= 4) ctx.colors = arguments[3];
  if (isBoolean(opts)) {
    // legacy...
    ctx.showHidden = opts;
  } else if (opts) {
    // got an "options" object
    exports._extend(ctx, opts);
  }
  // set default options
  if (isUndefined(ctx.showHidden)) ctx.showHidden = false;
  if (isUndefined(ctx.depth)) ctx.depth = 2;
  if (isUndefined(ctx.colors)) ctx.colors = false;
  if (isUndefined(ctx.customInspect)) ctx.customInspect = true;
  if (ctx.colors) ctx.stylize = stylizeWithColor;
  return formatValue(ctx, obj, ctx.depth);
}
exports.inspect = inspect;


// http://en.wikipedia.org/wiki/ANSI_escape_code#graphics
inspect.colors = {
  'bold' : [1, 22],
  'italic' : [3, 23],
  'underline' : [4, 24],
  'inverse' : [7, 27],
  'white' : [37, 39],
  'grey' : [90, 39],
  'black' : [30, 39],
  'blue' : [34, 39],
  'cyan' : [36, 39],
  'green' : [32, 39],
  'magenta' : [35, 39],
  'red' : [31, 39],
  'yellow' : [33, 39]
};

// Don't use 'blue' not visible on cmd.exe
inspect.styles = {
  'special': 'cyan',
  'number': 'yellow',
  'boolean': 'yellow',
  'undefined': 'grey',
  'null': 'bold',
  'string': 'green',
  'date': 'magenta',
  // "name": intentionally not styling
  'regexp': 'red'
};


function stylizeWithColor(str, styleType) {
  var style = inspect.styles[styleType];

  if (style) {
    return '\u001b[' + inspect.colors[style][0] + 'm' + str +
           '\u001b[' + inspect.colors[style][1] + 'm';
  } else {
    return str;
  }
}


function stylizeNoColor(str, styleType) {
  return str;
}


function arrayToHash(array) {
  var hash = {};

  array.forEach(function(val, idx) {
    hash[val] = true;
  });

  return hash;
}


function formatValue(ctx, value, recurseTimes) {
  // Provide a hook for user-specified inspect functions.
  // Check that value is an object with an inspect function on it
  if (ctx.customInspect &&
      value &&
      isFunction(value.inspect) &&
      // Filter out the util module, it's inspect function is special
      value.inspect !== exports.inspect &&
      // Also filter out any prototype objects using the circular check.
      !(value.constructor && value.constructor.prototype === value)) {
    var ret = value.inspect(recurseTimes, ctx);
    if (!isString(ret)) {
      ret = formatValue(ctx, ret, recurseTimes);
    }
    return ret;
  }

  // Primitive types cannot have properties
  var primitive = formatPrimitive(ctx, value);
  if (primitive) {
    return primitive;
  }

  // Look up the keys of the object.
  var keys = Object.keys(value);
  var visibleKeys = arrayToHash(keys);

  if (ctx.showHidden) {
    keys = Object.getOwnPropertyNames(value);
  }

  // IE doesn't make error fields non-enumerable
  // http://msdn.microsoft.com/en-us/library/ie/dww52sbt(v=vs.94).aspx
  if (isError(value)
      && (keys.indexOf('message') >= 0 || keys.indexOf('description') >= 0)) {
    return formatError(value);
  }

  // Some type of object without properties can be shortcutted.
  if (keys.length === 0) {
    if (isFunction(value)) {
      var name = value.name ? ': ' + value.name : '';
      return ctx.stylize('[Function' + name + ']', 'special');
    }
    if (isRegExp(value)) {
      return ctx.stylize(RegExp.prototype.toString.call(value), 'regexp');
    }
    if (isDate(value)) {
      return ctx.stylize(Date.prototype.toString.call(value), 'date');
    }
    if (isError(value)) {
      return formatError(value);
    }
  }

  var base = '', array = false, braces = ['{', '}'];

  // Make Array say that they are Array
  if (isArray(value)) {
    array = true;
    braces = ['[', ']'];
  }

  // Make functions say that they are functions
  if (isFunction(value)) {
    var n = value.name ? ': ' + value.name : '';
    base = ' [Function' + n + ']';
  }

  // Make RegExps say that they are RegExps
  if (isRegExp(value)) {
    base = ' ' + RegExp.prototype.toString.call(value);
  }

  // Make dates with properties first say the date
  if (isDate(value)) {
    base = ' ' + Date.prototype.toUTCString.call(value);
  }

  // Make error with message first say the error
  if (isError(value)) {
    base = ' ' + formatError(value);
  }

  if (keys.length === 0 && (!array || value.length == 0)) {
    return braces[0] + base + braces[1];
  }

  if (recurseTimes < 0) {
    if (isRegExp(value)) {
      return ctx.stylize(RegExp.prototype.toString.call(value), 'regexp');
    } else {
      return ctx.stylize('[Object]', 'special');
    }
  }

  ctx.seen.push(value);

  var output;
  if (array) {
    output = formatArray(ctx, value, recurseTimes, visibleKeys, keys);
  } else {
    output = keys.map(function(key) {
      return formatProperty(ctx, value, recurseTimes, visibleKeys, key, array);
    });
  }

  ctx.seen.pop();

  return reduceToSingleString(output, base, braces);
}


function formatPrimitive(ctx, value) {
  if (isUndefined(value))
    return ctx.stylize('undefined', 'undefined');
  if (isString(value)) {
    var simple = '\'' + JSON.stringify(value).replace(/^"|"$/g, '')
                                             .replace(/'/g, "\\'")
                                             .replace(/\\"/g, '"') + '\'';
    return ctx.stylize(simple, 'string');
  }
  if (isNumber(value))
    return ctx.stylize('' + value, 'number');
  if (isBoolean(value))
    return ctx.stylize('' + value, 'boolean');
  // For some reason typeof null is "object", so special case here.
  if (isNull(value))
    return ctx.stylize('null', 'null');
}


function formatError(value) {
  return '[' + Error.prototype.toString.call(value) + ']';
}


function formatArray(ctx, value, recurseTimes, visibleKeys, keys) {
  var output = [];
  for (var i = 0, l = value.length; i < l; ++i) {
    if (hasOwnProperty(value, String(i))) {
      output.push(formatProperty(ctx, value, recurseTimes, visibleKeys,
          String(i), true));
    } else {
      output.push('');
    }
  }
  keys.forEach(function(key) {
    if (!key.match(/^\d+$/)) {
      output.push(formatProperty(ctx, value, recurseTimes, visibleKeys,
          key, true));
    }
  });
  return output;
}


function formatProperty(ctx, value, recurseTimes, visibleKeys, key, array) {
  var name, str, desc;
  desc = Object.getOwnPropertyDescriptor(value, key) || { value: value[key] };
  if (desc.get) {
    if (desc.set) {
      str = ctx.stylize('[Getter/Setter]', 'special');
    } else {
      str = ctx.stylize('[Getter]', 'special');
    }
  } else {
    if (desc.set) {
      str = ctx.stylize('[Setter]', 'special');
    }
  }
  if (!hasOwnProperty(visibleKeys, key)) {
    name = '[' + key + ']';
  }
  if (!str) {
    if (ctx.seen.indexOf(desc.value) < 0) {
      if (isNull(recurseTimes)) {
        str = formatValue(ctx, desc.value, null);
      } else {
        str = formatValue(ctx, desc.value, recurseTimes - 1);
      }
      if (str.indexOf('\n') > -1) {
        if (array) {
          str = str.split('\n').map(function(line) {
            return '  ' + line;
          }).join('\n').substr(2);
        } else {
          str = '\n' + str.split('\n').map(function(line) {
            return '   ' + line;
          }).join('\n');
        }
      }
    } else {
      str = ctx.stylize('[Circular]', 'special');
    }
  }
  if (isUndefined(name)) {
    if (array && key.match(/^\d+$/)) {
      return str;
    }
    name = JSON.stringify('' + key);
    if (name.match(/^"([a-zA-Z_][a-zA-Z_0-9]*)"$/)) {
      name = name.substr(1, name.length - 2);
      name = ctx.stylize(name, 'name');
    } else {
      name = name.replace(/'/g, "\\'")
                 .replace(/\\"/g, '"')
                 .replace(/(^"|"$)/g, "'");
      name = ctx.stylize(name, 'string');
    }
  }

  return name + ': ' + str;
}


function reduceToSingleString(output, base, braces) {
  var numLinesEst = 0;
  var length = output.reduce(function(prev, cur) {
    numLinesEst++;
    if (cur.indexOf('\n') >= 0) numLinesEst++;
    return prev + cur.replace(/\u001b\[\d\d?m/g, '').length + 1;
  }, 0);

  if (length > 60) {
    return braces[0] +
           (base === '' ? '' : base + '\n ') +
           ' ' +
           output.join(',\n  ') +
           ' ' +
           braces[1];
  }

  return braces[0] + base + ' ' + output.join(', ') + ' ' + braces[1];
}


// NOTE: These type checking functions intentionally don't use `instanceof`
// because it is fragile and can be easily faked with `Object.create()`.
function isArray(ar) {
  return Array.isArray(ar);
}
exports.isArray = isArray;

function isBoolean(arg) {
  return typeof arg === 'boolean';
}
exports.isBoolean = isBoolean;

function isNull(arg) {
  return arg === null;
}
exports.isNull = isNull;

function isNullOrUndefined(arg) {
  return arg == null;
}
exports.isNullOrUndefined = isNullOrUndefined;

function isNumber(arg) {
  return typeof arg === 'number';
}
exports.isNumber = isNumber;

function isString(arg) {
  return typeof arg === 'string';
}
exports.isString = isString;

function isSymbol(arg) {
  return typeof arg === 'symbol';
}
exports.isSymbol = isSymbol;

function isUndefined(arg) {
  return arg === void 0;
}
exports.isUndefined = isUndefined;

function isRegExp(re) {
  return isObject(re) && objectToString(re) === '[object RegExp]';
}
exports.isRegExp = isRegExp;

function isObject(arg) {
  return typeof arg === 'object' && arg !== null;
}
exports.isObject = isObject;

function isDate(d) {
  return isObject(d) && objectToString(d) === '[object Date]';
}
exports.isDate = isDate;

function isError(e) {
  return isObject(e) &&
      (objectToString(e) === '[object Error]' || e instanceof Error);
}
exports.isError = isError;

function isFunction(arg) {
  return typeof arg === 'function';
}
exports.isFunction = isFunction;

function isPrimitive(arg) {
  return arg === null ||
         typeof arg === 'boolean' ||
         typeof arg === 'number' ||
         typeof arg === 'string' ||
         typeof arg === 'symbol' ||  // ES6 symbol
         typeof arg === 'undefined';
}
exports.isPrimitive = isPrimitive;

exports.isBuffer = require('./support/isBuffer');

function objectToString(o) {
  return Object.prototype.toString.call(o);
}


function pad(n) {
  return n < 10 ? '0' + n.toString(10) : n.toString(10);
}


var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep',
              'Oct', 'Nov', 'Dec'];

// 26 Feb 16:19:34
function timestamp() {
  var d = new Date();
  var time = [pad(d.getHours()),
              pad(d.getMinutes()),
              pad(d.getSeconds())].join(':');
  return [d.getDate(), months[d.getMonth()], time].join(' ');
}


// log is just a thin wrapper to console.log that prepends a timestamp
exports.log = function() {
  console.log('%s - %s', timestamp(), exports.format.apply(exports, arguments));
};


/**
 * Inherit the prototype methods from one constructor into another.
 *
 * The Function.prototype.inherits from lang.js rewritten as a standalone
 * function (not on Function.prototype). NOTE: If this file is to be loaded
 * during bootstrapping this function needs to be rewritten using some native
 * functions as prototype setup using normal JavaScript does not work as
 * expected during bootstrapping (see mirror.js in r114903).
 *
 * @param {function} ctor Constructor function which needs to inherit the
 *     prototype.
 * @param {function} superCtor Constructor function to inherit prototype from.
 */
exports.inherits = require('inherits');

exports._extend = function(origin, add) {
  // Don't do anything if add isn't an object
  if (!add || !isObject(add)) return origin;

  var keys = Object.keys(add);
  var i = keys.length;
  while (i--) {
    origin[keys[i]] = add[keys[i]];
  }
  return origin;
};

function hasOwnProperty(obj, prop) {
  return Object.prototype.hasOwnProperty.call(obj, prop);
}

}).call(this,require('_process'),typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
//# sourceMappingURL=data:application/json;charset:utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy91dGlsL3V0aWwuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJmaWxlIjoiZ2VuZXJhdGVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXNDb250ZW50IjpbIi8vIENvcHlyaWdodCBKb3llbnQsIEluYy4gYW5kIG90aGVyIE5vZGUgY29udHJpYnV0b3JzLlxuLy9cbi8vIFBlcm1pc3Npb24gaXMgaGVyZWJ5IGdyYW50ZWQsIGZyZWUgb2YgY2hhcmdlLCB0byBhbnkgcGVyc29uIG9idGFpbmluZyBhXG4vLyBjb3B5IG9mIHRoaXMgc29mdHdhcmUgYW5kIGFzc29jaWF0ZWQgZG9jdW1lbnRhdGlvbiBmaWxlcyAodGhlXG4vLyBcIlNvZnR3YXJlXCIpLCB0byBkZWFsIGluIHRoZSBTb2Z0d2FyZSB3aXRob3V0IHJlc3RyaWN0aW9uLCBpbmNsdWRpbmdcbi8vIHdpdGhvdXQgbGltaXRhdGlvbiB0aGUgcmlnaHRzIHRvIHVzZSwgY29weSwgbW9kaWZ5LCBtZXJnZSwgcHVibGlzaCxcbi8vIGRpc3RyaWJ1dGUsIHN1YmxpY2Vuc2UsIGFuZC9vciBzZWxsIGNvcGllcyBvZiB0aGUgU29mdHdhcmUsIGFuZCB0byBwZXJtaXRcbi8vIHBlcnNvbnMgdG8gd2hvbSB0aGUgU29mdHdhcmUgaXMgZnVybmlzaGVkIHRvIGRvIHNvLCBzdWJqZWN0IHRvIHRoZVxuLy8gZm9sbG93aW5nIGNvbmRpdGlvbnM6XG4vL1xuLy8gVGhlIGFib3ZlIGNvcHlyaWdodCBub3RpY2UgYW5kIHRoaXMgcGVybWlzc2lvbiBub3RpY2Ugc2hhbGwgYmUgaW5jbHVkZWRcbi8vIGluIGFsbCBjb3BpZXMgb3Igc3Vic3RhbnRpYWwgcG9ydGlvbnMgb2YgdGhlIFNvZnR3YXJlLlxuLy9cbi8vIFRIRSBTT0ZUV0FSRSBJUyBQUk9WSURFRCBcIkFTIElTXCIsIFdJVEhPVVQgV0FSUkFOVFkgT0YgQU5ZIEtJTkQsIEVYUFJFU1Ncbi8vIE9SIElNUExJRUQsIElOQ0xVRElORyBCVVQgTk9UIExJTUlURUQgVE8gVEhFIFdBUlJBTlRJRVMgT0Zcbi8vIE1FUkNIQU5UQUJJTElUWSwgRklUTkVTUyBGT1IgQSBQQVJUSUNVTEFSIFBVUlBPU0UgQU5EIE5PTklORlJJTkdFTUVOVC4gSU5cbi8vIE5PIEVWRU5UIFNIQUxMIFRIRSBBVVRIT1JTIE9SIENPUFlSSUdIVCBIT0xERVJTIEJFIExJQUJMRSBGT1IgQU5ZIENMQUlNLFxuLy8gREFNQUdFUyBPUiBPVEhFUiBMSUFCSUxJVFksIFdIRVRIRVIgSU4gQU4gQUNUSU9OIE9GIENPTlRSQUNULCBUT1JUIE9SXG4vLyBPVEhFUldJU0UsIEFSSVNJTkcgRlJPTSwgT1VUIE9GIE9SIElOIENPTk5FQ1RJT04gV0lUSCBUSEUgU09GVFdBUkUgT1IgVEhFXG4vLyBVU0UgT1IgT1RIRVIgREVBTElOR1MgSU4gVEhFIFNPRlRXQVJFLlxuXG52YXIgZm9ybWF0UmVnRXhwID0gLyVbc2RqJV0vZztcbmV4cG9ydHMuZm9ybWF0ID0gZnVuY3Rpb24oZikge1xuICBpZiAoIWlzU3RyaW5nKGYpKSB7XG4gICAgdmFyIG9iamVjdHMgPSBbXTtcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IGFyZ3VtZW50cy5sZW5ndGg7IGkrKykge1xuICAgICAgb2JqZWN0cy5wdXNoKGluc3BlY3QoYXJndW1lbnRzW2ldKSk7XG4gICAgfVxuICAgIHJldHVybiBvYmplY3RzLmpvaW4oJyAnKTtcbiAgfVxuXG4gIHZhciBpID0gMTtcbiAgdmFyIGFyZ3MgPSBhcmd1bWVudHM7XG4gIHZhciBsZW4gPSBhcmdzLmxlbmd0aDtcbiAgdmFyIHN0ciA9IFN0cmluZyhmKS5yZXBsYWNlKGZvcm1hdFJlZ0V4cCwgZnVuY3Rpb24oeCkge1xuICAgIGlmICh4ID09PSAnJSUnKSByZXR1cm4gJyUnO1xuICAgIGlmIChpID49IGxlbikgcmV0dXJuIHg7XG4gICAgc3dpdGNoICh4KSB7XG4gICAgICBjYXNlICclcyc6IHJldHVybiBTdHJpbmcoYXJnc1tpKytdKTtcbiAgICAgIGNhc2UgJyVkJzogcmV0dXJuIE51bWJlcihhcmdzW2krK10pO1xuICAgICAgY2FzZSAnJWonOlxuICAgICAgICB0cnkge1xuICAgICAgICAgIHJldHVybiBKU09OLnN0cmluZ2lmeShhcmdzW2krK10pO1xuICAgICAgICB9IGNhdGNoIChfKSB7XG4gICAgICAgICAgcmV0dXJuICdbQ2lyY3VsYXJdJztcbiAgICAgICAgfVxuICAgICAgZGVmYXVsdDpcbiAgICAgICAgcmV0dXJuIHg7XG4gICAgfVxuICB9KTtcbiAgZm9yICh2YXIgeCA9IGFyZ3NbaV07IGkgPCBsZW47IHggPSBhcmdzWysraV0pIHtcbiAgICBpZiAoaXNOdWxsKHgpIHx8ICFpc09iamVjdCh4KSkge1xuICAgICAgc3RyICs9ICcgJyArIHg7XG4gICAgfSBlbHNlIHtcbiAgICAgIHN0ciArPSAnICcgKyBpbnNwZWN0KHgpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gc3RyO1xufTtcblxuXG4vLyBNYXJrIHRoYXQgYSBtZXRob2Qgc2hvdWxkIG5vdCBiZSB1c2VkLlxuLy8gUmV0dXJucyBhIG1vZGlmaWVkIGZ1bmN0aW9uIHdoaWNoIHdhcm5zIG9uY2UgYnkgZGVmYXVsdC5cbi8vIElmIC0tbm8tZGVwcmVjYXRpb24gaXMgc2V0LCB0aGVuIGl0IGlzIGEgbm8tb3AuXG5leHBvcnRzLmRlcHJlY2F0ZSA9IGZ1bmN0aW9uKGZuLCBtc2cpIHtcbiAgLy8gQWxsb3cgZm9yIGRlcHJlY2F0aW5nIHRoaW5ncyBpbiB0aGUgcHJvY2VzcyBvZiBzdGFydGluZyB1cC5cbiAgaWYgKGlzVW5kZWZpbmVkKGdsb2JhbC5wcm9jZXNzKSkge1xuICAgIHJldHVybiBmdW5jdGlvbigpIHtcbiAgICAgIHJldHVybiBleHBvcnRzLmRlcHJlY2F0ZShmbiwgbXNnKS5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICAgIH07XG4gIH1cblxuICBpZiAocHJvY2Vzcy5ub0RlcHJlY2F0aW9uID09PSB0cnVlKSB7XG4gICAgcmV0dXJuIGZuO1xuICB9XG5cbiAgdmFyIHdhcm5lZCA9IGZhbHNlO1xuICBmdW5jdGlvbiBkZXByZWNhdGVkKCkge1xuICAgIGlmICghd2FybmVkKSB7XG4gICAgICBpZiAocHJvY2Vzcy50aHJvd0RlcHJlY2F0aW9uKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihtc2cpO1xuICAgICAgfSBlbHNlIGlmIChwcm9jZXNzLnRyYWNlRGVwcmVjYXRpb24pIHtcbiAgICAgICAgY29uc29sZS50cmFjZShtc2cpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihtc2cpO1xuICAgICAgfVxuICAgICAgd2FybmVkID0gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuIGZuLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gIH1cblxuICByZXR1cm4gZGVwcmVjYXRlZDtcbn07XG5cblxudmFyIGRlYnVncyA9IHt9O1xudmFyIGRlYnVnRW52aXJvbjtcbmV4cG9ydHMuZGVidWdsb2cgPSBmdW5jdGlvbihzZXQpIHtcbiAgaWYgKGlzVW5kZWZpbmVkKGRlYnVnRW52aXJvbikpXG4gICAgZGVidWdFbnZpcm9uID0gcHJvY2Vzcy5lbnYuTk9ERV9ERUJVRyB8fCAnJztcbiAgc2V0ID0gc2V0LnRvVXBwZXJDYXNlKCk7XG4gIGlmICghZGVidWdzW3NldF0pIHtcbiAgICBpZiAobmV3IFJlZ0V4cCgnXFxcXGInICsgc2V0ICsgJ1xcXFxiJywgJ2knKS50ZXN0KGRlYnVnRW52aXJvbikpIHtcbiAgICAgIHZhciBwaWQgPSBwcm9jZXNzLnBpZDtcbiAgICAgIGRlYnVnc1tzZXRdID0gZnVuY3Rpb24oKSB7XG4gICAgICAgIHZhciBtc2cgPSBleHBvcnRzLmZvcm1hdC5hcHBseShleHBvcnRzLCBhcmd1bWVudHMpO1xuICAgICAgICBjb25zb2xlLmVycm9yKCclcyAlZDogJXMnLCBzZXQsIHBpZCwgbXNnKTtcbiAgICAgIH07XG4gICAgfSBlbHNlIHtcbiAgICAgIGRlYnVnc1tzZXRdID0gZnVuY3Rpb24oKSB7fTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGRlYnVnc1tzZXRdO1xufTtcblxuXG4vKipcbiAqIEVjaG9zIHRoZSB2YWx1ZSBvZiBhIHZhbHVlLiBUcnlzIHRvIHByaW50IHRoZSB2YWx1ZSBvdXRcbiAqIGluIHRoZSBiZXN0IHdheSBwb3NzaWJsZSBnaXZlbiB0aGUgZGlmZmVyZW50IHR5cGVzLlxuICpcbiAqIEBwYXJhbSB7T2JqZWN0fSBvYmogVGhlIG9iamVjdCB0byBwcmludCBvdXQuXG4gKiBAcGFyYW0ge09iamVjdH0gb3B0cyBPcHRpb25hbCBvcHRpb25zIG9iamVjdCB0aGF0IGFsdGVycyB0aGUgb3V0cHV0LlxuICovXG4vKiBsZWdhY3k6IG9iaiwgc2hvd0hpZGRlbiwgZGVwdGgsIGNvbG9ycyovXG5mdW5jdGlvbiBpbnNwZWN0KG9iaiwgb3B0cykge1xuICAvLyBkZWZhdWx0IG9wdGlvbnNcbiAgdmFyIGN0eCA9IHtcbiAgICBzZWVuOiBbXSxcbiAgICBzdHlsaXplOiBzdHlsaXplTm9Db2xvclxuICB9O1xuICAvLyBsZWdhY3kuLi5cbiAgaWYgKGFyZ3VtZW50cy5sZW5ndGggPj0gMykgY3R4LmRlcHRoID0gYXJndW1lbnRzWzJdO1xuICBpZiAoYXJndW1lbnRzLmxlbmd0aCA+PSA0KSBjdHguY29sb3JzID0gYXJndW1lbnRzWzNdO1xuICBpZiAoaXNCb29sZWFuKG9wdHMpKSB7XG4gICAgLy8gbGVnYWN5Li4uXG4gICAgY3R4LnNob3dIaWRkZW4gPSBvcHRzO1xuICB9IGVsc2UgaWYgKG9wdHMpIHtcbiAgICAvLyBnb3QgYW4gXCJvcHRpb25zXCIgb2JqZWN0XG4gICAgZXhwb3J0cy5fZXh0ZW5kKGN0eCwgb3B0cyk7XG4gIH1cbiAgLy8gc2V0IGRlZmF1bHQgb3B0aW9uc1xuICBpZiAoaXNVbmRlZmluZWQoY3R4LnNob3dIaWRkZW4pKSBjdHguc2hvd0hpZGRlbiA9IGZhbHNlO1xuICBpZiAoaXNVbmRlZmluZWQoY3R4LmRlcHRoKSkgY3R4LmRlcHRoID0gMjtcbiAgaWYgKGlzVW5kZWZpbmVkKGN0eC5jb2xvcnMpKSBjdHguY29sb3JzID0gZmFsc2U7XG4gIGlmIChpc1VuZGVmaW5lZChjdHguY3VzdG9tSW5zcGVjdCkpIGN0eC5jdXN0b21JbnNwZWN0ID0gdHJ1ZTtcbiAgaWYgKGN0eC5jb2xvcnMpIGN0eC5zdHlsaXplID0gc3R5bGl6ZVdpdGhDb2xvcjtcbiAgcmV0dXJuIGZvcm1hdFZhbHVlKGN0eCwgb2JqLCBjdHguZGVwdGgpO1xufVxuZXhwb3J0cy5pbnNwZWN0ID0gaW5zcGVjdDtcblxuXG4vLyBodHRwOi8vZW4ud2lraXBlZGlhLm9yZy93aWtpL0FOU0lfZXNjYXBlX2NvZGUjZ3JhcGhpY3Ncbmluc3BlY3QuY29sb3JzID0ge1xuICAnYm9sZCcgOiBbMSwgMjJdLFxuICAnaXRhbGljJyA6IFszLCAyM10sXG4gICd1bmRlcmxpbmUnIDogWzQsIDI0XSxcbiAgJ2ludmVyc2UnIDogWzcsIDI3XSxcbiAgJ3doaXRlJyA6IFszNywgMzldLFxuICAnZ3JleScgOiBbOTAsIDM5XSxcbiAgJ2JsYWNrJyA6IFszMCwgMzldLFxuICAnYmx1ZScgOiBbMzQsIDM5XSxcbiAgJ2N5YW4nIDogWzM2LCAzOV0sXG4gICdncmVlbicgOiBbMzIsIDM5XSxcbiAgJ21hZ2VudGEnIDogWzM1LCAzOV0sXG4gICdyZWQnIDogWzMxLCAzOV0sXG4gICd5ZWxsb3cnIDogWzMzLCAzOV1cbn07XG5cbi8vIERvbid0IHVzZSAnYmx1ZScgbm90IHZpc2libGUgb24gY21kLmV4ZVxuaW5zcGVjdC5zdHlsZXMgPSB7XG4gICdzcGVjaWFsJzogJ2N5YW4nLFxuICAnbnVtYmVyJzogJ3llbGxvdycsXG4gICdib29sZWFuJzogJ3llbGxvdycsXG4gICd1bmRlZmluZWQnOiAnZ3JleScsXG4gICdudWxsJzogJ2JvbGQnLFxuICAnc3RyaW5nJzogJ2dyZWVuJyxcbiAgJ2RhdGUnOiAnbWFnZW50YScsXG4gIC8vIFwibmFtZVwiOiBpbnRlbnRpb25hbGx5IG5vdCBzdHlsaW5nXG4gICdyZWdleHAnOiAncmVkJ1xufTtcblxuXG5mdW5jdGlvbiBzdHlsaXplV2l0aENvbG9yKHN0ciwgc3R5bGVUeXBlKSB7XG4gIHZhciBzdHlsZSA9IGluc3BlY3Quc3R5bGVzW3N0eWxlVHlwZV07XG5cbiAgaWYgKHN0eWxlKSB7XG4gICAgcmV0dXJuICdcXHUwMDFiWycgKyBpbnNwZWN0LmNvbG9yc1tzdHlsZV1bMF0gKyAnbScgKyBzdHIgK1xuICAgICAgICAgICAnXFx1MDAxYlsnICsgaW5zcGVjdC5jb2xvcnNbc3R5bGVdWzFdICsgJ20nO1xuICB9IGVsc2Uge1xuICAgIHJldHVybiBzdHI7XG4gIH1cbn1cblxuXG5mdW5jdGlvbiBzdHlsaXplTm9Db2xvcihzdHIsIHN0eWxlVHlwZSkge1xuICByZXR1cm4gc3RyO1xufVxuXG5cbmZ1bmN0aW9uIGFycmF5VG9IYXNoKGFycmF5KSB7XG4gIHZhciBoYXNoID0ge307XG5cbiAgYXJyYXkuZm9yRWFjaChmdW5jdGlvbih2YWwsIGlkeCkge1xuICAgIGhhc2hbdmFsXSA9IHRydWU7XG4gIH0pO1xuXG4gIHJldHVybiBoYXNoO1xufVxuXG5cbmZ1bmN0aW9uIGZvcm1hdFZhbHVlKGN0eCwgdmFsdWUsIHJlY3Vyc2VUaW1lcykge1xuICAvLyBQcm92aWRlIGEgaG9vayBmb3IgdXNlci1zcGVjaWZpZWQgaW5zcGVjdCBmdW5jdGlvbnMuXG4gIC8vIENoZWNrIHRoYXQgdmFsdWUgaXMgYW4gb2JqZWN0IHdpdGggYW4gaW5zcGVjdCBmdW5jdGlvbiBvbiBpdFxuICBpZiAoY3R4LmN1c3RvbUluc3BlY3QgJiZcbiAgICAgIHZhbHVlICYmXG4gICAgICBpc0Z1bmN0aW9uKHZhbHVlLmluc3BlY3QpICYmXG4gICAgICAvLyBGaWx0ZXIgb3V0IHRoZSB1dGlsIG1vZHVsZSwgaXQncyBpbnNwZWN0IGZ1bmN0aW9uIGlzIHNwZWNpYWxcbiAgICAgIHZhbHVlLmluc3BlY3QgIT09IGV4cG9ydHMuaW5zcGVjdCAmJlxuICAgICAgLy8gQWxzbyBmaWx0ZXIgb3V0IGFueSBwcm90b3R5cGUgb2JqZWN0cyB1c2luZyB0aGUgY2lyY3VsYXIgY2hlY2suXG4gICAgICAhKHZhbHVlLmNvbnN0cnVjdG9yICYmIHZhbHVlLmNvbnN0cnVjdG9yLnByb3RvdHlwZSA9PT0gdmFsdWUpKSB7XG4gICAgdmFyIHJldCA9IHZhbHVlLmluc3BlY3QocmVjdXJzZVRpbWVzLCBjdHgpO1xuICAgIGlmICghaXNTdHJpbmcocmV0KSkge1xuICAgICAgcmV0ID0gZm9ybWF0VmFsdWUoY3R4LCByZXQsIHJlY3Vyc2VUaW1lcyk7XG4gICAgfVxuICAgIHJldHVybiByZXQ7XG4gIH1cblxuICAvLyBQcmltaXRpdmUgdHlwZXMgY2Fubm90IGhhdmUgcHJvcGVydGllc1xuICB2YXIgcHJpbWl0aXZlID0gZm9ybWF0UHJpbWl0aXZlKGN0eCwgdmFsdWUpO1xuICBpZiAocHJpbWl0aXZlKSB7XG4gICAgcmV0dXJuIHByaW1pdGl2ZTtcbiAgfVxuXG4gIC8vIExvb2sgdXAgdGhlIGtleXMgb2YgdGhlIG9iamVjdC5cbiAgdmFyIGtleXMgPSBPYmplY3Qua2V5cyh2YWx1ZSk7XG4gIHZhciB2aXNpYmxlS2V5cyA9IGFycmF5VG9IYXNoKGtleXMpO1xuXG4gIGlmIChjdHguc2hvd0hpZGRlbikge1xuICAgIGtleXMgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyh2YWx1ZSk7XG4gIH1cblxuICAvLyBJRSBkb2Vzbid0IG1ha2UgZXJyb3IgZmllbGRzIG5vbi1lbnVtZXJhYmxlXG4gIC8vIGh0dHA6Ly9tc2RuLm1pY3Jvc29mdC5jb20vZW4tdXMvbGlicmFyeS9pZS9kd3c1MnNidCh2PXZzLjk0KS5hc3B4XG4gIGlmIChpc0Vycm9yKHZhbHVlKVxuICAgICAgJiYgKGtleXMuaW5kZXhPZignbWVzc2FnZScpID49IDAgfHwga2V5cy5pbmRleE9mKCdkZXNjcmlwdGlvbicpID49IDApKSB7XG4gICAgcmV0dXJuIGZvcm1hdEVycm9yKHZhbHVlKTtcbiAgfVxuXG4gIC8vIFNvbWUgdHlwZSBvZiBvYmplY3Qgd2l0aG91dCBwcm9wZXJ0aWVzIGNhbiBiZSBzaG9ydGN1dHRlZC5cbiAgaWYgKGtleXMubGVuZ3RoID09PSAwKSB7XG4gICAgaWYgKGlzRnVuY3Rpb24odmFsdWUpKSB7XG4gICAgICB2YXIgbmFtZSA9IHZhbHVlLm5hbWUgPyAnOiAnICsgdmFsdWUubmFtZSA6ICcnO1xuICAgICAgcmV0dXJuIGN0eC5zdHlsaXplKCdbRnVuY3Rpb24nICsgbmFtZSArICddJywgJ3NwZWNpYWwnKTtcbiAgICB9XG4gICAgaWYgKGlzUmVnRXhwKHZhbHVlKSkge1xuICAgICAgcmV0dXJuIGN0eC5zdHlsaXplKFJlZ0V4cC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbCh2YWx1ZSksICdyZWdleHAnKTtcbiAgICB9XG4gICAgaWYgKGlzRGF0ZSh2YWx1ZSkpIHtcbiAgICAgIHJldHVybiBjdHguc3R5bGl6ZShEYXRlLnByb3RvdHlwZS50b1N0cmluZy5jYWxsKHZhbHVlKSwgJ2RhdGUnKTtcbiAgICB9XG4gICAgaWYgKGlzRXJyb3IodmFsdWUpKSB7XG4gICAgICByZXR1cm4gZm9ybWF0RXJyb3IodmFsdWUpO1xuICAgIH1cbiAgfVxuXG4gIHZhciBiYXNlID0gJycsIGFycmF5ID0gZmFsc2UsIGJyYWNlcyA9IFsneycsICd9J107XG5cbiAgLy8gTWFrZSBBcnJheSBzYXkgdGhhdCB0aGV5IGFyZSBBcnJheVxuICBpZiAoaXNBcnJheSh2YWx1ZSkpIHtcbiAgICBhcnJheSA9IHRydWU7XG4gICAgYnJhY2VzID0gWydbJywgJ10nXTtcbiAgfVxuXG4gIC8vIE1ha2UgZnVuY3Rpb25zIHNheSB0aGF0IHRoZXkgYXJlIGZ1bmN0aW9uc1xuICBpZiAoaXNGdW5jdGlvbih2YWx1ZSkpIHtcbiAgICB2YXIgbiA9IHZhbHVlLm5hbWUgPyAnOiAnICsgdmFsdWUubmFtZSA6ICcnO1xuICAgIGJhc2UgPSAnIFtGdW5jdGlvbicgKyBuICsgJ10nO1xuICB9XG5cbiAgLy8gTWFrZSBSZWdFeHBzIHNheSB0aGF0IHRoZXkgYXJlIFJlZ0V4cHNcbiAgaWYgKGlzUmVnRXhwKHZhbHVlKSkge1xuICAgIGJhc2UgPSAnICcgKyBSZWdFeHAucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwodmFsdWUpO1xuICB9XG5cbiAgLy8gTWFrZSBkYXRlcyB3aXRoIHByb3BlcnRpZXMgZmlyc3Qgc2F5IHRoZSBkYXRlXG4gIGlmIChpc0RhdGUodmFsdWUpKSB7XG4gICAgYmFzZSA9ICcgJyArIERhdGUucHJvdG90eXBlLnRvVVRDU3RyaW5nLmNhbGwodmFsdWUpO1xuICB9XG5cbiAgLy8gTWFrZSBlcnJvciB3aXRoIG1lc3NhZ2UgZmlyc3Qgc2F5IHRoZSBlcnJvclxuICBpZiAoaXNFcnJvcih2YWx1ZSkpIHtcbiAgICBiYXNlID0gJyAnICsgZm9ybWF0RXJyb3IodmFsdWUpO1xuICB9XG5cbiAgaWYgKGtleXMubGVuZ3RoID09PSAwICYmICghYXJyYXkgfHwgdmFsdWUubGVuZ3RoID09IDApKSB7XG4gICAgcmV0dXJuIGJyYWNlc1swXSArIGJhc2UgKyBicmFjZXNbMV07XG4gIH1cblxuICBpZiAocmVjdXJzZVRpbWVzIDwgMCkge1xuICAgIGlmIChpc1JlZ0V4cCh2YWx1ZSkpIHtcbiAgICAgIHJldHVybiBjdHguc3R5bGl6ZShSZWdFeHAucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwodmFsdWUpLCAncmVnZXhwJyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBjdHguc3R5bGl6ZSgnW09iamVjdF0nLCAnc3BlY2lhbCcpO1xuICAgIH1cbiAgfVxuXG4gIGN0eC5zZWVuLnB1c2godmFsdWUpO1xuXG4gIHZhciBvdXRwdXQ7XG4gIGlmIChhcnJheSkge1xuICAgIG91dHB1dCA9IGZvcm1hdEFycmF5KGN0eCwgdmFsdWUsIHJlY3Vyc2VUaW1lcywgdmlzaWJsZUtleXMsIGtleXMpO1xuICB9IGVsc2Uge1xuICAgIG91dHB1dCA9IGtleXMubWFwKGZ1bmN0aW9uKGtleSkge1xuICAgICAgcmV0dXJuIGZvcm1hdFByb3BlcnR5KGN0eCwgdmFsdWUsIHJlY3Vyc2VUaW1lcywgdmlzaWJsZUtleXMsIGtleSwgYXJyYXkpO1xuICAgIH0pO1xuICB9XG5cbiAgY3R4LnNlZW4ucG9wKCk7XG5cbiAgcmV0dXJuIHJlZHVjZVRvU2luZ2xlU3RyaW5nKG91dHB1dCwgYmFzZSwgYnJhY2VzKTtcbn1cblxuXG5mdW5jdGlvbiBmb3JtYXRQcmltaXRpdmUoY3R4LCB2YWx1ZSkge1xuICBpZiAoaXNVbmRlZmluZWQodmFsdWUpKVxuICAgIHJldHVybiBjdHguc3R5bGl6ZSgndW5kZWZpbmVkJywgJ3VuZGVmaW5lZCcpO1xuICBpZiAoaXNTdHJpbmcodmFsdWUpKSB7XG4gICAgdmFyIHNpbXBsZSA9ICdcXCcnICsgSlNPTi5zdHJpbmdpZnkodmFsdWUpLnJlcGxhY2UoL15cInxcIiQvZywgJycpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAucmVwbGFjZSgvJy9nLCBcIlxcXFwnXCIpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAucmVwbGFjZSgvXFxcXFwiL2csICdcIicpICsgJ1xcJyc7XG4gICAgcmV0dXJuIGN0eC5zdHlsaXplKHNpbXBsZSwgJ3N0cmluZycpO1xuICB9XG4gIGlmIChpc051bWJlcih2YWx1ZSkpXG4gICAgcmV0dXJuIGN0eC5zdHlsaXplKCcnICsgdmFsdWUsICdudW1iZXInKTtcbiAgaWYgKGlzQm9vbGVhbih2YWx1ZSkpXG4gICAgcmV0dXJuIGN0eC5zdHlsaXplKCcnICsgdmFsdWUsICdib29sZWFuJyk7XG4gIC8vIEZvciBzb21lIHJlYXNvbiB0eXBlb2YgbnVsbCBpcyBcIm9iamVjdFwiLCBzbyBzcGVjaWFsIGNhc2UgaGVyZS5cbiAgaWYgKGlzTnVsbCh2YWx1ZSkpXG4gICAgcmV0dXJuIGN0eC5zdHlsaXplKCdudWxsJywgJ251bGwnKTtcbn1cblxuXG5mdW5jdGlvbiBmb3JtYXRFcnJvcih2YWx1ZSkge1xuICByZXR1cm4gJ1snICsgRXJyb3IucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwodmFsdWUpICsgJ10nO1xufVxuXG5cbmZ1bmN0aW9uIGZvcm1hdEFycmF5KGN0eCwgdmFsdWUsIHJlY3Vyc2VUaW1lcywgdmlzaWJsZUtleXMsIGtleXMpIHtcbiAgdmFyIG91dHB1dCA9IFtdO1xuICBmb3IgKHZhciBpID0gMCwgbCA9IHZhbHVlLmxlbmd0aDsgaSA8IGw7ICsraSkge1xuICAgIGlmIChoYXNPd25Qcm9wZXJ0eSh2YWx1ZSwgU3RyaW5nKGkpKSkge1xuICAgICAgb3V0cHV0LnB1c2goZm9ybWF0UHJvcGVydHkoY3R4LCB2YWx1ZSwgcmVjdXJzZVRpbWVzLCB2aXNpYmxlS2V5cyxcbiAgICAgICAgICBTdHJpbmcoaSksIHRydWUpKTtcbiAgICB9IGVsc2Uge1xuICAgICAgb3V0cHV0LnB1c2goJycpO1xuICAgIH1cbiAgfVxuICBrZXlzLmZvckVhY2goZnVuY3Rpb24oa2V5KSB7XG4gICAgaWYgKCFrZXkubWF0Y2goL15cXGQrJC8pKSB7XG4gICAgICBvdXRwdXQucHVzaChmb3JtYXRQcm9wZXJ0eShjdHgsIHZhbHVlLCByZWN1cnNlVGltZXMsIHZpc2libGVLZXlzLFxuICAgICAgICAgIGtleSwgdHJ1ZSkpO1xuICAgIH1cbiAgfSk7XG4gIHJldHVybiBvdXRwdXQ7XG59XG5cblxuZnVuY3Rpb24gZm9ybWF0UHJvcGVydHkoY3R4LCB2YWx1ZSwgcmVjdXJzZVRpbWVzLCB2aXNpYmxlS2V5cywga2V5LCBhcnJheSkge1xuICB2YXIgbmFtZSwgc3RyLCBkZXNjO1xuICBkZXNjID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcih2YWx1ZSwga2V5KSB8fCB7IHZhbHVlOiB2YWx1ZVtrZXldIH07XG4gIGlmIChkZXNjLmdldCkge1xuICAgIGlmIChkZXNjLnNldCkge1xuICAgICAgc3RyID0gY3R4LnN0eWxpemUoJ1tHZXR0ZXIvU2V0dGVyXScsICdzcGVjaWFsJyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHN0ciA9IGN0eC5zdHlsaXplKCdbR2V0dGVyXScsICdzcGVjaWFsJyk7XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIGlmIChkZXNjLnNldCkge1xuICAgICAgc3RyID0gY3R4LnN0eWxpemUoJ1tTZXR0ZXJdJywgJ3NwZWNpYWwnKTtcbiAgICB9XG4gIH1cbiAgaWYgKCFoYXNPd25Qcm9wZXJ0eSh2aXNpYmxlS2V5cywga2V5KSkge1xuICAgIG5hbWUgPSAnWycgKyBrZXkgKyAnXSc7XG4gIH1cbiAgaWYgKCFzdHIpIHtcbiAgICBpZiAoY3R4LnNlZW4uaW5kZXhPZihkZXNjLnZhbHVlKSA8IDApIHtcbiAgICAgIGlmIChpc051bGwocmVjdXJzZVRpbWVzKSkge1xuICAgICAgICBzdHIgPSBmb3JtYXRWYWx1ZShjdHgsIGRlc2MudmFsdWUsIG51bGwpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc3RyID0gZm9ybWF0VmFsdWUoY3R4LCBkZXNjLnZhbHVlLCByZWN1cnNlVGltZXMgLSAxKTtcbiAgICAgIH1cbiAgICAgIGlmIChzdHIuaW5kZXhPZignXFxuJykgPiAtMSkge1xuICAgICAgICBpZiAoYXJyYXkpIHtcbiAgICAgICAgICBzdHIgPSBzdHIuc3BsaXQoJ1xcbicpLm1hcChmdW5jdGlvbihsaW5lKSB7XG4gICAgICAgICAgICByZXR1cm4gJyAgJyArIGxpbmU7XG4gICAgICAgICAgfSkuam9pbignXFxuJykuc3Vic3RyKDIpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHN0ciA9ICdcXG4nICsgc3RyLnNwbGl0KCdcXG4nKS5tYXAoZnVuY3Rpb24obGluZSkge1xuICAgICAgICAgICAgcmV0dXJuICcgICAnICsgbGluZTtcbiAgICAgICAgICB9KS5qb2luKCdcXG4nKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBzdHIgPSBjdHguc3R5bGl6ZSgnW0NpcmN1bGFyXScsICdzcGVjaWFsJyk7XG4gICAgfVxuICB9XG4gIGlmIChpc1VuZGVmaW5lZChuYW1lKSkge1xuICAgIGlmIChhcnJheSAmJiBrZXkubWF0Y2goL15cXGQrJC8pKSB7XG4gICAgICByZXR1cm4gc3RyO1xuICAgIH1cbiAgICBuYW1lID0gSlNPTi5zdHJpbmdpZnkoJycgKyBrZXkpO1xuICAgIGlmIChuYW1lLm1hdGNoKC9eXCIoW2EtekEtWl9dW2EtekEtWl8wLTldKilcIiQvKSkge1xuICAgICAgbmFtZSA9IG5hbWUuc3Vic3RyKDEsIG5hbWUubGVuZ3RoIC0gMik7XG4gICAgICBuYW1lID0gY3R4LnN0eWxpemUobmFtZSwgJ25hbWUnKTtcbiAgICB9IGVsc2Uge1xuICAgICAgbmFtZSA9IG5hbWUucmVwbGFjZSgvJy9nLCBcIlxcXFwnXCIpXG4gICAgICAgICAgICAgICAgIC5yZXBsYWNlKC9cXFxcXCIvZywgJ1wiJylcbiAgICAgICAgICAgICAgICAgLnJlcGxhY2UoLyheXCJ8XCIkKS9nLCBcIidcIik7XG4gICAgICBuYW1lID0gY3R4LnN0eWxpemUobmFtZSwgJ3N0cmluZycpO1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiBuYW1lICsgJzogJyArIHN0cjtcbn1cblxuXG5mdW5jdGlvbiByZWR1Y2VUb1NpbmdsZVN0cmluZyhvdXRwdXQsIGJhc2UsIGJyYWNlcykge1xuICB2YXIgbnVtTGluZXNFc3QgPSAwO1xuICB2YXIgbGVuZ3RoID0gb3V0cHV0LnJlZHVjZShmdW5jdGlvbihwcmV2LCBjdXIpIHtcbiAgICBudW1MaW5lc0VzdCsrO1xuICAgIGlmIChjdXIuaW5kZXhPZignXFxuJykgPj0gMCkgbnVtTGluZXNFc3QrKztcbiAgICByZXR1cm4gcHJldiArIGN1ci5yZXBsYWNlKC9cXHUwMDFiXFxbXFxkXFxkP20vZywgJycpLmxlbmd0aCArIDE7XG4gIH0sIDApO1xuXG4gIGlmIChsZW5ndGggPiA2MCkge1xuICAgIHJldHVybiBicmFjZXNbMF0gK1xuICAgICAgICAgICAoYmFzZSA9PT0gJycgPyAnJyA6IGJhc2UgKyAnXFxuICcpICtcbiAgICAgICAgICAgJyAnICtcbiAgICAgICAgICAgb3V0cHV0LmpvaW4oJyxcXG4gICcpICtcbiAgICAgICAgICAgJyAnICtcbiAgICAgICAgICAgYnJhY2VzWzFdO1xuICB9XG5cbiAgcmV0dXJuIGJyYWNlc1swXSArIGJhc2UgKyAnICcgKyBvdXRwdXQuam9pbignLCAnKSArICcgJyArIGJyYWNlc1sxXTtcbn1cblxuXG4vLyBOT1RFOiBUaGVzZSB0eXBlIGNoZWNraW5nIGZ1bmN0aW9ucyBpbnRlbnRpb25hbGx5IGRvbid0IHVzZSBgaW5zdGFuY2VvZmBcbi8vIGJlY2F1c2UgaXQgaXMgZnJhZ2lsZSBhbmQgY2FuIGJlIGVhc2lseSBmYWtlZCB3aXRoIGBPYmplY3QuY3JlYXRlKClgLlxuZnVuY3Rpb24gaXNBcnJheShhcikge1xuICByZXR1cm4gQXJyYXkuaXNBcnJheShhcik7XG59XG5leHBvcnRzLmlzQXJyYXkgPSBpc0FycmF5O1xuXG5mdW5jdGlvbiBpc0Jvb2xlYW4oYXJnKSB7XG4gIHJldHVybiB0eXBlb2YgYXJnID09PSAnYm9vbGVhbic7XG59XG5leHBvcnRzLmlzQm9vbGVhbiA9IGlzQm9vbGVhbjtcblxuZnVuY3Rpb24gaXNOdWxsKGFyZykge1xuICByZXR1cm4gYXJnID09PSBudWxsO1xufVxuZXhwb3J0cy5pc051bGwgPSBpc051bGw7XG5cbmZ1bmN0aW9uIGlzTnVsbE9yVW5kZWZpbmVkKGFyZykge1xuICByZXR1cm4gYXJnID09IG51bGw7XG59XG5leHBvcnRzLmlzTnVsbE9yVW5kZWZpbmVkID0gaXNOdWxsT3JVbmRlZmluZWQ7XG5cbmZ1bmN0aW9uIGlzTnVtYmVyKGFyZykge1xuICByZXR1cm4gdHlwZW9mIGFyZyA9PT0gJ251bWJlcic7XG59XG5leHBvcnRzLmlzTnVtYmVyID0gaXNOdW1iZXI7XG5cbmZ1bmN0aW9uIGlzU3RyaW5nKGFyZykge1xuICByZXR1cm4gdHlwZW9mIGFyZyA9PT0gJ3N0cmluZyc7XG59XG5leHBvcnRzLmlzU3RyaW5nID0gaXNTdHJpbmc7XG5cbmZ1bmN0aW9uIGlzU3ltYm9sKGFyZykge1xuICByZXR1cm4gdHlwZW9mIGFyZyA9PT0gJ3N5bWJvbCc7XG59XG5leHBvcnRzLmlzU3ltYm9sID0gaXNTeW1ib2w7XG5cbmZ1bmN0aW9uIGlzVW5kZWZpbmVkKGFyZykge1xuICByZXR1cm4gYXJnID09PSB2b2lkIDA7XG59XG5leHBvcnRzLmlzVW5kZWZpbmVkID0gaXNVbmRlZmluZWQ7XG5cbmZ1bmN0aW9uIGlzUmVnRXhwKHJlKSB7XG4gIHJldHVybiBpc09iamVjdChyZSkgJiYgb2JqZWN0VG9TdHJpbmcocmUpID09PSAnW29iamVjdCBSZWdFeHBdJztcbn1cbmV4cG9ydHMuaXNSZWdFeHAgPSBpc1JlZ0V4cDtcblxuZnVuY3Rpb24gaXNPYmplY3QoYXJnKSB7XG4gIHJldHVybiB0eXBlb2YgYXJnID09PSAnb2JqZWN0JyAmJiBhcmcgIT09IG51bGw7XG59XG5leHBvcnRzLmlzT2JqZWN0ID0gaXNPYmplY3Q7XG5cbmZ1bmN0aW9uIGlzRGF0ZShkKSB7XG4gIHJldHVybiBpc09iamVjdChkKSAmJiBvYmplY3RUb1N0cmluZyhkKSA9PT0gJ1tvYmplY3QgRGF0ZV0nO1xufVxuZXhwb3J0cy5pc0RhdGUgPSBpc0RhdGU7XG5cbmZ1bmN0aW9uIGlzRXJyb3IoZSkge1xuICByZXR1cm4gaXNPYmplY3QoZSkgJiZcbiAgICAgIChvYmplY3RUb1N0cmluZyhlKSA9PT0gJ1tvYmplY3QgRXJyb3JdJyB8fCBlIGluc3RhbmNlb2YgRXJyb3IpO1xufVxuZXhwb3J0cy5pc0Vycm9yID0gaXNFcnJvcjtcblxuZnVuY3Rpb24gaXNGdW5jdGlvbihhcmcpIHtcbiAgcmV0dXJuIHR5cGVvZiBhcmcgPT09ICdmdW5jdGlvbic7XG59XG5leHBvcnRzLmlzRnVuY3Rpb24gPSBpc0Z1bmN0aW9uO1xuXG5mdW5jdGlvbiBpc1ByaW1pdGl2ZShhcmcpIHtcbiAgcmV0dXJuIGFyZyA9PT0gbnVsbCB8fFxuICAgICAgICAgdHlwZW9mIGFyZyA9PT0gJ2Jvb2xlYW4nIHx8XG4gICAgICAgICB0eXBlb2YgYXJnID09PSAnbnVtYmVyJyB8fFxuICAgICAgICAgdHlwZW9mIGFyZyA9PT0gJ3N0cmluZycgfHxcbiAgICAgICAgIHR5cGVvZiBhcmcgPT09ICdzeW1ib2wnIHx8ICAvLyBFUzYgc3ltYm9sXG4gICAgICAgICB0eXBlb2YgYXJnID09PSAndW5kZWZpbmVkJztcbn1cbmV4cG9ydHMuaXNQcmltaXRpdmUgPSBpc1ByaW1pdGl2ZTtcblxuZXhwb3J0cy5pc0J1ZmZlciA9IHJlcXVpcmUoJy4vc3VwcG9ydC9pc0J1ZmZlcicpO1xuXG5mdW5jdGlvbiBvYmplY3RUb1N0cmluZyhvKSB7XG4gIHJldHVybiBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwobyk7XG59XG5cblxuZnVuY3Rpb24gcGFkKG4pIHtcbiAgcmV0dXJuIG4gPCAxMCA/ICcwJyArIG4udG9TdHJpbmcoMTApIDogbi50b1N0cmluZygxMCk7XG59XG5cblxudmFyIG1vbnRocyA9IFsnSmFuJywgJ0ZlYicsICdNYXInLCAnQXByJywgJ01heScsICdKdW4nLCAnSnVsJywgJ0F1ZycsICdTZXAnLFxuICAgICAgICAgICAgICAnT2N0JywgJ05vdicsICdEZWMnXTtcblxuLy8gMjYgRmViIDE2OjE5OjM0XG5mdW5jdGlvbiB0aW1lc3RhbXAoKSB7XG4gIHZhciBkID0gbmV3IERhdGUoKTtcbiAgdmFyIHRpbWUgPSBbcGFkKGQuZ2V0SG91cnMoKSksXG4gICAgICAgICAgICAgIHBhZChkLmdldE1pbnV0ZXMoKSksXG4gICAgICAgICAgICAgIHBhZChkLmdldFNlY29uZHMoKSldLmpvaW4oJzonKTtcbiAgcmV0dXJuIFtkLmdldERhdGUoKSwgbW9udGhzW2QuZ2V0TW9udGgoKV0sIHRpbWVdLmpvaW4oJyAnKTtcbn1cblxuXG4vLyBsb2cgaXMganVzdCBhIHRoaW4gd3JhcHBlciB0byBjb25zb2xlLmxvZyB0aGF0IHByZXBlbmRzIGEgdGltZXN0YW1wXG5leHBvcnRzLmxvZyA9IGZ1bmN0aW9uKCkge1xuICBjb25zb2xlLmxvZygnJXMgLSAlcycsIHRpbWVzdGFtcCgpLCBleHBvcnRzLmZvcm1hdC5hcHBseShleHBvcnRzLCBhcmd1bWVudHMpKTtcbn07XG5cblxuLyoqXG4gKiBJbmhlcml0IHRoZSBwcm90b3R5cGUgbWV0aG9kcyBmcm9tIG9uZSBjb25zdHJ1Y3RvciBpbnRvIGFub3RoZXIuXG4gKlxuICogVGhlIEZ1bmN0aW9uLnByb3RvdHlwZS5pbmhlcml0cyBmcm9tIGxhbmcuanMgcmV3cml0dGVuIGFzIGEgc3RhbmRhbG9uZVxuICogZnVuY3Rpb24gKG5vdCBvbiBGdW5jdGlvbi5wcm90b3R5cGUpLiBOT1RFOiBJZiB0aGlzIGZpbGUgaXMgdG8gYmUgbG9hZGVkXG4gKiBkdXJpbmcgYm9vdHN0cmFwcGluZyB0aGlzIGZ1bmN0aW9uIG5lZWRzIHRvIGJlIHJld3JpdHRlbiB1c2luZyBzb21lIG5hdGl2ZVxuICogZnVuY3Rpb25zIGFzIHByb3RvdHlwZSBzZXR1cCB1c2luZyBub3JtYWwgSmF2YVNjcmlwdCBkb2VzIG5vdCB3b3JrIGFzXG4gKiBleHBlY3RlZCBkdXJpbmcgYm9vdHN0cmFwcGluZyAoc2VlIG1pcnJvci5qcyBpbiByMTE0OTAzKS5cbiAqXG4gKiBAcGFyYW0ge2Z1bmN0aW9ufSBjdG9yIENvbnN0cnVjdG9yIGZ1bmN0aW9uIHdoaWNoIG5lZWRzIHRvIGluaGVyaXQgdGhlXG4gKiAgICAgcHJvdG90eXBlLlxuICogQHBhcmFtIHtmdW5jdGlvbn0gc3VwZXJDdG9yIENvbnN0cnVjdG9yIGZ1bmN0aW9uIHRvIGluaGVyaXQgcHJvdG90eXBlIGZyb20uXG4gKi9cbmV4cG9ydHMuaW5oZXJpdHMgPSByZXF1aXJlKCdpbmhlcml0cycpO1xuXG5leHBvcnRzLl9leHRlbmQgPSBmdW5jdGlvbihvcmlnaW4sIGFkZCkge1xuICAvLyBEb24ndCBkbyBhbnl0aGluZyBpZiBhZGQgaXNuJ3QgYW4gb2JqZWN0XG4gIGlmICghYWRkIHx8ICFpc09iamVjdChhZGQpKSByZXR1cm4gb3JpZ2luO1xuXG4gIHZhciBrZXlzID0gT2JqZWN0LmtleXMoYWRkKTtcbiAgdmFyIGkgPSBrZXlzLmxlbmd0aDtcbiAgd2hpbGUgKGktLSkge1xuICAgIG9yaWdpbltrZXlzW2ldXSA9IGFkZFtrZXlzW2ldXTtcbiAgfVxuICByZXR1cm4gb3JpZ2luO1xufTtcblxuZnVuY3Rpb24gaGFzT3duUHJvcGVydHkob2JqLCBwcm9wKSB7XG4gIHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBwcm9wKTtcbn1cbiJdfQ==
},{"./support/isBuffer":33,"_process":32,"inherits":31}]},{},[1])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJfc3RyZWFtXzAuanMiLCJhZGhvYy9ob3N0LmpzIiwiYXBpZXZlbnRlbWl0dGVyLmpzIiwiYXJndW1lbnRzLmpzIiwiYXJndW1lbnRzL2Jhc2ljLmpzIiwiYXJndW1lbnRzL2NhbGxiYWNrLmpzIiwiYXJndW1lbnRzL2NvbnRhaW5lci5qcyIsImFyZ3VtZW50cy9kYXRhLmpzIiwiYXJndW1lbnRzL2RhdGFidWZmZXIuanMiLCJhcmd1bWVudHMvZmFjdG9yeS5qcyIsImJvb3RzdHJhcGhvc3QuanMiLCJob3N0Y29ubmVjdGlvbi5qcyIsImxvZy5qcyIsIm1lc3NhZ2luZy5qcyIsIm1lc3NhZ2luZy9jaHJvbWUuanMiLCJtZXNzYWdpbmcvZHVtbXkuanMiLCJyZXF1ZXN0cy5qcyIsInJlcXVlc3RzL2J1cnN0LmpzIiwicmVxdWVzdHMvZ2VuZXJpYy5qcyIsInJlcXVlc3RzL21ldGhvZC5qcyIsInJlc3BvbnNlcy5qcyIsInJlc3BvbnNlcy9hY2suanMiLCJyZXNwb25zZXMvYXJndW1lbnRzLmpzIiwicmVzcG9uc2VzL2J1cnN0LmpzIiwicmVzcG9uc2VzL2Vycm9yLmpzIiwicmVzcG9uc2VzL2dlbmVyaWMuanMiLCJzZXJ2ZXIuanMiLCJzZXRpbW1lZGlhdGUuanMiLCJ1dGlsLmpzIiwiLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Fzc2VydC9hc3NlcnQuanMiLCIuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvaW5oZXJpdHMvaW5oZXJpdHNfYnJvd3Nlci5qcyIsIi4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9wcm9jZXNzL2Jyb3dzZXIuanMiLCIuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdXRpbC9zdXBwb3J0L2lzQnVmZmVyQnJvd3Nlci5qcyIsIi4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy91dGlsL3V0aWwuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ0pBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDbEZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDckxBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2ZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNuQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUM3REE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUM1RUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN2REE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN2REE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3BCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDMUJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDOUxBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDdEVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDNUJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2ZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDOUxBO0FBQ0E7QUFDQTtBQUNBOztBQ0hBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzFGQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDekNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQy9QQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDakJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN0Q0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDM0VBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2pJQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ25FQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3BEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2xPQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN6REE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDN0NBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3hXQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDdkJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN0RkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ0xBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJmaWxlIjoiZ2VuZXJhdGVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXNDb250ZW50IjpbIihmdW5jdGlvbiBlKHQsbixyKXtmdW5jdGlvbiBzKG8sdSl7aWYoIW5bb10pe2lmKCF0W29dKXt2YXIgYT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2lmKCF1JiZhKXJldHVybiBhKG8sITApO2lmKGkpcmV0dXJuIGkobywhMCk7dmFyIGY9bmV3IEVycm9yKFwiQ2Fubm90IGZpbmQgbW9kdWxlICdcIitvK1wiJ1wiKTt0aHJvdyBmLmNvZGU9XCJNT0RVTEVfTk9UX0ZPVU5EXCIsZn12YXIgbD1uW29dPXtleHBvcnRzOnt9fTt0W29dWzBdLmNhbGwobC5leHBvcnRzLGZ1bmN0aW9uKGUpe3ZhciBuPXRbb11bMV1bZV07cmV0dXJuIHMobj9uOmUpfSxsLGwuZXhwb3J0cyxlLHQsbixyKX1yZXR1cm4gbltvXS5leHBvcnRzfXZhciBpPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7Zm9yKHZhciBvPTA7bzxyLmxlbmd0aDtvKyspcyhyW29dKTtyZXR1cm4gc30pIiwidmFyIHNlcnZlciA9IHJlcXVpcmUoJy4vc2VydmVyLmpzJyksXG4gICAgc3J2ID0gbmV3IHNlcnZlci5Ib3N0U2VydmVyKGNocm9tZSk7XG53aW5kb3cuYXBpID0gc2VydmVyO1xuY29uc29sZS5sb2coXCJTZXJ2aW5nLi4uXCIpO1xuIiwiZnVuY3Rpb24gaXNPbGRzdHlsZUdldE1hbmlmZXN0IChtZXNzYWdlKSB7XG4gIC8vIEhlcmUgaXMgYW4gZXhlbXBsYXJ5IG9sZHN0eWxlIG1lc3NhZ2U6XG4gIC8vXG4gIC8vIHtcbiAgLy8gICAgIHRpbWVzdGFtcDogMTQzNTkzMDE4MDM4NSxcbiAgLy8gICAgIG9iamVjdDogXCJydW50aW1lXCIsXG4gIC8vICAgICBtZXRob2Q6IFwiZ2V0TWFuaWZlc3RBc3luY1wiLFxuICAvLyAgICAgYXJnczoge1xuICAvLyAgICAgICBhcmdzOiBbe1xuICAvLyAgICAgICAgIHR5cGU6IFwiZnVuY3Rpb25cIlxuICAvLyAgICAgICB9XVxuICAvLyAgICAgfSxcbiAgLy8gICAgIGVycm9yOiBudWxsLFxuICAvLyAgICAgY2FsbGJhY2tJZDogMTQzNTkzMDE4MDM4NSxcbiAgLy8gICAgIHNlbmRlcjogMTQzNTkzMDE4MDM4NVxuICAvLyAgIH1cblxuICByZXR1cm4gbWVzc2FnZSAmJlxuICAgIG1lc3NhZ2UubWV0aG9kID09IFwiZ2V0TWFuaWZlc3RBc3luY1wiICYmXG4gICAgbWVzc2FnZS5vYmplY3QgPT0gXCJydW50aW1lXCIgJiZcbiAgICBtZXNzYWdlLmNhbGxiYWNrSWQ7XG59XG5cblxuZnVuY3Rpb24gZ2V0U3RhdGUgKGFwaVJvb3QsIHN0YXRlLCBjYikge1xuICB2YXIgZm9ybWF0dGVkU3RhdGUgPSBhcGlSb290LnJ1bnRpbWUuZ2V0TWFuaWZlc3QoKTtcbiAgZm9ybWF0dGVkU3RhdGUuY29ubmVjdGlvbnMgPSBzdGF0ZS5jb25uZWN0aW9ucy5tYXAoZnVuY3Rpb24gKGMpIHtcbiAgICByZXR1cm4gYyAmJiB7XG4gICAgICBidWZmZXJMZW5ndGg6IGMuYnVmZmVyTGVuZ3RoLFxuICAgICAgY29uZjogYy5wb3J0Q29uZixcbiAgICAgIGlkOiBjLmlkLFxuICAgICAgY2xvc2VkOiBjLmNsb3NlZFxuICAgIH07XG4gIH0pLFxuXG4gIGZvcm1hdHRlZFN0YXRlLmtlZXBhbGl2ZXMgPSBzdGF0ZS5rZWVwYWxpdmVzLm1hcChmdW5jdGlvbiAoaykge1xuICAgIHJldHVybiBrICYmIHtcbiAgICAgIGNsaWVudElkOiBrLmNsaWVudElkLFxuICAgICAgY29uZjogay5wb3J0Q29uZixcbiAgICAgIGNsb3NlZDogay5jbG9zZWRcbiAgICB9O1xuICB9KSxcblxuICBjYihmb3JtYXR0ZWRTdGF0ZSk7XG59O1xuXG5mdW5jdGlvbiBzZXR1cEFkSG9jIChzdGF0ZSkge1xuICB2YXIgYXBpUm9vdCA9IHN0YXRlLmFwaVJvb3Q7XG5cbiAgLy8gUmVtZW1iZXIgdG8gYWRkIHRoZXNlIHRvIHRoZSBjbGllbnQgY29uZmlndXJhdGlvbi5cbiAgaWYgKGFwaVJvb3QucnVudGltZSkge1xuICAgIGlmICghYXBpUm9vdC5iYWJlbGZpc2gpIGFwaVJvb3QuYmFiZWxmaXNoID0ge307XG4gICAgYXBpUm9vdC5iYWJlbGZpc2guZ2V0U3RhdGUgPVxuICAgICAgYXBpUm9vdC5ydW50aW1lLmdldE1hbmlmZXN0QXN5bmMgPVxuICAgICAgZ2V0U3RhdGUuYmluZChudWxsLCBhcGlSb290LCBzdGF0ZSk7XG5cblxuICAgIC8vIExpc3RlbiBmb3IgZ2V0IHN0YXRlIHRvIG5vbi1iYWJlbGZpc2ggb3IgZWFybHkgYmFiZWxmaXNoLlxuICAgIGZ1bmN0aW9uIHByb3ZpZGVTdGF0ZSAobXNnLCBzZW5kUmVzcCkge1xuICAgICAgaWYgKG1zZyAmJiAobXNnLm1ldGhvZCA9PSBcImdldFN0YXRlXCIgfHwgaXNPbGRzdHlsZUdldE1hbmlmZXN0KG1zZykpKSB7XG4gICAgICAgIGFwaVJvb3QuYmFiZWxmaXNoLmdldFN0YXRlKHNlbmRSZXNwKTtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9O1xuXG4gICAgc3RhdGUuYm9vdHN0cmFwSG9zdC5jb21tYW5kcy5wdXNoKHByb3ZpZGVTdGF0ZSk7XG4gIH1cblxuICBpZiAoYXBpUm9vdC5zZXJpYWwpIHtcbiAgICBhcGlSb290LnNlcmlhbC5vblJlY2VpdmVFcnJvci5mb3JjZURpc3BhdGNoID0gZnVuY3Rpb24gKGluZm8pIHtcbiAgICAgIHN0YXRlLmNvbm5lY3Rpb25zLmZvckVhY2goZnVuY3Rpb24gKGMpIHtcbiAgICAgICAgaWYgKGMuYXBpRXZlbnQubWV0aG9kTmFtZSA9PSAnc2VyaWFsLm9uUmVjZWl2ZUVycm9yLmFkZExpc3RlbmVyJykge1xuICAgICAgICAgIGMuYXBpRXZlbnQubWV0aG9kUmVxdWVzdC5yZWFsQ2FsbGJhY2soKS5jYWxsKG51bGwsIGluZm8pO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9O1xuICB9XG59XG5cbm1vZHVsZS5leHBvcnRzLnNldHVwQWRIb2MgPSBzZXR1cEFkSG9jO1xuIiwiLyoqXG4gKiBAZmlsZU92ZXJ2aWV3IEEgd3JhcHBlciBhcm91bmQgYSBjaHJvbWUgYXBpIGV2ZW50IG9yIG5vbi1wdXJlIGNhbGxcbiAqIHRoYXQgbmVlZHMgY2xlYW5pbmcgdXAuIFVuZGVyc3RhbmRzIHRoZSBjdXJyZW5jeSBvZiBNZXRob2RSZXF1ZXN0c1xuICogZm9yIGNsZWFuaW5nIHVwIGFuZCBtYW5hZ2luZyBzdGF0ZSBhbmQgcHJvdmlkZXMgYSB1bmlmaWVkIGludGVyZmFjZVxuICogZm9yIGNsZWFuaW5nIGFueSBjYWxsIGJhc2VkIG9uIGNsaWVudCdzIGluc3RydWN0aW9ucyB1cG9uXG4gKiBjb25uZWN0aW9uLlxuICpcbiAqIER1ZSB0byB1c2IuZmluZERldmljZXMgd2hpY2ggb3BlbnMgbXVsdGlwbGUgZGV2aWNlcyBhdCBvbmNlIHdlIG1heVxuICogbmVlZCBtb3JlIHRoYW4gb25lIGNsZWFudXAgbWV0aG9kcyB0byBhY3R1YWxseSBjbG9zZSB0aGUgZXZlbnRcbiAqIGVtaXR0ZXIuXG4gKlxuICogQG5hbWUgYXBpZXZlbnRlbWl0dGVyLmpzXG4gKiBAYXV0aG9yIENocmlzIFBlcml2b2xhcm9wb3Vsb3NcbiAqL1xudmFyIHV0aWwgPSByZXF1aXJlKFwiLi91dGlsXCIpLFxuICAgIEFja1Jlc3BvbnNlID0gcmVxdWlyZSgnLi9yZXNwb25zZXMuanMnKS5BY2tSZXNwb25zZSxcbiAgICBBcmdzUmVzcG9uc2UgPSByZXF1aXJlKCcuL3Jlc3BvbnNlcy5qcycpLkFyZ3NSZXNwb25zZSxcbiAgICBNZXRob2RSZXF1ZXN0ID0gcmVxdWlyZSgnLi9yZXF1ZXN0cy5qcycpLk1ldGhvZFJlcXVlc3QsXG4gICAgQXJndW1lbnRzID0gcmVxdWlyZSgnLi9hcmd1bWVudHMuanMnKS5Bcmd1bWVudHMsXG4gICAgbG9nID0gbmV3IChyZXF1aXJlKCcuL2xvZy5qcycpLkxvZykoJ2FwaWV2ZW50ZW1pdHRlcicpO1xuXG5cbi8qKlxuICogUmVzcG9uc2UgbWV0aG9kcyB0byBpbmplY3QgaW4gYW4gYXBpIGRlcGVuZGluZyBvbiB0aGUgY2xvc2luZyB0eXBlLlxuICovXG52YXIgY2xvc2luZ1Jlc3BvbnNlcyA9IHtcbiAgY2FsbGluZ0FyZ3VtZW50czogZnVuY3Rpb24gKGNsb3NpbmdSZXF1ZXN0KSB7XG4gICAgdmFyIG1ldGhvZCA9IHV0aWwucGF0aDJjYWxsYWJsZSh0aGlzLmhvc3RBcGksIHRoaXMucmV2ZXJzZXIucGF0aCksXG4gICAgICAgIGFyZ3MgPSB0aGlzLm1ldGhvZFJlcXVlc3QuYXJncy5mb3JDYWxsaW5nKCk7XG4gICAgaWYgKCFjbG9zaW5nUmVxdWVzdCkge1xuICAgICAgbWV0aG9kLmFwcGx5KG51bGwsIGFyZ3MpO1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuXG4gICAgaWYgKHRoaXMucmV2ZXJzZXIucGF0aCA9PSBjbG9zaW5nUmVxdWVzdC5tZXRob2QgJiZcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoY2xvc2luZ1JlcXVlc3QuYXJncy5mb3JTZW5kaW5nKCkpID09XG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHRoaXMubWV0aG9kUmVxdWVzdC5hcmdzLmZvclNlbmRpbmcoKSkpIHtcbiAgICAgIG1ldGhvZC5hcHBseShudWxsLCBhcmdzKTtcbiAgICAgIHRoaXMuZGVzdHJveSh0cnVlKTtcbiAgICAgIHJldHVybiBuZXcgQWNrUmVzcG9uc2UoKTtcbiAgICB9XG5cbiAgICByZXR1cm4gbnVsbDtcbiAgfSxcblxuICAvKipcbiAgICogTWF5YmUgY2xlYW51cCBiYXNlZCBvbiB0aGUgYXJndW1lbnRzIG9mIHRoZSBmaXJzdCBjYWxsYmFjay5cbiAgICpcbiAgICogQHBhcmFtIHt1bmRlZmluZWR8TWV0aG9kUmVxZXN0fSBjbG9zaW5nUmVxdWVzdCBBIG1ldGhvZCByZXF1ZXN0XG4gICAqIHRoYXQgaXMgc3VwcG9zZWQgdG8gY2xvc2UuIElmIG5vdCBwcm92aWRlZCBtYWtlIHN1cmUgd2UgYXJlXG4gICAqIGRlc3Ryb3llZCBhcyB0aGVyZSBpcyBub29uZSB0byByZXBvcnQgdG8uXG4gICAqIEByZXR1cm5zIHtudWxsfEFyZ3NSZXNwb25zZX0gVGhlIHJlc3BvbnNlIHRvIGJlIHNlbnQgYWZ0ZXIgdGhlIGNsZWFudXAuXG4gICAqL1xuICBmaXJzdFJlc3BvbnNlOiBmdW5jdGlvbiAoY2xvc2luZ1JlcXVlc3QpIHtcbiAgICB2YXIgZnIgPSB0aGlzLmZpcnN0UmVzcG9uc2VNc2c7XG4gICAgaWYgKCFmciB8fCBmci5yZXNwb25zZVR5cGUgIT0gJ0FyZ3NSZXNwb25zZScpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cblxuICAgIHZhciBjbG9zaW5nQXJnID0gZnIuYXJnc1swXTtcbiAgICBpZiAodGhpcy5yZXZlcnNlci5maXJzdEFyZ1BhdGgpIHtcbiAgICAgIGNsb3NpbmdBcmcgPSBjbG9zaW5nQXJnW3RoaXMucmV2ZXJzZXIuZmlyc3RBcmdQYXRoXTtcbiAgICB9XG5cbiAgICBpZiAoIWNsb3NpbmdSZXF1ZXN0KSB7XG4gICAgICAvLyBKdXN0IGRvIHlvdXIgYmVzdC5cbiAgICAgIHZhciBtciA9IG5ldyBNZXRob2RSZXF1ZXN0KG51bGwsIHRoaXMucmV2ZXJzZXIucGF0aCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5ldyBBcmd1bWVudHMoW2Nsb3NpbmdBcmcsIGZ1bmN0aW9uICgpIHt9XSkpO1xuICAgICAgbXIuY2FsbChudWxsLCB0aGlzLmhvc3RBcGkpO1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuXG4gICAgaWYgKEpTT04uc3RyaW5naWZ5KGNsb3NpbmdBcmcpID09XG4gICAgICAgIEpTT04uc3RyaW5naWZ5KGNsb3NpbmdSZXF1ZXN0LmFyZ3MuZm9yU2VuZGluZygpWzBdKSAmJlxuICAgICAgICBjbG9zaW5nUmVxdWVzdC5tZXRob2QgPT0gdGhpcy5yZXZlcnNlci5wYXRoKSB7XG4gICAgICB0aGlzLmRlc3Ryb3kodHJ1ZSk7XG4gICAgICAvLyBUaGUgcmVxdWVzdCB3aWxsIGJlIGNhbGxlZCBhbmQgd2lsbCBjYWxsIGFuIGFjdHVhbCBjYWxsYmFjay5cbiAgICAgIHJldHVybiBBcmdzUmVzcG9uc2UuYXN5bmMoY2xvc2luZ1JlcXVlc3QsIHRoaXMuaG9zdEFwaSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIG51bGw7XG4gIH0sXG5cbiAgLy8gQmFja3dhcmRzIGNvbXBhdGlibGVcbiAgc2VyaWFsOiBmdW5jdGlvbiAoY2xvc2luZ1JlcXVlc3QpIHtcbiAgICB2YXIgb2xkZmFwID0gdGhpcy5yZXZlcnNlci5maXJzdEFyZ1BhdGggPSAnY29ubmVjdGlvbklkJztcbiAgICByZXR1cm4gY2xvc2luZ1Jlc3BvbnNlcy5maXJzdFJlc3BvbnNlKGNsb3NpbmdSZXF1ZXN0KTtcbiAgICB0aGlzLnJldmVyc2VyLmZpcnN0QXJnUGF0aCA9IG9sZGZhcDtcbiAgfSxcblxuICBkZWZhdWx0OiBmdW5jdGlvbiAoY2xvc2luZ1JlcXVlc3QpIHtcbiAgICByZXR1cm4gY2xvc2luZ1Jlc3BvbnNlcy5zZXJpYWwoY2xvc2luZ1JlcXVlc3QpIHx8XG4gICAgICBjbG9zaW5nUmVzcG9uc2VzLmZpcnN0UmVzcG9uc2UoY2xvc2luZ1JlcXVlc3QpIHx8XG4gICAgICBjbG9zaW5nUmVzcG9uc2VzLmNhbGxpbmdBcmd1bWVudHMoY2xvc2luZ1JlcXVlc3QpO1xuICB9XG59O1xuXG5cbi8qKlxuICogQW4gQXBpIGV2ZW50IGVtaXR0ZXIgb3IgYSBtZXRob2Qgd2l0aCBzaWRlIGVmZmVjdHMgdGhhdCBuZWVkXG4gKiBjbGVhbmluZyB1cC5cbiAqXG4gKiBAcGFyYW0ge01ldGhvZFJlcXVlc3R9IG1ldGhvZFJlcXVlc3QgdGhlIGluZm9ybWF0aW9uIG9uIGhvdyB0byBjYWxsXG4gKiB0aGUgZW1pdHRlclxuICogQHBhcmFtIHtSZXZlcnNlck9iamVjdH0gcmV2ZXJzZXIgYSB7cGF0aCwgdHlwZX0gcmV2ZXJzZXIgb2JqZWN0LlxuICogQHBhcmFtIHtPYmplY3R9IGhvc3RBcGkgVGhlIHJvb3Qgb2YgdGhlIGhvc3QgYXBpLlxuICogQHBhcmFtIHtGdW5jdGlvbn0gY2xvc2VDYiBDYWxsIHRoaXMgd2hlbiBjbG9zZWRcbiAqL1xuZnVuY3Rpb24gQXBpRXZlbnRFbWl0dGVyIChtZXRob2RSZXF1ZXN0LCByZXZlcnNlciwgaG9zdEFwaSwgY2xvc2VDYikge1xuICB2YXIgc2VsZiA9IHRoaXM7XG4gIHRoaXMubWV0aG9kTmFtZSA9IG1ldGhvZFJlcXVlc3QubWV0aG9kO1xuICB0aGlzLnJldmVyc2VyID0gcmV2ZXJzZXI7XG4gIHRoaXMuaG9zdEFwaSA9IGhvc3RBcGk7XG4gIHRoaXMuY2FsbGVkQ2xvc2luZ1JlcXVlc3RzID0gW107XG5cbiAgLy8gUmVtZW1iZXIgdGhlIGZpcnN0IHJlc3BvbnNlXG4gIHRoaXMubWV0aG9kUmVxdWVzdCA9IG1ldGhvZFJlcXVlc3Q7XG4gIHRoaXMubWV0aG9kUmVxdWVzdC5hcmdzLnNldExlbnMoZnVuY3Rpb24gKGNiKSB7XG4gICAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICAgIHZhciBhcmdzID0gW10uc2xpY2UuY2FsbChhcmd1bWVudHMpO1xuICAgICAgc2VsZi5maXJzdFJlc3BvbnNlTXNnID0gc2VsZi5maXJzdFJlc3BvbnNlTXNnIHx8IGFyZ3NbMF07XG4gICAgICBjYi5hcHBseShudWxsLCBhcmdzKTtcbiAgICB9O1xuICB9KTtcbiAgdGhpcy5tZXRob2RSZXF1ZXN0LmFyZ3Muc2V0TGVucyA9IG51bGw7XG5cbiAgdGhpcy5tYXliZVJ1bkNsb3NlciA9IGZ1bmN0aW9uIChjbG9zaW5nUmVxdWVzdCkge1xuICAgIGlmIChzZWxmLmNsb3NlZCkge1xuICAgICAgY29uc29sZS5lcnJvcihcIlRyeWluZyB0byBjbG9zZSBhIGNsb3NlZCBldmVudCBlbWl0dGVyXCIpO1xuICAgICAgcmV0dXJuIG51bGw7ICAgICAgICAgICAgICAgICAvL1RIaXMgc2hvdWxkbjt0IGhhcHBlblxuICAgIH1cblxuICAgIC8vIERlZmF1bHQgdG8gKnNvbWUqIHdheSBvZiBoYW5kbGluZyByZXNwb25zZXMuXG4gICAgdmFyIGNsb3NpbmdSZXNwb25zZUZhY3RvcnkgPSBjbG9zaW5nUmVzcG9uc2VzW3NlbGYucmV2ZXJzZXIudHlwZV0gfHxcbiAgICAgICAgICBjbG9zaW5nUmVzcG9uc2VzLmRlZmF1bHQsXG4gICAgICAgIHJldCA9IGNsb3NpbmdSZXNwb25zZUZhY3RvcnkuY2FsbChzZWxmLCBjbG9zaW5nUmVxdWVzdCk7XG5cbiAgICBpZiAocmV0KSB7XG4gICAgICBsb2cubG9nKFwiQ2xvc2luZ1tcIiArIHNlbGYucmV2ZXJzZXIudHlwZSArIFwiXTpcIiwgcmV0LFxuICAgICAgICAgICAgICBcIndpdGhcIiwgY2xvc2luZ1JlcXVlc3QpO1xuICAgIH1cbiAgICByZXR1cm4gcmV0O1xuICB9O1xuXG4gIC8vIEFjdHVhbGx5IHRyaWdnZXIgdGhlIGV2ZW50LlxuICB0aGlzLmNsb3NlQ2IgPSBjbG9zZUNiO1xufVxuXG5BcGlFdmVudEVtaXR0ZXIucHJvdG90eXBlID0ge1xuICAvKipcbiAgICogQWN0dWFsbHkgcnVuIHRoZSBhcGkgZXZlbnQgZW1pdHRlci5cbiAgICovXG4gIGZpcmU6IGZ1bmN0aW9uICgpIHtcbiAgICB0aGlzLm1ldGhvZFJlcXVlc3QuY2FsbChudWxsLCB0aGlzLmhvc3RBcGkpO1xuICB9LFxuXG4gIC8qKlxuICAgKiBDYWxsIGFsbCB0aGUgY2xvc2luZyByZXF1ZXN0cyB0byBjbG9zZSB0aGlzIGV2ZW50LlxuICAgKiBAcGFyYW0ge0Jvb2xlYW59IHNoYWxsb3cgVHJ1ZSBtZWFucyB0aGUgQVBJIHBhcnQgb2YgZGVzdHJveWluZ1xuICAgKiBoYXMgYmVlbiBoYW5kbGVkLlxuICAgKi9cbiAgZGVzdHJveTogZnVuY3Rpb24gKHNoYWxsb3cpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgLy8gQ2xvc2luZyB0aGlzIGFuZCB0aGUgY29ubmVjdGlvbiB3aWxsIGNyZWF0ZSBhIGxvb3Agc28gZG9uJ3Qgb21pdCB0aGlzLlxuICAgIGlmICh0aGlzLmNsb3NlZCkgcmV0dXJuO1xuICAgIGlmICghc2hhbGxvdykgdGhpcy5tYXliZVJ1bkNsb3NlcigpO1xuICAgIHRoaXMuY2xvc2VkID0gdHJ1ZTtcbiAgICB0aGlzLmNsb3NlQ2IoKTtcbiAgICBsb2cubG9nKFwiRGlzY29uZWN0ZWQ6XCIsIHRoaXMubWV0aG9kUmVxdWVzdC5mb3JTZW5kaW5nKCkpO1xuICB9LFxuXG4gIG1pc3NpbmdSZXZlcnNlQ2I6IGZ1bmN0aW9uICgpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJObyBzdWNoIG1ldGhvZCBhcyBcIiArIHRoaXMubWV0aG9kTmFtZSk7XG4gIH0sXG5cbiAgbWlzc2luZ01ldGhvZENiOiBmdW5jdGlvbiAoKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiTm8gcmV2ZXJzZSBtZXRob2QgZm9yIFwiICsgdGhpcy5tZXRob2ROYW1lKTtcbiAgfVxufTtcblxubW9kdWxlLmV4cG9ydHMuQXBpRXZlbnRFbWl0dGVyID0gQXBpRXZlbnRFbWl0dGVyO1xuIiwiLyoqXG4gKiBAZmlsZU92ZXJ2aWV3IEFic3RyYWN0aW9ucyBmb3IgaGFuZGxpbmcgYXJndW1lbnQgdHJhbnNmb3JtYXRpb24gZm9yXG4gKiB0cmFuc3BvcnRhdGlvbiBiZXR3ZWVuIGhvc3QtY2xpZW50LlxuICogQG5hbWUgYXJndW1lbnRzLmpzXG4gKiBAYXV0aG9yIENocmlzIFBlcml2b2xhcm91bG9zXG4gKi9cblxuLy8gVGhlIHNvcnRpbmcgYmVsb3cgd2lsbCBiZSByZWZsZWN0ZWQuXG5tb2R1bGUuZXhwb3J0cy5DYWxsYmFja0FyZ3VtZW50ID0gcmVxdWlyZSgnLi9hcmd1bWVudHMvY2FsbGJhY2suanMnKTtcbm1vZHVsZS5leHBvcnRzLkRhdGFBcmd1bWVudCA9IHJlcXVpcmUoJy4vYXJndW1lbnRzL2RhdGEuanMnKTtcbm1vZHVsZS5leHBvcnRzLkRhdGFidWZmZXJBcmd1bWVudCA9IHJlcXVpcmUoJy4vYXJndW1lbnRzL2RhdGFidWZmZXIuanMnKTtcbm1vZHVsZS5leHBvcnRzLkJhc2ljQXJndW1lbnQgPSByZXF1aXJlKCcuL2FyZ3VtZW50cy9iYXNpYy5qcycpO1xubW9kdWxlLmV4cG9ydHMuQXJndW1lbnRzID0gcmVxdWlyZSgnLi9hcmd1bWVudHMvY29udGFpbmVyLmpzJyk7XG5tb2R1bGUuZXhwb3J0cy5hcmd1bWVudEZhY3RvcnkgPSByZXF1aXJlKCcuL2FyZ3VtZW50cy9mYWN0b3J5LmpzJykuYXJndW1lbnRGYWN0b3J5O1xubW9kdWxlLmV4cG9ydHMuYXJndW1lbnRDbGFzc2VzID0gcmVxdWlyZSgnLi9hcmd1bWVudHMvZmFjdG9yeS5qcycpLmFyZ3VtZW50Q2xhc3NlcztcbiIsInZhciBhcmd1bWVudENsYXNzZXMgPSByZXF1aXJlKCcuL2ZhY3RvcnkuanMnKS5hcmd1bWVudENsYXNzZXM7XG5cbi8qKlxuICogQW4gYWxyZWFkeSBzZXJpYWxpemFibGUgYXJndW1lbnQgYm94ZXIuXG4gKiBAcGFyYW0ge2FyZ3VtZW50fSBhcmdcbiAqL1xuZnVuY3Rpb24gQmFzaWNBcmd1bWVudChhcmcpIHtcbiAgdGhpcy52YWx1ZSA9IGFyZztcbn1cbi8qKlxuICogV2V0aGVyIHdlIGNhbiB3cmFwLiBXZSBhc3N1bWUgd2UgYWx3YXlzIGNhbi5cbiAqIEBwYXJhbSB7YW55dGhpbmd9IGFyZ1xuICogQHJldHVybnMge0Jvb2xlYW59IEFsd2F5cyB0cnVlLlxuICovXG5CYXNpY0FyZ3VtZW50LmNhbldyYXAgPSBmdW5jdGlvbiAoYXJnKSB7XG4gIHJldHVybiB0cnVlO1xufTtcblxuQmFzaWNBcmd1bWVudC5wcm90b3R5cGUgPSB7XG4gIC8qKlxuICAgKiBAcmV0dXJucyB7YW55dGhpbmd9IEp1c3QgcmV0dXJuIHRoZSB2YWx1ZS5cbiAgICovXG4gIGZvckNhbGxpbmc6IGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gdGhpcy52YWx1ZTtcbiAgfSxcblxuICAvKipcbiAgICogQHJldHVybnMge2FueXRoaW5nfSBKdXN0IHJldHVybiB0aGUgdmFsdWUuXG4gICAqL1xuICBmb3JTZW5kaW5nOiBmdW5jdGlvbiAoKSB7XG4gICAgcmV0dXJuIHRoaXMudmFsdWU7XG4gIH1cbn07XG5hcmd1bWVudENsYXNzZXMucHVzaChCYXNpY0FyZ3VtZW50KTtcbm1vZHVsZS5leHBvcnRzID0gQmFzaWNBcmd1bWVudDtcbiIsInZhciBhcmd1bWVudENsYXNzZXMgPSByZXF1aXJlKCcuL2ZhY3RvcnkuanMnKS5hcmd1bWVudENsYXNzZXM7XG5cbi8qKlxuICogV3JhcCBhIGNhbGxiYWNrLiBUaGUgY2FsbGJhY2sgd2lsbCBnZXQgYW4gaWQuIFRoZSBhcmcncyBpZCAod2V0aGVyXG4gKiBmdW5jdGlvbiBvciBvYmplY3QpIHByZWNlZWRzIHRoZSByZXBsYWNlQ2IgaWQuXG4gKlxuICogQHBhcmFtIHtGdW5jdGlvbnxPYmplY3R9IGFyZyBhIHNlcmlhbGl6ZWQgQ2FsbGJhY2tBcmd1bWVudCBvciB0aGVcbiAqIGNhbGxiYWNrIGl0c2VsZi5cbiAqIEBwYXJhbSB7RnVuY3Rpb259IHJlcGxhY2VDYiBpZiB0aGUgcHJvdmlkZWQgYXJnIHdhcyBzZXJpYWxpemVkXG4gKiBzdWJzdGl0dXRlIGl0IHdpdGggdGhpcyB3aGVuIGFza2VkIGZvciBhIGNhbGxhYmxlLlxuICovXG5mdW5jdGlvbiBDYWxsYmFja0FyZ3VtZW50KGFyZywgcmVwbGFjZUNiKSB7XG4gIGlmICghQ2FsbGJhY2tBcmd1bWVudC5jYW5XcmFwKGFyZykpIHtcbiAgICB0aHJvdyBFcnJvcihcIkNhbnQgd3JhcCBhcmd1bWVudCBcIiArIGFyZyArIFwiYXMgYSBmdW5jdGlvblwiKTtcbiAgfVxuXG4gIHRoaXMucmVwbGFjZUNiID0gcmVwbGFjZUNiIHx8IG51bGw7XG4gIHRoaXMuaWQgPSBhcmcuaWQgfHxcbiAgICAodGhpcy5yZXBsYWNlQ2IgJiYgdGhpcy5yZXBsYWNlQ2IuaWQpIHx8XG4gICAgRGF0ZS5ub3coKSArIE1hdGgucmFuZG9tKCk7XG4gIHRoaXMuY2FsbGJhY2sgPSBhcmcgaW5zdGFuY2VvZiBGdW5jdGlvbiA/IGFyZyA6IHJlcGxhY2VDYjtcblxuICBpZiAodGhpcy5jYWxsYmFjaykge1xuICAgIHRoaXMuY2FsbGJhY2suaWQgPSB0aGlzLmlkO1xuICB9XG5cbiAgdGhpcy5wbGFjZWhvbGRlciA9IHtpZDogdGhpcy5pZCwgaXNDYWxsYmFjazogdHJ1ZX07XG59XG5cbi8qKlxuICogQ2hlY2sgaWYgdGhlIGFyZ3VtZW50IGlzIHN1aXRhYmxlIGZvciB3cmFwcGluZy5cbiAqXG4gKiBAcGFyYW0ge2FueXRoaW5nfSBhcmdcbiAqIEByZXR1cm5zIHtCb29sZWFufSBUcnVlIGlmIGl0J3Mgc2FmZSB0byBib3ggd2l0aCB0aGlzIHR5cGUuXG4gKi9cbkNhbGxiYWNrQXJndW1lbnQuY2FuV3JhcCA9IGZ1bmN0aW9uIChhcmcpIHtcbiAgcmV0dXJuIGFyZyAmJiAoYXJnIGluc3RhbmNlb2YgRnVuY3Rpb24gfHwgYXJnLmlzQ2FsbGJhY2spO1xufTtcblxuQ2FsbGJhY2tBcmd1bWVudC5wcm90b3R5cGUgPSB7XG4gIC8qKlxuICAgKiBAcmV0dXJucyB7RnVuY3Rpb24gfSBBIGNhbGxhYmxlIHRoYXQgd2lsbCBlaXRoZXIgZG8gdGhlIGpvYiBvblxuICAgKiB0aGUgY2xpZW50LCBvciBzZW5kIGEgbWVzc2FnZS5cbiAgICovXG4gIGZvckNhbGxpbmc6IGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gdGhpcy5sZW5zID8gdGhpcy5sZW5zKHRoaXMuY2FsbGJhY2spIDogdGhpcy5jYWxsYmFjaztcbiAgfSxcblxuICAvKipcbiAgICogQHJldHVybnMge09iamVjdH0gQSBzZXJpYWxpemFibGUgb2JqZWN0LlxuICAgKi9cbiAgZm9yU2VuZGluZzogZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiB0aGlzLnBsYWNlaG9sZGVyO1xuICB9LFxuXG4gIHNldExlbnM6IGZ1bmN0aW9uIChsZW5zKSB7XG4gICAgdGhpcy5sZW5zID0gbGVucztcbiAgfVxufTtcbmFyZ3VtZW50Q2xhc3Nlcy5wdXNoKENhbGxiYWNrQXJndW1lbnQpO1xubW9kdWxlLmV4cG9ydHMgPSBDYWxsYmFja0FyZ3VtZW50O1xuIiwiLyoqXG4gKiBAZmlsZU92ZXJ2aWV3IEFic3RyYWN0aW9ucyBmb3IgaGFuZGxpbmcgYXJndW1lbnQgdHJhbnNmb3JtYXRpb24gZm9yXG4gKiB0cmFuc3BvcnRhdGlvbiBiZXR3ZWVuIGhvc3QtY2xpZW50LlxuICogQG5hbWUgY29udGFpbmVyLmpzXG4gKiBAYXV0aG9yIENocmlzIFBlcml2b2xhcm91bG9zXG4gKi9cblxudmFyIENhbGxiYWNrQXJndW1lbnQgPSByZXF1aXJlKCcuL2NhbGxiYWNrLmpzJyksXG4gICAgYXJndW1lbnRGYWN0b3J5ID0gcmVxdWlyZSgnLi9mYWN0b3J5LmpzJykuYXJndW1lbnRGYWN0b3J5O1xuXG4vKipcbiAqIEFuIHdyYXBwZXIgYXJvdW5kIGFuIGFyZ3VtZW50cyBsaXN0IHRoYXQgYWJzdHJhY3RzIGFsbFxuICogdHJhc2Zvcm1hdGlvbnMgdG8gc2VyaWFsaXplIHRoZW0sIGNvbnZlcnQgdGhlbSB0byBhIGNhbGxhYmxlIHN0YXRlLFxuICogc3Vic3RpdHV0ZSBjYWxsYmFja3Mgd2l0aCAnc2VuZCByZXNwb25zZScgY2FsbGJha2NzIGV0Yy4gV2Ugc3VwcG9ydFxuICogb25seSBvbmUgY2FsbGJhY2sgcGVyIEFyZ3VtZW50cyBvYmplY3QuIFRoaXMgb2JqZWN0IHdpbGwgZG8gdGhlXG4gKiByaWdodCB0aGluZyBkZXBlbmRpbmcgb24gd2hldGhlciB3ZWFyZSBvbiB0aGUgaG9zdCBvciB0aGUgY2xpZW50LlxuICpcbiAqIEBwYXJhbSB7QXJyYXl9IGFyZ3VtZW50cyBBbiBhcnJheSBvZiBhcmd1bWVudHMgZWl0aGVyIHNlcmlhbGl6ZWQgb3JcbiAqIG5vdC4gVGhlIGVsZW1lbnRzIHdpbGwgYmUgaGFuZGxlZCBieSBhcmd1bWVudCB0eXBlcy5cbiAqIEBwYXJhbSB7RnVuY3Rpb259IHJlcGxhY2VDYiBUaGUgJ3NlbmQgcmVxdWVzdCcgY2FsbGJhY2sgdHlwaWNhbGx5XG4gKiB0byBzdWJzdGl0dXRlIHRoZSBjYWxsYmFjayBpbiB0aGUgYXJndW1lbnRzLlxuICovXG5mdW5jdGlvbiBBcmd1bWVudHMgKGFyZ3VtZW50cywgcmVwbGFjZUNiKSB7XG4gIHRoaXMuYXJndW1lbnRzID0gYXJndW1lbnRzLm1hcChmdW5jdGlvbiAoYSkge1xuICAgIHJldHVybiBhcmd1bWVudEZhY3RvcnkoYSwgcmVwbGFjZUNiKTtcbiAgfSk7XG59XG5cbkFyZ3VtZW50cy5wcm90b3R5cGUgPSB7XG4gIC8qKlxuICAgKiBUaGUgYXJndW1lbnQgbGlzdCBzdWl0YWJsZSBmb3IgcGFzc2luZyB0byBhbiBhcGkgbWV0aG9kLlxuICAgKiBAcmV0dXJucyB7QXJyYXl9IEFuIGFycmF5IG9mIGFyZ3VtZW50cyBhcyBleHBlY3RlZCBieSB0aGUgQVBJXG4gICAqL1xuICBmb3JDYWxsaW5nOiBmdW5jdGlvbiAoKSB7XG4gICAgcmV0dXJuIHRoaXMuYXJndW1lbnRzLm1hcChmdW5jdGlvbiAoYSkge3JldHVybiBhLmZvckNhbGxpbmcoKTt9KTtcbiAgfSxcblxuICAvKipcbiAgICogVGhlIGFyZ3VtZW50IGxpc3Qgc3VpdGFibGUgZm9yIHNlbmRpbmcgb3ZlciB0aGUgbWVzc2FnZSBwYXNzaW5nXG4gICAqIGFwaSBvZiBjaHJvbWUuXG4gICAqIEByZXR1cm5zIHtBcnJheX0gVGhlIGFyZ3VtZW50IGFycmF5IHNlcmlhbGl6ZWQuXG4gICAqL1xuICBmb3JTZW5kaW5nOiBmdW5jdGlvbiAoKSB7XG4gICAgcmV0dXJuIHRoaXMuYXJndW1lbnRzLm1hcChmdW5jdGlvbiAoYSkge1xuICAgICAgcmV0dXJuIGEuZm9yU2VuZGluZygpO1xuICAgIH0pO1xuICB9LFxuXG4gIC8qKlxuICAgKiBEZXBlbmRpbmcgb24gd2V0aGVyIHdlIGFyZSBvbiB0aGUgY2xpZW50IG9yIHRoZSBob3N0IGdldCB0aGVcbiAgICogY2FsbGJhY2sgZm91bmQgaW4gdGhlIGFyZ3VtZW50cy5cbiAgICpcbiAgICogQHJldHVybnMge0Z1bmN0aW9ufSBFaXRoZXIgdGhlICdzZW5kIHJlc3BvbnNlJyBjYWxsYmFjaywgb3IgdGhlXG4gICAqIGFjdHVhbCBjYWxsYmFjay5cbiAgICovXG4gIGdldENhbGxiYWNrOiBmdW5jdGlvbiAoKSB7XG4gICAgdmFyIGNiQXJnID0gdGhpcy5hcmd1bWVudHMuZmlsdGVyKGZ1bmN0aW9uIChhKSB7XG4gICAgICByZXR1cm4gYSBpbnN0YW5jZW9mIENhbGxiYWNrQXJndW1lbnQ7XG4gICAgfSlbMF0sXG4gICAgICAgIHJldCA9IGNiQXJnID8gY2JBcmcuZm9yQ2FsbGluZygpIDogdGhpcy5yZXBsYWNlQ2I7XG5cbiAgICByZXR1cm4gcmV0O1xuICB9LFxuXG4gIHNldExlbnM6IGZ1bmN0aW9uKGxlbnMpIHtcbiAgICBpZiAodGhpcy5yZXBsYWNlQ2IpIHtcbiAgICAgIHRoaXMucmVwbGFjZUNiID0gbGVucyh0aGlzLnJlcGxhY2VDYik7XG4gICAgfVxuXG4gICAgdGhpcy5hcmd1bWVudHMuZm9yRWFjaChmdW5jdGlvbihhKSB7XG4gICAgICBpZiAoYS5zZXRMZW5zKSBhLnNldExlbnMobGVucyk7XG4gICAgfSk7XG4gIH1cbn07XG5cbm1vZHVsZS5leHBvcnRzID0gQXJndW1lbnRzO1xuIiwidmFyIGFyZ3VtZW50Q2xhc3NlcyA9IHJlcXVpcmUoJy4vZmFjdG9yeS5qcycpLmFyZ3VtZW50Q2xhc3NlcyxcbiAgICBEYXRhYnVmZmVyQXJndW1lbnQgPSByZXF1aXJlKCcuL2RhdGFidWZmZXIuanMnKTtcblxuZnVuY3Rpb24gRGF0YUFyZ3VtZW50KGFyZykge1xuICBpZiAoIURhdGFBcmd1bWVudC5jYW5XcmFwKGFyZykpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJFeHBlY3RlZCBvYmplY3QgbGlrZSB7ZGF0YTogQXJyYXlCdWZmZXJ9LCBnb3Q6IFwiLCBhcmcpO1xuICB9XG4gIHRoaXMuYXJnID0gYXJnO1xuICB0aGlzLmRhdGEgPSBuZXcgRGF0YWJ1ZmZlckFyZ3VtZW50KGFyZy5kYXRhKTtcbn1cblxuRGF0YUFyZ3VtZW50LmNhbldyYXAgPSBmdW5jdGlvbiAoYXJnKSB7XG4gIHJldHVybiBhcmcgaW5zdGFuY2VvZiBPYmplY3QgJiZcbiAgICBEYXRhYnVmZmVyQXJndW1lbnQuY2FuV3JhcChhcmcuZGF0YSk7XG59O1xuXG5EYXRhQXJndW1lbnQucHJvdG90eXBlID0ge1xuICBhcmdDb3B5OiBmdW5jdGlvbiAoKSB7XG4gICAgdmFyIHJldCA9IHt9LCBzZWxmID0gdGhpcztcbiAgICBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyh0aGlzLmFyZykuZm9yRWFjaChmdW5jdGlvbiAoaykge1xuICAgICAgcmV0W2tdID0gc2VsZi5hcmdba107XG4gICAgfSk7XG5cbiAgICByZXR1cm4gcmV0O1xuICB9LFxuXG4gIC8qKlxuICAgKiBAcmV0dXJucyB7T2JqZWN0fSBXaGF0IHRoZSBBUEkgZXhwZWN0cyBvciB3aGF0IGlzIGV4cGVjdGVkIGJ5XG4gICAqIHRoZSBBUEkuXG4gICAqL1xuICBmb3JDYWxsaW5nOiBmdW5jdGlvbiAoKSB7XG4gICAgdmFyIHJldCA9IHRoaXMuYXJnQ29weSgpO1xuICAgIHJldC5kYXRhID0gdGhpcy5kYXRhLmZvckNhbGxpbmcoKTtcbiAgICByZXR1cm4gcmV0O1xuICB9LFxuXG4gIC8qKlxuICAgKiBAcmV0dXJucyB7T2JqZWN0fSBBbiBzZXJpYWxpemFibGUgb2JqZWN0IHRoYXQgd2UgY2FuIHR1cm4gYmFja1xuICAgKiBpbnRvIGEgZGF0YWJ1ZmZlciBjb250YWluZXIuXG4gICAqL1xuICBmb3JTZW5kaW5nOiBmdW5jdGlvbiAoKSB7XG4gICAgdmFyIHJldCA9IHRoaXMuYXJnQ29weSgpO1xuICAgIHJldC5kYXRhID0gdGhpcy5kYXRhLmZvclNlbmRpbmcoKTtcbiAgICByZXR1cm4gcmV0O1xuICB9LFxuXG4gIGNvbmNhdDogZnVuY3Rpb24gKG1zZykge1xuICAgIGlmICghbXNnLmRhdGEgfHwgIW1zZy5kYXRhLmlzQXJyYXlCdWZmZXIpIHJldHVybiB0aGlzO1xuICAgIHZhciByZXQgPSB0aGlzLmZvclNlbmRpbmcoKTtcbiAgICByZXQuZGF0YSA9IHRoaXMuZGF0YS5jb25jYXQobXNnLmRhdGEpLmZvclNlbmRpbmcoKTtcbiAgICByZXR1cm4gbmV3IERhdGFBcmd1bWVudChyZXQpO1xuICB9XG59O1xuYXJndW1lbnRDbGFzc2VzLnB1c2goRGF0YUFyZ3VtZW50KTtcbm1vZHVsZS5leHBvcnRzID0gRGF0YUFyZ3VtZW50O1xuIiwidmFyIGFyZ3VtZW50Q2xhc3NlcyA9IHJlcXVpcmUoJy4vZmFjdG9yeS5qcycpLmFyZ3VtZW50Q2xhc3NlcyxcbiAgICB1dGlsID0gcmVxdWlyZSgnLi4vdXRpbC5qcycpO1xuLyoqXG4gKiBCb3hpbmcgZm9yIGRhdGFidWZmZXJzLlxuICpcbiAqIEBwYXJhbSB7RGF0YUJ1ZmZlcnxPYmplY3R9IGFyZyBFaXRoZXIgYSBkYXRhYnVmZmVyIG9yIGEgc2VyaWFsaXplZFxuICogZGF0YWJ1ZmZlciBvYmplY3QuXG4gKiBAdGhyb3dzIHtFcnJvcn0gUHJvdGVjdHMgeW91IGluIGNhc2UgeW91IGZvcmdvdCB0byBjYWxsIGNhbldyYXBcbiAqL1xuZnVuY3Rpb24gRGF0YWJ1ZmZlckFyZ3VtZW50KGFyZykge1xuICBpZiAoIURhdGFidWZmZXJBcmd1bWVudC5jYW5XcmFwKGFyZykpIHtcbiAgICB0aHJvdyBFcnJvcihcIkNhbnQgd3JhcCBhcmd1bWVudCBcIiArIGFyZyArIFwiIGFzIGEgZGF0YWJ1ZmZlclwiKTtcbiAgfVxuXG4gIHRoaXMuYnVmZmVyID0gYXJnIGluc3RhbmNlb2YgQXJyYXlCdWZmZXIgPyBhcmcgOiBudWxsO1xuICB0aGlzLm9iaiA9IGFyZy5pc0FycmF5QnVmZmVyID8gYXJnIDogbnVsbDtcbn1cblxuLyoqXG4gKiBDaGVjayBpZiB0aGUgb2JqZWN0IGlzIGVpdGhlIGEgZGF0YWJ1ZmZlciBvciBhIHNlcmlhbGl6ZWQgZGF0YWJ1ZmZlclxuICpcbiAqIEBwYXJhbSB7YW55dGhpbmd9IGFyZyBUaGUgb2JqZWN0IHRvIGNoZWNrXG4gKiBAcmV0dXJucyB7Qm9vbGVhbn0gVHJ1ZSBpZiB3ZSBjYW4gd3JhcC5cbiAqL1xuRGF0YWJ1ZmZlckFyZ3VtZW50LmNhbldyYXAgPSBmdW5jdGlvbiAoYXJnKSB7XG4gIHJldHVybiBhcmcgJiYgKChhcmcgaW5zdGFuY2VvZiBBcnJheUJ1ZmZlcikgfHwgYXJnLmlzQXJyYXlCdWZmZXIpO1xufTtcblxuRGF0YWJ1ZmZlckFyZ3VtZW50LnByb3RvdHlwZSA9IHtcbiAgLyoqXG4gICAqIEByZXR1cm5zIHtEYXRhQnVmZmVyfSBXaGF0IHRoZSBBUEkgZXhwZWN0cyBvciB3aGF0IGlzIGV4cGVjdGVkIGJ5XG4gICAqIHRoZSBBUEkuXG4gICAqL1xuICBmb3JDYWxsaW5nOiBmdW5jdGlvbiAoKSB7XG4gICAgcmV0dXJuIHRoaXMuYnVmZmVyIHx8IHV0aWwuYXJyVG9CdWYodGhpcy5vYmouZGF0YSk7XG4gIH0sXG5cbiAgLyoqXG4gICAqIEByZXR1cm5zIHtPYmplY3R9IEFuIHNlcmlhbGl6YWJsZSBvYmplY3QgdGhhdCB3ZSBjYW4gdHVybiBiYWNrXG4gICAqIGludG8gYSBEYXRhQnVmZmVyLlxuICAgKi9cbiAgZm9yU2VuZGluZzogZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiB0aGlzLm9iaiB8fCB7ZGF0YTogdXRpbC5idWZUb0Fycih0aGlzLmJ1ZmZlciksXG4gICAgICAgICAgICAgICAgICAgICAgICBpc0FycmF5QnVmZmVyOiB0cnVlfTtcbiAgfSxcblxuICBjb25jYXQ6IGZ1bmN0aW9uIChtc2cpIHtcbiAgICBpZiAoIW1zZy5pc0FycmF5QnVmZmVyKSByZXR1cm4gdGhpcztcbiAgICB2YXIgcmV0ID0gdGhpcy5mb3JTZW5kaW5nKCk7XG4gICAgcmV0LmRhdGEgPSByZXQuZGF0YS5jb25jYXQobXNnLmRhdGEpO1xuICAgIHJldHVybiBuZXcgRGF0YWJ1ZmZlckFyZ3VtZW50KHJldCk7XG4gIH1cbn07XG5hcmd1bWVudENsYXNzZXMucHVzaChEYXRhYnVmZmVyQXJndW1lbnQpO1xubW9kdWxlLmV4cG9ydHMgPSBEYXRhYnVmZmVyQXJndW1lbnQ7XG4iLCJ2YXIgYXJndW1lbnRDbGFzc2VzID0gW107XG5cbi8qKlxuICogQ2hvb3NlIHRoZSByaWdodCAqQXJndW1lbnQgdHlwZSBhbmQgY3JlYXRlIGl0IGZvciBhcmcuXG4gKiBAcGFyYW0ge2FueXRoaW5nfSBhcmcgVGhlIHJhdyBhcmd1bWVudFxuICogQHBhcmFtIHtGdW5jdGlvbn0gcmVwbGFjaW5nQ2IgQSBjYWxsYmFjayB0byByZXBsYWNlIGFyZyBpZiBpdCBpc1xuICogc2VyaWFsaXplZCBDYWxsYmFja0FyZ3VtZW50LlxuICogQHJldHVybnMgeypBcmd1bWVudH0gQW4gYXJndW1lbnQgaW4gYXJndW1lbnRDbGFzc2VzXG4gKi9cbmZ1bmN0aW9uIGFyZ3VtZW50RmFjdG9yeShhcmcsIHJlcGxhY2luZ0NiKSB7XG4gIHZhciBjbGFzc2VzID0gYXJndW1lbnRDbGFzc2VzLmZpbHRlcihmdW5jdGlvbiAoYWMpIHtcbiAgICByZXR1cm4gYWMuY2FuV3JhcChhcmcpO1xuICB9KTtcblxuICAvLyBBdCBsZWFzdCBiYXNpYyBhcmd1bWVudCB3aWxsIGJlIGFibGUgdG8gZG8gdGhpcy5cbiAgcmV0dXJuIG5ldyBjbGFzc2VzWzBdKGFyZywgcmVwbGFjaW5nQ2IpO1xufVxuXG5tb2R1bGUuZXhwb3J0cy5hcmd1bWVudEZhY3RvcnkgPSBhcmd1bWVudEZhY3Rvcnk7XG5tb2R1bGUuZXhwb3J0cy5hcmd1bWVudENsYXNzZXMgPSBhcmd1bWVudENsYXNzZXM7XG4iLCJ2YXIgbWVzc2FnZUFwaSA9IHJlcXVpcmUoJy4vbWVzc2FnaW5nLmpzJyk7XG5cbmZ1bmN0aW9uIEJvb3RzdHJhcEhvc3QgKCkge1xuICB0aGlzLmNvbW1hbmRzID0gW107XG4gIHRoaXMubGlzdGVuZXIgPSBudWxsO1xuICB0aGlzLmxpc3RlbigpO1xufVxuQm9vdHN0cmFwSG9zdC5wcm90b3R5cGUgPSB7XG4gIGxpc3RlbjogZnVuY3Rpb24gKCkge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICB0aGlzLmxpc3RlbmVyID0gZnVuY3Rpb24gKHJlcSwgc2VuZGVyLCBzZW5kUmVzcCkge1xuICAgICAgLy8gQmxvY2sgaWYgYSBjb21tYW5kIHNhaXMgZmFsc2UgLT5cbiAgICAgIC8vIFNheSBmYWxzZSBpZiBzb21lIGNvbW1hbmQgc2FpcyBmYWxzZVxuICAgICAgcmV0dXJuIHNlbGYuY29tbWFuZHMubGVuZ3RoID09IDAgfHwgIXNlbGYuY29tbWFuZHMuc29tZShmdW5jdGlvbiAoYykge1xuICAgICAgICByZXR1cm4gIWMocmVxLCBzZW5kUmVzcCk7XG4gICAgICB9KTtcbiAgICB9O1xuXG4gICAgbWVzc2FnZUFwaS5vbk1lc3NhZ2VFeHRlcm5hbC5hZGRMaXN0ZW5lcih0aGlzLmxpc3RlbmVyKTtcbiAgfSxcblxuICBjbGVhbnVwOiBmdW5jdGlvbiAoKSB7XG4gICAgbWVzc2FnZUFwaS5vbk1lc3NhZ2VFeHRlcm5hbC5yZW1vdmVMaXN0ZW5lcih0aGlzLmxpc3RlbmVyKTtcbiAgfVxufTtcbm1vZHVsZS5leHBvcnRzLkJvb3RzdHJhcEhvc3QgPSBCb290c3RyYXBIb3N0O1xuIiwiLyoqXG4gKiBAZmlsZU92ZXJ2aWV3IEtub3cgd2hlbiB0aGUgY2xpZW50IGNsb3NlcyBhbmQgYWxzbyBjbG9zZSBpZlxuICogb3JwaGFuZWQuXG4gKlxuICogQ29tbW9uIG9wZXJhdGlvbnM6XG4gKiAtIGNsb3NlTWVzc2FnZSAtPiBjbG9zZUNhbGxcbiAqIC0gY2xvc2VGbihvcGVuRm4pID0gY2xvc2VmblxuICpcbiAqIFBhcmFtZXRlcml6ZWQgb3BlcmF0aW9uOlxuICogLSBjbG9zZUFyZ3MoY2xvc2VGbiwgb3BlbkFyZ3MsIGNhbGxiYWNrQXJncylcbiAqXG4gKiBPbiBjb25uZWN0aW9uIG9wZW46XG4gKiBmcm9tT3BlbihvcGVuRm4sIG9wZW5BcmdzLCBjYWxsYmFja0FyZ3MpID1cbiAqICAgICBmcm9tQ2xvc2UoY2xvc2VGbihvcGVuRm4pLCBjbG9zZUFyZ3MoY2xvc2VGbiwgb3BlbkFyZ3MsIGNhbGxiYWNrQXJncykpID1cbiAqICAgICBjbG9zZU1lc3NhZ2UgLT4gY2xvc2VDYWxsXG4gKlxuICogT24gbWV0aG9kOlxuICogZnJvbUNsb3NlKGNsb3NlRm4sIGNsb3NlQXJncykgPSBjbG9zZU1lc3NhZ2UgLT4gY2xvc2VDYWxsXG4gKiBAbmFtZSBob3N0Y29ubmVjdGlvbi5qc1xuICogQGF1dGhvclxuICogQGxpY2Vuc2VcbiAqL1xuXG52YXIgQXJndW1lbnRzID0gcmVxdWlyZSgnLi9hcmd1bWVudHMuanMnKS5Bcmd1bWVudHMsXG4gICAgTWV0aG9kUmVxdWVzdCA9IHJlcXVpcmUoJy4vcmVxdWVzdHMuanMnKS5NZXRob2RSZXF1ZXN0LFxuICAgIEFwaUV2ZW50RW1pdHRlciA9IHJlcXVpcmUoXCIuL2FwaWV2ZW50ZW1pdHRlci5qc1wiKS5BcGlFdmVudEVtaXR0ZXIsXG4gICAgciA9IHJlcXVpcmUoXCIuL3Jlc3BvbnNlcy5qc1wiKSxcbiAgICB1dGlsID0gcmVxdWlyZShcIi4vdXRpbC5qc1wiKSxcbiAgICBjbG9zZWQgPSBbXSxcbiAgICBsb2cgPSBuZXcgKHJlcXVpcmUoJy4vbG9nLmpzJykuTG9nKSgnaG9zdGNvbm5lY3Rpb24nKTtcbnJlcXVpcmUoJy4vc2V0aW1tZWRpYXRlLmpzJyk7XG5cbi8qKlxuICogTWV0aG9kIGdldHMgdGhlIGFyZ3MgZnJvbSB0aGUgY29ubmVjdGlvbi4gUmV2ZXJzZSBqdXN0IGdldHMgdGhlXG4gKiBwcm92aWRlZCBjYWxsYmFjay4gVGhlcmUgaXMgb25lIGNvbm5lY3Rpb24gcGVyIGV2ZW50IHBlciBjYWxsYmFja1xuICogcGVyIGNsaWVudC5cbiAqXG4gKiBUaGVyZSBhcmUgMyBzdGFnZXMgaW4gdGhlIGxpZmVjeWNsZSBvZiBhIGNvbm5lY3Rpb25cbiAqXG4gKiAtIEluaXQgd2hlcmUgdGhlIGNvbm5lY3Rpb24gaXMgaW5pdGlhdGVkIGFuZCB0aGUgYXBwIGV2ZW50IGlzXG4gKiAgIHRyaWdnZXJlZC4gSGFuZGxlZCBieSB0aGUgY29uc3RydWN0b3IgYW5kIGluaXQuXG4gKlxuICogLSBDb21tdW5pY2F0aW9uIHdoZXJlIHRoZSBob3N0IHBva2VzIHRoZSBjbGllbnQgd2l0aCBhIGRhdGEgcmVhZHlcbiAqICAgKERUUikgc2lnbmFsIHRoYXQgdGhlcmUgaXMgZGF0YSBhdmFpbGFibGUsIGFuZCB0aGUgY2xpZW50IHJlcXVlc3RzXG4gKiAgIGZvciB0aGUgYXZhaWxhYmxlIGRhdGEgd2l0aCBhIHNlcGFyYXRlIG9uZSB0aW1lIHJlcXVlc3RcbiAqXG4gKiAtIENsb3NlIHdoZXJlIHRoZSBEVFIgY29ubmVjdGlvbiBpcyBjbG9zZWQgYW5kIHRoZSBsaXN0ZW5lciBpc1xuICogICByZW1vdmVkLiBIYW5kbGVkIGJ5IGNsb3NlLlxuICpcbiAqIEBwYXJhbSB7UG9ydH0gcG9ydCBUaGUgcG9ydCByZXR1cm5lZCBmcm9tIG9uQ29ubmVjdEV4dGVybmFsLiBUaGVcbiAqIG5hbWUgc2hvdWxkIGJlIGEganNvbiBlbmNvZGVkIG9iamVjdCB3aXRoXG4gKlxuICogLSBpZDogdGhlIGNvbm5lY3Rpb24gaWRcbiAqIC0gY2xpZW50SWQ6IHRoZSBpZCBvZiB0aGUgdGFiLCBnZW5lcmF0ZWQgYnkgYSBLZWVwQWxpdmVDb25uZXRpb25cbiAqIC0gbWV0aG9kUmVxdWVzdDogQW4gb2JqZWN0IGNhbGxlZCBmcm9tIE1ldGhvZFJlcXVlc3QuZm9yU2VuZGluZ1xuICogLSByZXZlcnNlOiBBIHtwYXRoLCB0eXBlfSBvYmplY3QgZGVzY3JpYmluZyB0aGUgcmV2ZXJzZXIuXG4gKlxuICogQHBhcmFtIHtGdW5jdGlvbn0gY2xvc2VDYiBPcHRpb25hbGx5IGEgY2FsbGJhY2sgd2hlbiB0aGUgY29ubmVjdGlvblxuICogY2xvc2VzLiBUaGlzIHNob3VsZCBoYW5kbGUgdGhlIGNsZWFudXAgb2YgdGhlIGNvbm5lY3Rpb24gZm9yXG4gKiBleHRlcm5hbCByZXNvdXJjZXMuXG4gKi9cbmZ1bmN0aW9uIEhvc3RDb25uZWN0aW9uIChwb3J0LCBob3N0QXBpLCBjbG9zZUNiKSB7XG4gIHZhciBzZWxmID0gdGhpcztcbiAgdGhpcy5idWZmZXIgPSBbXTtcbiAgdGhpcy5wb3J0ID0gcG9ydDtcbiAgdGhpcy5wb3J0Q29uZiA9IEpTT04ucGFyc2UocG9ydC5uYW1lKTtcbiAgdGhpcy5pZCA9IHRoaXMucG9ydENvbmYuaWQ7XG4gIHRoaXMuY2xvc2VDYiA9IGNsb3NlQ2IuYmluZCh0aGlzKTtcbiAgdGhpcy5jbG9zZWQgPSBmYWxzZTtcblxuICAvLyBXaWxsIG5vdCBiZSBzZW50LlxuICB2YXIgc2VuZFJhdyA9IGZ1bmN0aW9uIChtc2cpIHtcbiAgICBzZWxmLnB1c2hSZXF1ZXN0KG1zZyk7XG4gIH07XG4gIHRoaXMubWV0aG9kUmVxdWVzdCA9IE1ldGhvZFJlcXVlc3QuZnJvbU1lc3NhZ2UoXG4gICAgbnVsbCwgdGhpcy5wb3J0Q29uZi5tZXRob2RSZXF1ZXN0TXNnLCBzZW5kUmF3KTtcblxuICBsb2cubG9nKFwiT3BlbmluZyBjb25uZWN0aW9uOlwiLCB0aGlzLnJlcHIoKSk7XG4gIHRoaXMuYXBpRXZlbnQgPSBuZXcgQXBpRXZlbnRFbWl0dGVyKHRoaXMubWV0aG9kUmVxdWVzdCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5wb3J0Q29uZi5yZXZlcnNlcixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaG9zdEFwaSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jbG9zZS5iaW5kKHRoaXMpKTtcbiAgdGhpcy5wb3J0Lm9uTWVzc2FnZS5hZGRMaXN0ZW5lcihmdW5jdGlvbiAobXNnKSB7XG4gICAgaWYgKG1zZyA9PSBcImNsaWVudCBjcmVhdGVkXCIpIHtcbiAgICAgIHNlbGYucG9ydC5wb3N0TWVzc2FnZShcImFja1wiKTtcbiAgICAgIHNlbGYuYXBpRXZlbnQuZmlyZSgpO1xuICAgIH1cbiAgfSk7XG4gIGxvZy5sb2coXCJSZWdpc3RlcmluZyBzZXJ2ZXIgc2lkZSBvbmRpc2Nvbm5lY3QgZm9yIG1ldGhvZCBjb25uZWN0aW9uXCIpO1xuICB0aGlzLnBvcnQub25EaXNjb25uZWN0LmFkZExpc3RlbmVyKHRoaXMuY2xvc2UuYmluZCh0aGlzKSk7XG59XG5cbkhvc3RDb25uZWN0aW9uLnByb3RvdHlwZSA9IHtcbiAgcmVwcjogZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiB0aGlzLmlkICsgIFwiICggXCIgKyB0aGlzLm1ldGhvZFJlcXVlc3QubWV0aG9kICsgXCIgKVwiO1xuICB9LFxuXG4gIC8qKlxuICAgKiBDbG9zZSB0aGUgY29ubmVjdGlvbiBncmFjZWZ1bGx5LlxuICAgKi9cbiAgY2xvc2U6IGZ1bmN0aW9uICgpIHtcbiAgICBpZiAodGhpcy5jbG9zZWQpIHJldHVybjtcbiAgICBsb2cubG9nKFwiQ2xvc2luZyBjb25uZWN0aW9uOlwiLCB0aGlzLnJlcHIoKSk7XG4gICAgdGhpcy5jbG9zZWQgPSB0cnVlO1xuICAgIHRoaXMucG9ydC5kaXNjb25uZWN0KCk7XG4gICAgdGhpcy5hcGlFdmVudC5kZXN0cm95KCk7XG4gICAgdGhpcy5wb3J0ID0gbnVsbDtcbiAgICB0aGlzLmNsb3NlQ2IoKTtcbiAgfSxcblxuICAvKipcbiAgICogU2VuZCBhbiBlcnJvciBtZXNzYWdlIHRvIHRoZSBjbGllbnQgb3ZlciB0aGUgY29ubmVjdGlvbiBwb3J0LlxuICAgKlxuICAgKiBAcGFyYW0ge1N0cmluZ30gbWVzc2FnZSBUaGUgY29udGVudHMgb2YgdGhlIGVycm9yLlxuICAgKi9cbiAgc2VuZEVycm9yOiBmdW5jdGlvbiAobWVzc2FnZSkge1xuICAgIGlmICh0aGlzLmNsb3NlZCkgcmV0dXJuO1xuXG4gICAgdGhpcy5wb3J0LnBvc3RNZXNzYWdlKG5ldyByLkVyclJlc3BvbnNlKG1lc3NhZ2UpLmZvclNlbmRpbmcoKSk7XG4gICAgdGhpcy5jbG9zZSgpO1xuICB9LFxuXG4gIC8qKlxuICAgKiBAcGFyYW0ge01lc3NhZ2V9IHJlcU1zZyBBIG1lc3NhZ2UgdGhhdCB3YXMgdG8gYmUgY2FsbGVkIGlzXG4gICAqIGluc3RlYWQgYnVmZmVyZWQuXG4gICAqL1xuICBwdXNoUmVxdWVzdDogZnVuY3Rpb24gKHJlcU1zZykge1xuICAgIGlmICh0aGlzLmNsb3NlZCkgcmV0dXJuO1xuXG4gICAgaWYgKHJlcU1zZy5yZXNwb25zZVR5cGUgPT0gXCJFcnJSZXNwb25zZVwiKSB7XG4gICAgICB0aGlzLnNlbmRFcnJvcihyZXFNc2cuZXJyKTtcbiAgICB9XG5cbiAgICAvLyBXZSBleHBlY3QgdGhleSB3b250IGNvbnRhaW4gYSBmdW5jdGlvbi5cbiAgICBpZiAoIXRoaXMuYXBpRXZlbnQuZmlyc3RSZXNwb25zZU1zZyl7XG4gICAgICB0aGlzLmFwaUV2ZW50LmZpcnN0UmVzcG9uc2VNc2cgPSByZXFNc2c7XG4gICAgfVxuXG4gICAgaWYgKHRoaXMuYnVmZmVyLmxlbmd0aCA9PSAwKXtcbiAgICAgIC8vIFRvIHRoZSBlbmQgb2YgdGhlIHF1ZXVlLlxuICAgICAgc2V0SW1tZWRpYXRlKHRoaXMuc2V0RHRyLmJpbmQodGhpcykpO1xuICAgIH1cblxuICAgIHRoaXMuYnVmZmVyLnB1c2gocmVxTXNnKTtcbiAgICB0aGlzLmJ1ZmZlci50aW1lc3RhbXAgPSBEYXRlLm5vdygpO1xuICB9LFxuXG4gIC8qKlxuICAgKiBOb3RpZnkgdGhlIGNsaWVudCB0aGF0IHRoZXJlIGlzIGRhdGEgdG8gYmUgcmVhZC5cbiAgICovXG4gIHNldER0cjogZnVuY3Rpb24gKCkge1xuICAgIC8vIFRoaXMgbWlnaHQgYmUgbGVmIG92ZXIgb24gdGhlIHF1ZXVlLlxuICAgIGlmICh0aGlzLnBvcnQpXG4gICAgICB0aGlzLnBvcnQucG9zdE1lc3NhZ2Uoe3RpbWVzdGFtcDogdGhpcy5idWZmZXIudGltZXN0YW1wLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25uZWN0aW9uOiB0aGlzLmlkfSk7XG4gIH0sXG5cbiAgLyoqXG4gICAqIFNlbmQgdGhlIGxpc3Qgb2YgYXJndW1lbnRzIGFjY3VtdWxhdGVkLlxuICAgKlxuICAgKiBAcGFyYW0ge0Z1bmN0aW9ufSBjYWxsYmFjayBjYWxsYmFjayB0byBhY2NlcHQgdGhlIGJ1ZmZlciBvZlxuICAgKiBBcmd1bWVudHMgb2JqZWN0cy5cbiAgICovXG4gIGZsdXNoQnVmZmVyOiBmdW5jdGlvbiAoY2FsbGJhY2spIHtcbiAgICBjYWxsYmFjayh0aGlzLmJ1ZmZlcik7XG4gICAgdGhpcy5idWZmZXIgPSBbXTtcbiAgfSxcblxuICAvKipcbiAgICogTGV0IHRoZSBjb25uZWN0aW9uIGRlY2lkZSBpZiBpdCB3YW50cyB0byBhcHBseSBhIGNsb3NpbmcgcmVxdWVzdFxuICAgKiBvbiBpdHNlbGYuXG4gICAqXG4gICAqIEBwYXJhbSB7TWV0aG9kUmVxdWVzdHxNZXRob2RSZXF1ZXN0TWVzc2FnZX0gY2xvc2luZ1JlcXVlc3QgdGhlXG4gICAqIHJlcXVlc3QgZnJvbSB0aGUgY2xpZW50IHRoYXQgbWF5IGJlIGNhbGxlZC5cbiAgICogQHJldHVybnMge251bGx8QWNrUmVzcG9uc2V8QXJnc1Jlc3BvbnNlfSBUcnVlIGlmIHdlIGFjdHVhbGx5XG4gICAqIGNhbGxlZCB0aGUgcmVxdWVzdC4gV2UgbWF5IHN0aWxsIGJlIG9wZW4gaWYgd2UgbmVlZCBtb3JlIGNsb3NpbmdcbiAgICogcmVxdWVzdHMgdG8gdGVtaW5hdGUuIElmIHRoZSBldmVudCBlbWl0dGVyIGNhbiBjYWxsIGEgY2FsbGJhY2tcbiAgICogdGhpcyBpcyBhbiBBcmdzUmVzcG9uc2UuXG4gICAqL1xuICB0cnlDbG9zaW5nOiBmdW5jdGlvbiAoY2xvc2luZ1JlcXVlc3QpIHtcbiAgICBpZiAodGhpcy5jbG9zZWQpIHJldHVybiBmYWxzZTtcbiAgICB2YXIgcmV0ID0gdGhpcy5hcGlFdmVudC5tYXliZVJ1bkNsb3NlcihjbG9zaW5nUmVxdWVzdCk7XG4gICAgaWYgKHRoaXMuYXBpRXZlbnQuY2xvc2VkKSB7XG4gICAgICB0aGlzLmNsb3NlKCk7XG4gICAgfVxuICAgIHJldHVybiByZXQ7XG4gIH1cbn07XG5cbm1vZHVsZS5leHBvcnRzLkhvc3RDb25uZWN0aW9uID0gSG9zdENvbm5lY3Rpb247XG4iLCIoZnVuY3Rpb24gKGdsb2JhbCl7XG52YXIgdGltZU9mZnNldCA9IERhdGUubm93KCk7XG5nbG9iYWwuZGVidWdCYWJlbGZpc2ggPSBmYWxzZTtcblxuZnVuY3Rpb24gemVyb0ZpbGwoIG51bWJlciwgd2lkdGggKVxue1xuICB3aWR0aCAtPSBudW1iZXIudG9TdHJpbmcoKS5sZW5ndGg7XG4gIGlmICggd2lkdGggPiAwIClcbiAge1xuICAgIHJldHVybiBuZXcgQXJyYXkoIHdpZHRoICsgKC9cXC4vLnRlc3QoIG51bWJlciApID8gMiA6IDEpICkuam9pbiggJzAnICkgKyBudW1iZXI7XG4gIH1cbiAgcmV0dXJuIG51bWJlciArIFwiXCI7IC8vIGFsd2F5cyByZXR1cm4gYSBzdHJpbmdcbn1cblxuZnVuY3Rpb24gTG9nIChuYW1lLCB2ZXJib3NpdHkpIHtcbiAgdGhpcy52ZXJib3NpdHkgPSB2ZXJib3NpdHkgfHwgMTtcbiAgdGhpcy5uYW1lID0gbmFtZTtcbiAgdGhpcy5yZXNldFRpbWVPZmZzZXQoKTtcblxuICB0aGlzLnNob3dUaW1lcyA9IGZhbHNlO1xuICB0aGlzLmVycm9yID0gdGhpcy5jb25zb2xlXygnZXJyb3InLCAwKTtcbiAgdGhpcy53YXJuID0gdGhpcy5jb25zb2xlXygnd2FybicsIDEpO1xuICB0aGlzLmluZm8gPSB0aGlzLmNvbnNvbGVfKCdsb2cnLCAyKTtcbiAgdGhpcy5sb2cgPSAgdGhpcy5jb25zb2xlXygnbG9nJywgMyk7XG59XG5cbkxvZy5wcm90b3R5cGUgPSB7XG4gIHRpbWVzdGFtcFN0cmluZzogZnVuY3Rpb24gKCkge1xuICAgIHZhciBub3cgPSBuZXcgRGF0ZShuZXcgRGF0ZSgpIC0gdGltZU9mZnNldCArXG4gICAgICAgICAgICAgICAgICAgICAgIHRpbWVPZmZzZXQuZ2V0VGltZXpvbmVPZmZzZXQoKSAqIDYwMDAwKTtcbiAgICB2YXIgcGFkID0gZnVuY3Rpb24gKG4pIHtcbiAgICAgIGlmIChuIDwgMTApIHsgcmV0dXJuIFwiMFwiICsgbjsgfVxuICAgICAgcmV0dXJuIG47XG4gICAgfTtcbiAgICByZXR1cm4gcGFkKG5vdy5nZXRIb3VycygpKSArIFwiOlwiICsgcGFkKG5vdy5nZXRNaW51dGVzKCkpXG4gICAgICArIFwiOlwiICsgcGFkKG5vdy5nZXRTZWNvbmRzKCkpICsgXCIuXCIgKyB6ZXJvRmlsbChub3cuZ2V0TWlsbGlzZWNvbmRzKCksIDMpO1xuICB9LFxuXG4gIHJlc2V0VGltZU9mZnNldDogZnVuY3Rpb24gKCkge1xuICAgIHRpbWVPZmZzZXQgPSBuZXcgRGF0ZSgpO1xuICB9LFxuXG5cbiAgY29uc29sZV86IGZ1bmN0aW9uICh0eXBlLCB2ZXJib3NpdHkpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgaWYgKHRoaXMuc2hvd1RpbWVzKSB7XG4gICAgICByZXR1cm4gZnVuY3Rpb24gKCkge1xuICAgICAgICBpZiAoc2VsZi52ZXJib3NpdHkgPiB2ZXJib3NpdHkgfHwgZ2xvYmFsLmRlYnVnQmFiZWxmaXNoKSB7XG4gICAgICAgICAgcmV0dXJuIGNvbnNvbGVbdHlwZV0uYXBwbHkoY29uc29sZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbc2VsZi5wcmVmaXgoKV0uY29uY2F0KGFyZ3VtZW50cykpO1xuICAgICAgICB9XG4gICAgICB9O1xuICAgIH1cbiAgICBpZiAodGhpcy52ZXJib3NpdHkgPiB2ZXJib3NpdHkgfHwgZ2xvYmFsLmRlYnVnQmFiZWxmaXNoKSB7XG4gICAgICByZXR1cm4gY29uc29sZVt0eXBlXS5iaW5kKGNvbnNvbGUsIHRoaXMucHJlZml4KCkpO1xuICAgIH1cbiAgICByZXR1cm4gZnVuY3Rpb24gKCkge307XG4gIH0sXG5cblxuICBwcmVmaXg6IGZ1bmN0aW9uICgpIHtcbiAgICBpZiAodGhpcy5zaG93VGltZXMpXG4gICAgICByZXR1cm4gXCJbXCIgKyB0aGlzLnRpbWVzdGFtcFN0cmluZygpICsgIFwiIDogXCIgKyB0aGlzLm5hbWUgKyBcIl1cIjtcblxuICAgIHJldHVybiBcIltcIiArdGhpcy5uYW1lICsgXCJdIFwiO1xuICB9XG59O1xubW9kdWxlLmV4cG9ydHMuTG9nID0gTG9nO1xuXG59KS5jYWxsKHRoaXMsdHlwZW9mIGdsb2JhbCAhPT0gXCJ1bmRlZmluZWRcIiA/IGdsb2JhbCA6IHR5cGVvZiBzZWxmICE9PSBcInVuZGVmaW5lZFwiID8gc2VsZiA6IHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIgPyB3aW5kb3cgOiB7fSlcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWRhdGE6YXBwbGljYXRpb24vanNvbjtjaGFyc2V0OnV0Zi04O2Jhc2U2NCxleUoyWlhKemFXOXVJam96TENKemIzVnlZMlZ6SWpwYklteHZaeTVxY3lKZExDSnVZVzFsY3lJNlcxMHNJbTFoY0hCcGJtZHpJam9pTzBGQlFVRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRU0lzSW1acGJHVWlPaUpuWlc1bGNtRjBaV1F1YW5NaUxDSnpiM1Z5WTJWU2IyOTBJam9pSWl3aWMyOTFjbU5sYzBOdmJuUmxiblFpT2xzaWRtRnlJSFJwYldWUFptWnpaWFFnUFNCRVlYUmxMbTV2ZHlncE8xeHVaMnh2WW1Gc0xtUmxZblZuUW1GaVpXeG1hWE5vSUQwZ1ptRnNjMlU3WEc1Y2JtWjFibU4wYVc5dUlIcGxjbTlHYVd4c0tDQnVkVzFpWlhJc0lIZHBaSFJvSUNsY2JudGNiaUFnZDJsa2RHZ2dMVDBnYm5WdFltVnlMblJ2VTNSeWFXNW5LQ2t1YkdWdVozUm9PMXh1SUNCcFppQW9JSGRwWkhSb0lENGdNQ0FwWEc0Z0lIdGNiaUFnSUNCeVpYUjFjbTRnYm1WM0lFRnljbUY1S0NCM2FXUjBhQ0FySUNndlhGd3VMeTUwWlhOMEtDQnVkVzFpWlhJZ0tTQS9JRElnT2lBeEtTQXBMbXB2YVc0b0lDY3dKeUFwSUNzZ2JuVnRZbVZ5TzF4dUlDQjlYRzRnSUhKbGRIVnliaUJ1ZFcxaVpYSWdLeUJjSWx3aU95QXZMeUJoYkhkaGVYTWdjbVYwZFhKdUlHRWdjM1J5YVc1blhHNTlYRzVjYm1aMWJtTjBhVzl1SUV4dlp5QW9ibUZ0WlN3Z2RtVnlZbTl6YVhSNUtTQjdYRzRnSUhSb2FYTXVkbVZ5WW05emFYUjVJRDBnZG1WeVltOXphWFI1SUh4OElERTdYRzRnSUhSb2FYTXVibUZ0WlNBOUlHNWhiV1U3WEc0Z0lIUm9hWE11Y21WelpYUlVhVzFsVDJabWMyVjBLQ2s3WEc1Y2JpQWdkR2hwY3k1emFHOTNWR2x0WlhNZ1BTQm1ZV3h6WlR0Y2JpQWdkR2hwY3k1bGNuSnZjaUE5SUhSb2FYTXVZMjl1YzI5c1pWOG9KMlZ5Y205eUp5d2dNQ2s3WEc0Z0lIUm9hWE11ZDJGeWJpQTlJSFJvYVhNdVkyOXVjMjlzWlY4b0ozZGhjbTRuTENBeEtUdGNiaUFnZEdocGN5NXBibVp2SUQwZ2RHaHBjeTVqYjI1emIyeGxYeWduYkc5bkp5d2dNaWs3WEc0Z0lIUm9hWE11Ykc5bklEMGdJSFJvYVhNdVkyOXVjMjlzWlY4b0oyeHZaeWNzSURNcE8xeHVmVnh1WEc1TWIyY3VjSEp2ZEc5MGVYQmxJRDBnZTF4dUlDQjBhVzFsYzNSaGJYQlRkSEpwYm1jNklHWjFibU4wYVc5dUlDZ3BJSHRjYmlBZ0lDQjJZWElnYm05M0lEMGdibVYzSUVSaGRHVW9ibVYzSUVSaGRHVW9LU0F0SUhScGJXVlBabVp6WlhRZ0sxeHVJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNCMGFXMWxUMlptYzJWMExtZGxkRlJwYldWNmIyNWxUMlptYzJWMEtDa2dLaUEyTURBd01DazdYRzRnSUNBZ2RtRnlJSEJoWkNBOUlHWjFibU4wYVc5dUlDaHVLU0I3WEc0Z0lDQWdJQ0JwWmlBb2JpQThJREV3S1NCN0lISmxkSFZ5YmlCY0lqQmNJaUFySUc0N0lIMWNiaUFnSUNBZ0lISmxkSFZ5YmlCdU8xeHVJQ0FnSUgwN1hHNGdJQ0FnY21WMGRYSnVJSEJoWkNodWIzY3VaMlYwU0c5MWNuTW9LU2tnS3lCY0lqcGNJaUFySUhCaFpDaHViM2N1WjJWMFRXbHVkWFJsY3lncEtWeHVJQ0FnSUNBZ0t5QmNJanBjSWlBcklIQmhaQ2h1YjNjdVoyVjBVMlZqYjI1a2N5Z3BLU0FySUZ3aUxsd2lJQ3NnZW1WeWIwWnBiR3dvYm05M0xtZGxkRTFwYkd4cGMyVmpiMjVrY3lncExDQXpLVHRjYmlBZ2ZTeGNibHh1SUNCeVpYTmxkRlJwYldWUFptWnpaWFE2SUdaMWJtTjBhVzl1SUNncElIdGNiaUFnSUNCMGFXMWxUMlptYzJWMElEMGdibVYzSUVSaGRHVW9LVHRjYmlBZ2ZTeGNibHh1WEc0Z0lHTnZibk52YkdWZk9pQm1kVzVqZEdsdmJpQW9kSGx3WlN3Z2RtVnlZbTl6YVhSNUtTQjdYRzRnSUNBZ2RtRnlJSE5sYkdZZ1BTQjBhR2x6TzF4dUlDQWdJR2xtSUNoMGFHbHpMbk5vYjNkVWFXMWxjeWtnZTF4dUlDQWdJQ0FnY21WMGRYSnVJR1oxYm1OMGFXOXVJQ2dwSUh0Y2JpQWdJQ0FnSUNBZ2FXWWdLSE5sYkdZdWRtVnlZbTl6YVhSNUlENGdkbVZ5WW05emFYUjVJSHg4SUdkc2IySmhiQzVrWldKMVowSmhZbVZzWm1semFDa2dlMXh1SUNBZ0lDQWdJQ0FnSUhKbGRIVnliaUJqYjI1emIyeGxXM1I1Y0dWZExtRndjR3g1S0dOdmJuTnZiR1VzWEc0Z0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ1czTmxiR1l1Y0hKbFptbDRLQ2xkTG1OdmJtTmhkQ2hoY21kMWJXVnVkSE1wS1R0Y2JpQWdJQ0FnSUNBZ2ZWeHVJQ0FnSUNBZ2ZUdGNiaUFnSUNCOVhHNGdJQ0FnYVdZZ0tIUm9hWE11ZG1WeVltOXphWFI1SUQ0Z2RtVnlZbTl6YVhSNUlIeDhJR2RzYjJKaGJDNWtaV0oxWjBKaFltVnNabWx6YUNrZ2UxeHVJQ0FnSUNBZ2NtVjBkWEp1SUdOdmJuTnZiR1ZiZEhsd1pWMHVZbWx1WkNoamIyNXpiMnhsTENCMGFHbHpMbkJ5WldacGVDZ3BLVHRjYmlBZ0lDQjlYRzRnSUNBZ2NtVjBkWEp1SUdaMWJtTjBhVzl1SUNncElIdDlPMXh1SUNCOUxGeHVYRzVjYmlBZ2NISmxabWw0T2lCbWRXNWpkR2x2YmlBb0tTQjdYRzRnSUNBZ2FXWWdLSFJvYVhNdWMyaHZkMVJwYldWektWeHVJQ0FnSUNBZ2NtVjBkWEp1SUZ3aVcxd2lJQ3NnZEdocGN5NTBhVzFsYzNSaGJYQlRkSEpwYm1jb0tTQXJJQ0JjSWlBNklGd2lJQ3NnZEdocGN5NXVZVzFsSUNzZ1hDSmRYQ0k3WEc1Y2JpQWdJQ0J5WlhSMWNtNGdYQ0piWENJZ0szUm9hWE11Ym1GdFpTQXJJRndpWFNCY0lqdGNiaUFnZlZ4dWZUdGNibTF2WkhWc1pTNWxlSEJ2Y25SekxreHZaeUE5SUV4dlp6dGNiaUpkZlE9PSIsIihmdW5jdGlvbiAoZ2xvYmFsKXtcbnZhciBEdW1teVJ1bnRpbWUgPSByZXF1aXJlKCcuL21lc3NhZ2luZy9kdW1teS5qcycpLkR1bW15UnVudGltZSxcbiAgICBDaHJvbWVNZXNzYWdpbmcgPSByZXF1aXJlKCcuL21lc3NhZ2luZy9jaHJvbWUuanMnKS5DaHJvbWVNZXNzYWdpbmc7XG5cbi8qKlxuICogVGhlIG1lc3NhZ2luZyBpbnRlZmFjZXMgc2hvdWxkIGltcGxlbWVudFxuICpcbiAqIC0gb25Db25uZWN0RXh0ZXJuYWxcbiAqIC0gb25NZXNzYWdlRXh0ZXJuYWxcbiAqIC0gc2VuZE1lc3NhZ2VcbiAqIC0gY29ubmVjdFxuICpcbiAqIFRoYXQgYmVoYXZlIGxpa2UgdGhhIGNocm9tZSBydW50aW1lIG1lc3NhZ2luZyBpbnRlcmZhY2UuXG4gKi9cbnZhciBpbnRlcmZhY2VzID0ge1xuICBjaHJvbWU6IENocm9tZU1lc3NhZ2luZyxcbiAgdGVzdDogRHVtbXlSdW50aW1lXG59O1xuXG5pZiAoIWdsb2JhbC5jaHJvbWUgfHxcbiAgICAhZ2xvYmFsLmNocm9tZS5ydW50aW1lIHx8XG4gICAgIWdsb2JhbC5jaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZSkge1xuICBnbG9iYWwuTUVTU0FHSU5HX01FVEhPRCA9ICd0ZXN0Jztcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBuZXcgKGludGVyZmFjZXNbZ2xvYmFsLk1FU1NBR0lOR19NRVRIT0QgfHwgJ2Nocm9tZSddKSgpO1xuXG59KS5jYWxsKHRoaXMsdHlwZW9mIGdsb2JhbCAhPT0gXCJ1bmRlZmluZWRcIiA/IGdsb2JhbCA6IHR5cGVvZiBzZWxmICE9PSBcInVuZGVmaW5lZFwiID8gc2VsZiA6IHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIgPyB3aW5kb3cgOiB7fSlcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWRhdGE6YXBwbGljYXRpb24vanNvbjtjaGFyc2V0OnV0Zi04O2Jhc2U2NCxleUoyWlhKemFXOXVJam96TENKemIzVnlZMlZ6SWpwYkltMWxjM05oWjJsdVp5NXFjeUpkTENKdVlXMWxjeUk2VzEwc0ltMWhjSEJwYm1keklqb2lPMEZCUVVFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVNJc0ltWnBiR1VpT2lKblpXNWxjbUYwWldRdWFuTWlMQ0p6YjNWeVkyVlNiMjkwSWpvaUlpd2ljMjkxY21ObGMwTnZiblJsYm5RaU9sc2lkbUZ5SUVSMWJXMTVVblZ1ZEdsdFpTQTlJSEpsY1hWcGNtVW9KeTR2YldWemMyRm5hVzVuTDJSMWJXMTVMbXB6SnlrdVJIVnRiWGxTZFc1MGFXMWxMRnh1SUNBZ0lFTm9jbTl0WlUxbGMzTmhaMmx1WnlBOUlISmxjWFZwY21Vb0p5NHZiV1Z6YzJGbmFXNW5MMk5vY205dFpTNXFjeWNwTGtOb2NtOXRaVTFsYzNOaFoybHVaenRjYmx4dUx5b3FYRzRnS2lCVWFHVWdiV1Z6YzJGbmFXNW5JR2x1ZEdWbVlXTmxjeUJ6YUc5MWJHUWdhVzF3YkdWdFpXNTBYRzRnS2x4dUlDb2dMU0J2YmtOdmJtNWxZM1JGZUhSbGNtNWhiRnh1SUNvZ0xTQnZiazFsYzNOaFoyVkZlSFJsY201aGJGeHVJQ29nTFNCelpXNWtUV1Z6YzJGblpWeHVJQ29nTFNCamIyNXVaV04wWEc0Z0tseHVJQ29nVkdoaGRDQmlaV2hoZG1VZ2JHbHJaU0IwYUdFZ1kyaHliMjFsSUhKMWJuUnBiV1VnYldWemMyRm5hVzVuSUdsdWRHVnlabUZqWlM1Y2JpQXFMMXh1ZG1GeUlHbHVkR1Z5Wm1GalpYTWdQU0I3WEc0Z0lHTm9jbTl0WlRvZ1EyaHliMjFsVFdWemMyRm5hVzVuTEZ4dUlDQjBaWE4wT2lCRWRXMXRlVkoxYm5ScGJXVmNibjA3WEc1Y2JtbG1JQ2doWjJ4dlltRnNMbU5vY205dFpTQjhmRnh1SUNBZ0lDRm5iRzlpWVd3dVkyaHliMjFsTG5KMWJuUnBiV1VnZkh4Y2JpQWdJQ0FoWjJ4dlltRnNMbU5vY205dFpTNXlkVzUwYVcxbExuTmxibVJOWlhOellXZGxLU0I3WEc0Z0lHZHNiMkpoYkM1TlJWTlRRVWRKVGtkZlRVVlVTRTlFSUQwZ0ozUmxjM1FuTzF4dWZWeHVYRzV0YjJSMWJHVXVaWGh3YjNKMGN5QTlJRzVsZHlBb2FXNTBaWEptWVdObGMxdG5iRzlpWVd3dVRVVlRVMEZIU1U1SFgwMUZWRWhQUkNCOGZDQW5ZMmh5YjIxbEoxMHBLQ2s3WEc0aVhYMD0iLCIvKipcbiAqIEBmaWxlT3ZlcnZpZXcgVGhlIGNocm9tZSBBUEkgbWVzc2FnZSBwYXNzaW5nIG1ldGhvZC5cbiAqIEBuYW1lIGNocm9tZS5qc1xuICogQGF1dGhvciBDaHJpcyBQZXJpdm9sYXJvcG91bG9zXG4gKi9cblxuZnVuY3Rpb24gQ2hyb21lTWVzc2FnaW5nICgpIHtcbiAgdGhpcy52ZXJzaW9uID0gY2hyb21lLnJ1bnRpbWUuZ2V0TWFuaWZlc3QgP1xuICAgIGNocm9tZS5ydW50aW1lLmdldE1hbmlmZXN0KCkudmVyc2lvbiA6IFwiMVwiIDtcbiAgdGhpcy5vbkNvbm5lY3RFeHRlcm5hbCA9IGNocm9tZS5ydW50aW1lLm9uQ29ubmVjdEV4dGVybmFsO1xuICB0aGlzLm9uTWVzc2FnZUV4dGVybmFsID0gY2hyb21lLnJ1bnRpbWUub25NZXNzYWdlRXh0ZXJuYWw7XG4gIHRoaXMuc2VuZE1lc3NhZ2UgPSBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZS5iaW5kKGNocm9tZS5ydW50aW1lKTtcbiAgdGhpcy5jb25uZWN0ID0gY2hyb21lLnJ1bnRpbWUuY29ubmVjdC5iaW5kKGNocm9tZS5ydW50aW1lKTtcbn1cbm1vZHVsZS5leHBvcnRzLkNocm9tZU1lc3NhZ2luZyA9IENocm9tZU1lc3NhZ2luZztcbiIsIihmdW5jdGlvbiAoZ2xvYmFsKXtcbi8vIFhYWDogSWYgZGlzY29ubmVjdCBpcyB0b28gc29vbiBhZnRlciB0aGUgY29ubmVjdCB0aGUgYWN0dWFsXG4vLyBjb25uZWN0aW9uIG1heSBoYXBwZW4gYmVmb3JlIGRpc2Nvbm5lY3QuXG5cbi8qKlxuICogQGZpbGVPdmVydmlldyBBIGxvb3BiYWNrIG1ldGhvZCBtaXJyb3JpbmcgY2hyb21lIGFwaS5cbiAqIEBuYW1lIGR1bW15LmpzXG4gKiBAYXV0aG9yIENocmlzIFBlcml2b2xhcm9wb3Vsb3NcbiAqL1xuXG5nbG9iYWwuQVBQX0lEID0gZ2xvYmFsLkFQUF9JRCB8fCBcImZha2Vob3N0aWRcIjtcbi8vIERFQlVHOiBkZWJ1ZyBtZXNzYWdlc1xuLy8gc3RhY2tEZWJ1Zzogbm9uIGFzeW5jIG1lc3NhZ2luZy5cbnZhciBERUJVRyA9IGZhbHNlLCBzdGFja0RlYnVnID0gZmFsc2U7XG52YXIgYXNzZXJ0ID0gcmVxdWlyZSgnYXNzZXJ0JyksXG4gICAgbWF5YmVBc3luYyA9IHN0YWNrRGVidWcgPyBmdW5jdGlvbiAoY2IpIHtjYigpO30gOiBmdW5jdGlvbiAoY2IpIHtcbiAgICAgIHZhciBlcnIgPSBuZXcgRXJyb3IoXCJTdGFjayBiZWZvcmUgYXN5bmMgbWVzc2FnZVwiKTtcbiAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xuICAgICAgICB0cnl7XG4gICAgICAgICAgY2IoKTtcbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgIGNvbnNvbGUubG9nKGUuc3RhY2spO1xuICAgICAgICAgIGNvbnNvbGUubG9nKGVyci5zdGFjayk7XG4gICAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9LFxuICAgIGRiZyA9IGZ1bmN0aW9uICgpIHt9O1xuaWYgKERFQlVHKSB7XG4gIGRiZyA9IGNvbnNvbGUubG9nLmJpbmQoY29uc29sZSwgJ1tkdW1teSBtZXNzYWdlcl0nKTtcbn1cblxuZnVuY3Rpb24gdmFsaWRhdGVNZXNzYWdlKG1zZykge1xuICBpZiAoIW1zZyB8fCBKU09OLnN0cmluZ2lmeShtc2cpID09IFwie31cIikge1xuICAgIHRocm93IG5ldyBFcnJvcihcIk1lc3NhZ2Ugc2hvdWxkIGJlIHNvbWV0aGluZy4gR290OlwiICsgbXNnKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBFdmVudCAoanNvbk9ubHksIG5hbWUsIGJ1ZmZlcmVkKSB7XG4gIHRoaXMubGlzdGVuZXJzID0gW107XG4gIHRoaXMucmVtb3ZlZCA9IFtdO1xuICB0aGlzLm5hbWUgPSBuYW1lO1xuXG4gIGlmIChidWZmZXJlZCkge1xuICAgIHRoaXMuYnVmZmVyID0gW107XG4gIH1cblxuICBpZiAoanNvbk9ubHkpIHtcbiAgICB0aGlzLndyYXAgPSBmdW5jdGlvbiAoYXJncykge1xuICAgICAgcmV0dXJuIEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkoYXJncykpO1xuICAgIH07XG4gIH0gZWxzZSB7XG4gICAgdGhpcy53cmFwID0gZnVuY3Rpb24gKGEpIHtyZXR1cm4gYTt9O1xuICB9XG59XG5cbkV2ZW50LnByb3RvdHlwZSA9IHtcbiAgYWRkTGlzdGVuZXI6IGZ1bmN0aW9uIChjYikge1xuICAgIGRiZygnQWRkaW5nIGxpc3RuZXI6ICcgKyBjYi5pZCArIFwiIHRvIFwiICsgdGhpcy5uYW1lKTtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgdGhpcy5saXN0ZW5lcnMgPSB0aGlzLmxpc3RlbmVycy5jb25jYXQoW2NiXSk7XG5cbiAgICAodGhpcy5idWZmZXJ8fFtdKS5mb3JFYWNoKGZ1bmN0aW9uIChhcmdzKSB7XG4gICAgICBtYXliZUFzeW5jKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgc2VsZi5saXN0ZW5lcnMuc29tZShmdW5jdGlvbiAobCkge1xuICAgICAgICAgIHJldHVybiAhbC5hcHBseShudWxsLCBhcmdzKTtcbiAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgICB9KTtcbiAgfSxcblxuICByZW1vdmVMaXN0ZW5lcjogZnVuY3Rpb24gKGNiKSB7XG4gICAgZGJnKCdSZW1vdmluZyBsaXN0bmVyOiAnICsgY2IuaWQgKyBcIiBmcm9tIFwiICsgdGhpcy5uYW1lICtcbiAgICAgICAgXCIgKFwiICsgdGhpcy5saXN0ZW5lcnMubWFwKGZ1bmN0aW9uIChsKSB7cmV0dXJuIGwuaWQ7fSkgKyBcIiAtIFwiICtcbiAgICAgICAgdGhpcy5yZW1vdmVkICsgXCIgKVwiKTtcbiAgICB0aGlzLmxpc3RlbmVycyA9IHRoaXMubGlzdGVuZXJzLmZpbHRlcihmdW5jdGlvbiAobCkge1xuICAgICAgdmFyIHNhbWUgPSBjYiA9PT0gbCxcbiAgICAgICAgICBzYW1lSWRzID0gKGNiLmlkICYmIGwuaWQgJiYgY2IuaWQgPT0gbC5pZCk7XG4gICAgICByZXR1cm4gIShzYW1lIHx8IHNhbWVJZHMpO1xuICAgIH0pO1xuICB9LFxuXG4gIHRyaWdnZXI6IGZ1bmN0aW9uICh2YXJBcmdzKSB7XG4gICAgdmFyIGFyZ3MgPSBbXS5zbGljZS5jYWxsKGFyZ3VtZW50cyksXG4gICAgICAgIHNlbGYgPSB0aGlzLFxuICAgICAgICBsaXN0ZW5lcnMgPSB0aGlzLmxpc3RlbmVyczsgLy9NYWtlIHN1cmUgYXN5bmMgZG9lcyd0IGZ1Y2sgd2l0aCBsaXN0ZW5lcnNcbiAgICBkYmcoJ1RyaWdnZXJpbmdbJyArIHRoaXMubGlzdGVuZXJzLmxlbmd0aCArICddOiAnICsgdGhpcy5uYW1lICsgXCJ8XCIgK1xuICAgICAgICAoKGFyZ3NbMF0gaW5zdGFuY2VvZiBQb3J0KSA/IFwiPHBvcnQ+XCIgOiBKU09OLnN0cmluZ2lmeShhcmdzKSkpO1xuXG4gICAgaWYgKHRoaXMuYnVmZmVyICYmIHRoaXMubGlzdGVuZXJzLmxlbmd0aCA9PSAwKSB7XG4gICAgICB0aGlzLmJ1ZmZlci5wdXNoKGFyZ3MpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIG1heWJlQXN5bmMoZnVuY3Rpb24gKCkge1xuICAgICAgdmFyIHRvayA9IE1hdGgucmFuZG9tKCk7XG4gICAgICBsaXN0ZW5lcnMuc29tZShmdW5jdGlvbiAobCwgaSkge1xuICAgICAgICByZXR1cm4gbC5hcHBseShudWxsLCBhcmdzKSA9PT0gZmFsc2U7XG4gICAgICB9KTtcbiAgICB9KTtcblxuICB9XG59O1xuXG5mdW5jdGlvbiBSdW50aW1lICgpIHtcbiAgZGJnKCdDcmVhdGluZyBydW50aW1lLi4uJyk7XG4gIHRoaXMuaWQgPSBnbG9iYWwuQVBQX0lEO1xuICB0aGlzLm9uQ29ubmVjdEV4dGVybmFsID0gbmV3IEV2ZW50KGZhbHNlLCBcIm9uQ29ubmVjdEV4dGVybmFsXCIpO1xuICB0aGlzLm9uTWVzc2FnZUV4dGVybmFsID0gbmV3IEV2ZW50KHRydWUsIFwib25NZXNzYWdlRXh0ZXJuYWxcIik7XG4gIHRoaXMucG9ydHMgPSBbXTtcbiAgdGhpcy52ZXJzaW9uID0gXCIxLjBcIjtcbn1cblxuUnVudGltZS5wcm90b3R5cGUgPSB7XG4gIHNlbmRNZXNzYWdlOiBmdW5jdGlvbiAoaG9zdElkLCBtZXNzYWdlLCBjYikge1xuICAgIHZhciBzZW5kZXIgPSBudWxsO1xuXG4gICAgdmFsaWRhdGVNZXNzYWdlKG1lc3NhZ2UpO1xuICAgIGFzc2VydChtZXNzYWdlKTtcbiAgICBhc3NlcnQoaG9zdElkKTtcbiAgICBpZiAoaG9zdElkICE9IHRoaXMuaWQgfHwgZ2xvYmFsLmJsb2NrTWVzc2FnaW5nKSB7XG4gICAgICBtYXliZUFzeW5jKGNiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICB0aGlzLm9uTWVzc2FnZUV4dGVybmFsLnRyaWdnZXIobWVzc2FnZSwgc2VuZGVyLCBjYik7XG4gIH0sXG5cbiAgY29ubmVjdDogZnVuY3Rpb24gKGhvc3RJZCwgY29ubmVjdEluZm8pIHtcbiAgICB2YXIgY2xpZW50UG9ydCA9IG5ldyBQb3J0KGNvbm5lY3RJbmZvLm5hbWUsIHRoaXMpLFxuICAgICAgICBzZWxmID0gdGhpcztcbiAgICBhc3NlcnQuZXF1YWwoaG9zdElkLCB0aGlzLmlkKTtcblxuICAgIGlmIChnbG9iYWwuYmxvY2tNZXNzYWdpbmcpIHtcbiAgICAgIHNldEltbWVkaWF0ZSggZnVuY3Rpb24gKCkge1xuICAgICAgICBjbGllbnRQb3J0Lm9uRGlzY29ubmVjdC50cmlnZ2VyKGNsaWVudFBvcnQpO1xuICAgICAgfSk7XG4gICAgICByZXR1cm4gY2xpZW50UG9ydDtcbiAgICB9XG5cbiAgICBtYXliZUFzeW5jKGZ1bmN0aW9uICgpIHtcbiAgICAgIHNlbGYub25Db25uZWN0RXh0ZXJuYWwudHJpZ2dlcihjbGllbnRQb3J0Lm90aGVyUG9ydCk7XG4gICAgfSk7XG4gICAgcmV0dXJuIGNsaWVudFBvcnQ7XG4gIH1cbn07XG5cbmZ1bmN0aW9uIFBvcnQgKG5hbWUsIHJ1bnRpbWUsIG90aGVyUG9ydCkge1xuICB0aGlzLm5hbWUgPSBuYW1lO1xuICB0aGlzLnJ1bnRpbWUgPSBydW50aW1lO1xuICBydW50aW1lLnBvcnRzID0gcnVudGltZS5wb3J0cy5jb25jYXQoW3RoaXNdKTtcbiAgdGhpcy5wcmVmaXggPSBcIlBvcnRcIiArICghb3RoZXJQb3J0ID8gXCI8Y2xpZW50PlwiIDogXCI8aG9zdD5cIik7XG4gIHRoaXMub25EaXNjb25uZWN0ID0gbmV3IEV2ZW50KGZhbHNlLCB0aGlzLnByZWZpeCArIFwiLm9uRGlzY29ubmVjdFwiKTtcbiAgdGhpcy5vbk1lc3NhZ2UgPSBuZXcgRXZlbnQodHJ1ZSwgdGhpcy5wcmVmaXggKyBcIi5vbk1lc3NhZ2VcIiwgdHJ1ZSk7XG5cbiAgdGhpcy5vdGhlclBvcnQgPSBvdGhlclBvcnQgfHwgbmV3IFBvcnQobmFtZSwgcnVudGltZSwgdGhpcyk7XG4gIHRoaXMuY29ubmVjdGVkID0gdHJ1ZTtcbn1cblxuUG9ydC5wcm90b3R5cGUgPSB7XG4gIHBvc3RNZXNzYWdlOiBmdW5jdGlvbiAobXNnKSB7XG4gICAgdmFsaWRhdGVNZXNzYWdlKG1zZyk7XG4gICAgdGhpcy5vdGhlclBvcnQub25NZXNzYWdlLnRyaWdnZXIobXNnKTtcbiAgfSxcblxuICBkaXNjb25uZWN0OiBmdW5jdGlvbiAoZm9yY2VMaXN0ZW5lcnMpIHtcbiAgICBpZiAodGhpcy5jb25uZWN0ZWQpIHtcbiAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgIHRoaXMucnVudGltZS5wb3J0cyA9IHRoaXMucnVudGltZS5wb3J0cy5maWx0ZXIoZnVuY3Rpb24gKHApIHtcbiAgICAgICAgcmV0dXJuIHAgIT09IHNlbGY7XG4gICAgICB9KTtcblxuICAgICAgdGhpcy5jb25uZWN0ZWQgPSBmYWxzZTtcbiAgICAgIHRoaXMub25NZXNzYWdlLmxpc3RlbmVycyA9IFtdO1xuICAgICAgaWYgKGZvcmNlTGlzdGVuZXJzKXtcbiAgICAgICAgdGhpcy5vbkRpc2Nvbm5lY3QudHJpZ2dlcigpO1xuICAgICAgfVxuICAgICAgdGhpcy5vbkRpc2Nvbm5lY3QubGlzdGVuZXJzID0gW107XG4gICAgICB0aGlzLm90aGVyUG9ydC5kaXNjb25uZWN0KHRydWUpO1xuICAgIH1cbiAgfVxufTtcblxuZ2xvYmFsLmNocm9tZSA9IGdsb2JhbC5jaHJvbWUgfHwge3J1bnRpbWU6IHtpZDogQVBQX0lEfX07XG5cbm1vZHVsZS5leHBvcnRzLkR1bW15UnVudGltZSA9IFJ1bnRpbWU7XG5tb2R1bGUuZXhwb3J0cy5FdmVudCA9IEV2ZW50O1xubW9kdWxlLmV4cG9ydHMuUG9ydCA9IFBvcnQ7XG5cbn0pLmNhbGwodGhpcyx0eXBlb2YgZ2xvYmFsICE9PSBcInVuZGVmaW5lZFwiID8gZ2xvYmFsIDogdHlwZW9mIHNlbGYgIT09IFwidW5kZWZpbmVkXCIgPyBzZWxmIDogdHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIiA/IHdpbmRvdyA6IHt9KVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZGF0YTphcHBsaWNhdGlvbi9qc29uO2NoYXJzZXQ6dXRmLTg7YmFzZTY0LGV5SjJaWEp6YVc5dUlqb3pMQ0p6YjNWeVkyVnpJanBiSW0xbGMzTmhaMmx1Wnk5a2RXMXRlUzVxY3lKZExDSnVZVzFsY3lJNlcxMHNJbTFoY0hCcGJtZHpJam9pTzBGQlFVRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFTSXNJbVpwYkdVaU9pSm5aVzVsY21GMFpXUXVhbk1pTENKemIzVnlZMlZTYjI5MElqb2lJaXdpYzI5MWNtTmxjME52Ym5SbGJuUWlPbHNpTHk4Z1dGaFlPaUJKWmlCa2FYTmpiMjV1WldOMElHbHpJSFJ2YnlCemIyOXVJR0ZtZEdWeUlIUm9aU0JqYjI1dVpXTjBJSFJvWlNCaFkzUjFZV3hjYmk4dklHTnZibTVsWTNScGIyNGdiV0Y1SUdoaGNIQmxiaUJpWldadmNtVWdaR2x6WTI5dWJtVmpkQzVjYmx4dUx5b3FYRzRnS2lCQVptbHNaVTkyWlhKMmFXVjNJRUVnYkc5dmNHSmhZMnNnYldWMGFHOWtJRzFwY25KdmNtbHVaeUJqYUhKdmJXVWdZWEJwTGx4dUlDb2dRRzVoYldVZ1pIVnRiWGt1YW5OY2JpQXFJRUJoZFhSb2IzSWdRMmh5YVhNZ1VHVnlhWFp2YkdGeWIzQnZkV3h2YzF4dUlDb3ZYRzVjYm1kc2IySmhiQzVCVUZCZlNVUWdQU0JuYkc5aVlXd3VRVkJRWDBsRUlIeDhJRndpWm1GclpXaHZjM1JwWkZ3aU8xeHVMeThnUkVWQ1ZVYzZJR1JsWW5WbklHMWxjM05oWjJWelhHNHZMeUJ6ZEdGamEwUmxZblZuT2lCdWIyNGdZWE41Ym1NZ2JXVnpjMkZuYVc1bkxseHVkbUZ5SUVSRlFsVkhJRDBnWm1Gc2MyVXNJSE4wWVdOclJHVmlkV2NnUFNCbVlXeHpaVHRjYm5aaGNpQmhjM05sY25RZ1BTQnlaWEYxYVhKbEtDZGhjM05sY25RbktTeGNiaUFnSUNCdFlYbGlaVUZ6ZVc1aklEMGdjM1JoWTJ0RVpXSjFaeUEvSUdaMWJtTjBhVzl1SUNoallpa2dlMk5pS0NrN2ZTQTZJR1oxYm1OMGFXOXVJQ2hqWWlrZ2UxeHVJQ0FnSUNBZ2RtRnlJR1Z5Y2lBOUlHNWxkeUJGY25KdmNpaGNJbE4wWVdOcklHSmxabTl5WlNCaGMzbHVZeUJ0WlhOellXZGxYQ0lwTzF4dUlDQWdJQ0FnYzJWMFZHbHRaVzkxZENobWRXNWpkR2x2YmlBb0tTQjdYRzRnSUNBZ0lDQWdJSFJ5ZVh0Y2JpQWdJQ0FnSUNBZ0lDQmpZaWdwTzF4dUlDQWdJQ0FnSUNCOUlHTmhkR05vSUNobEtTQjdYRzRnSUNBZ0lDQWdJQ0FnWTI5dWMyOXNaUzVzYjJjb1pTNXpkR0ZqYXlrN1hHNGdJQ0FnSUNBZ0lDQWdZMjl1YzI5c1pTNXNiMmNvWlhKeUxuTjBZV05yS1R0Y2JpQWdJQ0FnSUNBZ0lDQjBhSEp2ZHlCbGNuSTdYRzRnSUNBZ0lDQWdJSDFjYmlBZ0lDQWdJSDBwTzF4dUlDQWdJSDBzWEc0Z0lDQWdaR0puSUQwZ1puVnVZM1JwYjI0Z0tDa2dlMzA3WEc1cFppQW9SRVZDVlVjcElIdGNiaUFnWkdKbklEMGdZMjl1YzI5c1pTNXNiMmN1WW1sdVpDaGpiMjV6YjJ4bExDQW5XMlIxYlcxNUlHMWxjM05oWjJWeVhTY3BPMXh1ZlZ4dVhHNW1kVzVqZEdsdmJpQjJZV3hwWkdGMFpVMWxjM05oWjJVb2JYTm5LU0I3WEc0Z0lHbG1JQ2doYlhObklIeDhJRXBUVDA0dWMzUnlhVzVuYVdaNUtHMXpaeWtnUFQwZ1hDSjdmVndpS1NCN1hHNGdJQ0FnZEdoeWIzY2dibVYzSUVWeWNtOXlLRndpVFdWemMyRm5aU0J6YUc5MWJHUWdZbVVnYzI5dFpYUm9hVzVuTGlCSGIzUTZYQ0lnS3lCdGMyY3BPMXh1SUNCOVhHNTlYRzVjYm1aMWJtTjBhVzl1SUVWMlpXNTBJQ2hxYzI5dVQyNXNlU3dnYm1GdFpTd2dZblZtWm1WeVpXUXBJSHRjYmlBZ2RHaHBjeTVzYVhOMFpXNWxjbk1nUFNCYlhUdGNiaUFnZEdocGN5NXlaVzF2ZG1Wa0lEMGdXMTA3WEc0Z0lIUm9hWE11Ym1GdFpTQTlJRzVoYldVN1hHNWNiaUFnYVdZZ0tHSjFabVpsY21Wa0tTQjdYRzRnSUNBZ2RHaHBjeTVpZFdabVpYSWdQU0JiWFR0Y2JpQWdmVnh1WEc0Z0lHbG1JQ2hxYzI5dVQyNXNlU2tnZTF4dUlDQWdJSFJvYVhNdWQzSmhjQ0E5SUdaMWJtTjBhVzl1SUNoaGNtZHpLU0I3WEc0Z0lDQWdJQ0J5WlhSMWNtNGdTbE5QVGk1d1lYSnpaU2hLVTA5T0xuTjBjbWx1WjJsbWVTaGhjbWR6S1NrN1hHNGdJQ0FnZlR0Y2JpQWdmU0JsYkhObElIdGNiaUFnSUNCMGFHbHpMbmR5WVhBZ1BTQm1kVzVqZEdsdmJpQW9ZU2tnZTNKbGRIVnliaUJoTzMwN1hHNGdJSDFjYm4xY2JseHVSWFpsYm5RdWNISnZkRzkwZVhCbElEMGdlMXh1SUNCaFpHUk1hWE4wWlc1bGNqb2dablZ1WTNScGIyNGdLR05pS1NCN1hHNGdJQ0FnWkdKbktDZEJaR1JwYm1jZ2JHbHpkRzVsY2pvZ0p5QXJJR05pTG1sa0lDc2dYQ0lnZEc4Z1hDSWdLeUIwYUdsekxtNWhiV1VwTzF4dUlDQWdJSFpoY2lCelpXeG1JRDBnZEdocGN6dGNiaUFnSUNCMGFHbHpMbXhwYzNSbGJtVnljeUE5SUhSb2FYTXViR2x6ZEdWdVpYSnpMbU52Ym1OaGRDaGJZMkpkS1R0Y2JseHVJQ0FnSUNoMGFHbHpMbUoxWm1abGNueDhXMTBwTG1admNrVmhZMmdvWm5WdVkzUnBiMjRnS0dGeVozTXBJSHRjYmlBZ0lDQWdJRzFoZVdKbFFYTjVibU1vWm5WdVkzUnBiMjRnS0NrZ2UxeHVJQ0FnSUNBZ0lDQnpaV3htTG14cGMzUmxibVZ5Y3k1emIyMWxLR1oxYm1OMGFXOXVJQ2hzS1NCN1hHNGdJQ0FnSUNBZ0lDQWdjbVYwZFhKdUlDRnNMbUZ3Y0d4NUtHNTFiR3dzSUdGeVozTXBPMXh1SUNBZ0lDQWdJQ0I5S1R0Y2JpQWdJQ0FnSUgwcE8xeHVJQ0FnSUgwcE8xeHVJQ0I5TEZ4dVhHNGdJSEpsYlc5MlpVeHBjM1JsYm1WeU9pQm1kVzVqZEdsdmJpQW9ZMklwSUh0Y2JpQWdJQ0JrWW1jb0oxSmxiVzkyYVc1bklHeHBjM1J1WlhJNklDY2dLeUJqWWk1cFpDQXJJRndpSUdaeWIyMGdYQ0lnS3lCMGFHbHpMbTVoYldVZ0sxeHVJQ0FnSUNBZ0lDQmNJaUFvWENJZ0t5QjBhR2x6TG14cGMzUmxibVZ5Y3k1dFlYQW9ablZ1WTNScGIyNGdLR3dwSUh0eVpYUjFjbTRnYkM1cFpEdDlLU0FySUZ3aUlDMGdYQ0lnSzF4dUlDQWdJQ0FnSUNCMGFHbHpMbkpsYlc5MlpXUWdLeUJjSWlBcFhDSXBPMXh1SUNBZ0lIUm9hWE11YkdsemRHVnVaWEp6SUQwZ2RHaHBjeTVzYVhOMFpXNWxjbk11Wm1sc2RHVnlLR1oxYm1OMGFXOXVJQ2hzS1NCN1hHNGdJQ0FnSUNCMllYSWdjMkZ0WlNBOUlHTmlJRDA5UFNCc0xGeHVJQ0FnSUNBZ0lDQWdJSE5oYldWSlpITWdQU0FvWTJJdWFXUWdKaVlnYkM1cFpDQW1KaUJqWWk1cFpDQTlQU0JzTG1sa0tUdGNiaUFnSUNBZ0lISmxkSFZ5YmlBaEtITmhiV1VnZkh3Z2MyRnRaVWxrY3lrN1hHNGdJQ0FnZlNrN1hHNGdJSDBzWEc1Y2JpQWdkSEpwWjJkbGNqb2dablZ1WTNScGIyNGdLSFpoY2tGeVozTXBJSHRjYmlBZ0lDQjJZWElnWVhKbmN5QTlJRnRkTG5Oc2FXTmxMbU5oYkd3b1lYSm5kVzFsYm5SektTeGNiaUFnSUNBZ0lDQWdjMlZzWmlBOUlIUm9hWE1zWEc0Z0lDQWdJQ0FnSUd4cGMzUmxibVZ5Y3lBOUlIUm9hWE11YkdsemRHVnVaWEp6T3lBdkwwMWhhMlVnYzNWeVpTQmhjM2x1WXlCa2IyVnpKM1FnWm5WamF5QjNhWFJvSUd4cGMzUmxibVZ5YzF4dUlDQWdJR1JpWnlnblZISnBaMmRsY21sdVoxc25JQ3NnZEdocGN5NXNhWE4wWlc1bGNuTXViR1Z1WjNSb0lDc2dKMTA2SUNjZ0t5QjBhR2x6TG01aGJXVWdLeUJjSW54Y0lpQXJYRzRnSUNBZ0lDQWdJQ2dvWVhKbmMxc3dYU0JwYm5OMFlXNWpaVzltSUZCdmNuUXBJRDhnWENJOGNHOXlkRDVjSWlBNklFcFRUMDR1YzNSeWFXNW5hV1o1S0dGeVozTXBLU2s3WEc1Y2JpQWdJQ0JwWmlBb2RHaHBjeTVpZFdabVpYSWdKaVlnZEdocGN5NXNhWE4wWlc1bGNuTXViR1Z1WjNSb0lEMDlJREFwSUh0Y2JpQWdJQ0FnSUhSb2FYTXVZblZtWm1WeUxuQjFjMmdvWVhKbmN5azdYRzRnSUNBZ0lDQnlaWFIxY200N1hHNGdJQ0FnZlZ4dVhHNGdJQ0FnYldGNVltVkJjM2x1WXlobWRXNWpkR2x2YmlBb0tTQjdYRzRnSUNBZ0lDQjJZWElnZEc5cklEMGdUV0YwYUM1eVlXNWtiMjBvS1R0Y2JpQWdJQ0FnSUd4cGMzUmxibVZ5Y3k1emIyMWxLR1oxYm1OMGFXOXVJQ2hzTENCcEtTQjdYRzRnSUNBZ0lDQWdJSEpsZEhWeWJpQnNMbUZ3Y0d4NUtHNTFiR3dzSUdGeVozTXBJRDA5UFNCbVlXeHpaVHRjYmlBZ0lDQWdJSDBwTzF4dUlDQWdJSDBwTzF4dVhHNGdJSDFjYm4wN1hHNWNibVoxYm1OMGFXOXVJRkoxYm5ScGJXVWdLQ2tnZTF4dUlDQmtZbWNvSjBOeVpXRjBhVzVuSUhKMWJuUnBiV1V1TGk0bktUdGNiaUFnZEdocGN5NXBaQ0E5SUdkc2IySmhiQzVCVUZCZlNVUTdYRzRnSUhSb2FYTXViMjVEYjI1dVpXTjBSWGgwWlhKdVlXd2dQU0J1WlhjZ1JYWmxiblFvWm1Gc2MyVXNJRndpYjI1RGIyNXVaV04wUlhoMFpYSnVZV3hjSWlrN1hHNGdJSFJvYVhNdWIyNU5aWE56WVdkbFJYaDBaWEp1WVd3Z1BTQnVaWGNnUlhabGJuUW9kSEoxWlN3Z1hDSnZiazFsYzNOaFoyVkZlSFJsY201aGJGd2lLVHRjYmlBZ2RHaHBjeTV3YjNKMGN5QTlJRnRkTzF4dUlDQjBhR2x6TG5abGNuTnBiMjRnUFNCY0lqRXVNRndpTzF4dWZWeHVYRzVTZFc1MGFXMWxMbkJ5YjNSdmRIbHdaU0E5SUh0Y2JpQWdjMlZ1WkUxbGMzTmhaMlU2SUdaMWJtTjBhVzl1SUNob2IzTjBTV1FzSUcxbGMzTmhaMlVzSUdOaUtTQjdYRzRnSUNBZ2RtRnlJSE5sYm1SbGNpQTlJRzUxYkd3N1hHNWNiaUFnSUNCMllXeHBaR0YwWlUxbGMzTmhaMlVvYldWemMyRm5aU2s3WEc0Z0lDQWdZWE56WlhKMEtHMWxjM05oWjJVcE8xeHVJQ0FnSUdGemMyVnlkQ2hvYjNOMFNXUXBPMXh1SUNBZ0lHbG1JQ2hvYjNOMFNXUWdJVDBnZEdocGN5NXBaQ0I4ZkNCbmJHOWlZV3d1WW14dlkydE5aWE56WVdkcGJtY3BJSHRjYmlBZ0lDQWdJRzFoZVdKbFFYTjVibU1vWTJJcE8xeHVJQ0FnSUNBZ2NtVjBkWEp1TzF4dUlDQWdJSDFjYmx4dUlDQWdJSFJvYVhNdWIyNU5aWE56WVdkbFJYaDBaWEp1WVd3dWRISnBaMmRsY2lodFpYTnpZV2RsTENCelpXNWtaWElzSUdOaUtUdGNiaUFnZlN4Y2JseHVJQ0JqYjI1dVpXTjBPaUJtZFc1amRHbHZiaUFvYUc5emRFbGtMQ0JqYjI1dVpXTjBTVzVtYnlrZ2UxeHVJQ0FnSUhaaGNpQmpiR2xsYm5SUWIzSjBJRDBnYm1WM0lGQnZjblFvWTI5dWJtVmpkRWx1Wm04dWJtRnRaU3dnZEdocGN5a3NYRzRnSUNBZ0lDQWdJSE5sYkdZZ1BTQjBhR2x6TzF4dUlDQWdJR0Z6YzJWeWRDNWxjWFZoYkNob2IzTjBTV1FzSUhSb2FYTXVhV1FwTzF4dVhHNGdJQ0FnYVdZZ0tHZHNiMkpoYkM1aWJHOWphMDFsYzNOaFoybHVaeWtnZTF4dUlDQWdJQ0FnYzJWMFNXMXRaV1JwWVhSbEtDQm1kVzVqZEdsdmJpQW9LU0I3WEc0Z0lDQWdJQ0FnSUdOc2FXVnVkRkJ2Y25RdWIyNUVhWE5qYjI1dVpXTjBMblJ5YVdkblpYSW9ZMnhwWlc1MFVHOXlkQ2s3WEc0Z0lDQWdJQ0I5S1R0Y2JpQWdJQ0FnSUhKbGRIVnliaUJqYkdsbGJuUlFiM0owTzF4dUlDQWdJSDFjYmx4dUlDQWdJRzFoZVdKbFFYTjVibU1vWm5WdVkzUnBiMjRnS0NrZ2UxeHVJQ0FnSUNBZ2MyVnNaaTV2YmtOdmJtNWxZM1JGZUhSbGNtNWhiQzUwY21sbloyVnlLR05zYVdWdWRGQnZjblF1YjNSb1pYSlFiM0owS1R0Y2JpQWdJQ0I5S1R0Y2JpQWdJQ0J5WlhSMWNtNGdZMnhwWlc1MFVHOXlkRHRjYmlBZ2ZWeHVmVHRjYmx4dVpuVnVZM1JwYjI0Z1VHOXlkQ0FvYm1GdFpTd2djblZ1ZEdsdFpTd2diM1JvWlhKUWIzSjBLU0I3WEc0Z0lIUm9hWE11Ym1GdFpTQTlJRzVoYldVN1hHNGdJSFJvYVhNdWNuVnVkR2x0WlNBOUlISjFiblJwYldVN1hHNGdJSEoxYm5ScGJXVXVjRzl5ZEhNZ1BTQnlkVzUwYVcxbExuQnZjblJ6TG1OdmJtTmhkQ2hiZEdocGMxMHBPMXh1SUNCMGFHbHpMbkJ5WldacGVDQTlJRndpVUc5eWRGd2lJQ3NnS0NGdmRHaGxjbEJ2Y25RZ1B5QmNJanhqYkdsbGJuUStYQ0lnT2lCY0lqeG9iM04wUGx3aUtUdGNiaUFnZEdocGN5NXZia1JwYzJOdmJtNWxZM1FnUFNCdVpYY2dSWFpsYm5Rb1ptRnNjMlVzSUhSb2FYTXVjSEpsWm1sNElDc2dYQ0l1YjI1RWFYTmpiMjV1WldOMFhDSXBPMXh1SUNCMGFHbHpMbTl1VFdWemMyRm5aU0E5SUc1bGR5QkZkbVZ1ZENoMGNuVmxMQ0IwYUdsekxuQnlaV1pwZUNBcklGd2lMbTl1VFdWemMyRm5aVndpTENCMGNuVmxLVHRjYmx4dUlDQjBhR2x6TG05MGFHVnlVRzl5ZENBOUlHOTBhR1Z5VUc5eWRDQjhmQ0J1WlhjZ1VHOXlkQ2h1WVcxbExDQnlkVzUwYVcxbExDQjBhR2x6S1R0Y2JpQWdkR2hwY3k1amIyNXVaV04wWldRZ1BTQjBjblZsTzF4dWZWeHVYRzVRYjNKMExuQnliM1J2ZEhsd1pTQTlJSHRjYmlBZ2NHOXpkRTFsYzNOaFoyVTZJR1oxYm1OMGFXOXVJQ2h0YzJjcElIdGNiaUFnSUNCMllXeHBaR0YwWlUxbGMzTmhaMlVvYlhObktUdGNiaUFnSUNCMGFHbHpMbTkwYUdWeVVHOXlkQzV2YmsxbGMzTmhaMlV1ZEhKcFoyZGxjaWh0YzJjcE8xeHVJQ0I5TEZ4dVhHNGdJR1JwYzJOdmJtNWxZM1E2SUdaMWJtTjBhVzl1SUNobWIzSmpaVXhwYzNSbGJtVnljeWtnZTF4dUlDQWdJR2xtSUNoMGFHbHpMbU52Ym01bFkzUmxaQ2tnZTF4dUlDQWdJQ0FnZG1GeUlITmxiR1lnUFNCMGFHbHpPMXh1SUNBZ0lDQWdkR2hwY3k1eWRXNTBhVzFsTG5CdmNuUnpJRDBnZEdocGN5NXlkVzUwYVcxbExuQnZjblJ6TG1acGJIUmxjaWhtZFc1amRHbHZiaUFvY0NrZ2UxeHVJQ0FnSUNBZ0lDQnlaWFIxY200Z2NDQWhQVDBnYzJWc1pqdGNiaUFnSUNBZ0lIMHBPMXh1WEc0Z0lDQWdJQ0IwYUdsekxtTnZibTVsWTNSbFpDQTlJR1poYkhObE8xeHVJQ0FnSUNBZ2RHaHBjeTV2YmsxbGMzTmhaMlV1YkdsemRHVnVaWEp6SUQwZ1cxMDdYRzRnSUNBZ0lDQnBaaUFvWm05eVkyVk1hWE4wWlc1bGNuTXBlMXh1SUNBZ0lDQWdJQ0IwYUdsekxtOXVSR2x6WTI5dWJtVmpkQzUwY21sbloyVnlLQ2s3WEc0Z0lDQWdJQ0I5WEc0Z0lDQWdJQ0IwYUdsekxtOXVSR2x6WTI5dWJtVmpkQzVzYVhOMFpXNWxjbk1nUFNCYlhUdGNiaUFnSUNBZ0lIUm9hWE11YjNSb1pYSlFiM0owTG1ScGMyTnZibTVsWTNRb2RISjFaU2s3WEc0Z0lDQWdmVnh1SUNCOVhHNTlPMXh1WEc1bmJHOWlZV3d1WTJoeWIyMWxJRDBnWjJ4dlltRnNMbU5vY205dFpTQjhmQ0I3Y25WdWRHbHRaVG9nZTJsa09pQkJVRkJmU1VSOWZUdGNibHh1Ylc5a2RXeGxMbVY0Y0c5eWRITXVSSFZ0YlhsU2RXNTBhVzFsSUQwZ1VuVnVkR2x0WlR0Y2JtMXZaSFZzWlM1bGVIQnZjblJ6TGtWMlpXNTBJRDBnUlhabGJuUTdYRzV0YjJSMWJHVXVaWGh3YjNKMGN5NVFiM0owSUQwZ1VHOXlkRHRjYmlKZGZRPT0iLCJtb2R1bGUuZXhwb3J0cy5CdXJzdFJlcXVlc3QgPSByZXF1aXJlKCcuL3JlcXVlc3RzL2J1cnN0LmpzJykuQnVyc3RSZXF1ZXN0O1xubW9kdWxlLmV4cG9ydHMuR2VuZXJpY1JlcXVlc3QgPSByZXF1aXJlKCcuL3JlcXVlc3RzL2dlbmVyaWMuanMnKS5HZW5lcmljUmVxdWVzdDtcbm1vZHVsZS5leHBvcnRzLk1ldGhvZFJlcXVlc3QgPSByZXF1aXJlKCcuL3JlcXVlc3RzL21ldGhvZC5qcycpLk1ldGhvZFJlcXVlc3Q7XG4iLCIvKipcbiAqIEBmaWxlT3ZlcnZpZXcgQSByZXF1ZXN0IGJ5IHRoZSBjbGllbnQgdG8gcmVjZWl2ZSBhIGJ1cnN0IG9mXG4gKiByZXF1ZXN0cyBmcm9tIGFuIGFwaSBlbWl0dGVyLiBUaGlzIGlzIGluaXRpYWxseSB0cmlnZ2VyZWQgYnkgYSBkYXRhXG4gKiByZWFkeSBzaWduYWwgdmlhIGEgY29ubmVjdGlvbiBmcm9tIHRoZSBob3N0LiBXaGVuIHRoZSBjbGllbnRcbiAqIHJlY2VpdmVzIGl0IHRoZXkgc2VuZCBhIEJ1cnN0UmVxdWVzdCB3aGVuIHRoZXkgYXJlIHJlYWR5IHRvIHJlY2VpdmVcbiAqIHRoZSBkYXRhLiBUaGUgbWFpbiByZWFzb24gZm9yIHRoaXMgaXMgdGhhdCBzZW5kaW5nIG1lc3NhZ2VzIGlzXG4gKiBxdWl0ZSBleHBlbnNpdmUgYW5kIHdlIHdhbnQgdG8gYnVuZGxlIHRoZW0gdG9nZXRoZXIgYXMgbXVjaCBhc1xuICogcG9zc2libGUgd2hlbiBhbiBldmVudCBlbW1pdHRlciBzcGFtcy5cbiAqIEBuYW1lIGJ1cnN0cmVxdWVzdC5qc1xuICogQGF1dGhvciBDaHJpcyBQZXJpdm9sYXJvcG91bG9zXG4gKi9cbnZhciBBcmd1bWVudHMgPSByZXF1aXJlKCcuLy4uL2FyZ3VtZW50cy5qcycpLkFyZ3VlbWVudHMsXG4gICAgbG9nID0gbmV3IChyZXF1aXJlKCcuLy4uL2xvZy5qcycpLkxvZykoJ2J1cnN0cmVxdWVzdCcpLFxuICAgIEdlbmVyaWNSZXF1ZXN0ID0gcmVxdWlyZSgnLi9nZW5lcmljLmpzJykuR2VuZXJpY1JlcXVlc3QsXG4gICAgRXJyUmVzcG9uc2UgPSByZXF1aXJlKCcuLy4uL3Jlc3BvbnNlcy5qcycpLkVyclJlc3BvbnNlLFxuICAgIEJ1cnN0UmVzcG9uc2UgPSByZXF1aXJlKCcuLy4uL3Jlc3BvbnNlcy5qcycpLkJ1cnN0UmVzcG9uc2U7XG5cbi8qKlxuICogQSByZXF1ZXN0IGZvciBhIGJ1cnN0IG9mIGNhbGxiYWNrcyB0aGF0IGFyZSBkZXN0aW5lZCBmb3IgdGhlXG4gKiBjbGllbnQgZnJvbSBhIGNvbm5lY3Rpb24uXG4gKlxuICogQHBhcmFtIHtTdHJpbmd9IGhvc3RJZCBUaGUgY2hyb21lIGFwcCBpZC5cbiAqIEBwYXJhbSB7Q2xpZW50Q29ubmVjdGlvbn0gY29ubmVjdGlvbiB0aGUgY29ubmVjdGlvbiB0aGF0IGhvbGRzIHRoZVxuICogY2FsbGJhY2sgYXJndW1lbnRzLlxuICogQHBhcmFtIHtGdW5jdGlvbn0gY2FsbGJhY2sgVGhlIGV2ZW50IGNhbGxiYWNrIHJhdy5cbiAqL1xuZnVuY3Rpb24gQnVyc3RSZXF1ZXN0IChob3N0SWQsIGNvbm5lY3Rpb24sIGNhbGxiYWNrKSB7XG4gIHRoaXMuaG9zdElkID0gaG9zdElkO1xuICB0aGlzLmNvbm5lY3Rpb24gPSBjb25uZWN0aW9uO1xuICB0aGlzLmNhbGxiYWNrID0gY2FsbGJhY2s7XG4gIHRoaXMuYmxvY2tlZCA9IGZhbHNlO1xufVxuXG4vKipcbiAqIEhhbmRsZSBhIHJlcXVlc3QgZm9yIGEgYnVyc3Qgb24gdGhlIHNlcnZlci4gSWYgdGhlIG1lc3NhZ2UgZG9lc24ndFxuICogc2VlbSB2YWxpZCwgZGlzcmVnYXJkIGl0LlxuICpcbiAqIEBwYXJhbSB7QXBpTWVzc2FnZX0gbXNnIFRoZSBtZXNzYWdlIGFzIHRha2VuIGZyb20gdGhlIHNlbmRcbiAqIGZ1bmN0aW9uLCBpZSB0aGUgZm9yU2VuZGluZyBtZXRob2QuXG4gKiBAcGFyYW0ge0FycmF5KEhvc3RDb25uZWN0aW9ucyl9IGNvbm5lY3Rpb25zIEFuIGFycmF5IG9mIGNvbm5lY3Rpb25zXG4gKiBAcGFyYW0ge0Z1bmN0aW9uKG1zZywgc2VuZGVyLCBzZW5kUmVzcCl9IHNlbmRSZXNwUmF3IGNhbGxiYWNrIHRvXG4gKiBzZW5kIHJlc3BvbnNlLlxuICogQHJldHVybiB7Qm9vbGVhbn0gVHJ1ZSBpZiB3ZSBoYW5kbGVkIGl0LlxuICovXG5CdXJzdFJlcXVlc3QubWF5YmVIYW5kbGUgPSBmdW5jdGlvbiAobXNnLCBjb25uZWN0aW9ucywgc2VuZFJlc3BSYXcpIHtcbiAgaWYgKG1zZy5yZXF1ZXN0VHlwZSAhPSAgXCJCdXJzdFJlcXVlc3RcIikge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfTtcbiAgdmFyIHVzZWZ1bENvbnMgPSBjb25uZWN0aW9ucy5maWx0ZXIoZnVuY3Rpb24gKGMpIHtcbiAgICByZXR1cm4gbXNnLmNvbm5JZCA9PSBjLmlkO1xuICB9KTtcblxuICBpZiAodXNlZnVsQ29ucy5sZW5ndGggIT0gMSkge1xuICAgIHZhciBlcnJNc2cgPSBcIkJ1cnN0IHJlcXVlc3QgZm9yIGNvbm5lY3Rpb24gXCIgKyBtc2cuY29ubklkICsgXCIgY29ycmVzcG9uZHMgdG8gXCIgK1xuICAgICAgICAgIHVzZWZ1bENvbnMubGVuZ3RoICsgXCIgY29ubmVjdGlvbnNcIixcbiAgICAgICAgZXJyUmVzcCA9IG5ldyBFcnJSZXNwb25zZShlcnJNc2cpO1xuICAgIGVyclJlc3Auc2VuZChzZW5kUmVzcFJhdyk7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cblxuICBmdW5jdGlvbiBzZW5kQnVmZmVyIChidWYpIHtcbiAgICB2YXIgYnIgPSBuZXcgQnVyc3RSZXNwb25zZShidWYsIG1zZyk7XG4gICAgYnIuc2VuZChzZW5kUmVzcFJhdyk7XG4gIH1cblxuICB1c2VmdWxDb25zWzBdLmZsdXNoQnVmZmVyKHNlbmRCdWZmZXIpO1xuICByZXR1cm4gdHJ1ZTtcbn07XG5cbkJ1cnN0UmVxdWVzdC5wcm90b3R5cGUgPSBPYmplY3QuY3JlYXRlKEdlbmVyaWNSZXF1ZXN0LnByb3RvdHlwZSk7XG5cbi8qKlxuICogQ3JlYXRlIGEgc2VyaWFsaXphYmxlIG9iamVjdCB0byBzZW5kIG92ZXIgdGhlIEFQSS5cbiAqIEByZXR1cm5zIHtNZXNzYWdlfSBhIHNlcmlhbGl6ZWQgbWVzc2FlXG4gKi9cbkJ1cnN0UmVxdWVzdC5wcm90b3R5cGUuZm9yU2VuZGluZyA9IGZ1bmN0aW9uICgpIHtcbiAgcmV0dXJuIHtyZXF1ZXN0VHlwZTogXCJCdXJzdFJlcXVlc3RcIixcbiAgICAgICAgICBjb25uSWQ6IHRoaXMuY29ubmVjdGlvbi5pZH07XG59O1xuXG4vKipcbiAqIEdldCB0aGUgY2FsbGJhY2sgZnJvbSB0aGUgYXJndW1lbnRzLiBXaWxsIG9ubHkgd29yayBvbiB0aGUgY2xpZW50XG4gKlxuICogQHJldHVybnMge0Z1bmN0aW9ufSB0aGUgY2FsbGJhY2sgb3IgdW5kZWZpbmVkLlxuICovXG5CdXJzdFJlcXVlc3QucHJvdG90eXBlLmdldENhbGxiYWNrID0gZnVuY3Rpb24gKCkge1xuICByZXR1cm4gdGhpcy5jYWxsYmFjaztcbn07XG5cbm1vZHVsZS5leHBvcnRzLkJ1cnN0UmVxdWVzdCA9IEJ1cnN0UmVxdWVzdDtcbiIsInZhciBnZW5lcmljUmVzcEhhbmRsZXIgPSByZXF1aXJlKCcuLy4uL3Jlc3BvbnNlcy5qcycpLmdlbmVyaWNSZXNwSGFuZGxlcixcbiAgICBtZXNzYWdlQXBpID0gcmVxdWlyZShcIi4vLi4vbWVzc2FnaW5nLmpzXCIpLFxuICAgIGxvZyA9IG5ldyAocmVxdWlyZSgnLi8uLi9sb2cuanMnKS5Mb2cpKCdnZW5lcmljcmVxdWVzdCcpO1xuXG4vKipcbiAqIEEgZ2VuZXJpYyByZXF1ZXN0IHRvIGluaGVyaXQgbmV3IG9uZXMgZnJvbS4gTWFrZSBzdXJlIHlvdSBkZWZpbmVcbiAqIGhvc3RJZCBwcm9wZXJ0eSBpbiB5b3VyIGNsYXNzZXMgYW5kIGFsc28gZGVmaW5lIGEgZm9yU2VuZGluZy5cbiAqL1xuZnVuY3Rpb24gR2VuZXJpY1JlcXVlc3QoKSB7fTtcblxuR2VuZXJpY1JlcXVlc3QucHJvdG90eXBlID0ge1xuICAvKipcbiAgICogQ3JlYXRlIGEgc2VyaWFsaXphYmxlIG9iamVjdCB0byBzZW5kIG92ZXIgdGhlIEFQSS5cbiAgICogQHJldHVybnMge01lc3NhZ2V9IGEgc2VyaWFsaXplZCBtZXNzYWVcbiAgICovXG4gIGZvclNlbmRpbmc6IGZ1bmN0aW9uICgpIHtcbiAgICB0aHJvdyBFcnJvcihcImZvclNlbmRpbmcgbm90IGltcGxlbWVudGVkLlwiKTtcbiAgfSxcblxuICAvKipcbiAgICogU2VuZCB0aGUgcmVxdWVzdCBhbmQgaGFuZGxlIHRoZSByZXNwb25zZS5cbiAgICogQHBhcmFtIHtGdW5jdGlvbn0gY2IgQ2FsbGVkIHdoZW4gaGFuZGxpbmcgaXMgZmluaXNoZWQuIE5vXG4gICAqIGFyZ3VtZW50cyBpbiBjYXNlIGl0IHN1Y2NlZWRzLCBhbiBlcnJvciBvYmplY3QgaWYgaXQgZmFpbGVzXG4gICAqL1xuICBzZW5kOiBmdW5jdGlvbiAoY2IsIGVycm9yQ2IpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXMsXG4gICAgICAgIG1zZyA9IHRoaXMuZm9yU2VuZGluZygpLFxuICAgICAgICBob3N0SWQgPSB0aGlzLmhvc3RJZDtcblxuICAgIG1lc3NhZ2VBcGkuc2VuZE1lc3NhZ2UoXG4gICAgICBob3N0SWQsIG1zZywgZnVuY3Rpb24gKHJlc3ApIHtcbiAgICAgICAgZ2VuZXJpY1Jlc3BIYW5kbGVyKHJlc3AsIHNlbGYsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBjYiB8fCBmdW5jdGlvbiAoZXJyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlcnIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgIH0pO1xuICB9XG59O1xubW9kdWxlLmV4cG9ydHMuR2VuZXJpY1JlcXVlc3QgPSBHZW5lcmljUmVxdWVzdDtcbiIsInZhciBBcmd1bWVudHMgPSByZXF1aXJlKFwiLi8uLi9hcmd1bWVudHMuanNcIikuQXJndW1lbnRzLFxuICAgIEdlbmVyaWNSZXF1ZXN0ID0gcmVxdWlyZSgnLi9nZW5lcmljLmpzJykuR2VuZXJpY1JlcXVlc3QsXG4gICAgdXRpbCA9IHJlcXVpcmUoXCIuLy4uL3V0aWxcIiksXG4gICAgQXJnc1Jlc3BvbnNlID0gcmVxdWlyZShcIi4vLi4vcmVzcG9uc2VzLmpzXCIpLkFyZ3NSZXNwb25zZSxcbiAgICBFcnJSZXNwb25zZSA9IHJlcXVpcmUoXCIuLy4uL3Jlc3BvbnNlcy5qc1wiKS5FcnJSZXNwb25zZSxcbiAgICBBY2tSZXNwb25zZSA9IHJlcXVpcmUoXCIuLy4uL3Jlc3BvbnNlcy5qc1wiKS5BY2tSZXNwb25zZSxcbiAgICBsb2cgPSBuZXcgKHJlcXVpcmUoJy4vLi4vbG9nLmpzJykuTG9nKSgnbWV0aG9kcmVxdWVzdCcpO1xuXG5cbmZ1bmN0aW9uIGlzTm9kZSAoKSB7XG4gIGlmICh0eXBlb2Ygd2luZG93ID09PSAndW5kZWZpbmVkJykgcmV0dXJuIHRydWU7XG5cbiAgdmFyIGJhY2t1cCA9IHdpbmRvdyxcbiAgICAgIHdpbmRvd19jYW5fYmVfZGVsZXRlZCA9IGRlbGV0ZSB3aW5kb3c7XG4gIHdpbmRvdyA9IGJhY2t1cDsgLy8gUmVzdG9yaW5nIGZyb20gYmFja3VwXG5cbiAgcmV0dXJuIHdpbmRvd19jYW5fYmVfZGVsZXRlZDtcbn1cblxuLyoqXG4gKiBBIHJlcXVlc3QgZnJvbSB0aGUgY2xpZW50IHRvIHJlc29sdmUgYSBtZXRob2QgY2FsbC4gQWxzbyBoYW5kbGVzXG4gKiB0aGUgcmVzcG9uc2UuXG4gKlxuICogQHBhcmFtIHtTdHJpbmd9IGhvc3RJZCBUaGUgYXBwIGlkLiBDb3VsZCBiZSBudWxsIGlmIHlvdSBkb250IGludGVuZFxuICogdG8gc2VuZCBpdC5cbiAqIEBwYXJhbSB7U3RyaW5nfSBtZXRob2QgVGhlIG1ldGhvZCB0byBiZSBjYWxsZWQuXG4gKiBAcGFyYW0ge0FycmF5fEFyZ3VtZW50c30gYXJncyBUaGUgcmVhbCBhcmd1bWVudCBsaXN0IG9yIGEgd3JhcHBlZFxuICogYXJndW1lbnRzIG9iamVjdC5cbiAqIEBwYXJhbSB7Qm9vbGVhbn0gaXNSZXZlcnNlciBXZXRoZXIgdGhpcyBtZXRob2QgcmVxdWVzdCBpcyBzdXBwb3NlZFxuICogdG8gcmV2ZXJ0IHRoZSBzaWRlIGVmZmVjdHMgb2YgYSBwcmV2aW91cyByZXF1ZXN0LlxuICogQHBhcmFtIHtCb29sZWFufSBub0NhbGxiYWNrIHRydWUgbWVhbnMgdGhhdCBob3N0IHNob3VsZCByZXBseSB3aXRoXG4gKiBBY2tSZXNwb25zZS5cbiAqIEBwYXJhbSB7RnVuY3Rpb259IHdpdGhFcnJvciBXcmFwcGVyIHRvIGhhbmRsZSBlcnJvcnMuXG4gKi9cbmZ1bmN0aW9uIE1ldGhvZFJlcXVlc3QgKGhvc3RJZCwgbWV0aG9kLCBhcmdzLCBpc1JldmVyc2VyLCBub0NhbGxiYWNrLCB3aXRoRXJyb3IpIHtcbiAgdGhpcy5tZXRob2QgPSBtZXRob2Q7XG4gIHRoaXMuYXJncyA9IGFyZ3MgaW5zdGFuY2VvZiBBcmd1bWVudHMgPyBhcmdzIDpcbiAgICBuZXcgQXJndW1lbnRzKGFyZ3MpO1xuICB0aGlzLmhvc3RJZCA9IGhvc3RJZDtcbiAgdGhpcy5pc1JldmVyc2VyID0gaXNSZXZlcnNlciB8fCBmYWxzZTtcbiAgdGhpcy5ub0NhbGxiYWNrID0gbm9DYWxsYmFjayB8fCBmYWxzZTtcbiAgdGhpcy53aXRoRXJyb3IgPSB3aXRoRXJyb3I7XG4gIC8vIE5vZGUgc2VlbXMgdG8gZGlzcGxheSBlcnJvcnMgZXZlbiBpZiB3ZSBkb24ndCB0aHJvdyB0aGVtIGFuZCBpdFxuICAvLyBnZXRzIHJlYWxseSBhbm5veWluZ1xuICBpZiAoIWlzTm9kZSgpKSB7XG4gICAgdGhpcy50cmFjZSA9IChuZXcgRXJyb3IoKSkuc3RhY2s7XG4gIH1cblxuICBpZiAodGhpcy5hcmdzLmZvclNlbmRpbmcoKS5maWx0ZXIoZnVuY3Rpb24gKGEpIHtcbiAgICByZXR1cm4gISEoYSAmJiBhLmlzQ2FsbGJhY2spO1xuICB9KS5sZW5ndGggPiAxKSB7XG4gICAgdGhyb3cgRXJyb3IoXCJXZSBkbyBub3Qgc3VwcG9ydCBtb3JlIHRoYW4gb25lIGNhbGxiYWNrIGluIGFyZ3VtZW50cy5cIik7XG4gIH1cbn1cblxuTWV0aG9kUmVxdWVzdC5wcm90b3R5cGUgPSBPYmplY3QuY3JlYXRlKEdlbmVyaWNSZXF1ZXN0LnByb3RvdHlwZSk7XG5cbi8qKlxuICogQ3JlYXRlIGEgbWV0aG9kIHJlcXVlc3QgZnJvbSBhIG1lc3NhZ2UuIFdoZW4gYSBjYWxsYmFjayBpcyBwcm92aWRlZFxuICogaXQgd2lsbCBiZSB1c2VkLlxuICpcbiAqIEBwYXJhbSB7U3RyaW5nfSBob3N0SWQgVGhlIGhvc3QgdG8gc2VuZCB0aGUgcmVxdXNldC4gU2V0IHRoaXMgdG9cbiAqIG51bGwgaWYgaXQncyBqdXN0IGZvciBjb21wYXJpbmcgb3IgZm9yIGludm9raW5nIGl0J3MgY2FsbGJhY2tcbiAqIChnZW5lcmFsbHkgaWYgeW91IGFyZSBvbiB0aGUgaG9zdCBzaWRlLilcbiAqIEBwYXJhbSB7TWVzc2FnZX0gbXNnIEEgbWVzc2FnZSBhcyBnZW5lcmF0ZWQgYnkgZm9yU2VuZGluZygpXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSByZXNwQ2IgUmF3IHNlbmQgcmVzcG9uc2UgY2FsbGJhY2suXG4gKiBAcmV0dXJucyB7TWV0aG9kUmVxdWVzdH0gQSBtZXRob2QgcmVxdWVzdC5cbiAqL1xuTWV0aG9kUmVxdWVzdC5mcm9tTWVzc2FnZSA9IGZ1bmN0aW9uIChob3N0SWQsIG1zZywgcmVzcENiKSB7XG4gIHZhciBhcmdzID0gbmV3IEFyZ3VtZW50cyhtc2cuYXJncywgcmVzcENiKTtcbiAgcmV0dXJuIG5ldyBNZXRob2RSZXF1ZXN0KGhvc3RJZCwgbXNnLm1ldGhvZCwgYXJncyk7XG59O1xuXG4vKipcbiAqIElmIHRoZSBtZXNzYWdlIGlzIGEgcmVxdWVzdCB0byBjbG9zZSBhIGNvbm5lY3Rpb24gKHJldmVyc2VyKVxuICpcbiAqIEBwYXJhbSB7TWVzc2FnZX0gbXNnIEEgbWVzc2FnZSBnZW5lcmF0ZWQgYnkgYSBNZXRob2RSZXF1ZXN0LlxuICogQHBhcmFtIHtBcnJheShIb3N0Q29ubmVjdGlvbil9IGNvbm5lY3Rpb25zIGEgbGlzdCBvZiBvcGVuIGNvbm5lY3Rpb25zLlxuICogQHBhcmFtIHtGdW5jdGlvbn0gc2VuZFJlc3BSYXcgQ2FsbGJhY2sgdG8gc2VuZCBhIHJhdyBtZXNzYWdlLlxuICogQHBhcmFtIHtCb29sZWFufSBmb3JjZSBUaGlzIGlzIGEgcmV2ZXJzZXIgZXZlbiBpZiBpZCBkb2Vzbid0IGxvb2tcbiAqIGxpa2UgaXQuXG4gKiBAcmV0dXJucyB7Qm9vbGVhbn0gVHJ1ZSBpZiB3ZSBoYW5kbGVkIGl0LlxuICovXG5mdW5jdGlvbiBoYW5kbGVSZXZlcnNlciAobXNnLCBjb25uZWN0aW9ucywgaG9zdEFwaSkge1xuICBpZiAoIWNvbm5lY3Rpb25zICYmICFtc2cuaXNSZXZlcnNlcikgcmV0dXJuIGZhbHNlO1xuICB2YXIgcmVxID0gTWV0aG9kUmVxdWVzdC5mcm9tTWVzc2FnZShudWxsLCBtc2cpLFxuICAgICAgcmVzcG9uc2UgPSBjb25uZWN0aW9uc1xuICAgICAgICAubWFwKGZ1bmN0aW9uIChjKSB7XG4gICAgICAgICAgcmV0dXJuIGMudHJ5Q2xvc2luZyhyZXEpO1xuICAgICAgICB9KS5yZWR1Y2UoZnVuY3Rpb24gKGEsIGIpIHtcbiAgICAgICAgICByZXR1cm4gYSB8fCBiO1xuICAgICAgICB9LCBmYWxzZSk7XG5cbiAgLy8gV2Ugd29uJ3QgZ2V0IGEgcmVzcG9uc2UgZm9yIGFyZ3MgdGhhdCBkb24ndCByYWlzZSBhIGNhbGxiYWNrLlxuICBpZiAobXNnLmlzUmV2ZXJzZXIgJiYgIXJlc3BvbnNlKSB7XG4gICAgY29uc29sZS53YXJuKFxuICAgICAgXCJZb3UgdG9sZCBtZSBcIiArIEpTT04uc3RyaW5naWZ5KG1zZykgK1xuICAgICAgICBcIiB3YXMgYSByZXZlcnNlciBidXQgaSBmb3VuZCBub3RoaW5nIHRvIHJldmVyc2UuXCIpO1xuICAgIGlmIChtc2cubm9DYWxsYmFjaykge1xuICAgICAgLy8gVHJ1c3QgdGhlIHVzZXIga25vd3Mgd2hhdCB0aGV5IGFyZSBkb2luZ1xuICAgICAgcmVxLmNhbGwobnVsbCwgaG9zdEFwaSk7XG4gICAgICByZXR1cm4gbmV3IEVyclJlc3BvbnNlKFwiVHJpZWQgdG8gY2xlYW4gd2l0aCBcIiArIG1zZy5tZXRob2QgKyBcIiBidXQgZmFpbGVkLlwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIndhcm5pbmdcIik7XG4gICAgfVxuXG4gICAgLy8gVGhlcmUgbWF5IGJlIGEgY2FsbGJhY2sgd2FpdGluZy5cbiAgICByZXR1cm4gQXJnc1Jlc3BvbnNlLmFzeW5jKHJlcSwgaG9zdEFwaSk7XG4gIH1cblxuICByZXR1cm4gcmVzcG9uc2U7XG59XG5cbi8qKlxuICogSGFuZGxlIHRoZSByZXF1ZXN0IG9uIHRoZSBzZXJ2ZXIuIFRyeSB0byBydW4gdGhlIG1ldGhvZCBhbmRcbiAqIGdlbmVyYXRlIGEgKlJlc3BvbnNlLCBzZXJpYWxpemUgaXQgYW5kIHNlbmQgaXQgb3ZlciB0aGVcbiAqIHNlbmRSZXNwQXBpLiBJZiB0aGUgbWVzc2FnZSBkb2Vzbid0IHNlZW0gdmFsaWQsIGRpc3JlZ2FyZCBpdC5cbiAqXG4gKiBAcGFyYW0ge01lc3NhZ2V9IG1zZyBBIG1lc3NhZ2UgZ2VuZXJhdGVkIGJ5IGEgTWV0aG9kUmVxdWVzdC5cbiAqIEBwYXJhbSB7QXJyYXkoSG9zdENvbm5lY3Rpb24pfSBjb25uZWN0aW9ucyBhIGxpc3Qgb2Ygb3BlbiBjb25uZWN0aW9ucy5cbiAqIEBwYXJhbSB7aG9zdEFwaU9iamVjdH0gaG9zdEFwaSBjaHJvbWUgQVBJIGxpa2FlIG9iamVjdCB3aGVyZSB0aGVcbiAqIHJlcXVyZXN0IG1ldGhvZCBpcyBiYXNlZC5cbiAqIEBwYXJhbSB7RnVuY3Rpb259IHNlbmRSZXNwUmF3IENhbGxiYWNrIHRvIHNlbmQgYSByYXcgbWVzc2FnZS5cbiAqIEByZXR1cm5zIHtCb29sZWFufSBUcnVlIGlmIHdlIGhhbmRsZWQgaXQuXG4gKi9cbnZhciBtZXNzYWdlc1JlY2VpdmVkID0gMDtcbk1ldGhvZFJlcXVlc3QubWF5YmVIYW5kbGUgPSBmdW5jdGlvbiAobXNnLCBob3N0QXBpLCBzZW5kUmVzcFJhdywga3cpIHtcbiAga3cgPSBrdyB8fCB7fTtcbiAgdmFyIF9zZW5kUmVzcFJhdyA9IGZ1bmN0aW9uIChzZW5kTXNnKSB7XG4gICAgaWYgKCgrK21lc3NhZ2VzUmVjZWl2ZWQpICUgMTAwMCA9PSAwKSB7XG4gICAgICBsb2cubG9nKFwiU2VuZGluZyAxMDAwIG1lc3NhZ2VzXCIpO1xuICAgIH1cblxuICAgIGlmIChzZW5kTXNnLnJlc3BvbnNlVHlwZSA9PSBcIkVyclJlc3BvbnNlXCIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IobXNnLCBcIi0+XCIsIHNlbmRNc2cpO1xuICAgIH1cblxuICAgIHNlbmRSZXNwUmF3KHNlbmRNc2cpO1xuICB9O1xuXG4gIGlmIChtc2cucmVxdWVzdFR5cGUgIT0gXCJNZXRob2RSZXF1ZXN0XCIpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cblxuICB2YXIgcmVzcCA9IGhhbmRsZVJldmVyc2VyKG1zZywga3cuY29ubmVjdGlvbnMsIGhvc3RBcGkpO1xuICBpZiAocmVzcCkge1xuICAgIHJlc3Auc2VuZChfc2VuZFJlc3BSYXcpO1xuICAgIHJldHVybiB0cnVlO1xuICB9XG5cbiAgc2VuZFJlc3BSYXcgPSBzZW5kUmVzcFJhdyB8fCBmdW5jdGlvbiAoKSB7fTtcbiAgdmFyIHNlbmRBcmdzQXNSZXNwb25zZSA9IGZ1bmN0aW9uICh2YXJBcmdzKSB7XG4gICAgdmFyIGFyZ3NBcnIgPSBbXS5zbGljZS5jYWxsKGFyZ3VtZW50cyksXG4gICAgICAgIGNiQXJncyA9IG5ldyBBcmd1bWVudHMoYXJnc0FyciksXG4gICAgICAgIGFyZ3NSZXNwID0gbmV3IEFyZ3NSZXNwb25zZShjYkFyZ3MpO1xuXG4gICAgLy8gSW50ZXJuYWwgYXBpIGVycm9yXG4gICAgaWYgKGNocm9tZSAmJlxuICAgICAgICBjaHJvbWUucnVudGltZSAmJlxuICAgICAgICBjaHJvbWUucnVudGltZS5sYXN0RXJyb3IgJiZcbiAgICAgICAgYXJnc0Fyci5sZW5ndGggPT0gMCkge1xuICAgICAgbmV3IEVyclJlc3BvbnNlKGNocm9tZS5ydW50aW1lLmxhc3RFcnJvcixcbiAgICAgICAgICAgICAgICAgICAgICAnY2hyb21lLnJ1bnRpbWUubGFzdEVycm9yJylcbiAgICAgICAgLnNlbmQoX3NlbmRSZXNwUmF3KTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cblxuICAgIC8vIEV2ZXJ5dGhpbmcgd2VudCB3ZWxsLlxuICAgIGFyZ3NSZXNwLnNlbmQoX3NlbmRSZXNwUmF3KTtcbiAgfSwgbWV0aG9kQXJncyA9IG5ldyBBcmd1bWVudHMobXNnLmFyZ3MsIHNlbmRBcmdzQXNSZXNwb25zZSksXG4gICAgICBtZXRob2RDYiA9IHV0aWwucGF0aDJjYWxsYWJsZShob3N0QXBpLCBtc2cubWV0aG9kKTtcblxuICAvLyBCYWQgcGF0aCByZWNlaXZlZC5cbiAgaWYgKCFtZXRob2RDYikge1xuICAgIHJlc3AgPSBuZXcgRXJyUmVzcG9uc2UoXCJNZXRob2QgXCIgKyBtc2cubWV0aG9kICsgXCIgbm90IGZvdW5kLlwiKTtcbiAgICByZXNwLnNlbmQoX3NlbmRSZXNwUmF3KTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgLy8gQWxsIHdlbnQgd2VsbFxuICAgIGlmIChrdy51cGRhdGVBcmdzKSBrdy51cGRhdGVBcmdzKG1ldGhvZEFyZ3MpO1xuICAgIG1ldGhvZENiLmFwcGx5KG51bGwsIG1ldGhvZEFyZ3MuZm9yQ2FsbGluZygpKTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfSBjYXRjaCAoZSkge1xuICAgIHJlc3AgPSBuZXcgRXJyUmVzcG9uc2Uoe21lc3NhZ2U6IFwiRXJyb3Igb24gY2FsbGluZyBcIiArIG1zZy5tZXRob2QgKyBcIjpcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICsgZS5tZXNzYWdlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0YWNrOiBlLnN0YWNrfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICdjaHJvbWUucnVudGltZS5sYXN0RXJyb3InKTtcbiAgICByZXNwLnNlbmQoX3NlbmRSZXNwUmF3KTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuXG4gIC8vIFdlIGtub3cgdGhpcyBtZXRob2Qgd29udCBicmluZyB1cCBhIGNhbGxiYWNrLlxuICBpZiAobXNnLm5vQ2FsbGJhY2spIHtcbiAgICBuZXcgQWNrUmVzcG9uc2UoKS5zZW5kKF9zZW5kUmVzcFJhdyk7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbn07XG5cbi8qKlxuICogQHJldHVybnMge09iamVjdH0gU2VyaWFsaXphYmxlIG9iamVjdCB0byBjb21tdW5pY2F0ZSB3aXRoIHRoZSBzZXJ2ZXIuXG4gKi9cbk1ldGhvZFJlcXVlc3QucHJvdG90eXBlLmZvclNlbmRpbmcgPSBmdW5jdGlvbiAoKSB7XG4gIHZhciByZXQgPSB7cmVxdWVzdFR5cGU6IFwiTWV0aG9kUmVxdWVzdFwiLFxuICAgICAgICAgICAgIG1ldGhvZDogdGhpcy5tZXRob2QsXG4gICAgICAgICAgICAgYXJnczogdGhpcy5hcmdzLmZvclNlbmRpbmcoKSxcbiAgICAgICAgICAgICBub0NhbGxiYWNrOiB0aGlzLm5vQ2FsbGJhY2ssXG4gICAgICAgICAgICAgaXNSZXZlcnNlcjogdGhpcy5pc1JldmVyc2VyXG4gICAgICAgICAgICB9O1xuICByZXR1cm4gcmV0O1xuXG59O1xuXG4vKipcbiAqIFJ1biB0aGlzIG1ldGhvZCByZXF1ZXN0LiBUaGlzIHdpbGwgbm90IGhhbmRsZSByZXZlcnNlcnMuXG4gKi9cbk1ldGhvZFJlcXVlc3QucHJvdG90eXBlLmNhbGwgPSBmdW5jdGlvbiAoc2VuZFJlc3AsIGhvc3RBcGkpIHtcbiAgdmFyIHNlbGYgPSB0aGlzO1xuICBmdW5jdGlvbiB1cGRhdGVBcmdzIChhcmdzKSB7XG4gICAgc2VsZi5hcmdzID0gYXJncztcbiAgfVxuICBNZXRob2RSZXF1ZXN0Lm1heWJlSGFuZGxlKHRoaXMuZm9yU2VuZGluZygpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhvc3RBcGksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VuZFJlc3AgfHwgdGhpcy5nZXRDYWxsYmFjaygpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt1cGRhdGVBcmdzOiB1cGRhdGVBcmdzfSk7XG59O1xuXG4vKipcbiAqIEdldCB0aGUgY2FsbGJhY2sgZnJvbSB0aGUgYXJndW1lbnRzLiBPbiB0aGUgc2VydmVyIHRoaXMgaXMgYVxuICogZnVuY3Rpb24gYWNjZXB0aW5nIGEgcmVzcG9uc2UgdHlwZS5cbiAqXG4gKiBAcmV0dXJucyB7RnVuY3Rpb259IHRoZSBjYWxsYmFjayBvciB1bmRlZmluZWQuXG4gKi9cbk1ldGhvZFJlcXVlc3QucHJvdG90eXBlLmdldENhbGxiYWNrID0gZnVuY3Rpb24gKCkge1xuICByZXR1cm4gdGhpcy5hcmdzLmdldENhbGxiYWNrKCk7XG59O1xuXG5cbi8qKlxuICogR2V0IHRoZSBjYWxsYmFjayBmcm9tIHRoZSBhcmd1bWVudHMuIEEgdXNhYmxlIG9uZS5cbiAqXG4gKiBAcmV0dXJucyB7RnVuY3Rpb259IHRoZSBjYWxsYmFjayBvciB1bmRlZmluZWQuXG4gKi9cbk1ldGhvZFJlcXVlc3QucHJvdG90eXBlLnJlYWxDYWxsYmFjayA9IGZ1bmN0aW9uICgpIHtcbiAgdmFyIHNlbGYgPSB0aGlzLCBjYWxsYmFjayA9IHNlbGYuYXJncy5nZXRDYWxsYmFjaygpO1xuICByZXR1cm4gZnVuY3Rpb24gKCkge1xuICAgIHZhciBhcmdzID0gbmV3IEFyZ3VtZW50cyhbXS5zbGljZS5jYWxsKGFyZ3VtZW50cykpLFxuICAgICAgICByZXNwID0gbmV3IEFyZ3NSZXNwb25zZShhcmdzKTtcbiAgICBjYWxsYmFjay5jYWxsKG51bGwsIHJlc3AuZm9yU2VuZGluZygpKTtcbiAgfTtcbn07XG5cblxuXG5tb2R1bGUuZXhwb3J0cy5NZXRob2RSZXF1ZXN0ID0gTWV0aG9kUmVxdWVzdDtcbiIsIi8qKlxuICogQGZpbGVPdmVydmlldyBSZXNwb25zZXMgdGhhdCBjYW4gYmUgZ2VuZXJhdGVkIGJ5IHRoZSBob3N0LiAgRWFjaFxuICogcmVzcG9uc2UgaXMgZ2VuZXJhdGVkIGFkLWhvYyBzbyB0aGUgc2lnbmF0dXJlIG9mIHRoZWlyIGNvbnN0cnVjdG9yXG4gKiBpcyBhcmJpdHJhcnkgYnV0IGVhY2ggX3R5cGVfIGhhcyBpdCdzIG93biBoYW5kbGUgbWV0aG9kIHRoYXQgaXNcbiAqIGV4ZWN1dGVkIG9uIHRoZSBjbGllbnQgYW5kIGFjY2VwdHMgdGhlIHJlY2VpdmVkIG1lc3NhZ2UsIHRoZVxuICogcmVxdWVzdCBnZW5lcmF0aW5nIHRoZSByZXNwb25zZSBhbmQgYSBjYWxsYmFjayB3aGVuIHdlIGFyZSBkb25lXG4gKiBoYW5kbGluZyBpdC5cbiAqIEBuYW1lIHJlc3BvbnNlcy5qc1xuICogQGF1dGhvciBDaHJpcyBQZXJpdm9sYXJvcHVsb3NcbiAqL1xuXG5tb2R1bGUuZXhwb3J0cy5FcnJSZXNwb25zZSA9IHJlcXVpcmUoJy4vcmVzcG9uc2VzL2Vycm9yLmpzJyk7XG5tb2R1bGUuZXhwb3J0cy5CdXJzdFJlc3BvbnNlID0gcmVxdWlyZSgnLi9yZXNwb25zZXMvYnVyc3QuanMnKTtcbm1vZHVsZS5leHBvcnRzLkFyZ3NSZXNwb25zZSA9IHJlcXVpcmUoJy4vcmVzcG9uc2VzL2FyZ3VtZW50cy5qcycpO1xubW9kdWxlLmV4cG9ydHMuQWNrUmVzcG9uc2UgPSByZXF1aXJlKCcuL3Jlc3BvbnNlcy9hY2suanMnKTtcbm1vZHVsZS5leHBvcnRzLmdlbmVyaWNSZXNwSGFuZGxlciA9XG4gIHJlcXVpcmUoJy4vcmVzcG9uc2VzL2dlbmVyaWMuanMnKS5nZW5lcmljUmVzcEhhbmRsZXI7XG4iLCJ2YXIgR2VuZXJpY1Jlc3BvbnNlID0gcmVxdWlyZSgnLi9nZW5lcmljLmpzJykuR2VuZXJpY1Jlc3BvbnNlO1xucmVxdWlyZSgnLi8uLi9zZXRpbW1lZGlhdGUuanMnKTtcblxuLyoqXG4gKiBUaGUgcmVxdWVzdCB3YXNuJ3Qgc3VwcG9zZWQgdG8geWllbGQgYW55IHJlc3VsdCBidXQgd2FzXG4gKiBzdWNjZXNzZnVsLlxuICovXG5mdW5jdGlvbiBBY2tSZXNwb25zZSAoKSB7XG59O1xuXG4vKipcbiAqIEhhbmRsZSB0aGUgcmVzcG9uc2Ugb24gdGhlIGNsaWVudCBzaWRlIGlmIGl0IGlzIG9mIHRoZSBjb3JyZWN0XG4gKiB0eXBlLlxuICpcbiAqIEBwYXJhbSB7TWVzc2FnZX0gbXNnIHRoZSByYXcgbWVzc2FnZSByZWNlaXZlZCBieSB0aGUgc2VydmVyXG4gKiBAcGFyYW0ge1JlcXVlc3R9IHJlcXVlc3QgdGhlIHJlcXVlc3Qgb2JqZWN0IHRoYXQgbXNnIGlzIGEgcmVzcG9uc2VcbiAqIHRvLlxuICogQHBhcmFtIHtGdW5jdGlvbn0gZG9uZUNiIENhbGwgdGhpcyB3aGVuIHlvdSBhcmUgZG9uZS4gSXQgd2lsbCBiZVxuICogY2FsbGVkIHdpdGggbm8gYXJndW1lbnRzIG9uIHN1Y2NlcyBvciBhbiBlcnJvciBvYmplY3Qgb24gZXJyb3IuXG4gKiBAcmV0dXJuIHtCb29sZWFufSB0cnVlIGlmIHdlIGhhbmRsZWQgaXQuXG4gKi9cbkFja1Jlc3BvbnNlLm1heWJlSGFuZGxlID0gZnVuY3Rpb24gKG1zZywgcmVxdWVzdCwgZG9uZUNiKSB7XG4gIGlmIChtc2cucmVzcG9uc2VUeXBlICE9IFwiQWNrUmVzcG9uc2VcIikgcmV0dXJuIGZhbHNlO1xuICBzZXRJbW1lZGlhdGUoZG9uZUNiKTtcbiAgcmV0dXJuIHRydWU7XG59O1xuXG5BY2tSZXNwb25zZS5wcm90b3R5cGUgPSBPYmplY3QuY3JlYXRlKEdlbmVyaWNSZXNwb25zZS5wcm90b3R5cGUpO1xuXG4vKipcbiAqIFNlcmlhbGl6ZWQgcmVzcG9uc2UgdGhhdCBhbHNvIGNhbiBiZSByZWNvZ25pemVkIGFzIGEgcmVzcG9uc2UuXG4gKlxuICogQHJldHVybnMge09iamVjdH0gdGhlIG9iamVjdCB0byBiZSBwdXQgdGhyb3VnaCB0aGUgQVBJLlxuICovXG5BY2tSZXNwb25zZS5wcm90b3R5cGUuZm9yU2VuZGluZyA9IGZ1bmN0aW9uICgpIHtcbiAgcmV0dXJuIHtyZXNwb25zZVR5cGU6IFwiQWNrUmVzcG9uc2VcIn07XG59O1xubW9kdWxlLmV4cG9ydHMgPSBBY2tSZXNwb25zZTtcbiIsInZhciBBcmd1bWVudHMgPSByZXF1aXJlKFwiLi8uLi9hcmd1bWVudHMuanNcIikuQXJndW1lbnRzLFxuICAgIEdlbmVyaWNSZXNwb25zZSA9IHJlcXVpcmUoJy4vZ2VuZXJpYy5qcycpLkdlbmVyaWNSZXNwb25zZTtcbnJlcXVpcmUoJy4vLi4vc2V0aW1tZWRpYXRlLmpzJyk7XG5cbi8qKlxuICogVGhlIHJlcXVlc3QgeWllbGRlZCBieSBhIHNpbmdsZSBjYWxsYmFjayB0aGF0IGlzIHRvIGJlIGNhbGxlZCBieVxuICogdGhlIGNsaWVudC5cbiAqXG4gKiBAcGFyYW0ge0FyZ3VtZW50c30gYXJncyBUaGUgY2FsbGJhY2sgYXJndW1lbnRzIG9yIGEgc2VyaWFsaXplZFxuICogb2JqZWN0IGdlbmVyYXRlZCBieSBhIHNlcnZlciBzaWRlIEFyZ3NSZXNwb25zZS4gU2luY2UgdGhlc2UgYXJlXG4gKiBjYWxsYmFjayBhcmd1bWVudHMgdGhleSBzaG91bGQgY29udGFpbiBubyBjYWxsYmFja1xuICogdGhlbXNlbHZlcy5cbiAqL1xuZnVuY3Rpb24gQXJnc1Jlc3BvbnNlIChhcmdzKSB7XG4gIHRoaXMuY2JBcmdzID0gYXJncztcbn1cblxuQXJnc1Jlc3BvbnNlLmFzeW5jID0gZnVuY3Rpb24gKG1yLCBob3N0QXBpKSB7XG4gIHZhciByZXNwID0gbmV3IEFyZ3NSZXNwb25zZSgpO1xuICByZXNwLm1yID0gbXI7XG4gIHJlc3AuaG9zdEFwaSA9IGhvc3RBcGk7XG4gIHJldHVybiByZXNwO1xufTtcblxuLyoqXG4gKiBIYW5kbGUgdGhlIHJlc3BvbnNlIG9uIHRoZSBjbGllbnQgc2lkZSBpZiBpdCBpcyBvZiB0aGUgY29ycmVjdFxuICogdHlwZS5cbiAqXG4gKiBAcGFyYW0ge01lc3NhZ2V9IG1zZyB0aGUgcmF3IG1lc3NhZ2UgcmVjZWl2ZWQgYnkgdGhlIHNlcnZlclxuICogQHBhcmFtIHtSZXF1ZXN0fSByZXF1ZXN0IHRoZSByZXF1ZXN0IG9iamVjdCB0aGF0IG1zZyBpcyBhIHJlc3BvbnNlXG4gKiB0by5cbiAqIEBwYXJhbSB7RnVuY3Rpb259IGRvbmVDYiBDYWxsIHRoaXMgd2hlbiB5b3UgYXJlIGRvbmUuIEl0IHdpbGwgYmVcbiAqIGNhbGxlZCB3aXRoIG5vIGFyZ3VtZW50cyBvbiBzdWNjZXMgb3IgYW4gZXJyb3Igb2JqZWN0IG9uIGVycm9yLlxuICogQHJldHVybiB7Qm9vbGVhbn0gdHJ1ZSBpZiB3ZSBoYW5kbGVkIGl0LlxuICovXG5BcmdzUmVzcG9uc2UubWF5YmVIYW5kbGUgPSBmdW5jdGlvbiAobXNnLCByZXF1ZXN0LCBkb25lQ2IpIHtcbiAgaWYgKG1zZy5yZXNwb25zZVR5cGUgIT0gXCJBcmdzUmVzcG9uc2VcIikgcmV0dXJuIGZhbHNlO1xuICBpZiAoIXJlcXVlc3QuZ2V0Q2FsbGJhY2soKSkge1xuICAgIGRvbmVDYihuZXcgRXJyb3IoXCJObyByZWFsIGNhbGxiYWNrIHByb3ZpZGVkIG9uIHRoZSBjbGllbnQuXCIpKTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICB2YXIgY2JBcmdzID0gbmV3IEFyZ3VtZW50cyhtc2cuYXJncyksXG4gICAgICBjYWxsQXJncyA9IGNiQXJncy5mb3JDYWxsaW5nKCksXG4gICAgICBjYWxsYmFjayA9IHJlcXVlc3QuZ2V0Q2FsbGJhY2soKTtcblxuICAvLyBsb2cubG9nKFwiUmVjZWl2ZWQ6XCIsIGNiQXJncy5mb3JTZW5kaW5nKCksIFwiZm9yXCIsIHtmbjogU3RyaW5nKGNhbGxiYWNrKX0pO1xuICBjYWxsYmFjay5hcHBseShudWxsLCBjYWxsQXJncyk7XG4gIGRvbmVDYiAmJiBzZXRJbW1lZGlhdGUoZG9uZUNiKTtcbiAgcmV0dXJuIHRydWU7XG59O1xuXG5BcmdzUmVzcG9uc2UucHJvdG90eXBlID0gT2JqZWN0LmNyZWF0ZShHZW5lcmljUmVzcG9uc2UucHJvdG90eXBlKTtcblxuLyoqXG4gKiBUaGUgY2FsbGJhY2sgYXJndW1lbnRzIHNlcmlhbGl6ZWQuXG4gKlxuICogQHJldHVybnMge09iamVjdH0gdGhlIG9iamVjdCB0byBiZSBwdXQgdGhyb3VnaCB0aGUgQVBJLlxuICovXG5BcmdzUmVzcG9uc2UucHJvdG90eXBlLmZvclNlbmRpbmcgPSBmdW5jdGlvbiAoKSB7XG4gIHJldHVybiB7cmVzcG9uc2VUeXBlOiBcIkFyZ3NSZXNwb25zZVwiLFxuICAgICAgICAgIGFyZ3M6IHRoaXMuY2JBcmdzLmZvclNlbmRpbmcoKX07XG59O1xuXG5BcmdzUmVzcG9uc2UucHJvdG90eXBlLnNlbmQgPSBmdW5jdGlvbiAoc2VuZENiKSB7XG4gIGlmICh0aGlzLm1yKSB7XG4gICAgLy8gTk9URTogQXJnc1JlcHNvbnNlIGZvciBjb25uZWN0aW9uIGNsZWFudXBzIGFyZSBsYXp5LiBUaGVcbiAgICAvLyBjYWxsYmFjayBvZiB0aGUgYXBpIGNhbGwgZG9lcyB0aGUgYWN0dWFsIHdvcmsgb2Ygc2VuZGluZyB0aGVcbiAgICAvLyByZXNwaW5zZS5cbiAgICB0aGlzLm1yLmNhbGwoc2VuZENiLCB0aGlzLmhvc3RBcGkpO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIHNlbmRDYih0aGlzLmZvclNlbmRpbmcoKSk7XG59O1xubW9kdWxlLmV4cG9ydHMgPSBBcmdzUmVzcG9uc2U7XG4iLCJ2YXIgQXJndW1lbnRzID0gcmVxdWlyZShcIi4vLi4vYXJndW1lbnRzLmpzXCIpLkFyZ3VtZW50cyxcbiAgICBEYXRhQXJndW1lbnQgPSByZXF1aXJlKFwiLi8uLi9hcmd1bWVudHMuanNcIikuRGF0YUFyZ3VtZW50LFxuICAgIGxvZyA9IG5ldyAocmVxdWlyZSgnLi8uLi9sb2cuanMnKS5Mb2cpKCdidXJzdHJlc3BvbnNlJyksXG4gICAgR2VuZXJpY1Jlc3BvbnNlID0gcmVxdWlyZSgnLi9nZW5lcmljLmpzJykuR2VuZXJpY1Jlc3BvbnNlLFxuICAgIEFyZ3NSZXNwb25zZSA9IHJlcXVpcmUoJy4vYXJndW1lbnRzLmpzJyksXG4gICAgZ2VuZXJpY1Jlc3BIYW5kbGVyID0gcmVxdWlyZSgnLi9nZW5lcmljLmpzJykuZ2VuZXJpY1Jlc3BIYW5kbGVyO1xucmVxdWlyZSgnLi8uLi9zZXRpbW1lZGlhdGUuanMnKTtcblxuLyoqXG4gKiBTZXJ2aW5nIGEgYnVyc3QgcmVzcG9uc2UuXG4gKlxuICogQHBhcmFtIHtBcnJheShBcmd1bWVudHMpfSBjYkFyZ3NBcnIgYW4gYXJyYXkgdGhlIGFyZ3VtZW50cyBvZiBjYWxsc1xuICogdG8gYSBjYWxsYmFjay4gV2UgdHJ1c3QgdGhlc2UgY29udGFpbiBubyBjYWxsYmFja3Mgc2luY2UgdGhleSBhcmVcbiAqIHJlc3BvbnNlcyB0byB0aGUgY2xpZW50LlxuICogQHBhcmFtIHtNZXNzYWdlfSByZXFNZXNzYWdlIFRoZSBtZXNzYWdlIGdlbmVyYXRlZCBieSBCdXJzdFJlcXVlc3QuXG4gKi9cbmZ1bmN0aW9uIEJ1cnN0UmVzcG9uc2UgKGNiQXJnc0FyciwgcmVxTWVzc2FnZSkge1xuICB0aGlzLmNiQXJnc0FyciA9IGNiQXJnc0FycjtcbiAgdGhpcy5jYWxsYmFja0lkID0gcmVxTWVzc2FnZS5jYWxsYmFja0lkO1xufTtcblxuLyoqXG4gKiBIYW5kbGUgdGhlIHJlc3BvbnNlIG9uIHRoZSBjbGllbnQgc2lkZSBpZiBpdCBpcyBvZiB0aGUgY29ycmVjdFxuICogdHlwZS5cbiAqXG4gKiBAcGFyYW0ge01lc3NhZ2V9IG1zZyB0aGUgcmF3IG1lc3NhZ2UgcmVjZWl2ZWQgYnkgdGhlIHNlcnZlclxuICogQHBhcmFtIHtCdXJzdFJlcXVlc3R9IHJlcXVlc3QgdGhlIHJlcXVlc3Qgb2JqZWN0IHRoYXQgbXNnIGlzIGEgcmVzcG9uc2VcbiAqIHRvLlxuICogQHBhcmFtIHtGdW5jdGlvbn0gZG9uZUNiIENhbGwgdGhpcyB3aGVuIHlvdSBhcmUgZG9uZS4gSXQgd2lsbCBiZVxuICogY2FsbGVkIHdpdGggbm8gYXJndW1lbnRzIG9uIHN1Y2NlcyBvciBhbiBlcnJvciBvYmplY3Qgb24gZXJyb3IuXG4gKiBAcmV0dXJuIHtCb29sZWFufSB0cnVlIGlmIHdlIGhhbmRsZWQgaXQuXG4gKi9cbnZhciBzZXJ2ZWRCdXJzdE1ldHJpY3MgPSBbXTtcbkJ1cnN0UmVzcG9uc2UubWF5YmVIYW5kbGUgPSBmdW5jdGlvbiAobXNnLCByZXF1ZXN0LCBkb25lQ2IpIHtcbiAgaWYgKG1zZy5yZXNwb25zZVR5cGUgIT0gXCJCdXJzdFJlc3BvbnNlXCIpIHJldHVybiBmYWxzZTtcbiAgLy8gVGhyb3cgZWFjaCByZXNwb25zZSBpbiB0aGUgcXVldWUgd2hlbiB0aGUgcHJldmlvdXMgb25lIGlzXG4gIC8vIGZpbmlzaGVkLiBCZWZvcmUgc2VydmluZyBjaGVjayBpZiB0aGV5IGFyZSB6b21iaWZpZWQgYnkgdGhlXG4gIC8vIHJlcXVlc3QuXG4gIGZ1bmN0aW9uIGFyckluUXVldWUocmVzcG9uc2VzLCBlcnIpIHtcbiAgICBpZiAoZXJyKSB7XG4gICAgICBkb25lQ2IoZXJyKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAocmVzcG9uc2VzLmxlbmd0aCA9PSAwKSB7XG4gICAgICBkb25lQ2IoKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBzZXRJbW1lZGlhdGUoZnVuY3Rpb24gKCkge1xuICAgICAgdmFyIGNhciA9IHJlc3BvbnNlc1swXSwgY2RyID0gcmVzcG9uc2VzLnNsaWNlKDEpO1xuXG4gICAgICBpZiAoIXJlcXVlc3QuY2xvc2VkKSB7XG4gICAgICAgIGdlbmVyaWNSZXNwSGFuZGxlcihjYXIsIHJlcXVlc3QsIGFyckluUXVldWUuYmluZChudWxsLCBjZHIpKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgZG9uZUNiKCk7XG4gICAgICAvLyBBbGxvdyB0aGUgZ2VuZXJpYyBoYW5kbGVyIHRvIHRocm93IGF0IGxlYXN0IHNvbWUgc3R1ZmYgaW4gdGhlXG4gICAgICAvLyBxdWV1ZS5cbiAgICB9KTtcbiAgfVxuXG4gIC8vIEl0IGlzIGFzc3VtZWQgdGhhdCB0aGUgb3JkZXJpbmcgb2YgZGF0YSBmcm9tIGRpZmZlcmVudCBzb3VyY2VzXG4gIC8vIGFuZCB0aGUgc2l6ZSBvZiB0aGUgcGFja2V0cyBkb2VzIG5vdCBtYXR0ZXIuIENvbmNhdCB0b2dldGhlclxuICAvLyBwYWNrZXRzIHRoYXQgaGF2ZSBldmVyeXRoaW5nIGluIGNvbW1vbiBleGNlcHQgdGhlIGRhdGEgZmllbGQuXG4gIGZ1bmN0aW9uIG1heWJlQ29uY2F0RGF0YShtc2dzKSB7XG4gICAgdmFyIGRhdGFTb3VyY2VzID0ge30sXG4gICAgICAgIGNvbmNhdEFyZyA9IG1zZ3MuZm9yRWFjaChmdW5jdGlvbiAobSwgaSkge1xuICAgICAgICAgIC8vIEp1c3Qga2VlcCB0aGlzIG9uZSBhcyBpc1xuICAgICAgICAgIGlmICghKG0uYXJncyAmJiBEYXRhQXJndW1lbnQuY2FuV3JhcChtLmFyZ3NbMF0pICYmIG0uYXJncy5sZW5ndGggPT0gMSkpIHtcbiAgICAgICAgICAgIGRhdGFTb3VyY2VzW2ldID0gbTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICAvLyBNYXNrIHRoZSBkYXRhIHRvIG1ha2UgYSBzb3VyY2UtdW5pcXVlIHRva2VuLlxuICAgICAgICAgIHZhciBhcmcgPSBtLmFyZ3NbMF0sIGJhY2t1cCA9IGFyZy5kYXRhO1xuICAgICAgICAgIGFyZy5kYXRhID0gbnVsbDtcbiAgICAgICAgICB2YXIgdG9rZW4gPSBKU09OLnN0cmluZ2lmeShhcmcpO1xuICAgICAgICAgIGFyZy5kYXRhID0gYmFja3VwO1xuICAgICAgICAgIHZhciByZXQgPSBkYXRhU291cmNlc1t0b2tlbl07XG4gICAgICAgICAgaWYgKHJldCkge1xuICAgICAgICAgICAgZGF0YVNvdXJjZXNbdG9rZW5dID0gcmV0LmNvbmNhdChhcmcpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGRhdGFTb3VyY2VzW3Rva2VuXSA9IG5ldyBEYXRhQXJndW1lbnQoYXJnKTtcbiAgICAgICAgfSk7XG5cbiAgICByZXR1cm4gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXMoZGF0YVNvdXJjZXMpLm1hcChmdW5jdGlvbiAoaykge1xuICAgICAgdmFyIGNvbmNhdEFyZyA9IGRhdGFTb3VyY2VzW2tdO1xuICAgICAgaWYgKGNvbmNhdEFyZyBpbnN0YW5jZW9mIERhdGFBcmd1bWVudCkge1xuICAgICAgICByZXR1cm4gbmV3IEFyZ3NSZXNwb25zZShcbiAgICAgICAgICBuZXcgQXJndW1lbnRzKFtjb25jYXRBcmcuZm9yU2VuZGluZygpXSkpLmZvclNlbmRpbmcoKTtcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIGNvbmNhdEFyZztcbiAgICB9KTtcbiAgfVxuXG4gIC8vIFNvbWUgZGVidWdnaW5nIGluZm9ybWF0aW9uXG4gIGlmICgwKSB7XG4gICAgc2VydmVkQnVyc3RNZXRyaWNzLnB1c2goe3RpbWU6IERhdGUubm93KCksIGxlbmd0aDogbXNnLmNiQXJnc0Fyci5sZW5ndGh9KTtcbiAgICB2YXIgdG90YWxSZXF1ZXN0cyA9IHNlcnZlZEJ1cnN0TWV0cmljcy5yZWR1Y2UoZnVuY3Rpb24gKHN1bSwgbSkge1xuICAgICAgcmV0dXJuIHN1bSArIG0ubGVuZ3RoO1xuICAgIH0sIDApO1xuICAgIGxvZy5sb2coXCJCdXJzdCBzdW1tYXJ5OlwiLCB7XG4gICAgICByZXF1ZXN0UGVyU2VjOiB0b3RhbFJlcXVlc3RzICogMTAwMCAvXG4gICAgICAgIChEYXRlLm5vdygpIC0gc2VydmVkQnVyc3RNZXRyaWNzWzBdLnRpbWUpLFxuICAgICAgdG90YWxSZXF1ZXN0czogdG90YWxSZXF1ZXN0cyxcbiAgICAgIGN1cnJlbnRSZXF1ZXN0czogbXNnLmNiQXJnc0Fyci5sZW5ndGhcbiAgICB9KTtcbiAgfVxuICBhcnJJblF1ZXVlKG1heWJlQ29uY2F0RGF0YShtc2cuY2JBcmdzQXJyKSk7XG5cbiAgcmV0dXJuIHRydWU7XG59O1xuQnVyc3RSZXNwb25zZS5wcm90b3R5cGUgPSBPYmplY3QuY3JlYXRlKEdlbmVyaWNSZXNwb25zZS5wcm90b3R5cGUpO1xuXG4vKipcbiAqIFNlcmlhbGl6ZWQgcmVzcG9uc2UgdGhhdCBhbHNvIGNhbiBiZSByZWNvZ25pemVkIGFzIGEgcmVzcG9uc2UuXG4gKlxuICogQHJldHVybnMge09iamVjdH0gdGhlIG9iamVjdCB0byBiZSBwdXQgdGhyb3VnaCB0aGUgQVBJLlxuICovXG5CdXJzdFJlc3BvbnNlLnByb3RvdHlwZS5mb3JTZW5kaW5nID0gZnVuY3Rpb24gKCkge1xuICByZXR1cm4ge3Jlc3BvbnNlVHlwZTogXCJCdXJzdFJlc3BvbnNlXCIsXG4gICAgICAgICAgY2JBcmdzQXJyOiB0aGlzLmNiQXJnc0FycixcbiAgICAgICAgICBjYWxsYmFja0lkOiB0aGlzLmNhbGxiYWNrSWR9O1xufTtcbm1vZHVsZS5leHBvcnRzID0gQnVyc3RSZXNwb25zZTtcbiIsInZhciBHZW5lcmljUmVzcG9uc2UgPSByZXF1aXJlKCcuL2dlbmVyaWMuanMnKS5HZW5lcmljUmVzcG9uc2U7XG5cbi8qKlxuICogQW4gZXJyb3Igb2NjdXJlZCBzZXJ2aW5nIHRoZSByZXF1ZXN0LlxuICpcbiAqIEBwYXJhbSB7U3RyaW5nfSBlcnJvciBUaGUgZXJyb3IgbWVzc2FnZS5cbiAqIEBwYXJhbSB7Qm9vbGVhbn0gaXNVbmNhdWdodCBUcnVlIGlmIHdlIHdhbnQgdG8gcmFpc2UgYW4gdW5jYXVnaHRcbiAqIGVycm9yIHdoZW4gdGhpcyBoYXBwZW5zIGFuZCBmYWxzZSBpZiBpdCBzaG91bGQgYmUgcGFzc2VkIHRvXG4gKiBjaHJvbWUucnVudGltZS5sYXN0RXJyb3JcbiAqL1xuZnVuY3Rpb24gRXJyUmVzcG9uc2UgKGVycm9yLCB0eXBlKSB7XG4gIHRoaXMuZXJyb3IgPSBlcnJvcjtcbiAgdGhpcy50eXBlID0gdHlwZTtcbn07XG5cbi8qKlxuICogSGFuZGxlIHRoZSByZXNwb25zZSBvbiB0aGUgY2xpZW50IHNpZGUgaWYgaXQgaXMgb2YgdGhlIGNvcnJlY3RcbiAqIHR5cGUuIFRoaXMgd2lsbCBhbHNvIGhhbmRsZSBtZXNzYWdlcyB0aGF0IGFyZSB1bmRlZmluZWQgbWVzc2FnZXMuXG4gKlxuICogQHBhcmFtIHtNZXNzYWdlfHVuZGVmaW5lZH0gbXNnIHRoZSByYXcgbWVzc2FnZSByZWNlaXZlZCBieSB0aGUgc2VydmVyXG4gKiBAcGFyYW0ge1JlcXVlc3R9IHJlcXVlc3QgdGhlIHJlcXVlc3Qgb2JqZWN0IHRoYXQgbXNnIGlzIGEgcmVzcG9uc2VcbiAqIHRvLlxuICogQHBhcmFtIHtGdW5jdGlvbn0gZG9uZUNiIENhbGwgdGhpcyB3aGVuIHlvdSBhcmUgZG9uZS4gSXQgd2lsbCBiZVxuICogY2FsbGVkIHdpdGggbm8gYXJndW1lbnRzIG9uIHN1Y2NlcyBvciBhbiBlcnJvciBvYmplY3Qgb24gZXJyb3IuXG4gKiBAcmV0dXJuIHtCb29sZWFufSB0cnVlIGlmIHdlIGhhbmRsZWQgaXQuXG4gKi9cbkVyclJlc3BvbnNlLm1heWJlSGFuZGxlID0gZnVuY3Rpb24gKG1zZywgcmVxdWVzdCwgZG9uZUNiKSB7XG4gIGlmIChtc2cgJiYgbXNnLnJlc3BvbnNlVHlwZSAhPSBcIkVyclJlc3BvbnNlXCIpIHJldHVybiBmYWxzZTtcblxuICB2YXIgcmF3RXJyb3IgPSBtc2cgPyBtc2cuZXJyIDogXCJVbmRlZmluZWQgbWVzc2FnZSwgcHJvYmFibHkgaG9zdCBpcyBkaXNjb25uZWN0ZWQuXCI7XG4gIGlmIChyZXF1ZXN0LnRyYWNlKSB7XG4gICAgY29uc29sZS53YXJuKFwiUmVjZWl2ZWQgZXJyb3I6XCIsIG1zZy5lcnIpO1xuICAgIGNvbnNvbGUud2FybihyZXF1ZXN0LnRyYWNlKTtcbiAgfTtcblxuICB2YXIgd2l0aEVycm9yID0gZnVuY3Rpb24gKGVyciwgY2IpIHtcbiAgICBjYigpO1xuXG4gICAgaWYgKGVycil7XG4gICAgICBjb25zb2xlLmVycm9yKFwiVW5jYXVnaHQ6XCIsIGVycik7XG4gICAgfVxuICB9O1xuXG4gIGlmIChyZXF1ZXN0LmdldENhbGxiYWNrKCkpIHtcbiAgICAocmVxdWVzdC53aXRoRXJyb3IgfHwgd2l0aEVycm9yKShyYXdFcnJvciwgcmVxdWVzdC5nZXRDYWxsYmFjaygpKTtcbiAgICBkb25lQ2IoKTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuXG4gIGRvbmVDYihyYXdFcnJvcik7XG4gIHJldHVybiB0cnVlO1xufTtcblxuRXJyUmVzcG9uc2UucHJvdG90eXBlID0gbmV3IEdlbmVyaWNSZXNwb25zZSgpO1xuXG4vKipcbiAqIFNlcmlhbGl6ZWQgcmVzcG9uc2UgdGhhdCBhbHNvIGNhbiBiZSByZWNvZ25pemVkIGFzIGEgcmVzcG9uc2UuXG4gKlxuICogQHJldHVybnMge09iamVjdH0gdGhlIG9iamVjdCB0byBiZSBwdXQgdGhyb3VnaCB0aGUgQVBJLlxuICovXG5FcnJSZXNwb25zZS5wcm90b3R5cGUuZm9yU2VuZGluZyA9IGZ1bmN0aW9uICgpIHtcbiAgcmV0dXJuIHtyZXNwb25zZVR5cGU6IFwiRXJyUmVzcG9uc2VcIixcbiAgICAgICAgICBlcnI6IHRoaXMuZXJyb3IsXG4gICAgICAgICAgdHlwZTogdGhpcy50eXBlXG4gICAgICAgICB9O1xufTtcbm1vZHVsZS5leHBvcnRzID0gRXJyUmVzcG9uc2U7XG4iLCIvKipcbiAqIEBmaWxlT3ZlcnZpZXcgVGhlIGludGVyZmFjZSB0aGF0IGFsbCByZXNwb25zZSB0eXBlcyBuZWVkIHRvIGJlXG4gKiBpbXBsZW1lbnRpbmdcbiAqIEBuYW1lIGdlbmVyaWMuanNcbiAqIEBhdXRob3IgQ2hyaXMgUGVyaXZvbGFyb3BvdWxvc1xuICovXG5cbmZ1bmN0aW9uIEdlbmVyaWNSZXNwb25zZSAoKSB7fVxuR2VuZXJpY1Jlc3BvbnNlLnByb3RvdHlwZSA9IHtcbiAgc2VuZDogZnVuY3Rpb24gKHNlbmRDYikge1xuICAgIHJldHVybiBzZW5kQ2IodGhpcy5mb3JTZW5kaW5nKCkpO1xuICB9LFxuXG4gIGZvclNlbmRpbmc6IGZ1bmN0aW9uICgpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJOb3QgaW1wbGVtZW50ZWRcIik7XG4gIH1cbn07XG5cblxuXG4vKipcbiAqIEl0ZXJhdGUgb3ZlciB0aGUgcmVzcG9uc2UgaGFuZGxlcnMgYW5kIGNvb3NlIHRoZSBjb3JyZWN0IG9uZSB0b1xuICogaGFuZGxlIGFuIGluY29taW5nIG1lc3NhZ2Ugb24gdGhlIGNsaWVudHMuXG4gKlxuICogQHBhcmFtIHtNZXNzYWdlfSBtc2cgdGhlIHJhdyBtZXNzYWdlIHJlY2VpdmVkIGJ5IHRoZSBzZXJ2ZXJcbiAqIEBwYXJhbSB7UmVxdWVzdH0gcmVxdWVzdCB0aGUgcmVxdWVzdCBvYmplY3QgdGhhdCBtc2cgaXMgYSByZXNwb25zZVxuICogdG8uXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBkb25lIENhbGwgdGhpcyB3aGVuIHlvdSBhcmUgZG9uZS4gSXQgd2lsbCBiZVxuICogY2FsbGVkIHdpdGggbm8gYXJndW1lbnRzIG9uIHN1Y2NlcyBvciBhbiBlcnJvciBvYmplY3Qgb24gZXJyb3IuXG4gKi9cblxuZnVuY3Rpb24gZ2VuZXJpY1Jlc3BIYW5kbGVyIChtc2csIHJlcXVlc3QsIGRvbmUpIHtcbiAgLy8gQmUgc3VyZSB0byB0aHJvdyBkb25lIGluIHRoZSBxdWV1ZS5cbiAgZnVuY3Rpb24gZG9uZUNiIChlcnIpIHtcbiAgICBkb25lKGVycik7XG4gIH1cblxuICB2YXIgcmVzcG9uc2VUeXBlc0FyciA9IFtcbiAgICByZXF1aXJlKCcuL2Vycm9yLmpzJyksICAgICAgICAgICAgICAgICAgLy9DYXRjaCB0aGUgZXJyb3JzIGZpcnN0XG4gICAgcmVxdWlyZSgnLi9idXJzdC5qcycpLFxuICAgIHJlcXVpcmUoJy4vYXJndW1lbnRzLmpzJyksXG4gICAgcmVxdWlyZSgnLi9hY2suanMnKSxcbiAgXTtcblxuICBpZiAoIXJlc3BvbnNlVHlwZXNBcnIuc29tZShmdW5jdGlvbiAoUlQpIHtcbiAgICByZXR1cm4gUlQubWF5YmVIYW5kbGUobXNnLCByZXF1ZXN0LCBkb25lQ2IpO1xuICB9KSkge1xuICAgIGRvbmUobmV3IEVycm9yKFwiQ291bGRuJ3QgaGFuZGxlIG1lc3NhZ2U6IFwiICsgSlNPTi5zdHJpbmdpZnkobXNnKSkpO1xuICB9XG59XG5tb2R1bGUuZXhwb3J0cy5HZW5lcmljUmVzcG9uc2UgPSBHZW5lcmljUmVzcG9uc2U7XG5tb2R1bGUuZXhwb3J0cy5nZW5lcmljUmVzcEhhbmRsZXIgPSBnZW5lcmljUmVzcEhhbmRsZXI7XG4iLCIvKipcbiAqIEBmaWxlT3ZlcnZpZXcgSW5pdGlhbGl6ZSBhbmQgaGFuZGxlIHJlcXVlc3RzIGFuZCBjb25uZWN0aW9ucy5cbiAqIEBuYW1lIHNlcnZlci5qc1xuICogQGF1dGhvciBDaHJpcyBQZXJpdm9sYXJvcG91bG9zXG4gKi9cbnZhciBIb3N0Q29ubmVjdGlvbiA9IHJlcXVpcmUoXCIuL2hvc3Rjb25uZWN0aW9uLmpzXCIpLkhvc3RDb25uZWN0aW9uLFxuICAgIE1ldGhvZFJlcXVlc3QgPSByZXF1aXJlKFwiLi9yZXF1ZXN0cy5qc1wiKS5NZXRob2RSZXF1ZXN0LFxuICAgIEJ1cnN0UmVxdWVzdCA9IHJlcXVpcmUoXCIuL3JlcXVlc3RzLmpzXCIpLkJ1cnN0UmVxdWVzdCxcbiAgICBFcnJSZXNwb25zZSA9IHJlcXVpcmUoXCIuL3Jlc3BvbnNlcy5qc1wiKS5FcnJSZXNwb25zZSxcbiAgICBBY2tSZXNwb25zZSA9IHJlcXVpcmUoXCIuL3Jlc3BvbnNlcy5qc1wiKS5BY2tSZXNwb25zZSxcbiAgICBsb2cgPSBuZXcgKHJlcXVpcmUoJy4vbG9nLmpzJykuTG9nKSgnc2VydmVyJyksXG4gICAgbWVzc2FnZUFwaSA9IHJlcXVpcmUoJy4vbWVzc2FnaW5nLmpzJyksXG4gICAgQm9vdHN0cmFwSG9zdCA9IHJlcXVpcmUoJy4vYm9vdHN0cmFwaG9zdC5qcycpLkJvb3RzdHJhcEhvc3Q7XG5yZXF1aXJlKCcuL3NldGltbWVkaWF0ZS5qcycpO1xuXG52YXIgc3RhdGUgPSB7Y29ubmVjdGlvbnM6IFtdLFxuICAgICAgICAgICAgIGtlZXBhbGl2ZXM6IFtdLFxuICAgICAgICAgICAgIHVuaXF1ZUlkOiAwLFxuICAgICAgICAgICAgIHZlcnNpb246IG1lc3NhZ2VBcGkudmVyc2lvbn07XG5cbi8qKlxuICogQSBwb3J0IHRvIGtlZXAgdHJhY2sgb2YgYSBjbGllbnQuIEl0IGFsc28gc2V0cyB0aGUgaWQgb2YgdGhlIGNsaWVudDtcbiAqIEBwYXJhbSB7UG9ydH0gcG9ydFxuICogQHBhcmFtIHtGdW5jdGlvbn0gZGllQ2IgQ2FsbGVkIHdoZW4gdGhlIGNsaWVudCBkaWVzLlxuICovXG5mdW5jdGlvbiBIb3N0S2VlcEFsaXZlQ29ubmVjdGlvbiAocG9ydCwgY2xvc2VDYikge1xuICBsb2cubG9nKFwiQ3JlYXRpbmcgaG9zdCBrZWVwYWxpdmVcIik7XG4gIHZhciBzZWxmID0gdGhpcztcbiAgdGhpcy5wb3J0ID0gcG9ydDtcbiAgcG9ydC5vbkRpc2Nvbm5lY3QuYWRkTGlzdGVuZXIodGhpcy5jbG9zZS5iaW5kKHRoaXMpKTtcbiAgdGhpcy5jbG9zZUNiID0gY2xvc2VDYi5iaW5kKG51bGwsIHRoaXMpO1xuICB0aGlzLmNsaWVudElkID0gc3RhdGUudW5pcXVlSWQrKztcbiAgdGhpcy5wb3J0Q29uZiA9IEpTT04ucGFyc2UocG9ydC5uYW1lKTtcblxuICAvLyBTZXQgdGhlIGNsaWVudElkXG4gIHBvcnQub25EaXNjb25uZWN0LmFkZExpc3RlbmVyKGZ1bmN0aW9uICgpIHtcbiAgICBsb2cubG9nKFwiQ2xpZW50IGRpc2Nvbm5lY3RlZDpcIiArIHNlbGYuY2xpZW50SWQpO1xuICB9KTtcbiAgcG9ydC5wb3N0TWVzc2FnZSh7XG4gICAgY2xpZW50SWQ6IHNlbGYuY2xpZW50SWQsXG4gICAgdmVyc2lvbjogc3RhdGUudmVyc2lvbn0pO1xuICBsb2cubG9nKFwiQ2xpZW50IGNvbm5lY3RlZDpcIiArIHNlbGYuY2xpZW50SWQpO1xuICB0aGlzLmNsb3NlZCA9IGZhbHNlO1xufVxuXG5Ib3N0S2VlcEFsaXZlQ29ubmVjdGlvbi5pcyA9IGZ1bmN0aW9uIChwb3J0KSB7XG4gIHJldHVybiBKU09OLnBhcnNlKHBvcnQubmFtZSkudHlwZSA9PSBcIktlZXBBbGl2ZUNvbm5lY3Rpb25cIjtcbn07XG5cbkhvc3RLZWVwQWxpdmVDb25uZWN0aW9uLnByb3RvdHlwZSA9IHtcbiAgbWF5YmVDbG9zZTogZnVuY3Rpb24gKGMpIHtcblxuICAgIGlmIChjLmNsaWVudElkID09IHRoaXMuY2xpZW50SWQpIHtcbiAgICAgIGMuY2xvc2UoKTtcbiAgICB9XG4gIH0sXG5cbiAgY2xvc2U6IGZ1bmN0aW9uICgpIHtcbiAgICBpZiAodGhpcy5jbG9zZWQpIHJldHVybjtcbiAgICAvLyBDbGVhbmluZyB1cCBtYXkgcmVxdWlyZSB0aGUgcG9ydC5cbiAgICB0aGlzLmNsb3NlZCA9IHRydWU7XG4gICAgdGhpcy5jbG9zZUNiKCk7XG4gICAgdGhpcy5wb3J0LmRpc2Nvbm5lY3QoKTtcbiAgICB0aGlzLnBvcnQgPSBudWxsO1xuICB9XG59O1xuXG4vKipcbiAqIEdldCBhIGtlZXAgYWxpdmUgY29ubmVjdGlvbiB0b2tlbiBmb3IgdGhlIGNsaWVudC4gVGhlIG9iamVjdCBpc1xuICoge3BvcnQsIGNsaWVudElkfS5cbiAqXG4gKiBAcGFyYW0ge1N0cmluZ30gaG9zdElkIFRoZSBpZGUgb2YgdGhlIGhvc3QgdG8gY29ubmVjdCB0by5cbiAqIEBwYXJhbSB7RnVuY3Rpb259IGNvbm5lY3RDYiBUaGUgY2FsbGJhY2sgdG8gYmUgY2FsbGVkIHdoZW4gdGhlXG4gKiBjb25uZWN0aW9uIGlzIHN1Y2Nlc3NmdWwuXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBkaWNvbm5lY3RDYiBXaWxsIGJlIGNhbGxlZCB3aGVuIHRoZSBob3N0XG4gKiBkaXNjb25lbmN0cy4gV2lsbCBiZSBjYWxsZWQgaW1tZWRpYXRlbHkgaWYgdGhlIGNvbm5lY3Rpb24gZmFpbHMuXG4gKi9cbmZ1bmN0aW9uIGdldEtlZXBBbGl2ZUNvbm5lY3Rpb24gKGhvc3RJZCwgY29ubmVjdENiLCBkaXNjb25uZWN0Q2IsIHRpbWVvdXQpIHtcbiAgbWVzc2FnZUFwaSA9IHJlcXVpcmUoXCIuL21lc3NhZ2luZy5qc1wiKTtcblxuICB2YXIgcG9ydE5hbWUgPSBKU09OLnN0cmluZ2lmeSh7dHlwZTpcIktlZXBBbGl2ZUNvbm5lY3Rpb25cIn0pLFxuICAgICAgcG9ydCA9IG1lc3NhZ2VBcGkuY29ubmVjdChob3N0SWQsIHtuYW1lOiBwb3J0TmFtZX0pO1xuICBpZiAoZGlzY29ubmVjdENiKSB7XG4gICAgbG9nLmxvZyhcIkRldGVjdGVkIGRpc2Nvbm5lY3QgY2Igb24gY2xpZW50IGtlZXBhbGl2ZVwiKTtcbiAgICBwb3J0Lm9uRGlzY29ubmVjdC5hZGRMaXN0ZW5lcihmdW5jdGlvbiAoKSB7ZGlzY29ubmVjdENiKCk7fSk7XG4gIH1cblxuICB2YXIgZ290VG9rZW4gPSBmYWxzZTtcbiAgcG9ydC5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIoZnVuY3Rpb24gdG9rZW5pemVyIChtc2cpIHtcbiAgICBwb3J0Lm9uTWVzc2FnZS5yZW1vdmVMaXN0ZW5lcih0b2tlbml6ZXIpO1xuICAgIGdvdFRva2VuID0gdHJ1ZTtcblxuICAgIGlmICghbXNnKSB7XG4gICAgICBsb2cud2FybihcIkVtcHR5IG1lc3NhZ2UgY2FtZSBvbiBrZWVwYWxpdmUgcG9ydC5cIik7XG4gICAgICBkaXNjb25uZWN0Q2IoXCJub19ob3N0XCIpO1xuICAgICAgcG9ydC5kaXNjb25uZWN0KCk7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG5cbiAgICAvLyBPbmx5IG1hdGNoaW5nIG1ham9yIHZlcnNpb24gbnVtYmVycyBjYW4gY29tbXVuaWNhdGUuXG4gICAgaWYgKG1zZyAmJiBtc2cudmVyc2lvbiAmJlxuICAgICAgICBtc2cudmVyc2lvbi5zcGxpdCgnLicpWzBdICE9IG1lc3NhZ2VBcGkudmVyc2lvbi5zcGxpdCgnLicpWzBdKSB7XG4gICAgICBsb2cud2FybihcIlJlY2VpdmVkIGJhZCBhcHAgdmVyc2lvbjpcIiwgbXNnLnZlcnNpb24pO1xuICAgICAgZGlzY29ubmVjdENiKFwiYmFkX3ZlcnNpb25cIik7XG4gICAgICBwb3J0LmRpc2Nvbm5lY3QoKTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cblxuXG4gICAgaWYgKHR5cGVvZiBtc2cuY2xpZW50SWQgIT09ICdudW1iZXInKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgdmFyIHRva2VuID0ge1xuICAgICAgcG9ydDogcG9ydCxcbiAgICAgIHZlcnNpb246IG1zZy52ZXJzaW9uLFxuICAgICAgY2xpZW50SWQ6IG1zZy5jbGllbnRJZCxcbiAgICAgIGRpc2Nvbm5lY3RDYjogZGlzY29ubmVjdENiXG4gICAgfTtcbiAgICBzZXRJbW1lZGlhdGUoY29ubmVjdENiLmJpbmQobnVsbCwgdG9rZW4pKTtcbiAgfSk7XG5cbiAgaWYgKHR5cGVvZiB0aW1lb3V0ICE9PSAndW5kZWZpbmVkJykge1xuICAgIHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7XG4gICAgICBpZiAoZ290VG9rZW4pIHJldHVybjtcbiAgICAgIGxvZy53YXJuKFwiSG9zdCBrZWVwYWxpdmUgY29ubmVjdGlvbiB3YXMgc2lsZW50IGZvciB0b28gbG9uZy5cIik7XG4gICAgICBkaXNjb25uZWN0Q2IoXCJ0aW1lb3V0XCIpO1xuICAgICAgcG9ydC5kaXNjb25uZWN0KCk7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9LCB0aW1lb3V0KTtcbiAgfVxufVxuXG5cbi8qKlxuICogSGFuZGxlIChvciBkZWxlZ2F0ZSkgY29ubmVjdGlvbnMgYW5kIG1lc3NhZ2VzIGZyb20gYW55IGNsaWVudC4gQWxzb1xuICoga2VlcCB0cmFjayBvZiBvcGVuIGNvbm5lY3Rpb25zIGFuZCBjbGVhbiB0aGVtIHVwIGlmIHRoZSB1c2VyIGFza3NcbiAqIGZvciBpdC5cbiAqXG4gKiBAcGFyYW0ge09iamVjdH0gYXBpUm9vdCB0aGUgcm9vdCBvZiB0aGUgYXBpIHRvIHNlcnZlLlxuICovXG5mdW5jdGlvbiBIb3N0U2VydmVyIChhcGlSb290KSB7XG4gIGlmIChzdGF0ZS5hcGlSb290ID09PSBhcGlSb290KSB7XG4gICAgdGhyb3cgRXJyb3IoXCJZb3UgYXJlIHRyeWluZyB0byBob3N0IGEgc2Vjb25kIHNlcnZlciBvbiB0aGUgc2FtZSBhcGkuXCIpO1xuICB9XG5cbiAgdmFyIGFkaG9jID0gcmVxdWlyZShcIi4vYWRob2MvaG9zdC5qc1wiKTtcbiAgYXBpUm9vdC5tZXNzYWdlQXBpID0gbWVzc2FnZUFwaTtcbiAgYXBpUm9vdC5zZXJ2ZXJJZCA9IE1hdGgucmFuZG9tKCk7XG4gIHN0YXRlLmFwaVJvb3QgPSBhcGlSb290O1xuICBzdGF0ZS5ib290c3RyYXBIb3N0ID0gbmV3IEJvb3RzdHJhcEhvc3QoKTtcbiAgYWRob2Muc2V0dXBBZEhvYyhzdGF0ZSk7XG5cbiAgZnVuY3Rpb24gY2xvc2VDYiAoY29ubmVjdGlvbikge1xuICAgIHZhciBsZW4gPSBzdGF0ZS5jb25uZWN0aW9ucy5sZW5ndGg7XG4gICAgc3RhdGUuY29ubmVjdGlvbnMgPSBzdGF0ZS5jb25uZWN0aW9ucy5maWx0ZXIoZnVuY3Rpb24gKGMpIHtcbiAgICAgIHJldHVybiBjICE9PSBjb25uZWN0aW9uO1xuICAgIH0pO1xuICAgIGxvZy5sb2coXCJDbGVhbmluZWQ6XCIsIGNvbm5lY3Rpb24ucmVwcigpLCAnKGJlZm9yZTogJywgbGVuLCdhZnRlcjogJyxcbiAgICAgICAgICAgIHN0YXRlLmNvbm5lY3Rpb25zLmxlbmd0aCwgJyknKTtcbiAgfTtcblxuICBmdW5jdGlvbiB0YWJEaWVkQ2IgKGtlZXBhbGl2ZSkge1xuICAgIC8vIEtlZXAgb25seSBvbmUgcmVmZXJlbmNlIHRvIGVhY2ggY29ubmVjdGlvbiwgaWUgZG9uJ3QgcmVnaXN0ZXJcbiAgICAvLyB0aGVtIHRvIGtlZXBhbGl2ZXMgb3Igd2hhdGV2ZXIuXG4gICAgc3RhdGUuY29ubmVjdGlvbnMuZm9yRWFjaChmdW5jdGlvbiAoYykge1xuICAgICAga2VlcGFsaXZlLm1heWJlQ2xvc2UoYyk7XG4gICAgfSk7XG4gICAgc3RhdGUua2VlcGFsaXZlcyA9IHN0YXRlLmtlZXBhbGl2ZXMuZmlsdGVyKGZ1bmN0aW9uIChrYSkge1xuICAgICAgcmV0dXJuICFrYS5jbG9zZWQ7XG4gICAgfSk7XG4gIH1cblxuICBmdW5jdGlvbiBtZXNzYWdlSGFuZGxlIChtZXNzYWdlLCBzZW5kZXIsIHNlbmRSZXNwKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIE1ldGhvZFJlcXVlc3QubWF5YmVIYW5kbGUobWVzc2FnZSwgYXBpUm9vdCwgc2VuZFJlc3AsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjb25uZWN0aW9uczogc3RhdGUuY29ubmVjdGlvbnN9KSB8fFxuICAgICAgICBCdXJzdFJlcXVlc3QubWF5YmVIYW5kbGUobWVzc2FnZSwgc3RhdGUuY29ubmVjdGlvbnMsIHNlbmRSZXNwKSB8fFxuICAgICAgICAobmV3IEVyclJlc3BvbnNlKFwiTm90aGluZyB0byBkbyBmb3IgbWVzc2FnZS5cIiArXG4gICAgICAgICAgICAgICAgICAgICAgICAgSlNPTi5zdHJpbmdpZnkobWVzc2FnZSksIGZhbHNlKVxuICAgICAgICAgLnNlbmQoc2VuZFJlc3ApKSk7XG4gIH1cblxuICBmdW5jdGlvbiBjb25uZWN0SGFuZGxlIChwb3J0KSB7XG4gICAgaWYgKEhvc3RLZWVwQWxpdmVDb25uZWN0aW9uLmlzKHBvcnQpKSB7XG4gICAgICB2YXIga2VlcGFsaXZlID0gbmV3IEhvc3RLZWVwQWxpdmVDb25uZWN0aW9uKHBvcnQsIHRhYkRpZWRDYik7XG4gICAgICBzdGF0ZS5rZWVwYWxpdmVzLnB1c2goa2VlcGFsaXZlKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICB2YXIgY29ubiA9IG5ldyBIb3N0Q29ubmVjdGlvbihwb3J0LCBhcGlSb290LCBmdW5jdGlvbiAoKSB7XG4gICAgICBjbG9zZUNiKGNvbm4pO1xuICAgIH0pO1xuICAgIHN0YXRlLmNvbm5lY3Rpb25zLnB1c2goY29ubik7XG4gIH1cblxuICBtZXNzYWdlQXBpLm9uQ29ubmVjdEV4dGVybmFsLmFkZExpc3RlbmVyKGNvbm5lY3RIYW5kbGUpO1xuICBsb2cubG9nKFwiTGlzdGVuaW5nIG9uIGNvbm5lY3Rpb25zLi4uXCIpO1xuICBtZXNzYWdlQXBpLm9uTWVzc2FnZUV4dGVybmFsLmFkZExpc3RlbmVyKG1lc3NhZ2VIYW5kbGUpO1xuICBsb2cubG9nKFwiTGlzdGVuaW5nIG9uIG1lc3NhZ2VzLi4uXCIpO1xuXG4gIGZ1bmN0aW9uIGNsZWFuVXAgKCkge1xuICAgIGxvZy5sb2coXCJDbGVhbmluZyBjb25uZWN0XCIpO1xuICAgIG1lc3NhZ2VBcGkub25Db25uZWN0RXh0ZXJuYWwucmVtb3ZlTGlzdGVuZXIoY29ubmVjdEhhbmRsZSk7XG4gICAgbG9nLmxvZyhcIkNsZWFuaW5nIG1lc3NhZ2VcIik7XG4gICAgbWVzc2FnZUFwaS5vbk1lc3NhZ2VFeHRlcm5hbC5yZW1vdmVMaXN0ZW5lcihtZXNzYWdlSGFuZGxlKTtcblxuICAgIHN0YXRlLmNvbm5lY3Rpb25zLmZvckVhY2goZnVuY3Rpb24oYykge1xuICAgICAgYy5jbG9zZSgpO1xuICAgIH0pO1xuXG4gICAgc3RhdGUua2VlcGFsaXZlcy5mb3JFYWNoKGZ1bmN0aW9uKGspIHtcbiAgICAgIGsuY2xvc2UoKTtcbiAgICB9KTtcblxuICAgIHN0YXRlLmJvb3RzdHJhcEhvc3QuY2xlYW51cCgpO1xuICAgIHN0YXRlLmFwaVJvb3QgPSBudWxsO1xuICB9XG5cbiAgcmV0dXJuIGNsZWFuVXA7XG59XG5cbm1vZHVsZS5leHBvcnRzLnN0YXRlID0gc3RhdGU7XG5tb2R1bGUuZXhwb3J0cy5Ib3N0U2VydmVyID0gSG9zdFNlcnZlcjtcbm1vZHVsZS5leHBvcnRzLmdldEtlZXBBbGl2ZUNvbm5lY3Rpb24gPSBnZXRLZWVwQWxpdmVDb25uZWN0aW9uO1xubW9kdWxlLmV4cG9ydHMubWVzc2FnZUFwaSA9IG1lc3NhZ2VBcGk7XG4iLCIoZnVuY3Rpb24gKGdsb2JhbCl7XG4vLyBzZXRUaW1lb3V0IGlzIGNsYW1wZWQgdG8gMTAwMG1zIG1pbiB0aW1lIGZvciBiYWNrZ3JvdW5kIHRhYnMuXG5cbi8vIENoZWNrIHdldGhlciB3ZSBhcmUgaW4gdGhlIGFwcCBjb250ZXh0LlxuZnVuY3Rpb24gaXNBcHAgKCkge1xuICAvLyBnZXRNYW5pZmVzdCByZXN0dXJucyBhIHZhbHVlIGFuZCB0aHVzIGlzIG5vdCBhdmFpbGFibGUgdG8gdGhlXG4gIC8vIGNsaWVudFxuICByZXR1cm4gISFjaHJvbWUucnVudGltZS5nZXRNYW5pZmVzdDtcbn07XG5cbi8vIE5vdCBpbiBhIGJyb3dzZXIgbWFrZXMgaXQgb2sgdG8gdXNlIHNldFRpbWVvdXRcbmlmICghKGdsb2JhbC5wb3N0TWVzc2FnZSAmJiBnbG9iYWwuYWRkRXZlbnRMaXN0ZW5lcikgfHwgaXNBcHAoKSkge1xuICBnbG9iYWwuc2V0SW1tZWRpYXRlID0gZ2xvYmFsLnNldFRpbWVvdXQuYmluZChnbG9iYWwpO1xuICBnbG9iYWwuY2xlYXJUaW1lb3V0ID0gZ2xvYmFsLmNsZWFyVGltZW91dC5iaW5kKGdsb2JhbCk7XG59IGVsc2Uge1xuICAoZnVuY3Rpb24gKCkge1xuICAgIFwidXNlIHN0cmljdFwiO1xuICAgIHZhciBpID0gMDtcbiAgICB2YXIgdGltZW91dHMgPSB7fTtcbiAgICB2YXIgbWVzc2FnZU5hbWUgPSBcInNldEltbWVkaWF0ZVwiICsgbmV3IERhdGUoKS5nZXRUaW1lKCk7XG5cbiAgICBmdW5jdGlvbiBwb3N0KGZuKSB7XG4gICAgICBpZiAoaSA9PT0gMHgxMDAwMDAwMDApIC8vIG1heCBxdWV1ZSBzaXplXG4gICAgICAgIGkgPSAwO1xuICAgICAgaWYgKCsraSBpbiB0aW1lb3V0cylcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwic2V0SW1tZWRpYXRlIHF1ZXVlIG92ZXJmbG93LlwiKTtcbiAgICAgIHRpbWVvdXRzW2ldID0gZm47XG4gICAgICBnbG9iYWwucG9zdE1lc3NhZ2UoeyB0eXBlOiBtZXNzYWdlTmFtZSwgaWQ6IGkgfSwgXCIqXCIpO1xuICAgICAgcmV0dXJuIGk7XG4gICAgfVxuXG4gICAgZnVuY3Rpb24gcmVjZWl2ZShldikge1xuICAgICAgaWYgKGV2LnNvdXJjZSAhPT0gd2luZG93KVxuICAgICAgICByZXR1cm47XG4gICAgICB2YXIgZGF0YSA9IGV2LmRhdGE7XG4gICAgICBpZiAoZGF0YSAmJiBkYXRhIGluc3RhbmNlb2YgT2JqZWN0ICYmIGRhdGEudHlwZSA9PT0gbWVzc2FnZU5hbWUpIHtcbiAgICAgICAgZXYuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICAgIHZhciBpZCA9IGV2LmRhdGEuaWQ7XG4gICAgICAgIHZhciBmbiA9IHRpbWVvdXRzW2lkXTtcbiAgICAgICAgaWYgKGZuKSB7XG4gICAgICAgICAgZGVsZXRlIHRpbWVvdXRzW2lkXTtcbiAgICAgICAgICBmbigpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgZnVuY3Rpb24gY2xlYXIoaWQpIHtcbiAgICAgIGRlbGV0ZSB0aW1lb3V0c1tpZF07XG4gICAgfVxuXG4gICAgZ2xvYmFsLmFkZEV2ZW50TGlzdGVuZXIoXCJtZXNzYWdlXCIsIHJlY2VpdmUsIHRydWUpO1xuICAgIGdsb2JhbC5zZXRJbW1lZGlhdGUgPSBwb3N0O1xuICAgIGdsb2JhbC5jbGVhckltbWVkaWF0ZSA9IGNsZWFyO1xuICB9KSgpO1xufVxuXG59KS5jYWxsKHRoaXMsdHlwZW9mIGdsb2JhbCAhPT0gXCJ1bmRlZmluZWRcIiA/IGdsb2JhbCA6IHR5cGVvZiBzZWxmICE9PSBcInVuZGVmaW5lZFwiID8gc2VsZiA6IHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIgPyB3aW5kb3cgOiB7fSlcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWRhdGE6YXBwbGljYXRpb24vanNvbjtjaGFyc2V0OnV0Zi04O2Jhc2U2NCxleUoyWlhKemFXOXVJam96TENKemIzVnlZMlZ6SWpwYkluTmxkR2x0YldWa2FXRjBaUzVxY3lKZExDSnVZVzFsY3lJNlcxMHNJbTFoY0hCcGJtZHpJam9pTzBGQlFVRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRWlMQ0ptYVd4bElqb2laMlZ1WlhKaGRHVmtMbXB6SWl3aWMyOTFjbU5sVW05dmRDSTZJaUlzSW5OdmRYSmpaWE5EYjI1MFpXNTBJanBiSWk4dklITmxkRlJwYldWdmRYUWdhWE1nWTJ4aGJYQmxaQ0IwYnlBeE1EQXdiWE1nYldsdUlIUnBiV1VnWm05eUlHSmhZMnRuY205MWJtUWdkR0ZpY3k1Y2JseHVMeThnUTJobFkyc2dkMlYwYUdWeUlIZGxJR0Z5WlNCcGJpQjBhR1VnWVhCd0lHTnZiblJsZUhRdVhHNW1kVzVqZEdsdmJpQnBjMEZ3Y0NBb0tTQjdYRzRnSUM4dklHZGxkRTFoYm1sbVpYTjBJSEpsYzNSMWNtNXpJR0VnZG1Gc2RXVWdZVzVrSUhSb2RYTWdhWE1nYm05MElHRjJZV2xzWVdKc1pTQjBieUIwYUdWY2JpQWdMeThnWTJ4cFpXNTBYRzRnSUhKbGRIVnliaUFoSVdOb2NtOXRaUzV5ZFc1MGFXMWxMbWRsZEUxaGJtbG1aWE4wTzF4dWZUdGNibHh1THk4Z1RtOTBJR2x1SUdFZ1luSnZkM05sY2lCdFlXdGxjeUJwZENCdmF5QjBieUIxYzJVZ2MyVjBWR2x0Wlc5MWRGeHVhV1lnS0NFb1oyeHZZbUZzTG5CdmMzUk5aWE56WVdkbElDWW1JR2RzYjJKaGJDNWhaR1JGZG1WdWRFeHBjM1JsYm1WeUtTQjhmQ0JwYzBGd2NDZ3BLU0I3WEc0Z0lHZHNiMkpoYkM1elpYUkpiVzFsWkdsaGRHVWdQU0JuYkc5aVlXd3VjMlYwVkdsdFpXOTFkQzVpYVc1a0tHZHNiMkpoYkNrN1hHNGdJR2RzYjJKaGJDNWpiR1ZoY2xScGJXVnZkWFFnUFNCbmJHOWlZV3d1WTJ4bFlYSlVhVzFsYjNWMExtSnBibVFvWjJ4dlltRnNLVHRjYm4wZ1pXeHpaU0I3WEc0Z0lDaG1kVzVqZEdsdmJpQW9LU0I3WEc0Z0lDQWdYQ0oxYzJVZ2MzUnlhV04wWENJN1hHNGdJQ0FnZG1GeUlHa2dQU0F3TzF4dUlDQWdJSFpoY2lCMGFXMWxiM1YwY3lBOUlIdDlPMXh1SUNBZ0lIWmhjaUJ0WlhOellXZGxUbUZ0WlNBOUlGd2ljMlYwU1cxdFpXUnBZWFJsWENJZ0t5QnVaWGNnUkdGMFpTZ3BMbWRsZEZScGJXVW9LVHRjYmx4dUlDQWdJR1oxYm1OMGFXOXVJSEJ2YzNRb1ptNHBJSHRjYmlBZ0lDQWdJR2xtSUNocElEMDlQU0F3ZURFd01EQXdNREF3TUNrZ0x5OGdiV0Y0SUhGMVpYVmxJSE5wZW1WY2JpQWdJQ0FnSUNBZ2FTQTlJREE3WEc0Z0lDQWdJQ0JwWmlBb0t5dHBJR2x1SUhScGJXVnZkWFJ6S1Z4dUlDQWdJQ0FnSUNCMGFISnZkeUJ1WlhjZ1JYSnliM0lvWENKelpYUkpiVzFsWkdsaGRHVWdjWFZsZFdVZ2IzWmxjbVpzYjNjdVhDSXBPMXh1SUNBZ0lDQWdkR2x0Wlc5MWRITmJhVjBnUFNCbWJqdGNiaUFnSUNBZ0lHZHNiMkpoYkM1d2IzTjBUV1Z6YzJGblpTaDdJSFI1Y0dVNklHMWxjM05oWjJWT1lXMWxMQ0JwWkRvZ2FTQjlMQ0JjSWlwY0lpazdYRzRnSUNBZ0lDQnlaWFIxY200Z2FUdGNiaUFnSUNCOVhHNWNiaUFnSUNCbWRXNWpkR2x2YmlCeVpXTmxhWFpsS0dWMktTQjdYRzRnSUNBZ0lDQnBaaUFvWlhZdWMyOTFjbU5sSUNFOVBTQjNhVzVrYjNjcFhHNGdJQ0FnSUNBZ0lISmxkSFZ5Ymp0Y2JpQWdJQ0FnSUhaaGNpQmtZWFJoSUQwZ1pYWXVaR0YwWVR0Y2JpQWdJQ0FnSUdsbUlDaGtZWFJoSUNZbUlHUmhkR0VnYVc1emRHRnVZMlZ2WmlCUFltcGxZM1FnSmlZZ1pHRjBZUzUwZVhCbElEMDlQU0J0WlhOellXZGxUbUZ0WlNrZ2UxeHVJQ0FnSUNBZ0lDQmxkaTV6ZEc5d1VISnZjR0ZuWVhScGIyNG9LVHRjYmlBZ0lDQWdJQ0FnZG1GeUlHbGtJRDBnWlhZdVpHRjBZUzVwWkR0Y2JpQWdJQ0FnSUNBZ2RtRnlJR1p1SUQwZ2RHbHRaVzkxZEhOYmFXUmRPMXh1SUNBZ0lDQWdJQ0JwWmlBb1ptNHBJSHRjYmlBZ0lDQWdJQ0FnSUNCa1pXeGxkR1VnZEdsdFpXOTFkSE5iYVdSZE8xeHVJQ0FnSUNBZ0lDQWdJR1p1S0NrN1hHNGdJQ0FnSUNBZ0lIMWNiaUFnSUNBZ0lIMWNiaUFnSUNCOVhHNWNiaUFnSUNCbWRXNWpkR2x2YmlCamJHVmhjaWhwWkNrZ2UxeHVJQ0FnSUNBZ1pHVnNaWFJsSUhScGJXVnZkWFJ6VzJsa1hUdGNiaUFnSUNCOVhHNWNiaUFnSUNCbmJHOWlZV3d1WVdSa1JYWmxiblJNYVhOMFpXNWxjaWhjSW0xbGMzTmhaMlZjSWl3Z2NtVmpaV2wyWlN3Z2RISjFaU2s3WEc0Z0lDQWdaMnh2WW1Gc0xuTmxkRWx0YldWa2FXRjBaU0E5SUhCdmMzUTdYRzRnSUNBZ1oyeHZZbUZzTG1Oc1pXRnlTVzF0WldScFlYUmxJRDBnWTJ4bFlYSTdYRzRnSUgwcEtDazdYRzU5WEc0aVhYMD0iLCJmdW5jdGlvbiBlcnJvclRocm93ZXIgKG5hbWUpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJObyBzdWNoIG1ldGhvZDogXCIgKyBuYW1lKTtcbiAgfTtcbn1cblxuZnVuY3Rpb24gYXJyVG9CdWYoaGV4KSB7XG4gIHZhciBidWZmZXIgPSBuZXcgQXJyYXlCdWZmZXIoaGV4Lmxlbmd0aCk7XG4gIHZhciBidWZmZXJWaWV3ID0gbmV3IFVpbnQ4QXJyYXkoYnVmZmVyKTtcbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBoZXgubGVuZ3RoOyBpKyspIHtcbiAgICBidWZmZXJWaWV3W2ldID0gaGV4W2ldO1xuICB9XG5cbiAgcmV0dXJuIGJ1ZmZlcjtcbn1cbm1vZHVsZS5leHBvcnRzLmFyclRvQnVmID0gYXJyVG9CdWY7XG5cbmZ1bmN0aW9uIGJ1ZlRvQXJyKGJpbikge1xuICB2YXIgYnVmZmVyVmlldyA9IG5ldyBVaW50OEFycmF5KGJpbik7XG4gIHZhciBoZXhlcyA9IFtdO1xuICBmb3IgKHZhciBpID0gMDsgaSA8IGJ1ZmZlclZpZXcubGVuZ3RoOyArK2kpIHtcbiAgICBoZXhlcy5wdXNoKGJ1ZmZlclZpZXdbaV0pO1xuICB9XG4gIHJldHVybiBoZXhlcztcbn1cbm1vZHVsZS5leHBvcnRzLmJ1ZlRvQXJyID0gYnVmVG9BcnI7XG5cbi8vIEdldCBhIGNhbGxhYmxlIG1lbWJlciBvZiB0aGlzLm9iaiBnaXZlbiB0aGUgbmFtZS4gRG90IHBhdGhzIGFyZVxuLy8gc3VwcG9ydGVkLlxuZnVuY3Rpb24gcGF0aDJjYWxsYWJsZSAob2JqZWN0LCBuYW1lLCBjYWxsYWJsZSkge1xuICB2YXIgbmFtZXMgPSBuYW1lLnNwbGl0KCcuJyksXG4gICAgICBtZXRob2QgPSBuYW1lcy5wb3AoKSxcbiAgICAgIG9iaiA9IChuYW1lcy5yZWR1Y2UoZnVuY3Rpb24gKG9iLCBtZXRoKSB7cmV0dXJuIG9iW21ldGhdO30sIG9iamVjdClcbiAgICAgICAgICAgICB8fCBvYmplY3QpLFxuICAgICAgc2VsZiA9IHRoaXM7XG5cbiAgaWYgKCFvYmpbbWV0aG9kXSkge1xuICAgIGNvbnNvbGUud2FybihcIlRyaWVkIHRvIHJlc29sdmUgYmFkIG9iamVjdCBwYXRoOiBcIiArIG5hbWUpO1xuICAgIGNvbnNvbGUud2FybihcIlNlcnZlcjpcIiwgb2JqZWN0KTtcbiAgICByZXR1cm4gbnVsbDsgLy8gZXJyb3JUaHJvd2VyKG5hbWUpO1xuICB9XG5cbiAgcmV0dXJuIG9ialttZXRob2RdLmJpbmQob2JqKTtcbn07XG5tb2R1bGUuZXhwb3J0cy5wYXRoMmNhbGxhYmxlID0gcGF0aDJjYWxsYWJsZTtcbiIsIi8vIGh0dHA6Ly93aWtpLmNvbW1vbmpzLm9yZy93aWtpL1VuaXRfVGVzdGluZy8xLjBcbi8vXG4vLyBUSElTIElTIE5PVCBURVNURUQgTk9SIExJS0VMWSBUTyBXT1JLIE9VVFNJREUgVjghXG4vL1xuLy8gT3JpZ2luYWxseSBmcm9tIG5hcndoYWwuanMgKGh0dHA6Ly9uYXJ3aGFsanMub3JnKVxuLy8gQ29weXJpZ2h0IChjKSAyMDA5IFRob21hcyBSb2JpbnNvbiA8Mjgwbm9ydGguY29tPlxuLy9cbi8vIFBlcm1pc3Npb24gaXMgaGVyZWJ5IGdyYW50ZWQsIGZyZWUgb2YgY2hhcmdlLCB0byBhbnkgcGVyc29uIG9idGFpbmluZyBhIGNvcHlcbi8vIG9mIHRoaXMgc29mdHdhcmUgYW5kIGFzc29jaWF0ZWQgZG9jdW1lbnRhdGlvbiBmaWxlcyAodGhlICdTb2Z0d2FyZScpLCB0b1xuLy8gZGVhbCBpbiB0aGUgU29mdHdhcmUgd2l0aG91dCByZXN0cmljdGlvbiwgaW5jbHVkaW5nIHdpdGhvdXQgbGltaXRhdGlvbiB0aGVcbi8vIHJpZ2h0cyB0byB1c2UsIGNvcHksIG1vZGlmeSwgbWVyZ2UsIHB1Ymxpc2gsIGRpc3RyaWJ1dGUsIHN1YmxpY2Vuc2UsIGFuZC9vclxuLy8gc2VsbCBjb3BpZXMgb2YgdGhlIFNvZnR3YXJlLCBhbmQgdG8gcGVybWl0IHBlcnNvbnMgdG8gd2hvbSB0aGUgU29mdHdhcmUgaXNcbi8vIGZ1cm5pc2hlZCB0byBkbyBzbywgc3ViamVjdCB0byB0aGUgZm9sbG93aW5nIGNvbmRpdGlvbnM6XG4vL1xuLy8gVGhlIGFib3ZlIGNvcHlyaWdodCBub3RpY2UgYW5kIHRoaXMgcGVybWlzc2lvbiBub3RpY2Ugc2hhbGwgYmUgaW5jbHVkZWQgaW5cbi8vIGFsbCBjb3BpZXMgb3Igc3Vic3RhbnRpYWwgcG9ydGlvbnMgb2YgdGhlIFNvZnR3YXJlLlxuLy9cbi8vIFRIRSBTT0ZUV0FSRSBJUyBQUk9WSURFRCAnQVMgSVMnLCBXSVRIT1VUIFdBUlJBTlRZIE9GIEFOWSBLSU5ELCBFWFBSRVNTIE9SXG4vLyBJTVBMSUVELCBJTkNMVURJTkcgQlVUIE5PVCBMSU1JVEVEIFRPIFRIRSBXQVJSQU5USUVTIE9GIE1FUkNIQU5UQUJJTElUWSxcbi8vIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFIEFORCBOT05JTkZSSU5HRU1FTlQuIElOIE5PIEVWRU5UIFNIQUxMIFRIRVxuLy8gQVVUSE9SUyBCRSBMSUFCTEUgRk9SIEFOWSBDTEFJTSwgREFNQUdFUyBPUiBPVEhFUiBMSUFCSUxJVFksIFdIRVRIRVIgSU4gQU5cbi8vIEFDVElPTiBPRiBDT05UUkFDVCwgVE9SVCBPUiBPVEhFUldJU0UsIEFSSVNJTkcgRlJPTSwgT1VUIE9GIE9SIElOIENPTk5FQ1RJT05cbi8vIFdJVEggVEhFIFNPRlRXQVJFIE9SIFRIRSBVU0UgT1IgT1RIRVIgREVBTElOR1MgSU4gVEhFIFNPRlRXQVJFLlxuXG4vLyB3aGVuIHVzZWQgaW4gbm9kZSwgdGhpcyB3aWxsIGFjdHVhbGx5IGxvYWQgdGhlIHV0aWwgbW9kdWxlIHdlIGRlcGVuZCBvblxuLy8gdmVyc3VzIGxvYWRpbmcgdGhlIGJ1aWx0aW4gdXRpbCBtb2R1bGUgYXMgaGFwcGVucyBvdGhlcndpc2Vcbi8vIHRoaXMgaXMgYSBidWcgaW4gbm9kZSBtb2R1bGUgbG9hZGluZyBhcyBmYXIgYXMgSSBhbSBjb25jZXJuZWRcbnZhciB1dGlsID0gcmVxdWlyZSgndXRpbC8nKTtcblxudmFyIHBTbGljZSA9IEFycmF5LnByb3RvdHlwZS5zbGljZTtcbnZhciBoYXNPd24gPSBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5O1xuXG4vLyAxLiBUaGUgYXNzZXJ0IG1vZHVsZSBwcm92aWRlcyBmdW5jdGlvbnMgdGhhdCB0aHJvd1xuLy8gQXNzZXJ0aW9uRXJyb3IncyB3aGVuIHBhcnRpY3VsYXIgY29uZGl0aW9ucyBhcmUgbm90IG1ldC4gVGhlXG4vLyBhc3NlcnQgbW9kdWxlIG11c3QgY29uZm9ybSB0byB0aGUgZm9sbG93aW5nIGludGVyZmFjZS5cblxudmFyIGFzc2VydCA9IG1vZHVsZS5leHBvcnRzID0gb2s7XG5cbi8vIDIuIFRoZSBBc3NlcnRpb25FcnJvciBpcyBkZWZpbmVkIGluIGFzc2VydC5cbi8vIG5ldyBhc3NlcnQuQXNzZXJ0aW9uRXJyb3IoeyBtZXNzYWdlOiBtZXNzYWdlLFxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFjdHVhbDogYWN0dWFsLFxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4cGVjdGVkOiBleHBlY3RlZCB9KVxuXG5hc3NlcnQuQXNzZXJ0aW9uRXJyb3IgPSBmdW5jdGlvbiBBc3NlcnRpb25FcnJvcihvcHRpb25zKSB7XG4gIHRoaXMubmFtZSA9ICdBc3NlcnRpb25FcnJvcic7XG4gIHRoaXMuYWN0dWFsID0gb3B0aW9ucy5hY3R1YWw7XG4gIHRoaXMuZXhwZWN0ZWQgPSBvcHRpb25zLmV4cGVjdGVkO1xuICB0aGlzLm9wZXJhdG9yID0gb3B0aW9ucy5vcGVyYXRvcjtcbiAgaWYgKG9wdGlvbnMubWVzc2FnZSkge1xuICAgIHRoaXMubWVzc2FnZSA9IG9wdGlvbnMubWVzc2FnZTtcbiAgICB0aGlzLmdlbmVyYXRlZE1lc3NhZ2UgPSBmYWxzZTtcbiAgfSBlbHNlIHtcbiAgICB0aGlzLm1lc3NhZ2UgPSBnZXRNZXNzYWdlKHRoaXMpO1xuICAgIHRoaXMuZ2VuZXJhdGVkTWVzc2FnZSA9IHRydWU7XG4gIH1cbiAgdmFyIHN0YWNrU3RhcnRGdW5jdGlvbiA9IG9wdGlvbnMuc3RhY2tTdGFydEZ1bmN0aW9uIHx8IGZhaWw7XG5cbiAgaWYgKEVycm9yLmNhcHR1cmVTdGFja1RyYWNlKSB7XG4gICAgRXJyb3IuY2FwdHVyZVN0YWNrVHJhY2UodGhpcywgc3RhY2tTdGFydEZ1bmN0aW9uKTtcbiAgfVxuICBlbHNlIHtcbiAgICAvLyBub24gdjggYnJvd3NlcnMgc28gd2UgY2FuIGhhdmUgYSBzdGFja3RyYWNlXG4gICAgdmFyIGVyciA9IG5ldyBFcnJvcigpO1xuICAgIGlmIChlcnIuc3RhY2spIHtcbiAgICAgIHZhciBvdXQgPSBlcnIuc3RhY2s7XG5cbiAgICAgIC8vIHRyeSB0byBzdHJpcCB1c2VsZXNzIGZyYW1lc1xuICAgICAgdmFyIGZuX25hbWUgPSBzdGFja1N0YXJ0RnVuY3Rpb24ubmFtZTtcbiAgICAgIHZhciBpZHggPSBvdXQuaW5kZXhPZignXFxuJyArIGZuX25hbWUpO1xuICAgICAgaWYgKGlkeCA+PSAwKSB7XG4gICAgICAgIC8vIG9uY2Ugd2UgaGF2ZSBsb2NhdGVkIHRoZSBmdW5jdGlvbiBmcmFtZVxuICAgICAgICAvLyB3ZSBuZWVkIHRvIHN0cmlwIG91dCBldmVyeXRoaW5nIGJlZm9yZSBpdCAoYW5kIGl0cyBsaW5lKVxuICAgICAgICB2YXIgbmV4dF9saW5lID0gb3V0LmluZGV4T2YoJ1xcbicsIGlkeCArIDEpO1xuICAgICAgICBvdXQgPSBvdXQuc3Vic3RyaW5nKG5leHRfbGluZSArIDEpO1xuICAgICAgfVxuXG4gICAgICB0aGlzLnN0YWNrID0gb3V0O1xuICAgIH1cbiAgfVxufTtcblxuLy8gYXNzZXJ0LkFzc2VydGlvbkVycm9yIGluc3RhbmNlb2YgRXJyb3JcbnV0aWwuaW5oZXJpdHMoYXNzZXJ0LkFzc2VydGlvbkVycm9yLCBFcnJvcik7XG5cbmZ1bmN0aW9uIHJlcGxhY2VyKGtleSwgdmFsdWUpIHtcbiAgaWYgKHV0aWwuaXNVbmRlZmluZWQodmFsdWUpKSB7XG4gICAgcmV0dXJuICcnICsgdmFsdWU7XG4gIH1cbiAgaWYgKHV0aWwuaXNOdW1iZXIodmFsdWUpICYmIChpc05hTih2YWx1ZSkgfHwgIWlzRmluaXRlKHZhbHVlKSkpIHtcbiAgICByZXR1cm4gdmFsdWUudG9TdHJpbmcoKTtcbiAgfVxuICBpZiAodXRpbC5pc0Z1bmN0aW9uKHZhbHVlKSB8fCB1dGlsLmlzUmVnRXhwKHZhbHVlKSkge1xuICAgIHJldHVybiB2YWx1ZS50b1N0cmluZygpO1xuICB9XG4gIHJldHVybiB2YWx1ZTtcbn1cblxuZnVuY3Rpb24gdHJ1bmNhdGUocywgbikge1xuICBpZiAodXRpbC5pc1N0cmluZyhzKSkge1xuICAgIHJldHVybiBzLmxlbmd0aCA8IG4gPyBzIDogcy5zbGljZSgwLCBuKTtcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gcztcbiAgfVxufVxuXG5mdW5jdGlvbiBnZXRNZXNzYWdlKHNlbGYpIHtcbiAgcmV0dXJuIHRydW5jYXRlKEpTT04uc3RyaW5naWZ5KHNlbGYuYWN0dWFsLCByZXBsYWNlciksIDEyOCkgKyAnICcgK1xuICAgICAgICAgc2VsZi5vcGVyYXRvciArICcgJyArXG4gICAgICAgICB0cnVuY2F0ZShKU09OLnN0cmluZ2lmeShzZWxmLmV4cGVjdGVkLCByZXBsYWNlciksIDEyOCk7XG59XG5cbi8vIEF0IHByZXNlbnQgb25seSB0aGUgdGhyZWUga2V5cyBtZW50aW9uZWQgYWJvdmUgYXJlIHVzZWQgYW5kXG4vLyB1bmRlcnN0b29kIGJ5IHRoZSBzcGVjLiBJbXBsZW1lbnRhdGlvbnMgb3Igc3ViIG1vZHVsZXMgY2FuIHBhc3Ncbi8vIG90aGVyIGtleXMgdG8gdGhlIEFzc2VydGlvbkVycm9yJ3MgY29uc3RydWN0b3IgLSB0aGV5IHdpbGwgYmVcbi8vIGlnbm9yZWQuXG5cbi8vIDMuIEFsbCBvZiB0aGUgZm9sbG93aW5nIGZ1bmN0aW9ucyBtdXN0IHRocm93IGFuIEFzc2VydGlvbkVycm9yXG4vLyB3aGVuIGEgY29ycmVzcG9uZGluZyBjb25kaXRpb24gaXMgbm90IG1ldCwgd2l0aCBhIG1lc3NhZ2UgdGhhdFxuLy8gbWF5IGJlIHVuZGVmaW5lZCBpZiBub3QgcHJvdmlkZWQuICBBbGwgYXNzZXJ0aW9uIG1ldGhvZHMgcHJvdmlkZVxuLy8gYm90aCB0aGUgYWN0dWFsIGFuZCBleHBlY3RlZCB2YWx1ZXMgdG8gdGhlIGFzc2VydGlvbiBlcnJvciBmb3Jcbi8vIGRpc3BsYXkgcHVycG9zZXMuXG5cbmZ1bmN0aW9uIGZhaWwoYWN0dWFsLCBleHBlY3RlZCwgbWVzc2FnZSwgb3BlcmF0b3IsIHN0YWNrU3RhcnRGdW5jdGlvbikge1xuICB0aHJvdyBuZXcgYXNzZXJ0LkFzc2VydGlvbkVycm9yKHtcbiAgICBtZXNzYWdlOiBtZXNzYWdlLFxuICAgIGFjdHVhbDogYWN0dWFsLFxuICAgIGV4cGVjdGVkOiBleHBlY3RlZCxcbiAgICBvcGVyYXRvcjogb3BlcmF0b3IsXG4gICAgc3RhY2tTdGFydEZ1bmN0aW9uOiBzdGFja1N0YXJ0RnVuY3Rpb25cbiAgfSk7XG59XG5cbi8vIEVYVEVOU0lPTiEgYWxsb3dzIGZvciB3ZWxsIGJlaGF2ZWQgZXJyb3JzIGRlZmluZWQgZWxzZXdoZXJlLlxuYXNzZXJ0LmZhaWwgPSBmYWlsO1xuXG4vLyA0LiBQdXJlIGFzc2VydGlvbiB0ZXN0cyB3aGV0aGVyIGEgdmFsdWUgaXMgdHJ1dGh5LCBhcyBkZXRlcm1pbmVkXG4vLyBieSAhIWd1YXJkLlxuLy8gYXNzZXJ0Lm9rKGd1YXJkLCBtZXNzYWdlX29wdCk7XG4vLyBUaGlzIHN0YXRlbWVudCBpcyBlcXVpdmFsZW50IHRvIGFzc2VydC5lcXVhbCh0cnVlLCAhIWd1YXJkLFxuLy8gbWVzc2FnZV9vcHQpOy4gVG8gdGVzdCBzdHJpY3RseSBmb3IgdGhlIHZhbHVlIHRydWUsIHVzZVxuLy8gYXNzZXJ0LnN0cmljdEVxdWFsKHRydWUsIGd1YXJkLCBtZXNzYWdlX29wdCk7LlxuXG5mdW5jdGlvbiBvayh2YWx1ZSwgbWVzc2FnZSkge1xuICBpZiAoIXZhbHVlKSBmYWlsKHZhbHVlLCB0cnVlLCBtZXNzYWdlLCAnPT0nLCBhc3NlcnQub2spO1xufVxuYXNzZXJ0Lm9rID0gb2s7XG5cbi8vIDUuIFRoZSBlcXVhbGl0eSBhc3NlcnRpb24gdGVzdHMgc2hhbGxvdywgY29lcmNpdmUgZXF1YWxpdHkgd2l0aFxuLy8gPT0uXG4vLyBhc3NlcnQuZXF1YWwoYWN0dWFsLCBleHBlY3RlZCwgbWVzc2FnZV9vcHQpO1xuXG5hc3NlcnQuZXF1YWwgPSBmdW5jdGlvbiBlcXVhbChhY3R1YWwsIGV4cGVjdGVkLCBtZXNzYWdlKSB7XG4gIGlmIChhY3R1YWwgIT0gZXhwZWN0ZWQpIGZhaWwoYWN0dWFsLCBleHBlY3RlZCwgbWVzc2FnZSwgJz09JywgYXNzZXJ0LmVxdWFsKTtcbn07XG5cbi8vIDYuIFRoZSBub24tZXF1YWxpdHkgYXNzZXJ0aW9uIHRlc3RzIGZvciB3aGV0aGVyIHR3byBvYmplY3RzIGFyZSBub3QgZXF1YWxcbi8vIHdpdGggIT0gYXNzZXJ0Lm5vdEVxdWFsKGFjdHVhbCwgZXhwZWN0ZWQsIG1lc3NhZ2Vfb3B0KTtcblxuYXNzZXJ0Lm5vdEVxdWFsID0gZnVuY3Rpb24gbm90RXF1YWwoYWN0dWFsLCBleHBlY3RlZCwgbWVzc2FnZSkge1xuICBpZiAoYWN0dWFsID09IGV4cGVjdGVkKSB7XG4gICAgZmFpbChhY3R1YWwsIGV4cGVjdGVkLCBtZXNzYWdlLCAnIT0nLCBhc3NlcnQubm90RXF1YWwpO1xuICB9XG59O1xuXG4vLyA3LiBUaGUgZXF1aXZhbGVuY2UgYXNzZXJ0aW9uIHRlc3RzIGEgZGVlcCBlcXVhbGl0eSByZWxhdGlvbi5cbi8vIGFzc2VydC5kZWVwRXF1YWwoYWN0dWFsLCBleHBlY3RlZCwgbWVzc2FnZV9vcHQpO1xuXG5hc3NlcnQuZGVlcEVxdWFsID0gZnVuY3Rpb24gZGVlcEVxdWFsKGFjdHVhbCwgZXhwZWN0ZWQsIG1lc3NhZ2UpIHtcbiAgaWYgKCFfZGVlcEVxdWFsKGFjdHVhbCwgZXhwZWN0ZWQpKSB7XG4gICAgZmFpbChhY3R1YWwsIGV4cGVjdGVkLCBtZXNzYWdlLCAnZGVlcEVxdWFsJywgYXNzZXJ0LmRlZXBFcXVhbCk7XG4gIH1cbn07XG5cbmZ1bmN0aW9uIF9kZWVwRXF1YWwoYWN0dWFsLCBleHBlY3RlZCkge1xuICAvLyA3LjEuIEFsbCBpZGVudGljYWwgdmFsdWVzIGFyZSBlcXVpdmFsZW50LCBhcyBkZXRlcm1pbmVkIGJ5ID09PS5cbiAgaWYgKGFjdHVhbCA9PT0gZXhwZWN0ZWQpIHtcbiAgICByZXR1cm4gdHJ1ZTtcblxuICB9IGVsc2UgaWYgKHV0aWwuaXNCdWZmZXIoYWN0dWFsKSAmJiB1dGlsLmlzQnVmZmVyKGV4cGVjdGVkKSkge1xuICAgIGlmIChhY3R1YWwubGVuZ3RoICE9IGV4cGVjdGVkLmxlbmd0aCkgcmV0dXJuIGZhbHNlO1xuXG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBhY3R1YWwubGVuZ3RoOyBpKyspIHtcbiAgICAgIGlmIChhY3R1YWxbaV0gIT09IGV4cGVjdGVkW2ldKSByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgcmV0dXJuIHRydWU7XG5cbiAgLy8gNy4yLiBJZiB0aGUgZXhwZWN0ZWQgdmFsdWUgaXMgYSBEYXRlIG9iamVjdCwgdGhlIGFjdHVhbCB2YWx1ZSBpc1xuICAvLyBlcXVpdmFsZW50IGlmIGl0IGlzIGFsc28gYSBEYXRlIG9iamVjdCB0aGF0IHJlZmVycyB0byB0aGUgc2FtZSB0aW1lLlxuICB9IGVsc2UgaWYgKHV0aWwuaXNEYXRlKGFjdHVhbCkgJiYgdXRpbC5pc0RhdGUoZXhwZWN0ZWQpKSB7XG4gICAgcmV0dXJuIGFjdHVhbC5nZXRUaW1lKCkgPT09IGV4cGVjdGVkLmdldFRpbWUoKTtcblxuICAvLyA3LjMgSWYgdGhlIGV4cGVjdGVkIHZhbHVlIGlzIGEgUmVnRXhwIG9iamVjdCwgdGhlIGFjdHVhbCB2YWx1ZSBpc1xuICAvLyBlcXVpdmFsZW50IGlmIGl0IGlzIGFsc28gYSBSZWdFeHAgb2JqZWN0IHdpdGggdGhlIHNhbWUgc291cmNlIGFuZFxuICAvLyBwcm9wZXJ0aWVzIChgZ2xvYmFsYCwgYG11bHRpbGluZWAsIGBsYXN0SW5kZXhgLCBgaWdub3JlQ2FzZWApLlxuICB9IGVsc2UgaWYgKHV0aWwuaXNSZWdFeHAoYWN0dWFsKSAmJiB1dGlsLmlzUmVnRXhwKGV4cGVjdGVkKSkge1xuICAgIHJldHVybiBhY3R1YWwuc291cmNlID09PSBleHBlY3RlZC5zb3VyY2UgJiZcbiAgICAgICAgICAgYWN0dWFsLmdsb2JhbCA9PT0gZXhwZWN0ZWQuZ2xvYmFsICYmXG4gICAgICAgICAgIGFjdHVhbC5tdWx0aWxpbmUgPT09IGV4cGVjdGVkLm11bHRpbGluZSAmJlxuICAgICAgICAgICBhY3R1YWwubGFzdEluZGV4ID09PSBleHBlY3RlZC5sYXN0SW5kZXggJiZcbiAgICAgICAgICAgYWN0dWFsLmlnbm9yZUNhc2UgPT09IGV4cGVjdGVkLmlnbm9yZUNhc2U7XG5cbiAgLy8gNy40LiBPdGhlciBwYWlycyB0aGF0IGRvIG5vdCBib3RoIHBhc3MgdHlwZW9mIHZhbHVlID09ICdvYmplY3QnLFxuICAvLyBlcXVpdmFsZW5jZSBpcyBkZXRlcm1pbmVkIGJ5ID09LlxuICB9IGVsc2UgaWYgKCF1dGlsLmlzT2JqZWN0KGFjdHVhbCkgJiYgIXV0aWwuaXNPYmplY3QoZXhwZWN0ZWQpKSB7XG4gICAgcmV0dXJuIGFjdHVhbCA9PSBleHBlY3RlZDtcblxuICAvLyA3LjUgRm9yIGFsbCBvdGhlciBPYmplY3QgcGFpcnMsIGluY2x1ZGluZyBBcnJheSBvYmplY3RzLCBlcXVpdmFsZW5jZSBpc1xuICAvLyBkZXRlcm1pbmVkIGJ5IGhhdmluZyB0aGUgc2FtZSBudW1iZXIgb2Ygb3duZWQgcHJvcGVydGllcyAoYXMgdmVyaWZpZWRcbiAgLy8gd2l0aCBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwpLCB0aGUgc2FtZSBzZXQgb2Yga2V5c1xuICAvLyAoYWx0aG91Z2ggbm90IG5lY2Vzc2FyaWx5IHRoZSBzYW1lIG9yZGVyKSwgZXF1aXZhbGVudCB2YWx1ZXMgZm9yIGV2ZXJ5XG4gIC8vIGNvcnJlc3BvbmRpbmcga2V5LCBhbmQgYW4gaWRlbnRpY2FsICdwcm90b3R5cGUnIHByb3BlcnR5LiBOb3RlOiB0aGlzXG4gIC8vIGFjY291bnRzIGZvciBib3RoIG5hbWVkIGFuZCBpbmRleGVkIHByb3BlcnRpZXMgb24gQXJyYXlzLlxuICB9IGVsc2Uge1xuICAgIHJldHVybiBvYmpFcXVpdihhY3R1YWwsIGV4cGVjdGVkKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBpc0FyZ3VtZW50cyhvYmplY3QpIHtcbiAgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbChvYmplY3QpID09ICdbb2JqZWN0IEFyZ3VtZW50c10nO1xufVxuXG5mdW5jdGlvbiBvYmpFcXVpdihhLCBiKSB7XG4gIGlmICh1dGlsLmlzTnVsbE9yVW5kZWZpbmVkKGEpIHx8IHV0aWwuaXNOdWxsT3JVbmRlZmluZWQoYikpXG4gICAgcmV0dXJuIGZhbHNlO1xuICAvLyBhbiBpZGVudGljYWwgJ3Byb3RvdHlwZScgcHJvcGVydHkuXG4gIGlmIChhLnByb3RvdHlwZSAhPT0gYi5wcm90b3R5cGUpIHJldHVybiBmYWxzZTtcbiAgLy9+fn5JJ3ZlIG1hbmFnZWQgdG8gYnJlYWsgT2JqZWN0LmtleXMgdGhyb3VnaCBzY3Jld3kgYXJndW1lbnRzIHBhc3NpbmcuXG4gIC8vICAgQ29udmVydGluZyB0byBhcnJheSBzb2x2ZXMgdGhlIHByb2JsZW0uXG4gIGlmIChpc0FyZ3VtZW50cyhhKSkge1xuICAgIGlmICghaXNBcmd1bWVudHMoYikpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgYSA9IHBTbGljZS5jYWxsKGEpO1xuICAgIGIgPSBwU2xpY2UuY2FsbChiKTtcbiAgICByZXR1cm4gX2RlZXBFcXVhbChhLCBiKTtcbiAgfVxuICB0cnkge1xuICAgIHZhciBrYSA9IG9iamVjdEtleXMoYSksXG4gICAgICAgIGtiID0gb2JqZWN0S2V5cyhiKSxcbiAgICAgICAga2V5LCBpO1xuICB9IGNhdGNoIChlKSB7Ly9oYXBwZW5zIHdoZW4gb25lIGlzIGEgc3RyaW5nIGxpdGVyYWwgYW5kIHRoZSBvdGhlciBpc24ndFxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICAvLyBoYXZpbmcgdGhlIHNhbWUgbnVtYmVyIG9mIG93bmVkIHByb3BlcnRpZXMgKGtleXMgaW5jb3Jwb3JhdGVzXG4gIC8vIGhhc093blByb3BlcnR5KVxuICBpZiAoa2EubGVuZ3RoICE9IGtiLmxlbmd0aClcbiAgICByZXR1cm4gZmFsc2U7XG4gIC8vdGhlIHNhbWUgc2V0IG9mIGtleXMgKGFsdGhvdWdoIG5vdCBuZWNlc3NhcmlseSB0aGUgc2FtZSBvcmRlciksXG4gIGthLnNvcnQoKTtcbiAga2Iuc29ydCgpO1xuICAvL35+fmNoZWFwIGtleSB0ZXN0XG4gIGZvciAoaSA9IGthLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG4gICAgaWYgKGthW2ldICE9IGtiW2ldKVxuICAgICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIC8vZXF1aXZhbGVudCB2YWx1ZXMgZm9yIGV2ZXJ5IGNvcnJlc3BvbmRpbmcga2V5LCBhbmRcbiAgLy9+fn5wb3NzaWJseSBleHBlbnNpdmUgZGVlcCB0ZXN0XG4gIGZvciAoaSA9IGthLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG4gICAga2V5ID0ga2FbaV07XG4gICAgaWYgKCFfZGVlcEVxdWFsKGFba2V5XSwgYltrZXldKSkgcmV0dXJuIGZhbHNlO1xuICB9XG4gIHJldHVybiB0cnVlO1xufVxuXG4vLyA4LiBUaGUgbm9uLWVxdWl2YWxlbmNlIGFzc2VydGlvbiB0ZXN0cyBmb3IgYW55IGRlZXAgaW5lcXVhbGl0eS5cbi8vIGFzc2VydC5ub3REZWVwRXF1YWwoYWN0dWFsLCBleHBlY3RlZCwgbWVzc2FnZV9vcHQpO1xuXG5hc3NlcnQubm90RGVlcEVxdWFsID0gZnVuY3Rpb24gbm90RGVlcEVxdWFsKGFjdHVhbCwgZXhwZWN0ZWQsIG1lc3NhZ2UpIHtcbiAgaWYgKF9kZWVwRXF1YWwoYWN0dWFsLCBleHBlY3RlZCkpIHtcbiAgICBmYWlsKGFjdHVhbCwgZXhwZWN0ZWQsIG1lc3NhZ2UsICdub3REZWVwRXF1YWwnLCBhc3NlcnQubm90RGVlcEVxdWFsKTtcbiAgfVxufTtcblxuLy8gOS4gVGhlIHN0cmljdCBlcXVhbGl0eSBhc3NlcnRpb24gdGVzdHMgc3RyaWN0IGVxdWFsaXR5LCBhcyBkZXRlcm1pbmVkIGJ5ID09PS5cbi8vIGFzc2VydC5zdHJpY3RFcXVhbChhY3R1YWwsIGV4cGVjdGVkLCBtZXNzYWdlX29wdCk7XG5cbmFzc2VydC5zdHJpY3RFcXVhbCA9IGZ1bmN0aW9uIHN0cmljdEVxdWFsKGFjdHVhbCwgZXhwZWN0ZWQsIG1lc3NhZ2UpIHtcbiAgaWYgKGFjdHVhbCAhPT0gZXhwZWN0ZWQpIHtcbiAgICBmYWlsKGFjdHVhbCwgZXhwZWN0ZWQsIG1lc3NhZ2UsICc9PT0nLCBhc3NlcnQuc3RyaWN0RXF1YWwpO1xuICB9XG59O1xuXG4vLyAxMC4gVGhlIHN0cmljdCBub24tZXF1YWxpdHkgYXNzZXJ0aW9uIHRlc3RzIGZvciBzdHJpY3QgaW5lcXVhbGl0eSwgYXNcbi8vIGRldGVybWluZWQgYnkgIT09LiAgYXNzZXJ0Lm5vdFN0cmljdEVxdWFsKGFjdHVhbCwgZXhwZWN0ZWQsIG1lc3NhZ2Vfb3B0KTtcblxuYXNzZXJ0Lm5vdFN0cmljdEVxdWFsID0gZnVuY3Rpb24gbm90U3RyaWN0RXF1YWwoYWN0dWFsLCBleHBlY3RlZCwgbWVzc2FnZSkge1xuICBpZiAoYWN0dWFsID09PSBleHBlY3RlZCkge1xuICAgIGZhaWwoYWN0dWFsLCBleHBlY3RlZCwgbWVzc2FnZSwgJyE9PScsIGFzc2VydC5ub3RTdHJpY3RFcXVhbCk7XG4gIH1cbn07XG5cbmZ1bmN0aW9uIGV4cGVjdGVkRXhjZXB0aW9uKGFjdHVhbCwgZXhwZWN0ZWQpIHtcbiAgaWYgKCFhY3R1YWwgfHwgIWV4cGVjdGVkKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgaWYgKE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbChleHBlY3RlZCkgPT0gJ1tvYmplY3QgUmVnRXhwXScpIHtcbiAgICByZXR1cm4gZXhwZWN0ZWQudGVzdChhY3R1YWwpO1xuICB9IGVsc2UgaWYgKGFjdHVhbCBpbnN0YW5jZW9mIGV4cGVjdGVkKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH0gZWxzZSBpZiAoZXhwZWN0ZWQuY2FsbCh7fSwgYWN0dWFsKSA9PT0gdHJ1ZSkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG5cbiAgcmV0dXJuIGZhbHNlO1xufVxuXG5mdW5jdGlvbiBfdGhyb3dzKHNob3VsZFRocm93LCBibG9jaywgZXhwZWN0ZWQsIG1lc3NhZ2UpIHtcbiAgdmFyIGFjdHVhbDtcblxuICBpZiAodXRpbC5pc1N0cmluZyhleHBlY3RlZCkpIHtcbiAgICBtZXNzYWdlID0gZXhwZWN0ZWQ7XG4gICAgZXhwZWN0ZWQgPSBudWxsO1xuICB9XG5cbiAgdHJ5IHtcbiAgICBibG9jaygpO1xuICB9IGNhdGNoIChlKSB7XG4gICAgYWN0dWFsID0gZTtcbiAgfVxuXG4gIG1lc3NhZ2UgPSAoZXhwZWN0ZWQgJiYgZXhwZWN0ZWQubmFtZSA/ICcgKCcgKyBleHBlY3RlZC5uYW1lICsgJykuJyA6ICcuJykgK1xuICAgICAgICAgICAgKG1lc3NhZ2UgPyAnICcgKyBtZXNzYWdlIDogJy4nKTtcblxuICBpZiAoc2hvdWxkVGhyb3cgJiYgIWFjdHVhbCkge1xuICAgIGZhaWwoYWN0dWFsLCBleHBlY3RlZCwgJ01pc3NpbmcgZXhwZWN0ZWQgZXhjZXB0aW9uJyArIG1lc3NhZ2UpO1xuICB9XG5cbiAgaWYgKCFzaG91bGRUaHJvdyAmJiBleHBlY3RlZEV4Y2VwdGlvbihhY3R1YWwsIGV4cGVjdGVkKSkge1xuICAgIGZhaWwoYWN0dWFsLCBleHBlY3RlZCwgJ0dvdCB1bndhbnRlZCBleGNlcHRpb24nICsgbWVzc2FnZSk7XG4gIH1cblxuICBpZiAoKHNob3VsZFRocm93ICYmIGFjdHVhbCAmJiBleHBlY3RlZCAmJlxuICAgICAgIWV4cGVjdGVkRXhjZXB0aW9uKGFjdHVhbCwgZXhwZWN0ZWQpKSB8fCAoIXNob3VsZFRocm93ICYmIGFjdHVhbCkpIHtcbiAgICB0aHJvdyBhY3R1YWw7XG4gIH1cbn1cblxuLy8gMTEuIEV4cGVjdGVkIHRvIHRocm93IGFuIGVycm9yOlxuLy8gYXNzZXJ0LnRocm93cyhibG9jaywgRXJyb3Jfb3B0LCBtZXNzYWdlX29wdCk7XG5cbmFzc2VydC50aHJvd3MgPSBmdW5jdGlvbihibG9jaywgLypvcHRpb25hbCovZXJyb3IsIC8qb3B0aW9uYWwqL21lc3NhZ2UpIHtcbiAgX3Rocm93cy5hcHBseSh0aGlzLCBbdHJ1ZV0uY29uY2F0KHBTbGljZS5jYWxsKGFyZ3VtZW50cykpKTtcbn07XG5cbi8vIEVYVEVOU0lPTiEgVGhpcyBpcyBhbm5veWluZyB0byB3cml0ZSBvdXRzaWRlIHRoaXMgbW9kdWxlLlxuYXNzZXJ0LmRvZXNOb3RUaHJvdyA9IGZ1bmN0aW9uKGJsb2NrLCAvKm9wdGlvbmFsKi9tZXNzYWdlKSB7XG4gIF90aHJvd3MuYXBwbHkodGhpcywgW2ZhbHNlXS5jb25jYXQocFNsaWNlLmNhbGwoYXJndW1lbnRzKSkpO1xufTtcblxuYXNzZXJ0LmlmRXJyb3IgPSBmdW5jdGlvbihlcnIpIHsgaWYgKGVycikge3Rocm93IGVycjt9fTtcblxudmFyIG9iamVjdEtleXMgPSBPYmplY3Qua2V5cyB8fCBmdW5jdGlvbiAob2JqKSB7XG4gIHZhciBrZXlzID0gW107XG4gIGZvciAodmFyIGtleSBpbiBvYmopIHtcbiAgICBpZiAoaGFzT3duLmNhbGwob2JqLCBrZXkpKSBrZXlzLnB1c2goa2V5KTtcbiAgfVxuICByZXR1cm4ga2V5cztcbn07XG4iLCJpZiAodHlwZW9mIE9iamVjdC5jcmVhdGUgPT09ICdmdW5jdGlvbicpIHtcbiAgLy8gaW1wbGVtZW50YXRpb24gZnJvbSBzdGFuZGFyZCBub2RlLmpzICd1dGlsJyBtb2R1bGVcbiAgbW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiBpbmhlcml0cyhjdG9yLCBzdXBlckN0b3IpIHtcbiAgICBjdG9yLnN1cGVyXyA9IHN1cGVyQ3RvclxuICAgIGN0b3IucHJvdG90eXBlID0gT2JqZWN0LmNyZWF0ZShzdXBlckN0b3IucHJvdG90eXBlLCB7XG4gICAgICBjb25zdHJ1Y3Rvcjoge1xuICAgICAgICB2YWx1ZTogY3RvcixcbiAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXG4gICAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICAgIH1cbiAgICB9KTtcbiAgfTtcbn0gZWxzZSB7XG4gIC8vIG9sZCBzY2hvb2wgc2hpbSBmb3Igb2xkIGJyb3dzZXJzXG4gIG1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gaW5oZXJpdHMoY3Rvciwgc3VwZXJDdG9yKSB7XG4gICAgY3Rvci5zdXBlcl8gPSBzdXBlckN0b3JcbiAgICB2YXIgVGVtcEN0b3IgPSBmdW5jdGlvbiAoKSB7fVxuICAgIFRlbXBDdG9yLnByb3RvdHlwZSA9IHN1cGVyQ3Rvci5wcm90b3R5cGVcbiAgICBjdG9yLnByb3RvdHlwZSA9IG5ldyBUZW1wQ3RvcigpXG4gICAgY3Rvci5wcm90b3R5cGUuY29uc3RydWN0b3IgPSBjdG9yXG4gIH1cbn1cbiIsIi8vIHNoaW0gZm9yIHVzaW5nIHByb2Nlc3MgaW4gYnJvd3NlclxuXG52YXIgcHJvY2VzcyA9IG1vZHVsZS5leHBvcnRzID0ge307XG5cbnByb2Nlc3MubmV4dFRpY2sgPSAoZnVuY3Rpb24gKCkge1xuICAgIHZhciBjYW5TZXRJbW1lZGlhdGUgPSB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJ1xuICAgICYmIHdpbmRvdy5zZXRJbW1lZGlhdGU7XG4gICAgdmFyIGNhbk11dGF0aW9uT2JzZXJ2ZXIgPSB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJ1xuICAgICYmIHdpbmRvdy5NdXRhdGlvbk9ic2VydmVyO1xuICAgIHZhciBjYW5Qb3N0ID0gdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCdcbiAgICAmJiB3aW5kb3cucG9zdE1lc3NhZ2UgJiYgd2luZG93LmFkZEV2ZW50TGlzdGVuZXJcbiAgICA7XG5cbiAgICBpZiAoY2FuU2V0SW1tZWRpYXRlKSB7XG4gICAgICAgIHJldHVybiBmdW5jdGlvbiAoZikgeyByZXR1cm4gd2luZG93LnNldEltbWVkaWF0ZShmKSB9O1xuICAgIH1cblxuICAgIHZhciBxdWV1ZSA9IFtdO1xuXG4gICAgaWYgKGNhbk11dGF0aW9uT2JzZXJ2ZXIpIHtcbiAgICAgICAgdmFyIGhpZGRlbkRpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gICAgICAgIHZhciBvYnNlcnZlciA9IG5ldyBNdXRhdGlvbk9ic2VydmVyKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHZhciBxdWV1ZUxpc3QgPSBxdWV1ZS5zbGljZSgpO1xuICAgICAgICAgICAgcXVldWUubGVuZ3RoID0gMDtcbiAgICAgICAgICAgIHF1ZXVlTGlzdC5mb3JFYWNoKGZ1bmN0aW9uIChmbikge1xuICAgICAgICAgICAgICAgIGZuKCk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgb2JzZXJ2ZXIub2JzZXJ2ZShoaWRkZW5EaXYsIHsgYXR0cmlidXRlczogdHJ1ZSB9KTtcblxuICAgICAgICByZXR1cm4gZnVuY3Rpb24gbmV4dFRpY2soZm4pIHtcbiAgICAgICAgICAgIGlmICghcXVldWUubGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgaGlkZGVuRGl2LnNldEF0dHJpYnV0ZSgneWVzJywgJ25vJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBxdWV1ZS5wdXNoKGZuKTtcbiAgICAgICAgfTtcbiAgICB9XG5cbiAgICBpZiAoY2FuUG9zdCkge1xuICAgICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignbWVzc2FnZScsIGZ1bmN0aW9uIChldikge1xuICAgICAgICAgICAgdmFyIHNvdXJjZSA9IGV2LnNvdXJjZTtcbiAgICAgICAgICAgIGlmICgoc291cmNlID09PSB3aW5kb3cgfHwgc291cmNlID09PSBudWxsKSAmJiBldi5kYXRhID09PSAncHJvY2Vzcy10aWNrJykge1xuICAgICAgICAgICAgICAgIGV2LnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICAgICAgICAgIGlmIChxdWV1ZS5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciBmbiA9IHF1ZXVlLnNoaWZ0KCk7XG4gICAgICAgICAgICAgICAgICAgIGZuKCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9LCB0cnVlKTtcblxuICAgICAgICByZXR1cm4gZnVuY3Rpb24gbmV4dFRpY2soZm4pIHtcbiAgICAgICAgICAgIHF1ZXVlLnB1c2goZm4pO1xuICAgICAgICAgICAgd2luZG93LnBvc3RNZXNzYWdlKCdwcm9jZXNzLXRpY2snLCAnKicpO1xuICAgICAgICB9O1xuICAgIH1cblxuICAgIHJldHVybiBmdW5jdGlvbiBuZXh0VGljayhmbikge1xuICAgICAgICBzZXRUaW1lb3V0KGZuLCAwKTtcbiAgICB9O1xufSkoKTtcblxucHJvY2Vzcy50aXRsZSA9ICdicm93c2VyJztcbnByb2Nlc3MuYnJvd3NlciA9IHRydWU7XG5wcm9jZXNzLmVudiA9IHt9O1xucHJvY2Vzcy5hcmd2ID0gW107XG5cbmZ1bmN0aW9uIG5vb3AoKSB7fVxuXG5wcm9jZXNzLm9uID0gbm9vcDtcbnByb2Nlc3MuYWRkTGlzdGVuZXIgPSBub29wO1xucHJvY2Vzcy5vbmNlID0gbm9vcDtcbnByb2Nlc3Mub2ZmID0gbm9vcDtcbnByb2Nlc3MucmVtb3ZlTGlzdGVuZXIgPSBub29wO1xucHJvY2Vzcy5yZW1vdmVBbGxMaXN0ZW5lcnMgPSBub29wO1xucHJvY2Vzcy5lbWl0ID0gbm9vcDtcblxucHJvY2Vzcy5iaW5kaW5nID0gZnVuY3Rpb24gKG5hbWUpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ3Byb2Nlc3MuYmluZGluZyBpcyBub3Qgc3VwcG9ydGVkJyk7XG59O1xuXG4vLyBUT0RPKHNodHlsbWFuKVxucHJvY2Vzcy5jd2QgPSBmdW5jdGlvbiAoKSB7IHJldHVybiAnLycgfTtcbnByb2Nlc3MuY2hkaXIgPSBmdW5jdGlvbiAoZGlyKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdwcm9jZXNzLmNoZGlyIGlzIG5vdCBzdXBwb3J0ZWQnKTtcbn07XG4iLCJtb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIGlzQnVmZmVyKGFyZykge1xuICByZXR1cm4gYXJnICYmIHR5cGVvZiBhcmcgPT09ICdvYmplY3QnXG4gICAgJiYgdHlwZW9mIGFyZy5jb3B5ID09PSAnZnVuY3Rpb24nXG4gICAgJiYgdHlwZW9mIGFyZy5maWxsID09PSAnZnVuY3Rpb24nXG4gICAgJiYgdHlwZW9mIGFyZy5yZWFkVUludDggPT09ICdmdW5jdGlvbic7XG59IiwiKGZ1bmN0aW9uIChwcm9jZXNzLGdsb2JhbCl7XG4vLyBDb3B5cmlnaHQgSm95ZW50LCBJbmMuIGFuZCBvdGhlciBOb2RlIGNvbnRyaWJ1dG9ycy5cbi8vXG4vLyBQZXJtaXNzaW9uIGlzIGhlcmVieSBncmFudGVkLCBmcmVlIG9mIGNoYXJnZSwgdG8gYW55IHBlcnNvbiBvYnRhaW5pbmcgYVxuLy8gY29weSBvZiB0aGlzIHNvZnR3YXJlIGFuZCBhc3NvY2lhdGVkIGRvY3VtZW50YXRpb24gZmlsZXMgKHRoZVxuLy8gXCJTb2Z0d2FyZVwiKSwgdG8gZGVhbCBpbiB0aGUgU29mdHdhcmUgd2l0aG91dCByZXN0cmljdGlvbiwgaW5jbHVkaW5nXG4vLyB3aXRob3V0IGxpbWl0YXRpb24gdGhlIHJpZ2h0cyB0byB1c2UsIGNvcHksIG1vZGlmeSwgbWVyZ2UsIHB1Ymxpc2gsXG4vLyBkaXN0cmlidXRlLCBzdWJsaWNlbnNlLCBhbmQvb3Igc2VsbCBjb3BpZXMgb2YgdGhlIFNvZnR3YXJlLCBhbmQgdG8gcGVybWl0XG4vLyBwZXJzb25zIHRvIHdob20gdGhlIFNvZnR3YXJlIGlzIGZ1cm5pc2hlZCB0byBkbyBzbywgc3ViamVjdCB0byB0aGVcbi8vIGZvbGxvd2luZyBjb25kaXRpb25zOlxuLy9cbi8vIFRoZSBhYm92ZSBjb3B5cmlnaHQgbm90aWNlIGFuZCB0aGlzIHBlcm1pc3Npb24gbm90aWNlIHNoYWxsIGJlIGluY2x1ZGVkXG4vLyBpbiBhbGwgY29waWVzIG9yIHN1YnN0YW50aWFsIHBvcnRpb25zIG9mIHRoZSBTb2Z0d2FyZS5cbi8vXG4vLyBUSEUgU09GVFdBUkUgSVMgUFJPVklERUQgXCJBUyBJU1wiLCBXSVRIT1VUIFdBUlJBTlRZIE9GIEFOWSBLSU5ELCBFWFBSRVNTXG4vLyBPUiBJTVBMSUVELCBJTkNMVURJTkcgQlVUIE5PVCBMSU1JVEVEIFRPIFRIRSBXQVJSQU5USUVTIE9GXG4vLyBNRVJDSEFOVEFCSUxJVFksIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFIEFORCBOT05JTkZSSU5HRU1FTlQuIElOXG4vLyBOTyBFVkVOVCBTSEFMTCBUSEUgQVVUSE9SUyBPUiBDT1BZUklHSFQgSE9MREVSUyBCRSBMSUFCTEUgRk9SIEFOWSBDTEFJTSxcbi8vIERBTUFHRVMgT1IgT1RIRVIgTElBQklMSVRZLCBXSEVUSEVSIElOIEFOIEFDVElPTiBPRiBDT05UUkFDVCwgVE9SVCBPUlxuLy8gT1RIRVJXSVNFLCBBUklTSU5HIEZST00sIE9VVCBPRiBPUiBJTiBDT05ORUNUSU9OIFdJVEggVEhFIFNPRlRXQVJFIE9SIFRIRVxuLy8gVVNFIE9SIE9USEVSIERFQUxJTkdTIElOIFRIRSBTT0ZUV0FSRS5cblxudmFyIGZvcm1hdFJlZ0V4cCA9IC8lW3NkaiVdL2c7XG5leHBvcnRzLmZvcm1hdCA9IGZ1bmN0aW9uKGYpIHtcbiAgaWYgKCFpc1N0cmluZyhmKSkge1xuICAgIHZhciBvYmplY3RzID0gW107XG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBhcmd1bWVudHMubGVuZ3RoOyBpKyspIHtcbiAgICAgIG9iamVjdHMucHVzaChpbnNwZWN0KGFyZ3VtZW50c1tpXSkpO1xuICAgIH1cbiAgICByZXR1cm4gb2JqZWN0cy5qb2luKCcgJyk7XG4gIH1cblxuICB2YXIgaSA9IDE7XG4gIHZhciBhcmdzID0gYXJndW1lbnRzO1xuICB2YXIgbGVuID0gYXJncy5sZW5ndGg7XG4gIHZhciBzdHIgPSBTdHJpbmcoZikucmVwbGFjZShmb3JtYXRSZWdFeHAsIGZ1bmN0aW9uKHgpIHtcbiAgICBpZiAoeCA9PT0gJyUlJykgcmV0dXJuICclJztcbiAgICBpZiAoaSA+PSBsZW4pIHJldHVybiB4O1xuICAgIHN3aXRjaCAoeCkge1xuICAgICAgY2FzZSAnJXMnOiByZXR1cm4gU3RyaW5nKGFyZ3NbaSsrXSk7XG4gICAgICBjYXNlICclZCc6IHJldHVybiBOdW1iZXIoYXJnc1tpKytdKTtcbiAgICAgIGNhc2UgJyVqJzpcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICByZXR1cm4gSlNPTi5zdHJpbmdpZnkoYXJnc1tpKytdKTtcbiAgICAgICAgfSBjYXRjaCAoXykge1xuICAgICAgICAgIHJldHVybiAnW0NpcmN1bGFyXSc7XG4gICAgICAgIH1cbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIHJldHVybiB4O1xuICAgIH1cbiAgfSk7XG4gIGZvciAodmFyIHggPSBhcmdzW2ldOyBpIDwgbGVuOyB4ID0gYXJnc1srK2ldKSB7XG4gICAgaWYgKGlzTnVsbCh4KSB8fCAhaXNPYmplY3QoeCkpIHtcbiAgICAgIHN0ciArPSAnICcgKyB4O1xuICAgIH0gZWxzZSB7XG4gICAgICBzdHIgKz0gJyAnICsgaW5zcGVjdCh4KTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHN0cjtcbn07XG5cblxuLy8gTWFyayB0aGF0IGEgbWV0aG9kIHNob3VsZCBub3QgYmUgdXNlZC5cbi8vIFJldHVybnMgYSBtb2RpZmllZCBmdW5jdGlvbiB3aGljaCB3YXJucyBvbmNlIGJ5IGRlZmF1bHQuXG4vLyBJZiAtLW5vLWRlcHJlY2F0aW9uIGlzIHNldCwgdGhlbiBpdCBpcyBhIG5vLW9wLlxuZXhwb3J0cy5kZXByZWNhdGUgPSBmdW5jdGlvbihmbiwgbXNnKSB7XG4gIC8vIEFsbG93IGZvciBkZXByZWNhdGluZyB0aGluZ3MgaW4gdGhlIHByb2Nlc3Mgb2Ygc3RhcnRpbmcgdXAuXG4gIGlmIChpc1VuZGVmaW5lZChnbG9iYWwucHJvY2VzcykpIHtcbiAgICByZXR1cm4gZnVuY3Rpb24oKSB7XG4gICAgICByZXR1cm4gZXhwb3J0cy5kZXByZWNhdGUoZm4sIG1zZykuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbiAgICB9O1xuICB9XG5cbiAgaWYgKHByb2Nlc3Mubm9EZXByZWNhdGlvbiA9PT0gdHJ1ZSkge1xuICAgIHJldHVybiBmbjtcbiAgfVxuXG4gIHZhciB3YXJuZWQgPSBmYWxzZTtcbiAgZnVuY3Rpb24gZGVwcmVjYXRlZCgpIHtcbiAgICBpZiAoIXdhcm5lZCkge1xuICAgICAgaWYgKHByb2Nlc3MudGhyb3dEZXByZWNhdGlvbikge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IobXNnKTtcbiAgICAgIH0gZWxzZSBpZiAocHJvY2Vzcy50cmFjZURlcHJlY2F0aW9uKSB7XG4gICAgICAgIGNvbnNvbGUudHJhY2UobXNnKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IobXNnKTtcbiAgICAgIH1cbiAgICAgIHdhcm5lZCA9IHRydWU7XG4gICAgfVxuICAgIHJldHVybiBmbi5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICB9XG5cbiAgcmV0dXJuIGRlcHJlY2F0ZWQ7XG59O1xuXG5cbnZhciBkZWJ1Z3MgPSB7fTtcbnZhciBkZWJ1Z0Vudmlyb247XG5leHBvcnRzLmRlYnVnbG9nID0gZnVuY3Rpb24oc2V0KSB7XG4gIGlmIChpc1VuZGVmaW5lZChkZWJ1Z0Vudmlyb24pKVxuICAgIGRlYnVnRW52aXJvbiA9IHByb2Nlc3MuZW52Lk5PREVfREVCVUcgfHwgJyc7XG4gIHNldCA9IHNldC50b1VwcGVyQ2FzZSgpO1xuICBpZiAoIWRlYnVnc1tzZXRdKSB7XG4gICAgaWYgKG5ldyBSZWdFeHAoJ1xcXFxiJyArIHNldCArICdcXFxcYicsICdpJykudGVzdChkZWJ1Z0Vudmlyb24pKSB7XG4gICAgICB2YXIgcGlkID0gcHJvY2Vzcy5waWQ7XG4gICAgICBkZWJ1Z3Nbc2V0XSA9IGZ1bmN0aW9uKCkge1xuICAgICAgICB2YXIgbXNnID0gZXhwb3J0cy5mb3JtYXQuYXBwbHkoZXhwb3J0cywgYXJndW1lbnRzKTtcbiAgICAgICAgY29uc29sZS5lcnJvcignJXMgJWQ6ICVzJywgc2V0LCBwaWQsIG1zZyk7XG4gICAgICB9O1xuICAgIH0gZWxzZSB7XG4gICAgICBkZWJ1Z3Nbc2V0XSA9IGZ1bmN0aW9uKCkge307XG4gICAgfVxuICB9XG4gIHJldHVybiBkZWJ1Z3Nbc2V0XTtcbn07XG5cblxuLyoqXG4gKiBFY2hvcyB0aGUgdmFsdWUgb2YgYSB2YWx1ZS4gVHJ5cyB0byBwcmludCB0aGUgdmFsdWUgb3V0XG4gKiBpbiB0aGUgYmVzdCB3YXkgcG9zc2libGUgZ2l2ZW4gdGhlIGRpZmZlcmVudCB0eXBlcy5cbiAqXG4gKiBAcGFyYW0ge09iamVjdH0gb2JqIFRoZSBvYmplY3QgdG8gcHJpbnQgb3V0LlxuICogQHBhcmFtIHtPYmplY3R9IG9wdHMgT3B0aW9uYWwgb3B0aW9ucyBvYmplY3QgdGhhdCBhbHRlcnMgdGhlIG91dHB1dC5cbiAqL1xuLyogbGVnYWN5OiBvYmosIHNob3dIaWRkZW4sIGRlcHRoLCBjb2xvcnMqL1xuZnVuY3Rpb24gaW5zcGVjdChvYmosIG9wdHMpIHtcbiAgLy8gZGVmYXVsdCBvcHRpb25zXG4gIHZhciBjdHggPSB7XG4gICAgc2VlbjogW10sXG4gICAgc3R5bGl6ZTogc3R5bGl6ZU5vQ29sb3JcbiAgfTtcbiAgLy8gbGVnYWN5Li4uXG4gIGlmIChhcmd1bWVudHMubGVuZ3RoID49IDMpIGN0eC5kZXB0aCA9IGFyZ3VtZW50c1syXTtcbiAgaWYgKGFyZ3VtZW50cy5sZW5ndGggPj0gNCkgY3R4LmNvbG9ycyA9IGFyZ3VtZW50c1szXTtcbiAgaWYgKGlzQm9vbGVhbihvcHRzKSkge1xuICAgIC8vIGxlZ2FjeS4uLlxuICAgIGN0eC5zaG93SGlkZGVuID0gb3B0cztcbiAgfSBlbHNlIGlmIChvcHRzKSB7XG4gICAgLy8gZ290IGFuIFwib3B0aW9uc1wiIG9iamVjdFxuICAgIGV4cG9ydHMuX2V4dGVuZChjdHgsIG9wdHMpO1xuICB9XG4gIC8vIHNldCBkZWZhdWx0IG9wdGlvbnNcbiAgaWYgKGlzVW5kZWZpbmVkKGN0eC5zaG93SGlkZGVuKSkgY3R4LnNob3dIaWRkZW4gPSBmYWxzZTtcbiAgaWYgKGlzVW5kZWZpbmVkKGN0eC5kZXB0aCkpIGN0eC5kZXB0aCA9IDI7XG4gIGlmIChpc1VuZGVmaW5lZChjdHguY29sb3JzKSkgY3R4LmNvbG9ycyA9IGZhbHNlO1xuICBpZiAoaXNVbmRlZmluZWQoY3R4LmN1c3RvbUluc3BlY3QpKSBjdHguY3VzdG9tSW5zcGVjdCA9IHRydWU7XG4gIGlmIChjdHguY29sb3JzKSBjdHguc3R5bGl6ZSA9IHN0eWxpemVXaXRoQ29sb3I7XG4gIHJldHVybiBmb3JtYXRWYWx1ZShjdHgsIG9iaiwgY3R4LmRlcHRoKTtcbn1cbmV4cG9ydHMuaW5zcGVjdCA9IGluc3BlY3Q7XG5cblxuLy8gaHR0cDovL2VuLndpa2lwZWRpYS5vcmcvd2lraS9BTlNJX2VzY2FwZV9jb2RlI2dyYXBoaWNzXG5pbnNwZWN0LmNvbG9ycyA9IHtcbiAgJ2JvbGQnIDogWzEsIDIyXSxcbiAgJ2l0YWxpYycgOiBbMywgMjNdLFxuICAndW5kZXJsaW5lJyA6IFs0LCAyNF0sXG4gICdpbnZlcnNlJyA6IFs3LCAyN10sXG4gICd3aGl0ZScgOiBbMzcsIDM5XSxcbiAgJ2dyZXknIDogWzkwLCAzOV0sXG4gICdibGFjaycgOiBbMzAsIDM5XSxcbiAgJ2JsdWUnIDogWzM0LCAzOV0sXG4gICdjeWFuJyA6IFszNiwgMzldLFxuICAnZ3JlZW4nIDogWzMyLCAzOV0sXG4gICdtYWdlbnRhJyA6IFszNSwgMzldLFxuICAncmVkJyA6IFszMSwgMzldLFxuICAneWVsbG93JyA6IFszMywgMzldXG59O1xuXG4vLyBEb24ndCB1c2UgJ2JsdWUnIG5vdCB2aXNpYmxlIG9uIGNtZC5leGVcbmluc3BlY3Quc3R5bGVzID0ge1xuICAnc3BlY2lhbCc6ICdjeWFuJyxcbiAgJ251bWJlcic6ICd5ZWxsb3cnLFxuICAnYm9vbGVhbic6ICd5ZWxsb3cnLFxuICAndW5kZWZpbmVkJzogJ2dyZXknLFxuICAnbnVsbCc6ICdib2xkJyxcbiAgJ3N0cmluZyc6ICdncmVlbicsXG4gICdkYXRlJzogJ21hZ2VudGEnLFxuICAvLyBcIm5hbWVcIjogaW50ZW50aW9uYWxseSBub3Qgc3R5bGluZ1xuICAncmVnZXhwJzogJ3JlZCdcbn07XG5cblxuZnVuY3Rpb24gc3R5bGl6ZVdpdGhDb2xvcihzdHIsIHN0eWxlVHlwZSkge1xuICB2YXIgc3R5bGUgPSBpbnNwZWN0LnN0eWxlc1tzdHlsZVR5cGVdO1xuXG4gIGlmIChzdHlsZSkge1xuICAgIHJldHVybiAnXFx1MDAxYlsnICsgaW5zcGVjdC5jb2xvcnNbc3R5bGVdWzBdICsgJ20nICsgc3RyICtcbiAgICAgICAgICAgJ1xcdTAwMWJbJyArIGluc3BlY3QuY29sb3JzW3N0eWxlXVsxXSArICdtJztcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gc3RyO1xuICB9XG59XG5cblxuZnVuY3Rpb24gc3R5bGl6ZU5vQ29sb3Ioc3RyLCBzdHlsZVR5cGUpIHtcbiAgcmV0dXJuIHN0cjtcbn1cblxuXG5mdW5jdGlvbiBhcnJheVRvSGFzaChhcnJheSkge1xuICB2YXIgaGFzaCA9IHt9O1xuXG4gIGFycmF5LmZvckVhY2goZnVuY3Rpb24odmFsLCBpZHgpIHtcbiAgICBoYXNoW3ZhbF0gPSB0cnVlO1xuICB9KTtcblxuICByZXR1cm4gaGFzaDtcbn1cblxuXG5mdW5jdGlvbiBmb3JtYXRWYWx1ZShjdHgsIHZhbHVlLCByZWN1cnNlVGltZXMpIHtcbiAgLy8gUHJvdmlkZSBhIGhvb2sgZm9yIHVzZXItc3BlY2lmaWVkIGluc3BlY3QgZnVuY3Rpb25zLlxuICAvLyBDaGVjayB0aGF0IHZhbHVlIGlzIGFuIG9iamVjdCB3aXRoIGFuIGluc3BlY3QgZnVuY3Rpb24gb24gaXRcbiAgaWYgKGN0eC5jdXN0b21JbnNwZWN0ICYmXG4gICAgICB2YWx1ZSAmJlxuICAgICAgaXNGdW5jdGlvbih2YWx1ZS5pbnNwZWN0KSAmJlxuICAgICAgLy8gRmlsdGVyIG91dCB0aGUgdXRpbCBtb2R1bGUsIGl0J3MgaW5zcGVjdCBmdW5jdGlvbiBpcyBzcGVjaWFsXG4gICAgICB2YWx1ZS5pbnNwZWN0ICE9PSBleHBvcnRzLmluc3BlY3QgJiZcbiAgICAgIC8vIEFsc28gZmlsdGVyIG91dCBhbnkgcHJvdG90eXBlIG9iamVjdHMgdXNpbmcgdGhlIGNpcmN1bGFyIGNoZWNrLlxuICAgICAgISh2YWx1ZS5jb25zdHJ1Y3RvciAmJiB2YWx1ZS5jb25zdHJ1Y3Rvci5wcm90b3R5cGUgPT09IHZhbHVlKSkge1xuICAgIHZhciByZXQgPSB2YWx1ZS5pbnNwZWN0KHJlY3Vyc2VUaW1lcywgY3R4KTtcbiAgICBpZiAoIWlzU3RyaW5nKHJldCkpIHtcbiAgICAgIHJldCA9IGZvcm1hdFZhbHVlKGN0eCwgcmV0LCByZWN1cnNlVGltZXMpO1xuICAgIH1cbiAgICByZXR1cm4gcmV0O1xuICB9XG5cbiAgLy8gUHJpbWl0aXZlIHR5cGVzIGNhbm5vdCBoYXZlIHByb3BlcnRpZXNcbiAgdmFyIHByaW1pdGl2ZSA9IGZvcm1hdFByaW1pdGl2ZShjdHgsIHZhbHVlKTtcbiAgaWYgKHByaW1pdGl2ZSkge1xuICAgIHJldHVybiBwcmltaXRpdmU7XG4gIH1cblxuICAvLyBMb29rIHVwIHRoZSBrZXlzIG9mIHRoZSBvYmplY3QuXG4gIHZhciBrZXlzID0gT2JqZWN0LmtleXModmFsdWUpO1xuICB2YXIgdmlzaWJsZUtleXMgPSBhcnJheVRvSGFzaChrZXlzKTtcblxuICBpZiAoY3R4LnNob3dIaWRkZW4pIHtcbiAgICBrZXlzID0gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXModmFsdWUpO1xuICB9XG5cbiAgLy8gSUUgZG9lc24ndCBtYWtlIGVycm9yIGZpZWxkcyBub24tZW51bWVyYWJsZVxuICAvLyBodHRwOi8vbXNkbi5taWNyb3NvZnQuY29tL2VuLXVzL2xpYnJhcnkvaWUvZHd3NTJzYnQodj12cy45NCkuYXNweFxuICBpZiAoaXNFcnJvcih2YWx1ZSlcbiAgICAgICYmIChrZXlzLmluZGV4T2YoJ21lc3NhZ2UnKSA+PSAwIHx8IGtleXMuaW5kZXhPZignZGVzY3JpcHRpb24nKSA+PSAwKSkge1xuICAgIHJldHVybiBmb3JtYXRFcnJvcih2YWx1ZSk7XG4gIH1cblxuICAvLyBTb21lIHR5cGUgb2Ygb2JqZWN0IHdpdGhvdXQgcHJvcGVydGllcyBjYW4gYmUgc2hvcnRjdXR0ZWQuXG4gIGlmIChrZXlzLmxlbmd0aCA9PT0gMCkge1xuICAgIGlmIChpc0Z1bmN0aW9uKHZhbHVlKSkge1xuICAgICAgdmFyIG5hbWUgPSB2YWx1ZS5uYW1lID8gJzogJyArIHZhbHVlLm5hbWUgOiAnJztcbiAgICAgIHJldHVybiBjdHguc3R5bGl6ZSgnW0Z1bmN0aW9uJyArIG5hbWUgKyAnXScsICdzcGVjaWFsJyk7XG4gICAgfVxuICAgIGlmIChpc1JlZ0V4cCh2YWx1ZSkpIHtcbiAgICAgIHJldHVybiBjdHguc3R5bGl6ZShSZWdFeHAucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwodmFsdWUpLCAncmVnZXhwJyk7XG4gICAgfVxuICAgIGlmIChpc0RhdGUodmFsdWUpKSB7XG4gICAgICByZXR1cm4gY3R4LnN0eWxpemUoRGF0ZS5wcm90b3R5cGUudG9TdHJpbmcuY2FsbCh2YWx1ZSksICdkYXRlJyk7XG4gICAgfVxuICAgIGlmIChpc0Vycm9yKHZhbHVlKSkge1xuICAgICAgcmV0dXJuIGZvcm1hdEVycm9yKHZhbHVlKTtcbiAgICB9XG4gIH1cblxuICB2YXIgYmFzZSA9ICcnLCBhcnJheSA9IGZhbHNlLCBicmFjZXMgPSBbJ3snLCAnfSddO1xuXG4gIC8vIE1ha2UgQXJyYXkgc2F5IHRoYXQgdGhleSBhcmUgQXJyYXlcbiAgaWYgKGlzQXJyYXkodmFsdWUpKSB7XG4gICAgYXJyYXkgPSB0cnVlO1xuICAgIGJyYWNlcyA9IFsnWycsICddJ107XG4gIH1cblxuICAvLyBNYWtlIGZ1bmN0aW9ucyBzYXkgdGhhdCB0aGV5IGFyZSBmdW5jdGlvbnNcbiAgaWYgKGlzRnVuY3Rpb24odmFsdWUpKSB7XG4gICAgdmFyIG4gPSB2YWx1ZS5uYW1lID8gJzogJyArIHZhbHVlLm5hbWUgOiAnJztcbiAgICBiYXNlID0gJyBbRnVuY3Rpb24nICsgbiArICddJztcbiAgfVxuXG4gIC8vIE1ha2UgUmVnRXhwcyBzYXkgdGhhdCB0aGV5IGFyZSBSZWdFeHBzXG4gIGlmIChpc1JlZ0V4cCh2YWx1ZSkpIHtcbiAgICBiYXNlID0gJyAnICsgUmVnRXhwLnByb3RvdHlwZS50b1N0cmluZy5jYWxsKHZhbHVlKTtcbiAgfVxuXG4gIC8vIE1ha2UgZGF0ZXMgd2l0aCBwcm9wZXJ0aWVzIGZpcnN0IHNheSB0aGUgZGF0ZVxuICBpZiAoaXNEYXRlKHZhbHVlKSkge1xuICAgIGJhc2UgPSAnICcgKyBEYXRlLnByb3RvdHlwZS50b1VUQ1N0cmluZy5jYWxsKHZhbHVlKTtcbiAgfVxuXG4gIC8vIE1ha2UgZXJyb3Igd2l0aCBtZXNzYWdlIGZpcnN0IHNheSB0aGUgZXJyb3JcbiAgaWYgKGlzRXJyb3IodmFsdWUpKSB7XG4gICAgYmFzZSA9ICcgJyArIGZvcm1hdEVycm9yKHZhbHVlKTtcbiAgfVxuXG4gIGlmIChrZXlzLmxlbmd0aCA9PT0gMCAmJiAoIWFycmF5IHx8IHZhbHVlLmxlbmd0aCA9PSAwKSkge1xuICAgIHJldHVybiBicmFjZXNbMF0gKyBiYXNlICsgYnJhY2VzWzFdO1xuICB9XG5cbiAgaWYgKHJlY3Vyc2VUaW1lcyA8IDApIHtcbiAgICBpZiAoaXNSZWdFeHAodmFsdWUpKSB7XG4gICAgICByZXR1cm4gY3R4LnN0eWxpemUoUmVnRXhwLnByb3RvdHlwZS50b1N0cmluZy5jYWxsKHZhbHVlKSwgJ3JlZ2V4cCcpO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gY3R4LnN0eWxpemUoJ1tPYmplY3RdJywgJ3NwZWNpYWwnKTtcbiAgICB9XG4gIH1cblxuICBjdHguc2Vlbi5wdXNoKHZhbHVlKTtcblxuICB2YXIgb3V0cHV0O1xuICBpZiAoYXJyYXkpIHtcbiAgICBvdXRwdXQgPSBmb3JtYXRBcnJheShjdHgsIHZhbHVlLCByZWN1cnNlVGltZXMsIHZpc2libGVLZXlzLCBrZXlzKTtcbiAgfSBlbHNlIHtcbiAgICBvdXRwdXQgPSBrZXlzLm1hcChmdW5jdGlvbihrZXkpIHtcbiAgICAgIHJldHVybiBmb3JtYXRQcm9wZXJ0eShjdHgsIHZhbHVlLCByZWN1cnNlVGltZXMsIHZpc2libGVLZXlzLCBrZXksIGFycmF5KTtcbiAgICB9KTtcbiAgfVxuXG4gIGN0eC5zZWVuLnBvcCgpO1xuXG4gIHJldHVybiByZWR1Y2VUb1NpbmdsZVN0cmluZyhvdXRwdXQsIGJhc2UsIGJyYWNlcyk7XG59XG5cblxuZnVuY3Rpb24gZm9ybWF0UHJpbWl0aXZlKGN0eCwgdmFsdWUpIHtcbiAgaWYgKGlzVW5kZWZpbmVkKHZhbHVlKSlcbiAgICByZXR1cm4gY3R4LnN0eWxpemUoJ3VuZGVmaW5lZCcsICd1bmRlZmluZWQnKTtcbiAgaWYgKGlzU3RyaW5nKHZhbHVlKSkge1xuICAgIHZhciBzaW1wbGUgPSAnXFwnJyArIEpTT04uc3RyaW5naWZ5KHZhbHVlKS5yZXBsYWNlKC9eXCJ8XCIkL2csICcnKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnJlcGxhY2UoLycvZywgXCJcXFxcJ1wiKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnJlcGxhY2UoL1xcXFxcIi9nLCAnXCInKSArICdcXCcnO1xuICAgIHJldHVybiBjdHguc3R5bGl6ZShzaW1wbGUsICdzdHJpbmcnKTtcbiAgfVxuICBpZiAoaXNOdW1iZXIodmFsdWUpKVxuICAgIHJldHVybiBjdHguc3R5bGl6ZSgnJyArIHZhbHVlLCAnbnVtYmVyJyk7XG4gIGlmIChpc0Jvb2xlYW4odmFsdWUpKVxuICAgIHJldHVybiBjdHguc3R5bGl6ZSgnJyArIHZhbHVlLCAnYm9vbGVhbicpO1xuICAvLyBGb3Igc29tZSByZWFzb24gdHlwZW9mIG51bGwgaXMgXCJvYmplY3RcIiwgc28gc3BlY2lhbCBjYXNlIGhlcmUuXG4gIGlmIChpc051bGwodmFsdWUpKVxuICAgIHJldHVybiBjdHguc3R5bGl6ZSgnbnVsbCcsICdudWxsJyk7XG59XG5cblxuZnVuY3Rpb24gZm9ybWF0RXJyb3IodmFsdWUpIHtcbiAgcmV0dXJuICdbJyArIEVycm9yLnByb3RvdHlwZS50b1N0cmluZy5jYWxsKHZhbHVlKSArICddJztcbn1cblxuXG5mdW5jdGlvbiBmb3JtYXRBcnJheShjdHgsIHZhbHVlLCByZWN1cnNlVGltZXMsIHZpc2libGVLZXlzLCBrZXlzKSB7XG4gIHZhciBvdXRwdXQgPSBbXTtcbiAgZm9yICh2YXIgaSA9IDAsIGwgPSB2YWx1ZS5sZW5ndGg7IGkgPCBsOyArK2kpIHtcbiAgICBpZiAoaGFzT3duUHJvcGVydHkodmFsdWUsIFN0cmluZyhpKSkpIHtcbiAgICAgIG91dHB1dC5wdXNoKGZvcm1hdFByb3BlcnR5KGN0eCwgdmFsdWUsIHJlY3Vyc2VUaW1lcywgdmlzaWJsZUtleXMsXG4gICAgICAgICAgU3RyaW5nKGkpLCB0cnVlKSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIG91dHB1dC5wdXNoKCcnKTtcbiAgICB9XG4gIH1cbiAga2V5cy5mb3JFYWNoKGZ1bmN0aW9uKGtleSkge1xuICAgIGlmICgha2V5Lm1hdGNoKC9eXFxkKyQvKSkge1xuICAgICAgb3V0cHV0LnB1c2goZm9ybWF0UHJvcGVydHkoY3R4LCB2YWx1ZSwgcmVjdXJzZVRpbWVzLCB2aXNpYmxlS2V5cyxcbiAgICAgICAgICBrZXksIHRydWUpKTtcbiAgICB9XG4gIH0pO1xuICByZXR1cm4gb3V0cHV0O1xufVxuXG5cbmZ1bmN0aW9uIGZvcm1hdFByb3BlcnR5KGN0eCwgdmFsdWUsIHJlY3Vyc2VUaW1lcywgdmlzaWJsZUtleXMsIGtleSwgYXJyYXkpIHtcbiAgdmFyIG5hbWUsIHN0ciwgZGVzYztcbiAgZGVzYyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IodmFsdWUsIGtleSkgfHwgeyB2YWx1ZTogdmFsdWVba2V5XSB9O1xuICBpZiAoZGVzYy5nZXQpIHtcbiAgICBpZiAoZGVzYy5zZXQpIHtcbiAgICAgIHN0ciA9IGN0eC5zdHlsaXplKCdbR2V0dGVyL1NldHRlcl0nLCAnc3BlY2lhbCcpO1xuICAgIH0gZWxzZSB7XG4gICAgICBzdHIgPSBjdHguc3R5bGl6ZSgnW0dldHRlcl0nLCAnc3BlY2lhbCcpO1xuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBpZiAoZGVzYy5zZXQpIHtcbiAgICAgIHN0ciA9IGN0eC5zdHlsaXplKCdbU2V0dGVyXScsICdzcGVjaWFsJyk7XG4gICAgfVxuICB9XG4gIGlmICghaGFzT3duUHJvcGVydHkodmlzaWJsZUtleXMsIGtleSkpIHtcbiAgICBuYW1lID0gJ1snICsga2V5ICsgJ10nO1xuICB9XG4gIGlmICghc3RyKSB7XG4gICAgaWYgKGN0eC5zZWVuLmluZGV4T2YoZGVzYy52YWx1ZSkgPCAwKSB7XG4gICAgICBpZiAoaXNOdWxsKHJlY3Vyc2VUaW1lcykpIHtcbiAgICAgICAgc3RyID0gZm9ybWF0VmFsdWUoY3R4LCBkZXNjLnZhbHVlLCBudWxsKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHN0ciA9IGZvcm1hdFZhbHVlKGN0eCwgZGVzYy52YWx1ZSwgcmVjdXJzZVRpbWVzIC0gMSk7XG4gICAgICB9XG4gICAgICBpZiAoc3RyLmluZGV4T2YoJ1xcbicpID4gLTEpIHtcbiAgICAgICAgaWYgKGFycmF5KSB7XG4gICAgICAgICAgc3RyID0gc3RyLnNwbGl0KCdcXG4nKS5tYXAoZnVuY3Rpb24obGluZSkge1xuICAgICAgICAgICAgcmV0dXJuICcgICcgKyBsaW5lO1xuICAgICAgICAgIH0pLmpvaW4oJ1xcbicpLnN1YnN0cigyKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBzdHIgPSAnXFxuJyArIHN0ci5zcGxpdCgnXFxuJykubWFwKGZ1bmN0aW9uKGxpbmUpIHtcbiAgICAgICAgICAgIHJldHVybiAnICAgJyArIGxpbmU7XG4gICAgICAgICAgfSkuam9pbignXFxuJyk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgc3RyID0gY3R4LnN0eWxpemUoJ1tDaXJjdWxhcl0nLCAnc3BlY2lhbCcpO1xuICAgIH1cbiAgfVxuICBpZiAoaXNVbmRlZmluZWQobmFtZSkpIHtcbiAgICBpZiAoYXJyYXkgJiYga2V5Lm1hdGNoKC9eXFxkKyQvKSkge1xuICAgICAgcmV0dXJuIHN0cjtcbiAgICB9XG4gICAgbmFtZSA9IEpTT04uc3RyaW5naWZ5KCcnICsga2V5KTtcbiAgICBpZiAobmFtZS5tYXRjaCgvXlwiKFthLXpBLVpfXVthLXpBLVpfMC05XSopXCIkLykpIHtcbiAgICAgIG5hbWUgPSBuYW1lLnN1YnN0cigxLCBuYW1lLmxlbmd0aCAtIDIpO1xuICAgICAgbmFtZSA9IGN0eC5zdHlsaXplKG5hbWUsICduYW1lJyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIG5hbWUgPSBuYW1lLnJlcGxhY2UoLycvZywgXCJcXFxcJ1wiKVxuICAgICAgICAgICAgICAgICAucmVwbGFjZSgvXFxcXFwiL2csICdcIicpXG4gICAgICAgICAgICAgICAgIC5yZXBsYWNlKC8oXlwifFwiJCkvZywgXCInXCIpO1xuICAgICAgbmFtZSA9IGN0eC5zdHlsaXplKG5hbWUsICdzdHJpbmcnKTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gbmFtZSArICc6ICcgKyBzdHI7XG59XG5cblxuZnVuY3Rpb24gcmVkdWNlVG9TaW5nbGVTdHJpbmcob3V0cHV0LCBiYXNlLCBicmFjZXMpIHtcbiAgdmFyIG51bUxpbmVzRXN0ID0gMDtcbiAgdmFyIGxlbmd0aCA9IG91dHB1dC5yZWR1Y2UoZnVuY3Rpb24ocHJldiwgY3VyKSB7XG4gICAgbnVtTGluZXNFc3QrKztcbiAgICBpZiAoY3VyLmluZGV4T2YoJ1xcbicpID49IDApIG51bUxpbmVzRXN0Kys7XG4gICAgcmV0dXJuIHByZXYgKyBjdXIucmVwbGFjZSgvXFx1MDAxYlxcW1xcZFxcZD9tL2csICcnKS5sZW5ndGggKyAxO1xuICB9LCAwKTtcblxuICBpZiAobGVuZ3RoID4gNjApIHtcbiAgICByZXR1cm4gYnJhY2VzWzBdICtcbiAgICAgICAgICAgKGJhc2UgPT09ICcnID8gJycgOiBiYXNlICsgJ1xcbiAnKSArXG4gICAgICAgICAgICcgJyArXG4gICAgICAgICAgIG91dHB1dC5qb2luKCcsXFxuICAnKSArXG4gICAgICAgICAgICcgJyArXG4gICAgICAgICAgIGJyYWNlc1sxXTtcbiAgfVxuXG4gIHJldHVybiBicmFjZXNbMF0gKyBiYXNlICsgJyAnICsgb3V0cHV0LmpvaW4oJywgJykgKyAnICcgKyBicmFjZXNbMV07XG59XG5cblxuLy8gTk9URTogVGhlc2UgdHlwZSBjaGVja2luZyBmdW5jdGlvbnMgaW50ZW50aW9uYWxseSBkb24ndCB1c2UgYGluc3RhbmNlb2ZgXG4vLyBiZWNhdXNlIGl0IGlzIGZyYWdpbGUgYW5kIGNhbiBiZSBlYXNpbHkgZmFrZWQgd2l0aCBgT2JqZWN0LmNyZWF0ZSgpYC5cbmZ1bmN0aW9uIGlzQXJyYXkoYXIpIHtcbiAgcmV0dXJuIEFycmF5LmlzQXJyYXkoYXIpO1xufVxuZXhwb3J0cy5pc0FycmF5ID0gaXNBcnJheTtcblxuZnVuY3Rpb24gaXNCb29sZWFuKGFyZykge1xuICByZXR1cm4gdHlwZW9mIGFyZyA9PT0gJ2Jvb2xlYW4nO1xufVxuZXhwb3J0cy5pc0Jvb2xlYW4gPSBpc0Jvb2xlYW47XG5cbmZ1bmN0aW9uIGlzTnVsbChhcmcpIHtcbiAgcmV0dXJuIGFyZyA9PT0gbnVsbDtcbn1cbmV4cG9ydHMuaXNOdWxsID0gaXNOdWxsO1xuXG5mdW5jdGlvbiBpc051bGxPclVuZGVmaW5lZChhcmcpIHtcbiAgcmV0dXJuIGFyZyA9PSBudWxsO1xufVxuZXhwb3J0cy5pc051bGxPclVuZGVmaW5lZCA9IGlzTnVsbE9yVW5kZWZpbmVkO1xuXG5mdW5jdGlvbiBpc051bWJlcihhcmcpIHtcbiAgcmV0dXJuIHR5cGVvZiBhcmcgPT09ICdudW1iZXInO1xufVxuZXhwb3J0cy5pc051bWJlciA9IGlzTnVtYmVyO1xuXG5mdW5jdGlvbiBpc1N0cmluZyhhcmcpIHtcbiAgcmV0dXJuIHR5cGVvZiBhcmcgPT09ICdzdHJpbmcnO1xufVxuZXhwb3J0cy5pc1N0cmluZyA9IGlzU3RyaW5nO1xuXG5mdW5jdGlvbiBpc1N5bWJvbChhcmcpIHtcbiAgcmV0dXJuIHR5cGVvZiBhcmcgPT09ICdzeW1ib2wnO1xufVxuZXhwb3J0cy5pc1N5bWJvbCA9IGlzU3ltYm9sO1xuXG5mdW5jdGlvbiBpc1VuZGVmaW5lZChhcmcpIHtcbiAgcmV0dXJuIGFyZyA9PT0gdm9pZCAwO1xufVxuZXhwb3J0cy5pc1VuZGVmaW5lZCA9IGlzVW5kZWZpbmVkO1xuXG5mdW5jdGlvbiBpc1JlZ0V4cChyZSkge1xuICByZXR1cm4gaXNPYmplY3QocmUpICYmIG9iamVjdFRvU3RyaW5nKHJlKSA9PT0gJ1tvYmplY3QgUmVnRXhwXSc7XG59XG5leHBvcnRzLmlzUmVnRXhwID0gaXNSZWdFeHA7XG5cbmZ1bmN0aW9uIGlzT2JqZWN0KGFyZykge1xuICByZXR1cm4gdHlwZW9mIGFyZyA9PT0gJ29iamVjdCcgJiYgYXJnICE9PSBudWxsO1xufVxuZXhwb3J0cy5pc09iamVjdCA9IGlzT2JqZWN0O1xuXG5mdW5jdGlvbiBpc0RhdGUoZCkge1xuICByZXR1cm4gaXNPYmplY3QoZCkgJiYgb2JqZWN0VG9TdHJpbmcoZCkgPT09ICdbb2JqZWN0IERhdGVdJztcbn1cbmV4cG9ydHMuaXNEYXRlID0gaXNEYXRlO1xuXG5mdW5jdGlvbiBpc0Vycm9yKGUpIHtcbiAgcmV0dXJuIGlzT2JqZWN0KGUpICYmXG4gICAgICAob2JqZWN0VG9TdHJpbmcoZSkgPT09ICdbb2JqZWN0IEVycm9yXScgfHwgZSBpbnN0YW5jZW9mIEVycm9yKTtcbn1cbmV4cG9ydHMuaXNFcnJvciA9IGlzRXJyb3I7XG5cbmZ1bmN0aW9uIGlzRnVuY3Rpb24oYXJnKSB7XG4gIHJldHVybiB0eXBlb2YgYXJnID09PSAnZnVuY3Rpb24nO1xufVxuZXhwb3J0cy5pc0Z1bmN0aW9uID0gaXNGdW5jdGlvbjtcblxuZnVuY3Rpb24gaXNQcmltaXRpdmUoYXJnKSB7XG4gIHJldHVybiBhcmcgPT09IG51bGwgfHxcbiAgICAgICAgIHR5cGVvZiBhcmcgPT09ICdib29sZWFuJyB8fFxuICAgICAgICAgdHlwZW9mIGFyZyA9PT0gJ251bWJlcicgfHxcbiAgICAgICAgIHR5cGVvZiBhcmcgPT09ICdzdHJpbmcnIHx8XG4gICAgICAgICB0eXBlb2YgYXJnID09PSAnc3ltYm9sJyB8fCAgLy8gRVM2IHN5bWJvbFxuICAgICAgICAgdHlwZW9mIGFyZyA9PT0gJ3VuZGVmaW5lZCc7XG59XG5leHBvcnRzLmlzUHJpbWl0aXZlID0gaXNQcmltaXRpdmU7XG5cbmV4cG9ydHMuaXNCdWZmZXIgPSByZXF1aXJlKCcuL3N1cHBvcnQvaXNCdWZmZXInKTtcblxuZnVuY3Rpb24gb2JqZWN0VG9TdHJpbmcobykge1xuICByZXR1cm4gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKG8pO1xufVxuXG5cbmZ1bmN0aW9uIHBhZChuKSB7XG4gIHJldHVybiBuIDwgMTAgPyAnMCcgKyBuLnRvU3RyaW5nKDEwKSA6IG4udG9TdHJpbmcoMTApO1xufVxuXG5cbnZhciBtb250aHMgPSBbJ0phbicsICdGZWInLCAnTWFyJywgJ0FwcicsICdNYXknLCAnSnVuJywgJ0p1bCcsICdBdWcnLCAnU2VwJyxcbiAgICAgICAgICAgICAgJ09jdCcsICdOb3YnLCAnRGVjJ107XG5cbi8vIDI2IEZlYiAxNjoxOTozNFxuZnVuY3Rpb24gdGltZXN0YW1wKCkge1xuICB2YXIgZCA9IG5ldyBEYXRlKCk7XG4gIHZhciB0aW1lID0gW3BhZChkLmdldEhvdXJzKCkpLFxuICAgICAgICAgICAgICBwYWQoZC5nZXRNaW51dGVzKCkpLFxuICAgICAgICAgICAgICBwYWQoZC5nZXRTZWNvbmRzKCkpXS5qb2luKCc6Jyk7XG4gIHJldHVybiBbZC5nZXREYXRlKCksIG1vbnRoc1tkLmdldE1vbnRoKCldLCB0aW1lXS5qb2luKCcgJyk7XG59XG5cblxuLy8gbG9nIGlzIGp1c3QgYSB0aGluIHdyYXBwZXIgdG8gY29uc29sZS5sb2cgdGhhdCBwcmVwZW5kcyBhIHRpbWVzdGFtcFxuZXhwb3J0cy5sb2cgPSBmdW5jdGlvbigpIHtcbiAgY29uc29sZS5sb2coJyVzIC0gJXMnLCB0aW1lc3RhbXAoKSwgZXhwb3J0cy5mb3JtYXQuYXBwbHkoZXhwb3J0cywgYXJndW1lbnRzKSk7XG59O1xuXG5cbi8qKlxuICogSW5oZXJpdCB0aGUgcHJvdG90eXBlIG1ldGhvZHMgZnJvbSBvbmUgY29uc3RydWN0b3IgaW50byBhbm90aGVyLlxuICpcbiAqIFRoZSBGdW5jdGlvbi5wcm90b3R5cGUuaW5oZXJpdHMgZnJvbSBsYW5nLmpzIHJld3JpdHRlbiBhcyBhIHN0YW5kYWxvbmVcbiAqIGZ1bmN0aW9uIChub3Qgb24gRnVuY3Rpb24ucHJvdG90eXBlKS4gTk9URTogSWYgdGhpcyBmaWxlIGlzIHRvIGJlIGxvYWRlZFxuICogZHVyaW5nIGJvb3RzdHJhcHBpbmcgdGhpcyBmdW5jdGlvbiBuZWVkcyB0byBiZSByZXdyaXR0ZW4gdXNpbmcgc29tZSBuYXRpdmVcbiAqIGZ1bmN0aW9ucyBhcyBwcm90b3R5cGUgc2V0dXAgdXNpbmcgbm9ybWFsIEphdmFTY3JpcHQgZG9lcyBub3Qgd29yayBhc1xuICogZXhwZWN0ZWQgZHVyaW5nIGJvb3RzdHJhcHBpbmcgKHNlZSBtaXJyb3IuanMgaW4gcjExNDkwMykuXG4gKlxuICogQHBhcmFtIHtmdW5jdGlvbn0gY3RvciBDb25zdHJ1Y3RvciBmdW5jdGlvbiB3aGljaCBuZWVkcyB0byBpbmhlcml0IHRoZVxuICogICAgIHByb3RvdHlwZS5cbiAqIEBwYXJhbSB7ZnVuY3Rpb259IHN1cGVyQ3RvciBDb25zdHJ1Y3RvciBmdW5jdGlvbiB0byBpbmhlcml0IHByb3RvdHlwZSBmcm9tLlxuICovXG5leHBvcnRzLmluaGVyaXRzID0gcmVxdWlyZSgnaW5oZXJpdHMnKTtcblxuZXhwb3J0cy5fZXh0ZW5kID0gZnVuY3Rpb24ob3JpZ2luLCBhZGQpIHtcbiAgLy8gRG9uJ3QgZG8gYW55dGhpbmcgaWYgYWRkIGlzbid0IGFuIG9iamVjdFxuICBpZiAoIWFkZCB8fCAhaXNPYmplY3QoYWRkKSkgcmV0dXJuIG9yaWdpbjtcblxuICB2YXIga2V5cyA9IE9iamVjdC5rZXlzKGFkZCk7XG4gIHZhciBpID0ga2V5cy5sZW5ndGg7XG4gIHdoaWxlIChpLS0pIHtcbiAgICBvcmlnaW5ba2V5c1tpXV0gPSBhZGRba2V5c1tpXV07XG4gIH1cbiAgcmV0dXJuIG9yaWdpbjtcbn07XG5cbmZ1bmN0aW9uIGhhc093blByb3BlcnR5KG9iaiwgcHJvcCkge1xuICByZXR1cm4gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iaiwgcHJvcCk7XG59XG5cbn0pLmNhbGwodGhpcyxyZXF1aXJlKCdfcHJvY2VzcycpLHR5cGVvZiBnbG9iYWwgIT09IFwidW5kZWZpbmVkXCIgPyBnbG9iYWwgOiB0eXBlb2Ygc2VsZiAhPT0gXCJ1bmRlZmluZWRcIiA/IHNlbGYgOiB0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiID8gd2luZG93IDoge30pXG4vLyMgc291cmNlTWFwcGluZ1VSTD1kYXRhOmFwcGxpY2F0aW9uL2pzb247Y2hhcnNldDp1dGYtODtiYXNlNjQsZXlKMlpYSnphVzl1SWpvekxDSnpiM1Z5WTJWeklqcGJJaTR1THk0dUx5NHVMeTR1TDI1dlpHVmZiVzlrZFd4bGN5OTFkR2xzTDNWMGFXd3Vhbk1pWFN3aWJtRnRaWE1pT2x0ZExDSnRZWEJ3YVc1bmN5STZJanRCUVVGQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEU3UVVGRFFUdEJRVU5CTzBGQlEwRTdRVUZEUVR0QlFVTkJPMEZCUTBFN1FVRkRRVHRCUVVOQk8wRkJRMEVpTENKbWFXeGxJam9pWjJWdVpYSmhkR1ZrTG1weklpd2ljMjkxY21ObFVtOXZkQ0k2SWlJc0luTnZkWEpqWlhORGIyNTBaVzUwSWpwYklpOHZJRU52Y0hseWFXZG9kQ0JLYjNsbGJuUXNJRWx1WXk0Z1lXNWtJRzkwYUdWeUlFNXZaR1VnWTI5dWRISnBZblYwYjNKekxseHVMeTljYmk4dklGQmxjbTFwYzNOcGIyNGdhWE1nYUdWeVpXSjVJR2R5WVc1MFpXUXNJR1p5WldVZ2IyWWdZMmhoY21kbExDQjBieUJoYm5rZ2NHVnljMjl1SUc5aWRHRnBibWx1WnlCaFhHNHZMeUJqYjNCNUlHOW1JSFJvYVhNZ2MyOW1kSGRoY21VZ1lXNWtJR0Z6YzI5amFXRjBaV1FnWkc5amRXMWxiblJoZEdsdmJpQm1hV3hsY3lBb2RHaGxYRzR2THlCY0lsTnZablIzWVhKbFhDSXBMQ0IwYnlCa1pXRnNJR2x1SUhSb1pTQlRiMlowZDJGeVpTQjNhWFJvYjNWMElISmxjM1J5YVdOMGFXOXVMQ0JwYm1Oc2RXUnBibWRjYmk4dklIZHBkR2h2ZFhRZ2JHbHRhWFJoZEdsdmJpQjBhR1VnY21sbmFIUnpJSFJ2SUhWelpTd2dZMjl3ZVN3Z2JXOWthV1o1TENCdFpYSm5aU3dnY0hWaWJHbHphQ3hjYmk4dklHUnBjM1J5YVdKMWRHVXNJSE4xWW14cFkyVnVjMlVzSUdGdVpDOXZjaUJ6Wld4c0lHTnZjR2xsY3lCdlppQjBhR1VnVTI5bWRIZGhjbVVzSUdGdVpDQjBieUJ3WlhKdGFYUmNiaTh2SUhCbGNuTnZibk1nZEc4Z2QyaHZiU0IwYUdVZ1UyOW1kSGRoY21VZ2FYTWdablZ5Ym1semFHVmtJSFJ2SUdSdklITnZMQ0J6ZFdKcVpXTjBJSFJ2SUhSb1pWeHVMeThnWm05c2JHOTNhVzVuSUdOdmJtUnBkR2x2Ym5NNlhHNHZMMXh1THk4Z1ZHaGxJR0ZpYjNabElHTnZjSGx5YVdkb2RDQnViM1JwWTJVZ1lXNWtJSFJvYVhNZ2NHVnliV2x6YzJsdmJpQnViM1JwWTJVZ2MyaGhiR3dnWW1VZ2FXNWpiSFZrWldSY2JpOHZJR2x1SUdGc2JDQmpiM0JwWlhNZ2IzSWdjM1ZpYzNSaGJuUnBZV3dnY0c5eWRHbHZibk1nYjJZZ2RHaGxJRk52Wm5SM1lYSmxMbHh1THk5Y2JpOHZJRlJJUlNCVFQwWlVWMEZTUlNCSlV5QlFVazlXU1VSRlJDQmNJa0ZUSUVsVFhDSXNJRmRKVkVoUFZWUWdWMEZTVWtGT1ZGa2dUMFlnUVU1WklFdEpUa1FzSUVWWVVGSkZVMU5jYmk4dklFOVNJRWxOVUV4SlJVUXNJRWxPUTB4VlJFbE9SeUJDVlZRZ1RrOVVJRXhKVFVsVVJVUWdWRThnVkVoRklGZEJVbEpCVGxSSlJWTWdUMFpjYmk4dklFMUZVa05JUVU1VVFVSkpURWxVV1N3Z1JrbFVUa1ZUVXlCR1QxSWdRU0JRUVZKVVNVTlZURUZTSUZCVlVsQlBVMFVnUVU1RUlFNVBUa2xPUmxKSlRrZEZUVVZPVkM0Z1NVNWNiaTh2SUU1UElFVldSVTVVSUZOSVFVeE1JRlJJUlNCQlZWUklUMUpUSUU5U0lFTlBVRmxTU1VkSVZDQklUMHhFUlZKVElFSkZJRXhKUVVKTVJTQkdUMUlnUVU1WklFTk1RVWxOTEZ4dUx5OGdSRUZOUVVkRlV5QlBVaUJQVkVoRlVpQk1TVUZDU1V4SlZGa3NJRmRJUlZSSVJWSWdTVTRnUVU0Z1FVTlVTVTlPSUU5R0lFTlBUbFJTUVVOVUxDQlVUMUpVSUU5U1hHNHZMeUJQVkVoRlVsZEpVMFVzSUVGU1NWTkpUa2NnUmxKUFRTd2dUMVZVSUU5R0lFOVNJRWxPSUVOUFRrNUZRMVJKVDA0Z1YwbFVTQ0JVU0VVZ1UwOUdWRmRCVWtVZ1QxSWdWRWhGWEc0dkx5QlZVMFVnVDFJZ1QxUklSVklnUkVWQlRFbE9SMU1nU1U0Z1ZFaEZJRk5QUmxSWFFWSkZMbHh1WEc1MllYSWdabTl5YldGMFVtVm5SWGh3SUQwZ0x5VmJjMlJxSlYwdlp6dGNibVY0Y0c5eWRITXVabTl5YldGMElEMGdablZ1WTNScGIyNG9aaWtnZTF4dUlDQnBaaUFvSVdselUzUnlhVzVuS0dZcEtTQjdYRzRnSUNBZ2RtRnlJRzlpYW1WamRITWdQU0JiWFR0Y2JpQWdJQ0JtYjNJZ0tIWmhjaUJwSUQwZ01Ec2dhU0E4SUdGeVozVnRaVzUwY3k1c1pXNW5kR2c3SUdrckt5a2dlMXh1SUNBZ0lDQWdiMkpxWldOMGN5NXdkWE5vS0dsdWMzQmxZM1FvWVhKbmRXMWxiblJ6VzJsZEtTazdYRzRnSUNBZ2ZWeHVJQ0FnSUhKbGRIVnliaUJ2WW1wbFkzUnpMbXB2YVc0b0p5QW5LVHRjYmlBZ2ZWeHVYRzRnSUhaaGNpQnBJRDBnTVR0Y2JpQWdkbUZ5SUdGeVozTWdQU0JoY21kMWJXVnVkSE03WEc0Z0lIWmhjaUJzWlc0Z1BTQmhjbWR6TG14bGJtZDBhRHRjYmlBZ2RtRnlJSE4wY2lBOUlGTjBjbWx1WnlobUtTNXlaWEJzWVdObEtHWnZjbTFoZEZKbFowVjRjQ3dnWm5WdVkzUnBiMjRvZUNrZ2UxeHVJQ0FnSUdsbUlDaDRJRDA5UFNBbkpTVW5LU0J5WlhSMWNtNGdKeVVuTzF4dUlDQWdJR2xtSUNocElENDlJR3hsYmlrZ2NtVjBkWEp1SUhnN1hHNGdJQ0FnYzNkcGRHTm9JQ2g0S1NCN1hHNGdJQ0FnSUNCallYTmxJQ2NsY3ljNklISmxkSFZ5YmlCVGRISnBibWNvWVhKbmMxdHBLeXRkS1R0Y2JpQWdJQ0FnSUdOaGMyVWdKeVZrSnpvZ2NtVjBkWEp1SUU1MWJXSmxjaWhoY21kelcya3JLMTBwTzF4dUlDQWdJQ0FnWTJGelpTQW5KV29uT2x4dUlDQWdJQ0FnSUNCMGNua2dlMXh1SUNBZ0lDQWdJQ0FnSUhKbGRIVnliaUJLVTA5T0xuTjBjbWx1WjJsbWVTaGhjbWR6VzJrcksxMHBPMXh1SUNBZ0lDQWdJQ0I5SUdOaGRHTm9JQ2hmS1NCN1hHNGdJQ0FnSUNBZ0lDQWdjbVYwZFhKdUlDZGJRMmx5WTNWc1lYSmRKenRjYmlBZ0lDQWdJQ0FnZlZ4dUlDQWdJQ0FnWkdWbVlYVnNkRHBjYmlBZ0lDQWdJQ0FnY21WMGRYSnVJSGc3WEc0Z0lDQWdmVnh1SUNCOUtUdGNiaUFnWm05eUlDaDJZWElnZUNBOUlHRnlaM05iYVYwN0lHa2dQQ0JzWlc0N0lIZ2dQU0JoY21keld5c3JhVjBwSUh0Y2JpQWdJQ0JwWmlBb2FYTk9kV3hzS0hncElIeDhJQ0ZwYzA5aWFtVmpkQ2g0S1NrZ2UxeHVJQ0FnSUNBZ2MzUnlJQ3M5SUNjZ0p5QXJJSGc3WEc0Z0lDQWdmU0JsYkhObElIdGNiaUFnSUNBZ0lITjBjaUFyUFNBbklDY2dLeUJwYm5Od1pXTjBLSGdwTzF4dUlDQWdJSDFjYmlBZ2ZWeHVJQ0J5WlhSMWNtNGdjM1J5TzF4dWZUdGNibHh1WEc0dkx5Qk5ZWEpySUhSb1lYUWdZU0J0WlhSb2IyUWdjMmh2ZFd4a0lHNXZkQ0JpWlNCMWMyVmtMbHh1THk4Z1VtVjBkWEp1Y3lCaElHMXZaR2xtYVdWa0lHWjFibU4wYVc5dUlIZG9hV05vSUhkaGNtNXpJRzl1WTJVZ1lua2daR1ZtWVhWc2RDNWNiaTh2SUVsbUlDMHRibTh0WkdWd2NtVmpZWFJwYjI0Z2FYTWdjMlYwTENCMGFHVnVJR2wwSUdseklHRWdibTh0YjNBdVhHNWxlSEJ2Y25SekxtUmxjSEpsWTJGMFpTQTlJR1oxYm1OMGFXOXVLR1p1TENCdGMyY3BJSHRjYmlBZ0x5OGdRV3hzYjNjZ1ptOXlJR1JsY0hKbFkyRjBhVzVuSUhSb2FXNW5jeUJwYmlCMGFHVWdjSEp2WTJWemN5QnZaaUJ6ZEdGeWRHbHVaeUIxY0M1Y2JpQWdhV1lnS0dselZXNWtaV1pwYm1Wa0tHZHNiMkpoYkM1d2NtOWpaWE56S1NrZ2UxeHVJQ0FnSUhKbGRIVnliaUJtZFc1amRHbHZiaWdwSUh0Y2JpQWdJQ0FnSUhKbGRIVnliaUJsZUhCdmNuUnpMbVJsY0hKbFkyRjBaU2htYml3Z2JYTm5LUzVoY0hCc2VTaDBhR2x6TENCaGNtZDFiV1Z1ZEhNcE8xeHVJQ0FnSUgwN1hHNGdJSDFjYmx4dUlDQnBaaUFvY0hKdlkyVnpjeTV1YjBSbGNISmxZMkYwYVc5dUlEMDlQU0IwY25WbEtTQjdYRzRnSUNBZ2NtVjBkWEp1SUdadU8xeHVJQ0I5WEc1Y2JpQWdkbUZ5SUhkaGNtNWxaQ0E5SUdaaGJITmxPMXh1SUNCbWRXNWpkR2x2YmlCa1pYQnlaV05oZEdWa0tDa2dlMXh1SUNBZ0lHbG1JQ2doZDJGeWJtVmtLU0I3WEc0Z0lDQWdJQ0JwWmlBb2NISnZZMlZ6Y3k1MGFISnZkMFJsY0hKbFkyRjBhVzl1S1NCN1hHNGdJQ0FnSUNBZ0lIUm9jbTkzSUc1bGR5QkZjbkp2Y2lodGMyY3BPMXh1SUNBZ0lDQWdmU0JsYkhObElHbG1JQ2h3Y205alpYTnpMblJ5WVdObFJHVndjbVZqWVhScGIyNHBJSHRjYmlBZ0lDQWdJQ0FnWTI5dWMyOXNaUzUwY21GalpTaHRjMmNwTzF4dUlDQWdJQ0FnZlNCbGJITmxJSHRjYmlBZ0lDQWdJQ0FnWTI5dWMyOXNaUzVsY25KdmNpaHRjMmNwTzF4dUlDQWdJQ0FnZlZ4dUlDQWdJQ0FnZDJGeWJtVmtJRDBnZEhKMVpUdGNiaUFnSUNCOVhHNGdJQ0FnY21WMGRYSnVJR1p1TG1Gd2NHeDVLSFJvYVhNc0lHRnlaM1Z0Wlc1MGN5azdYRzRnSUgxY2JseHVJQ0J5WlhSMWNtNGdaR1Z3Y21WallYUmxaRHRjYm4wN1hHNWNibHh1ZG1GeUlHUmxZblZuY3lBOUlIdDlPMXh1ZG1GeUlHUmxZblZuUlc1MmFYSnZianRjYm1WNGNHOXlkSE11WkdWaWRXZHNiMmNnUFNCbWRXNWpkR2x2YmloelpYUXBJSHRjYmlBZ2FXWWdLR2x6Vlc1a1pXWnBibVZrS0dSbFluVm5SVzUyYVhKdmJpa3BYRzRnSUNBZ1pHVmlkV2RGYm5acGNtOXVJRDBnY0hKdlkyVnpjeTVsYm5ZdVRrOUVSVjlFUlVKVlJ5QjhmQ0FuSnp0Y2JpQWdjMlYwSUQwZ2MyVjBMblJ2VlhCd1pYSkRZWE5sS0NrN1hHNGdJR2xtSUNnaFpHVmlkV2R6VzNObGRGMHBJSHRjYmlBZ0lDQnBaaUFvYm1WM0lGSmxaMFY0Y0NnblhGeGNYR0luSUNzZ2MyVjBJQ3NnSjF4Y1hGeGlKeXdnSjJrbktTNTBaWE4wS0dSbFluVm5SVzUyYVhKdmJpa3BJSHRjYmlBZ0lDQWdJSFpoY2lCd2FXUWdQU0J3Y205alpYTnpMbkJwWkR0Y2JpQWdJQ0FnSUdSbFluVm5jMXR6WlhSZElEMGdablZ1WTNScGIyNG9LU0I3WEc0Z0lDQWdJQ0FnSUhaaGNpQnRjMmNnUFNCbGVIQnZjblJ6TG1admNtMWhkQzVoY0hCc2VTaGxlSEJ2Y25SekxDQmhjbWQxYldWdWRITXBPMXh1SUNBZ0lDQWdJQ0JqYjI1emIyeGxMbVZ5Y205eUtDY2xjeUFsWkRvZ0pYTW5MQ0J6WlhRc0lIQnBaQ3dnYlhObktUdGNiaUFnSUNBZ0lIMDdYRzRnSUNBZ2ZTQmxiSE5sSUh0Y2JpQWdJQ0FnSUdSbFluVm5jMXR6WlhSZElEMGdablZ1WTNScGIyNG9LU0I3ZlR0Y2JpQWdJQ0I5WEc0Z0lIMWNiaUFnY21WMGRYSnVJR1JsWW5WbmMxdHpaWFJkTzF4dWZUdGNibHh1WEc0dktpcGNiaUFxSUVWamFHOXpJSFJvWlNCMllXeDFaU0J2WmlCaElIWmhiSFZsTGlCVWNubHpJSFJ2SUhCeWFXNTBJSFJvWlNCMllXeDFaU0J2ZFhSY2JpQXFJR2x1SUhSb1pTQmlaWE4wSUhkaGVTQndiM056YVdKc1pTQm5hWFpsYmlCMGFHVWdaR2xtWm1WeVpXNTBJSFI1Y0dWekxseHVJQ3BjYmlBcUlFQndZWEpoYlNCN1QySnFaV04wZlNCdlltb2dWR2hsSUc5aWFtVmpkQ0IwYnlCd2NtbHVkQ0J2ZFhRdVhHNGdLaUJBY0dGeVlXMGdlMDlpYW1WamRIMGdiM0IwY3lCUGNIUnBiMjVoYkNCdmNIUnBiMjV6SUc5aWFtVmpkQ0IwYUdGMElHRnNkR1Z5Y3lCMGFHVWdiM1YwY0hWMExseHVJQ292WEc0dktpQnNaV2RoWTNrNklHOWlhaXdnYzJodmQwaHBaR1JsYml3Z1pHVndkR2dzSUdOdmJHOXljeW92WEc1bWRXNWpkR2x2YmlCcGJuTndaV04wS0c5aWFpd2diM0IwY3lrZ2UxeHVJQ0F2THlCa1pXWmhkV3gwSUc5d2RHbHZibk5jYmlBZ2RtRnlJR04wZUNBOUlIdGNiaUFnSUNCelpXVnVPaUJiWFN4Y2JpQWdJQ0J6ZEhsc2FYcGxPaUJ6ZEhsc2FYcGxUbTlEYjJ4dmNseHVJQ0I5TzF4dUlDQXZMeUJzWldkaFkza3VMaTVjYmlBZ2FXWWdLR0Z5WjNWdFpXNTBjeTVzWlc1bmRHZ2dQajBnTXlrZ1kzUjRMbVJsY0hSb0lEMGdZWEpuZFcxbGJuUnpXekpkTzF4dUlDQnBaaUFvWVhKbmRXMWxiblJ6TG14bGJtZDBhQ0ErUFNBMEtTQmpkSGd1WTI5c2IzSnpJRDBnWVhKbmRXMWxiblJ6V3pOZE8xeHVJQ0JwWmlBb2FYTkNiMjlzWldGdUtHOXdkSE1wS1NCN1hHNGdJQ0FnTHk4Z2JHVm5ZV041TGk0dVhHNGdJQ0FnWTNSNExuTm9iM2RJYVdSa1pXNGdQU0J2Y0hSek8xeHVJQ0I5SUdWc2MyVWdhV1lnS0c5d2RITXBJSHRjYmlBZ0lDQXZMeUJuYjNRZ1lXNGdYQ0p2Y0hScGIyNXpYQ0lnYjJKcVpXTjBYRzRnSUNBZ1pYaHdiM0owY3k1ZlpYaDBaVzVrS0dOMGVDd2diM0IwY3lrN1hHNGdJSDFjYmlBZ0x5OGdjMlYwSUdSbFptRjFiSFFnYjNCMGFXOXVjMXh1SUNCcFppQW9hWE5WYm1SbFptbHVaV1FvWTNSNExuTm9iM2RJYVdSa1pXNHBLU0JqZEhndWMyaHZkMGhwWkdSbGJpQTlJR1poYkhObE8xeHVJQ0JwWmlBb2FYTlZibVJsWm1sdVpXUW9ZM1I0TG1SbGNIUm9LU2tnWTNSNExtUmxjSFJvSUQwZ01qdGNiaUFnYVdZZ0tHbHpWVzVrWldacGJtVmtLR04wZUM1amIyeHZjbk1wS1NCamRIZ3VZMjlzYjNKeklEMGdabUZzYzJVN1hHNGdJR2xtSUNocGMxVnVaR1ZtYVc1bFpDaGpkSGd1WTNWemRHOXRTVzV6Y0dWamRDa3BJR04wZUM1amRYTjBiMjFKYm5Od1pXTjBJRDBnZEhKMVpUdGNiaUFnYVdZZ0tHTjBlQzVqYjJ4dmNuTXBJR04wZUM1emRIbHNhWHBsSUQwZ2MzUjViR2w2WlZkcGRHaERiMnh2Y2p0Y2JpQWdjbVYwZFhKdUlHWnZjbTFoZEZaaGJIVmxLR04wZUN3Z2IySnFMQ0JqZEhndVpHVndkR2dwTzF4dWZWeHVaWGh3YjNKMGN5NXBibk53WldOMElEMGdhVzV6Y0dWamREdGNibHh1WEc0dkx5Qm9kSFJ3T2k4dlpXNHVkMmxyYVhCbFpHbGhMbTl5Wnk5M2FXdHBMMEZPVTBsZlpYTmpZWEJsWDJOdlpHVWpaM0poY0docFkzTmNibWx1YzNCbFkzUXVZMjlzYjNKeklEMGdlMXh1SUNBblltOXNaQ2NnT2lCYk1Td2dNakpkTEZ4dUlDQW5hWFJoYkdsakp5QTZJRnN6TENBeU0xMHNYRzRnSUNkMWJtUmxjbXhwYm1VbklEb2dXelFzSURJMFhTeGNiaUFnSjJsdWRtVnljMlVuSURvZ1d6Y3NJREkzWFN4Y2JpQWdKM2RvYVhSbEp5QTZJRnN6Tnl3Z016bGRMRnh1SUNBblozSmxlU2NnT2lCYk9UQXNJRE01WFN4Y2JpQWdKMkpzWVdOckp5QTZJRnN6TUN3Z016bGRMRnh1SUNBbllteDFaU2NnT2lCYk16UXNJRE01WFN4Y2JpQWdKMk41WVc0bklEb2dXek0yTENBek9WMHNYRzRnSUNkbmNtVmxiaWNnT2lCYk16SXNJRE01WFN4Y2JpQWdKMjFoWjJWdWRHRW5JRG9nV3pNMUxDQXpPVjBzWEc0Z0lDZHlaV1FuSURvZ1d6TXhMQ0F6T1Ywc1hHNGdJQ2Q1Wld4c2IzY25JRG9nV3pNekxDQXpPVjFjYm4wN1hHNWNiaTh2SUVSdmJpZDBJSFZ6WlNBbllteDFaU2NnYm05MElIWnBjMmxpYkdVZ2IyNGdZMjFrTG1WNFpWeHVhVzV6Y0dWamRDNXpkSGxzWlhNZ1BTQjdYRzRnSUNkemNHVmphV0ZzSnpvZ0oyTjVZVzRuTEZ4dUlDQW5iblZ0WW1WeUp6b2dKM2xsYkd4dmR5Y3NYRzRnSUNkaWIyOXNaV0Z1SnpvZ0ozbGxiR3h2ZHljc1hHNGdJQ2QxYm1SbFptbHVaV1FuT2lBblozSmxlU2NzWEc0Z0lDZHVkV3hzSnpvZ0oySnZiR1FuTEZ4dUlDQW5jM1J5YVc1bkp6b2dKMmR5WldWdUp5eGNiaUFnSjJSaGRHVW5PaUFuYldGblpXNTBZU2NzWEc0Z0lDOHZJRndpYm1GdFpWd2lPaUJwYm5SbGJuUnBiMjVoYkd4NUlHNXZkQ0J6ZEhsc2FXNW5YRzRnSUNkeVpXZGxlSEFuT2lBbmNtVmtKMXh1ZlR0Y2JseHVYRzVtZFc1amRHbHZiaUJ6ZEhsc2FYcGxWMmwwYUVOdmJHOXlLSE4wY2l3Z2MzUjViR1ZVZVhCbEtTQjdYRzRnSUhaaGNpQnpkSGxzWlNBOUlHbHVjM0JsWTNRdWMzUjViR1Z6VzNOMGVXeGxWSGx3WlYwN1hHNWNiaUFnYVdZZ0tITjBlV3hsS1NCN1hHNGdJQ0FnY21WMGRYSnVJQ2RjWEhVd01ERmlXeWNnS3lCcGJuTndaV04wTG1OdmJHOXljMXR6ZEhsc1pWMWJNRjBnS3lBbmJTY2dLeUJ6ZEhJZ0sxeHVJQ0FnSUNBZ0lDQWdJQ0FuWEZ4MU1EQXhZbHNuSUNzZ2FXNXpjR1ZqZEM1amIyeHZjbk5iYzNSNWJHVmRXekZkSUNzZ0oyMG5PMXh1SUNCOUlHVnNjMlVnZTF4dUlDQWdJSEpsZEhWeWJpQnpkSEk3WEc0Z0lIMWNibjFjYmx4dVhHNW1kVzVqZEdsdmJpQnpkSGxzYVhwbFRtOURiMnh2Y2loemRISXNJSE4wZVd4bFZIbHdaU2tnZTF4dUlDQnlaWFIxY200Z2MzUnlPMXh1ZlZ4dVhHNWNibVoxYm1OMGFXOXVJR0Z5Y21GNVZHOUlZWE5vS0dGeWNtRjVLU0I3WEc0Z0lIWmhjaUJvWVhOb0lEMGdlMzA3WEc1Y2JpQWdZWEp5WVhrdVptOXlSV0ZqYUNobWRXNWpkR2x2YmloMllXd3NJR2xrZUNrZ2UxeHVJQ0FnSUdoaGMyaGJkbUZzWFNBOUlIUnlkV1U3WEc0Z0lIMHBPMXh1WEc0Z0lISmxkSFZ5YmlCb1lYTm9PMXh1ZlZ4dVhHNWNibVoxYm1OMGFXOXVJR1p2Y20xaGRGWmhiSFZsS0dOMGVDd2dkbUZzZFdVc0lISmxZM1Z5YzJWVWFXMWxjeWtnZTF4dUlDQXZMeUJRY205MmFXUmxJR0VnYUc5dmF5Qm1iM0lnZFhObGNpMXpjR1ZqYVdacFpXUWdhVzV6Y0dWamRDQm1kVzVqZEdsdmJuTXVYRzRnSUM4dklFTm9aV05ySUhSb1lYUWdkbUZzZFdVZ2FYTWdZVzRnYjJKcVpXTjBJSGRwZEdnZ1lXNGdhVzV6Y0dWamRDQm1kVzVqZEdsdmJpQnZiaUJwZEZ4dUlDQnBaaUFvWTNSNExtTjFjM1J2YlVsdWMzQmxZM1FnSmlaY2JpQWdJQ0FnSUhaaGJIVmxJQ1ltWEc0Z0lDQWdJQ0JwYzBaMWJtTjBhVzl1S0haaGJIVmxMbWx1YzNCbFkzUXBJQ1ltWEc0Z0lDQWdJQ0F2THlCR2FXeDBaWElnYjNWMElIUm9aU0IxZEdsc0lHMXZaSFZzWlN3Z2FYUW5jeUJwYm5Od1pXTjBJR1oxYm1OMGFXOXVJR2x6SUhOd1pXTnBZV3hjYmlBZ0lDQWdJSFpoYkhWbExtbHVjM0JsWTNRZ0lUMDlJR1Y0Y0c5eWRITXVhVzV6Y0dWamRDQW1KbHh1SUNBZ0lDQWdMeThnUVd4emJ5Qm1hV3gwWlhJZ2IzVjBJR0Z1ZVNCd2NtOTBiM1I1Y0dVZ2IySnFaV04wY3lCMWMybHVaeUIwYUdVZ1kybHlZM1ZzWVhJZ1kyaGxZMnN1WEc0Z0lDQWdJQ0FoS0haaGJIVmxMbU52Ym5OMGNuVmpkRzl5SUNZbUlIWmhiSFZsTG1OdmJuTjBjblZqZEc5eUxuQnliM1J2ZEhsd1pTQTlQVDBnZG1Gc2RXVXBLU0I3WEc0Z0lDQWdkbUZ5SUhKbGRDQTlJSFpoYkhWbExtbHVjM0JsWTNRb2NtVmpkWEp6WlZScGJXVnpMQ0JqZEhncE8xeHVJQ0FnSUdsbUlDZ2hhWE5UZEhKcGJtY29jbVYwS1NrZ2UxeHVJQ0FnSUNBZ2NtVjBJRDBnWm05eWJXRjBWbUZzZFdVb1kzUjRMQ0J5WlhRc0lISmxZM1Z5YzJWVWFXMWxjeWs3WEc0Z0lDQWdmVnh1SUNBZ0lISmxkSFZ5YmlCeVpYUTdYRzRnSUgxY2JseHVJQ0F2THlCUWNtbHRhWFJwZG1VZ2RIbHdaWE1nWTJGdWJtOTBJR2hoZG1VZ2NISnZjR1Z5ZEdsbGMxeHVJQ0IyWVhJZ2NISnBiV2wwYVhabElEMGdabTl5YldGMFVISnBiV2wwYVhabEtHTjBlQ3dnZG1Gc2RXVXBPMXh1SUNCcFppQW9jSEpwYldsMGFYWmxLU0I3WEc0Z0lDQWdjbVYwZFhKdUlIQnlhVzFwZEdsMlpUdGNiaUFnZlZ4dVhHNGdJQzh2SUV4dmIyc2dkWEFnZEdobElHdGxlWE1nYjJZZ2RHaGxJRzlpYW1WamRDNWNiaUFnZG1GeUlHdGxlWE1nUFNCUFltcGxZM1F1YTJWNWN5aDJZV3gxWlNrN1hHNGdJSFpoY2lCMmFYTnBZbXhsUzJWNWN5QTlJR0Z5Y21GNVZHOUlZWE5vS0d0bGVYTXBPMXh1WEc0Z0lHbG1JQ2hqZEhndWMyaHZkMGhwWkdSbGJpa2dlMXh1SUNBZ0lHdGxlWE1nUFNCUFltcGxZM1F1WjJWMFQzZHVVSEp2Y0dWeWRIbE9ZVzFsY3loMllXeDFaU2s3WEc0Z0lIMWNibHh1SUNBdkx5QkpSU0JrYjJWemJpZDBJRzFoYTJVZ1pYSnliM0lnWm1sbGJHUnpJRzV2YmkxbGJuVnRaWEpoWW14bFhHNGdJQzh2SUdoMGRIQTZMeTl0YzJSdUxtMXBZM0p2YzI5bWRDNWpiMjB2Wlc0dGRYTXZiR2xpY21GeWVTOXBaUzlrZDNjMU1uTmlkQ2gyUFhaekxqazBLUzVoYzNCNFhHNGdJR2xtSUNocGMwVnljbTl5S0haaGJIVmxLVnh1SUNBZ0lDQWdKaVlnS0d0bGVYTXVhVzVrWlhoUFppZ25iV1Z6YzJGblpTY3BJRDQ5SURBZ2ZId2dhMlY1Y3k1cGJtUmxlRTltS0Nka1pYTmpjbWx3ZEdsdmJpY3BJRDQ5SURBcEtTQjdYRzRnSUNBZ2NtVjBkWEp1SUdadmNtMWhkRVZ5Y205eUtIWmhiSFZsS1R0Y2JpQWdmVnh1WEc0Z0lDOHZJRk52YldVZ2RIbHdaU0J2WmlCdlltcGxZM1FnZDJsMGFHOTFkQ0J3Y205d1pYSjBhV1Z6SUdOaGJpQmlaU0J6YUc5eWRHTjFkSFJsWkM1Y2JpQWdhV1lnS0d0bGVYTXViR1Z1WjNSb0lEMDlQU0F3S1NCN1hHNGdJQ0FnYVdZZ0tHbHpSblZ1WTNScGIyNG9kbUZzZFdVcEtTQjdYRzRnSUNBZ0lDQjJZWElnYm1GdFpTQTlJSFpoYkhWbExtNWhiV1VnUHlBbk9pQW5JQ3NnZG1Gc2RXVXVibUZ0WlNBNklDY25PMXh1SUNBZ0lDQWdjbVYwZFhKdUlHTjBlQzV6ZEhsc2FYcGxLQ2RiUm5WdVkzUnBiMjRuSUNzZ2JtRnRaU0FySUNkZEp5d2dKM053WldOcFlXd25LVHRjYmlBZ0lDQjlYRzRnSUNBZ2FXWWdLR2x6VW1WblJYaHdLSFpoYkhWbEtTa2dlMXh1SUNBZ0lDQWdjbVYwZFhKdUlHTjBlQzV6ZEhsc2FYcGxLRkpsWjBWNGNDNXdjbTkwYjNSNWNHVXVkRzlUZEhKcGJtY3VZMkZzYkNoMllXeDFaU2tzSUNkeVpXZGxlSEFuS1R0Y2JpQWdJQ0I5WEc0Z0lDQWdhV1lnS0dselJHRjBaU2gyWVd4MVpTa3BJSHRjYmlBZ0lDQWdJSEpsZEhWeWJpQmpkSGd1YzNSNWJHbDZaU2hFWVhSbExuQnliM1J2ZEhsd1pTNTBiMU4wY21sdVp5NWpZV3hzS0haaGJIVmxLU3dnSjJSaGRHVW5LVHRjYmlBZ0lDQjlYRzRnSUNBZ2FXWWdLR2x6UlhKeWIzSW9kbUZzZFdVcEtTQjdYRzRnSUNBZ0lDQnlaWFIxY200Z1ptOXliV0YwUlhKeWIzSW9kbUZzZFdVcE8xeHVJQ0FnSUgxY2JpQWdmVnh1WEc0Z0lIWmhjaUJpWVhObElEMGdKeWNzSUdGeWNtRjVJRDBnWm1Gc2MyVXNJR0p5WVdObGN5QTlJRnNuZXljc0lDZDlKMTA3WEc1Y2JpQWdMeThnVFdGclpTQkJjbkpoZVNCellYa2dkR2hoZENCMGFHVjVJR0Z5WlNCQmNuSmhlVnh1SUNCcFppQW9hWE5CY25KaGVTaDJZV3gxWlNrcElIdGNiaUFnSUNCaGNuSmhlU0E5SUhSeWRXVTdYRzRnSUNBZ1luSmhZMlZ6SUQwZ1d5ZGJKeXdnSjEwblhUdGNiaUFnZlZ4dVhHNGdJQzh2SUUxaGEyVWdablZ1WTNScGIyNXpJSE5oZVNCMGFHRjBJSFJvWlhrZ1lYSmxJR1oxYm1OMGFXOXVjMXh1SUNCcFppQW9hWE5HZFc1amRHbHZiaWgyWVd4MVpTa3BJSHRjYmlBZ0lDQjJZWElnYmlBOUlIWmhiSFZsTG01aGJXVWdQeUFuT2lBbklDc2dkbUZzZFdVdWJtRnRaU0E2SUNjbk8xeHVJQ0FnSUdKaGMyVWdQU0FuSUZ0R2RXNWpkR2x2YmljZ0t5QnVJQ3NnSjEwbk8xeHVJQ0I5WEc1Y2JpQWdMeThnVFdGclpTQlNaV2RGZUhCeklITmhlU0IwYUdGMElIUm9aWGtnWVhKbElGSmxaMFY0Y0hOY2JpQWdhV1lnS0dselVtVm5SWGh3S0haaGJIVmxLU2tnZTF4dUlDQWdJR0poYzJVZ1BTQW5JQ2NnS3lCU1pXZEZlSEF1Y0hKdmRHOTBlWEJsTG5SdlUzUnlhVzVuTG1OaGJHd29kbUZzZFdVcE8xeHVJQ0I5WEc1Y2JpQWdMeThnVFdGclpTQmtZWFJsY3lCM2FYUm9JSEJ5YjNCbGNuUnBaWE1nWm1seWMzUWdjMkY1SUhSb1pTQmtZWFJsWEc0Z0lHbG1JQ2hwYzBSaGRHVW9kbUZzZFdVcEtTQjdYRzRnSUNBZ1ltRnpaU0E5SUNjZ0p5QXJJRVJoZEdVdWNISnZkRzkwZVhCbExuUnZWVlJEVTNSeWFXNW5MbU5oYkd3b2RtRnNkV1VwTzF4dUlDQjlYRzVjYmlBZ0x5OGdUV0ZyWlNCbGNuSnZjaUIzYVhSb0lHMWxjM05oWjJVZ1ptbHljM1FnYzJGNUlIUm9aU0JsY25KdmNseHVJQ0JwWmlBb2FYTkZjbkp2Y2loMllXeDFaU2twSUh0Y2JpQWdJQ0JpWVhObElEMGdKeUFuSUNzZ1ptOXliV0YwUlhKeWIzSW9kbUZzZFdVcE8xeHVJQ0I5WEc1Y2JpQWdhV1lnS0d0bGVYTXViR1Z1WjNSb0lEMDlQU0F3SUNZbUlDZ2hZWEp5WVhrZ2ZId2dkbUZzZFdVdWJHVnVaM1JvSUQwOUlEQXBLU0I3WEc0Z0lDQWdjbVYwZFhKdUlHSnlZV05sYzFzd1hTQXJJR0poYzJVZ0t5QmljbUZqWlhOYk1WMDdYRzRnSUgxY2JseHVJQ0JwWmlBb2NtVmpkWEp6WlZScGJXVnpJRHdnTUNrZ2UxeHVJQ0FnSUdsbUlDaHBjMUpsWjBWNGNDaDJZV3gxWlNrcElIdGNiaUFnSUNBZ0lISmxkSFZ5YmlCamRIZ3VjM1I1YkdsNlpTaFNaV2RGZUhBdWNISnZkRzkwZVhCbExuUnZVM1J5YVc1bkxtTmhiR3dvZG1Gc2RXVXBMQ0FuY21WblpYaHdKeWs3WEc0Z0lDQWdmU0JsYkhObElIdGNiaUFnSUNBZ0lISmxkSFZ5YmlCamRIZ3VjM1I1YkdsNlpTZ25XMDlpYW1WamRGMG5MQ0FuYzNCbFkybGhiQ2NwTzF4dUlDQWdJSDFjYmlBZ2ZWeHVYRzRnSUdOMGVDNXpaV1Z1TG5CMWMyZ29kbUZzZFdVcE8xeHVYRzRnSUhaaGNpQnZkWFJ3ZFhRN1hHNGdJR2xtSUNoaGNuSmhlU2tnZTF4dUlDQWdJRzkxZEhCMWRDQTlJR1p2Y20xaGRFRnljbUY1S0dOMGVDd2dkbUZzZFdVc0lISmxZM1Z5YzJWVWFXMWxjeXdnZG1semFXSnNaVXRsZVhNc0lHdGxlWE1wTzF4dUlDQjlJR1ZzYzJVZ2UxeHVJQ0FnSUc5MWRIQjFkQ0E5SUd0bGVYTXViV0Z3S0daMWJtTjBhVzl1S0d0bGVTa2dlMXh1SUNBZ0lDQWdjbVYwZFhKdUlHWnZjbTFoZEZCeWIzQmxjblI1S0dOMGVDd2dkbUZzZFdVc0lISmxZM1Z5YzJWVWFXMWxjeXdnZG1semFXSnNaVXRsZVhNc0lHdGxlU3dnWVhKeVlYa3BPMXh1SUNBZ0lIMHBPMXh1SUNCOVhHNWNiaUFnWTNSNExuTmxaVzR1Y0c5d0tDazdYRzVjYmlBZ2NtVjBkWEp1SUhKbFpIVmpaVlJ2VTJsdVoyeGxVM1J5YVc1bktHOTFkSEIxZEN3Z1ltRnpaU3dnWW5KaFkyVnpLVHRjYm4xY2JseHVYRzVtZFc1amRHbHZiaUJtYjNKdFlYUlFjbWx0YVhScGRtVW9ZM1I0TENCMllXeDFaU2tnZTF4dUlDQnBaaUFvYVhOVmJtUmxabWx1WldRb2RtRnNkV1VwS1Z4dUlDQWdJSEpsZEhWeWJpQmpkSGd1YzNSNWJHbDZaU2duZFc1a1pXWnBibVZrSnl3Z0ozVnVaR1ZtYVc1bFpDY3BPMXh1SUNCcFppQW9hWE5UZEhKcGJtY29kbUZzZFdVcEtTQjdYRzRnSUNBZ2RtRnlJSE5wYlhCc1pTQTlJQ2RjWENjbklDc2dTbE5QVGk1emRISnBibWRwWm5rb2RtRnNkV1VwTG5KbGNHeGhZMlVvTDE1Y0lueGNJaVF2Wnl3Z0p5Y3BYRzRnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0F1Y21Wd2JHRmpaU2d2Snk5bkxDQmNJbHhjWEZ3blhDSXBYRzRnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0F1Y21Wd2JHRmpaU2d2WEZ4Y1hGd2lMMmNzSUNkY0lpY3BJQ3NnSjF4Y0p5YzdYRzRnSUNBZ2NtVjBkWEp1SUdOMGVDNXpkSGxzYVhwbEtITnBiWEJzWlN3Z0ozTjBjbWx1WnljcE8xeHVJQ0I5WEc0Z0lHbG1JQ2hwYzA1MWJXSmxjaWgyWVd4MVpTa3BYRzRnSUNBZ2NtVjBkWEp1SUdOMGVDNXpkSGxzYVhwbEtDY25JQ3NnZG1Gc2RXVXNJQ2R1ZFcxaVpYSW5LVHRjYmlBZ2FXWWdLR2x6UW05dmJHVmhiaWgyWVd4MVpTa3BYRzRnSUNBZ2NtVjBkWEp1SUdOMGVDNXpkSGxzYVhwbEtDY25JQ3NnZG1Gc2RXVXNJQ2RpYjI5c1pXRnVKeWs3WEc0Z0lDOHZJRVp2Y2lCemIyMWxJSEpsWVhOdmJpQjBlWEJsYjJZZ2JuVnNiQ0JwY3lCY0ltOWlhbVZqZEZ3aUxDQnpieUJ6Y0dWamFXRnNJR05oYzJVZ2FHVnlaUzVjYmlBZ2FXWWdLR2x6VG5Wc2JDaDJZV3gxWlNrcFhHNGdJQ0FnY21WMGRYSnVJR04wZUM1emRIbHNhWHBsS0NkdWRXeHNKeXdnSjI1MWJHd25LVHRjYm4xY2JseHVYRzVtZFc1amRHbHZiaUJtYjNKdFlYUkZjbkp2Y2loMllXeDFaU2tnZTF4dUlDQnlaWFIxY200Z0oxc25JQ3NnUlhKeWIzSXVjSEp2ZEc5MGVYQmxMblJ2VTNSeWFXNW5MbU5oYkd3b2RtRnNkV1VwSUNzZ0oxMG5PMXh1ZlZ4dVhHNWNibVoxYm1OMGFXOXVJR1p2Y20xaGRFRnljbUY1S0dOMGVDd2dkbUZzZFdVc0lISmxZM1Z5YzJWVWFXMWxjeXdnZG1semFXSnNaVXRsZVhNc0lHdGxlWE1wSUh0Y2JpQWdkbUZ5SUc5MWRIQjFkQ0E5SUZ0ZE8xeHVJQ0JtYjNJZ0tIWmhjaUJwSUQwZ01Dd2diQ0E5SUhaaGJIVmxMbXhsYm1kMGFEc2dhU0E4SUd3N0lDc3JhU2tnZTF4dUlDQWdJR2xtSUNob1lYTlBkMjVRY205d1pYSjBlU2gyWVd4MVpTd2dVM1J5YVc1bktHa3BLU2tnZTF4dUlDQWdJQ0FnYjNWMGNIVjBMbkIxYzJnb1ptOXliV0YwVUhKdmNHVnlkSGtvWTNSNExDQjJZV3gxWlN3Z2NtVmpkWEp6WlZScGJXVnpMQ0IyYVhOcFlteGxTMlY1Y3l4Y2JpQWdJQ0FnSUNBZ0lDQlRkSEpwYm1jb2FTa3NJSFJ5ZFdVcEtUdGNiaUFnSUNCOUlHVnNjMlVnZTF4dUlDQWdJQ0FnYjNWMGNIVjBMbkIxYzJnb0p5Y3BPMXh1SUNBZ0lIMWNiaUFnZlZ4dUlDQnJaWGx6TG1admNrVmhZMmdvWm5WdVkzUnBiMjRvYTJWNUtTQjdYRzRnSUNBZ2FXWWdLQ0ZyWlhrdWJXRjBZMmdvTDE1Y1hHUXJKQzhwS1NCN1hHNGdJQ0FnSUNCdmRYUndkWFF1Y0hWemFDaG1iM0p0WVhSUWNtOXdaWEowZVNoamRIZ3NJSFpoYkhWbExDQnlaV04xY25ObFZHbHRaWE1zSUhacGMybGliR1ZMWlhsekxGeHVJQ0FnSUNBZ0lDQWdJR3RsZVN3Z2RISjFaU2twTzF4dUlDQWdJSDFjYmlBZ2ZTazdYRzRnSUhKbGRIVnliaUJ2ZFhSd2RYUTdYRzU5WEc1Y2JseHVablZ1WTNScGIyNGdabTl5YldGMFVISnZjR1Z5ZEhrb1kzUjRMQ0IyWVd4MVpTd2djbVZqZFhKelpWUnBiV1Z6TENCMmFYTnBZbXhsUzJWNWN5d2dhMlY1TENCaGNuSmhlU2tnZTF4dUlDQjJZWElnYm1GdFpTd2djM1J5TENCa1pYTmpPMXh1SUNCa1pYTmpJRDBnVDJKcVpXTjBMbWRsZEU5M2JsQnliM0JsY25SNVJHVnpZM0pwY0hSdmNpaDJZV3gxWlN3Z2EyVjVLU0I4ZkNCN0lIWmhiSFZsT2lCMllXeDFaVnRyWlhsZElIMDdYRzRnSUdsbUlDaGtaWE5qTG1kbGRDa2dlMXh1SUNBZ0lHbG1JQ2hrWlhOakxuTmxkQ2tnZTF4dUlDQWdJQ0FnYzNSeUlEMGdZM1I0TG5OMGVXeHBlbVVvSjF0SFpYUjBaWEl2VTJWMGRHVnlYU2NzSUNkemNHVmphV0ZzSnlrN1hHNGdJQ0FnZlNCbGJITmxJSHRjYmlBZ0lDQWdJSE4wY2lBOUlHTjBlQzV6ZEhsc2FYcGxLQ2RiUjJWMGRHVnlYU2NzSUNkemNHVmphV0ZzSnlrN1hHNGdJQ0FnZlZ4dUlDQjlJR1ZzYzJVZ2UxeHVJQ0FnSUdsbUlDaGtaWE5qTG5ObGRDa2dlMXh1SUNBZ0lDQWdjM1J5SUQwZ1kzUjRMbk4wZVd4cGVtVW9KMXRUWlhSMFpYSmRKeXdnSjNOd1pXTnBZV3duS1R0Y2JpQWdJQ0I5WEc0Z0lIMWNiaUFnYVdZZ0tDRm9ZWE5QZDI1UWNtOXdaWEowZVNoMmFYTnBZbXhsUzJWNWN5d2dhMlY1S1NrZ2UxeHVJQ0FnSUc1aGJXVWdQU0FuV3ljZ0t5QnJaWGtnS3lBblhTYzdYRzRnSUgxY2JpQWdhV1lnS0NGemRISXBJSHRjYmlBZ0lDQnBaaUFvWTNSNExuTmxaVzR1YVc1a1pYaFBaaWhrWlhOakxuWmhiSFZsS1NBOElEQXBJSHRjYmlBZ0lDQWdJR2xtSUNocGMwNTFiR3dvY21WamRYSnpaVlJwYldWektTa2dlMXh1SUNBZ0lDQWdJQ0J6ZEhJZ1BTQm1iM0p0WVhSV1lXeDFaU2hqZEhnc0lHUmxjMk11ZG1Gc2RXVXNJRzUxYkd3cE8xeHVJQ0FnSUNBZ2ZTQmxiSE5sSUh0Y2JpQWdJQ0FnSUNBZ2MzUnlJRDBnWm05eWJXRjBWbUZzZFdVb1kzUjRMQ0JrWlhOakxuWmhiSFZsTENCeVpXTjFjbk5sVkdsdFpYTWdMU0F4S1R0Y2JpQWdJQ0FnSUgxY2JpQWdJQ0FnSUdsbUlDaHpkSEl1YVc1a1pYaFBaaWduWEZ4dUp5a2dQaUF0TVNrZ2UxeHVJQ0FnSUNBZ0lDQnBaaUFvWVhKeVlYa3BJSHRjYmlBZ0lDQWdJQ0FnSUNCemRISWdQU0J6ZEhJdWMzQnNhWFFvSjF4Y2JpY3BMbTFoY0NobWRXNWpkR2x2Ymloc2FXNWxLU0I3WEc0Z0lDQWdJQ0FnSUNBZ0lDQnlaWFIxY200Z0p5QWdKeUFySUd4cGJtVTdYRzRnSUNBZ0lDQWdJQ0FnZlNrdWFtOXBiaWduWEZ4dUp5a3VjM1ZpYzNSeUtESXBPMXh1SUNBZ0lDQWdJQ0I5SUdWc2MyVWdlMXh1SUNBZ0lDQWdJQ0FnSUhOMGNpQTlJQ2RjWEc0bklDc2djM1J5TG5Od2JHbDBLQ2RjWEc0bktTNXRZWEFvWm5WdVkzUnBiMjRvYkdsdVpTa2dlMXh1SUNBZ0lDQWdJQ0FnSUNBZ2NtVjBkWEp1SUNjZ0lDQW5JQ3NnYkdsdVpUdGNiaUFnSUNBZ0lDQWdJQ0I5S1M1cWIybHVLQ2RjWEc0bktUdGNiaUFnSUNBZ0lDQWdmVnh1SUNBZ0lDQWdmVnh1SUNBZ0lIMGdaV3h6WlNCN1hHNGdJQ0FnSUNCemRISWdQU0JqZEhndWMzUjViR2w2WlNnblcwTnBjbU4xYkdGeVhTY3NJQ2R6Y0dWamFXRnNKeWs3WEc0Z0lDQWdmVnh1SUNCOVhHNGdJR2xtSUNocGMxVnVaR1ZtYVc1bFpDaHVZVzFsS1NrZ2UxeHVJQ0FnSUdsbUlDaGhjbkpoZVNBbUppQnJaWGt1YldGMFkyZ29MMTVjWEdRckpDOHBLU0I3WEc0Z0lDQWdJQ0J5WlhSMWNtNGdjM1J5TzF4dUlDQWdJSDFjYmlBZ0lDQnVZVzFsSUQwZ1NsTlBUaTV6ZEhKcGJtZHBabmtvSnljZ0t5QnJaWGtwTzF4dUlDQWdJR2xtSUNodVlXMWxMbTFoZEdOb0tDOWVYQ0lvVzJFdGVrRXRXbDlkVzJFdGVrRXRXbDh3TFRsZEtpbGNJaVF2S1NrZ2UxeHVJQ0FnSUNBZ2JtRnRaU0E5SUc1aGJXVXVjM1ZpYzNSeUtERXNJRzVoYldVdWJHVnVaM1JvSUMwZ01pazdYRzRnSUNBZ0lDQnVZVzFsSUQwZ1kzUjRMbk4wZVd4cGVtVW9ibUZ0WlN3Z0oyNWhiV1VuS1R0Y2JpQWdJQ0I5SUdWc2MyVWdlMXh1SUNBZ0lDQWdibUZ0WlNBOUlHNWhiV1V1Y21Wd2JHRmpaU2d2Snk5bkxDQmNJbHhjWEZ3blhDSXBYRzRnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJQzV5WlhCc1lXTmxLQzljWEZ4Y1hDSXZaeXdnSjF3aUp5bGNiaUFnSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdMbkpsY0d4aFkyVW9MeWhlWENKOFhDSWtLUzluTENCY0lpZGNJaWs3WEc0Z0lDQWdJQ0J1WVcxbElEMGdZM1I0TG5OMGVXeHBlbVVvYm1GdFpTd2dKM04wY21sdVp5Y3BPMXh1SUNBZ0lIMWNiaUFnZlZ4dVhHNGdJSEpsZEhWeWJpQnVZVzFsSUNzZ0p6b2dKeUFySUhOMGNqdGNibjFjYmx4dVhHNW1kVzVqZEdsdmJpQnlaV1IxWTJWVWIxTnBibWRzWlZOMGNtbHVaeWh2ZFhSd2RYUXNJR0poYzJVc0lHSnlZV05sY3lrZ2UxeHVJQ0IyWVhJZ2JuVnRUR2x1WlhORmMzUWdQU0F3TzF4dUlDQjJZWElnYkdWdVozUm9JRDBnYjNWMGNIVjBMbkpsWkhWalpTaG1kVzVqZEdsdmJpaHdjbVYyTENCamRYSXBJSHRjYmlBZ0lDQnVkVzFNYVc1bGMwVnpkQ3NyTzF4dUlDQWdJR2xtSUNoamRYSXVhVzVrWlhoUFppZ25YRnh1SnlrZ1BqMGdNQ2tnYm5WdFRHbHVaWE5GYzNRckt6dGNiaUFnSUNCeVpYUjFjbTRnY0hKbGRpQXJJR04xY2k1eVpYQnNZV05sS0M5Y1hIVXdNREZpWEZ4YlhGeGtYRnhrUDIwdlp5d2dKeWNwTG14bGJtZDBhQ0FySURFN1hHNGdJSDBzSURBcE8xeHVYRzRnSUdsbUlDaHNaVzVuZEdnZ1BpQTJNQ2tnZTF4dUlDQWdJSEpsZEhWeWJpQmljbUZqWlhOYk1GMGdLMXh1SUNBZ0lDQWdJQ0FnSUNBb1ltRnpaU0E5UFQwZ0p5Y2dQeUFuSnlBNklHSmhjMlVnS3lBblhGeHVJQ2NwSUN0Y2JpQWdJQ0FnSUNBZ0lDQWdKeUFuSUN0Y2JpQWdJQ0FnSUNBZ0lDQWdiM1YwY0hWMExtcHZhVzRvSnl4Y1hHNGdJQ2NwSUN0Y2JpQWdJQ0FnSUNBZ0lDQWdKeUFuSUN0Y2JpQWdJQ0FnSUNBZ0lDQWdZbkpoWTJWeld6RmRPMXh1SUNCOVhHNWNiaUFnY21WMGRYSnVJR0p5WVdObGMxc3dYU0FySUdKaGMyVWdLeUFuSUNjZ0t5QnZkWFJ3ZFhRdWFtOXBiaWduTENBbktTQXJJQ2NnSnlBcklHSnlZV05sYzFzeFhUdGNibjFjYmx4dVhHNHZMeUJPVDFSRk9pQlVhR1Z6WlNCMGVYQmxJR05vWldOcmFXNW5JR1oxYm1OMGFXOXVjeUJwYm5SbGJuUnBiMjVoYkd4NUlHUnZiaWQwSUhWelpTQmdhVzV6ZEdGdVkyVnZabUJjYmk4dklHSmxZMkYxYzJVZ2FYUWdhWE1nWm5KaFoybHNaU0JoYm1RZ1kyRnVJR0psSUdWaGMybHNlU0JtWVd0bFpDQjNhWFJvSUdCUFltcGxZM1F1WTNKbFlYUmxLQ2xnTGx4dVpuVnVZM1JwYjI0Z2FYTkJjbkpoZVNoaGNpa2dlMXh1SUNCeVpYUjFjbTRnUVhKeVlYa3VhWE5CY25KaGVTaGhjaWs3WEc1OVhHNWxlSEJ2Y25SekxtbHpRWEp5WVhrZ1BTQnBjMEZ5Y21GNU8xeHVYRzVtZFc1amRHbHZiaUJwYzBKdmIyeGxZVzRvWVhKbktTQjdYRzRnSUhKbGRIVnliaUIwZVhCbGIyWWdZWEpuSUQwOVBTQW5ZbTl2YkdWaGJpYzdYRzU5WEc1bGVIQnZjblJ6TG1selFtOXZiR1ZoYmlBOUlHbHpRbTl2YkdWaGJqdGNibHh1Wm5WdVkzUnBiMjRnYVhOT2RXeHNLR0Z5WnlrZ2UxeHVJQ0J5WlhSMWNtNGdZWEpuSUQwOVBTQnVkV3hzTzF4dWZWeHVaWGh3YjNKMGN5NXBjMDUxYkd3Z1BTQnBjMDUxYkd3N1hHNWNibVoxYm1OMGFXOXVJR2x6VG5Wc2JFOXlWVzVrWldacGJtVmtLR0Z5WnlrZ2UxeHVJQ0J5WlhSMWNtNGdZWEpuSUQwOUlHNTFiR3c3WEc1OVhHNWxlSEJ2Y25SekxtbHpUblZzYkU5eVZXNWtaV1pwYm1Wa0lEMGdhWE5PZFd4c1QzSlZibVJsWm1sdVpXUTdYRzVjYm1aMWJtTjBhVzl1SUdselRuVnRZbVZ5S0dGeVp5a2dlMXh1SUNCeVpYUjFjbTRnZEhsd1pXOW1JR0Z5WnlBOVBUMGdKMjUxYldKbGNpYzdYRzU5WEc1bGVIQnZjblJ6TG1selRuVnRZbVZ5SUQwZ2FYTk9kVzFpWlhJN1hHNWNibVoxYm1OMGFXOXVJR2x6VTNSeWFXNW5LR0Z5WnlrZ2UxeHVJQ0J5WlhSMWNtNGdkSGx3Wlc5bUlHRnlaeUE5UFQwZ0ozTjBjbWx1WnljN1hHNTlYRzVsZUhCdmNuUnpMbWx6VTNSeWFXNW5JRDBnYVhOVGRISnBibWM3WEc1Y2JtWjFibU4wYVc5dUlHbHpVM2x0WW05c0tHRnlaeWtnZTF4dUlDQnlaWFIxY200Z2RIbHdaVzltSUdGeVp5QTlQVDBnSjNONWJXSnZiQ2M3WEc1OVhHNWxlSEJ2Y25SekxtbHpVM2x0WW05c0lEMGdhWE5UZVcxaWIydzdYRzVjYm1aMWJtTjBhVzl1SUdselZXNWtaV1pwYm1Wa0tHRnlaeWtnZTF4dUlDQnlaWFIxY200Z1lYSm5JRDA5UFNCMmIybGtJREE3WEc1OVhHNWxlSEJ2Y25SekxtbHpWVzVrWldacGJtVmtJRDBnYVhOVmJtUmxabWx1WldRN1hHNWNibVoxYm1OMGFXOXVJR2x6VW1WblJYaHdLSEpsS1NCN1hHNGdJSEpsZEhWeWJpQnBjMDlpYW1WamRDaHlaU2tnSmlZZ2IySnFaV04wVkc5VGRISnBibWNvY21VcElEMDlQU0FuVzI5aWFtVmpkQ0JTWldkRmVIQmRKenRjYm4xY2JtVjRjRzl5ZEhNdWFYTlNaV2RGZUhBZ1BTQnBjMUpsWjBWNGNEdGNibHh1Wm5WdVkzUnBiMjRnYVhOUFltcGxZM1FvWVhKbktTQjdYRzRnSUhKbGRIVnliaUIwZVhCbGIyWWdZWEpuSUQwOVBTQW5iMkpxWldOMEp5QW1KaUJoY21jZ0lUMDlJRzUxYkd3N1hHNTlYRzVsZUhCdmNuUnpMbWx6VDJKcVpXTjBJRDBnYVhOUFltcGxZM1E3WEc1Y2JtWjFibU4wYVc5dUlHbHpSR0YwWlNoa0tTQjdYRzRnSUhKbGRIVnliaUJwYzA5aWFtVmpkQ2hrS1NBbUppQnZZbXBsWTNSVWIxTjBjbWx1Wnloa0tTQTlQVDBnSjF0dlltcGxZM1FnUkdGMFpWMG5PMXh1ZlZ4dVpYaHdiM0owY3k1cGMwUmhkR1VnUFNCcGMwUmhkR1U3WEc1Y2JtWjFibU4wYVc5dUlHbHpSWEp5YjNJb1pTa2dlMXh1SUNCeVpYUjFjbTRnYVhOUFltcGxZM1FvWlNrZ0ppWmNiaUFnSUNBZ0lDaHZZbXBsWTNSVWIxTjBjbWx1WnlobEtTQTlQVDBnSjF0dlltcGxZM1FnUlhKeWIzSmRKeUI4ZkNCbElHbHVjM1JoYm1ObGIyWWdSWEp5YjNJcE8xeHVmVnh1Wlhod2IzSjBjeTVwYzBWeWNtOXlJRDBnYVhORmNuSnZjanRjYmx4dVpuVnVZM1JwYjI0Z2FYTkdkVzVqZEdsdmJpaGhjbWNwSUh0Y2JpQWdjbVYwZFhKdUlIUjVjR1Z2WmlCaGNtY2dQVDA5SUNkbWRXNWpkR2x2YmljN1hHNTlYRzVsZUhCdmNuUnpMbWx6Um5WdVkzUnBiMjRnUFNCcGMwWjFibU4wYVc5dU8xeHVYRzVtZFc1amRHbHZiaUJwYzFCeWFXMXBkR2wyWlNoaGNtY3BJSHRjYmlBZ2NtVjBkWEp1SUdGeVp5QTlQVDBnYm5Wc2JDQjhmRnh1SUNBZ0lDQWdJQ0FnZEhsd1pXOW1JR0Z5WnlBOVBUMGdKMkp2YjJ4bFlXNG5JSHg4WEc0Z0lDQWdJQ0FnSUNCMGVYQmxiMllnWVhKbklEMDlQU0FuYm5WdFltVnlKeUI4ZkZ4dUlDQWdJQ0FnSUNBZ2RIbHdaVzltSUdGeVp5QTlQVDBnSjNOMGNtbHVaeWNnZkh4Y2JpQWdJQ0FnSUNBZ0lIUjVjR1Z2WmlCaGNtY2dQVDA5SUNkemVXMWliMnduSUh4OElDQXZMeUJGVXpZZ2MzbHRZbTlzWEc0Z0lDQWdJQ0FnSUNCMGVYQmxiMllnWVhKbklEMDlQU0FuZFc1a1pXWnBibVZrSnp0Y2JuMWNibVY0Y0c5eWRITXVhWE5RY21sdGFYUnBkbVVnUFNCcGMxQnlhVzFwZEdsMlpUdGNibHh1Wlhod2IzSjBjeTVwYzBKMVptWmxjaUE5SUhKbGNYVnBjbVVvSnk0dmMzVndjRzl5ZEM5cGMwSjFabVpsY2ljcE8xeHVYRzVtZFc1amRHbHZiaUJ2WW1wbFkzUlViMU4wY21sdVp5aHZLU0I3WEc0Z0lISmxkSFZ5YmlCUFltcGxZM1F1Y0hKdmRHOTBlWEJsTG5SdlUzUnlhVzVuTG1OaGJHd29ieWs3WEc1OVhHNWNibHh1Wm5WdVkzUnBiMjRnY0dGa0tHNHBJSHRjYmlBZ2NtVjBkWEp1SUc0Z1BDQXhNQ0EvSUNjd0p5QXJJRzR1ZEc5VGRISnBibWNvTVRBcElEb2diaTUwYjFOMGNtbHVaeWd4TUNrN1hHNTlYRzVjYmx4dWRtRnlJRzF2Ym5Sb2N5QTlJRnNuU21GdUp5d2dKMFpsWWljc0lDZE5ZWEluTENBblFYQnlKeXdnSjAxaGVTY3NJQ2RLZFc0bkxDQW5TblZzSnl3Z0owRjFaeWNzSUNkVFpYQW5MRnh1SUNBZ0lDQWdJQ0FnSUNBZ0lDQW5UMk4wSnl3Z0owNXZkaWNzSUNkRVpXTW5YVHRjYmx4dUx5OGdNallnUm1WaUlERTJPakU1T2pNMFhHNW1kVzVqZEdsdmJpQjBhVzFsYzNSaGJYQW9LU0I3WEc0Z0lIWmhjaUJrSUQwZ2JtVjNJRVJoZEdVb0tUdGNiaUFnZG1GeUlIUnBiV1VnUFNCYmNHRmtLR1F1WjJWMFNHOTFjbk1vS1Nrc1hHNGdJQ0FnSUNBZ0lDQWdJQ0FnSUhCaFpDaGtMbWRsZEUxcGJuVjBaWE1vS1Nrc1hHNGdJQ0FnSUNBZ0lDQWdJQ0FnSUhCaFpDaGtMbWRsZEZObFkyOXVaSE1vS1NsZExtcHZhVzRvSnpvbktUdGNiaUFnY21WMGRYSnVJRnRrTG1kbGRFUmhkR1VvS1N3Z2JXOXVkR2h6VzJRdVoyVjBUVzl1ZEdnb0tWMHNJSFJwYldWZExtcHZhVzRvSnlBbktUdGNibjFjYmx4dVhHNHZMeUJzYjJjZ2FYTWdhblZ6ZENCaElIUm9hVzRnZDNKaGNIQmxjaUIwYnlCamIyNXpiMnhsTG14dlp5QjBhR0YwSUhCeVpYQmxibVJ6SUdFZ2RHbHRaWE4wWVcxd1hHNWxlSEJ2Y25SekxteHZaeUE5SUdaMWJtTjBhVzl1S0NrZ2UxeHVJQ0JqYjI1emIyeGxMbXh2WnlnbkpYTWdMU0FsY3ljc0lIUnBiV1Z6ZEdGdGNDZ3BMQ0JsZUhCdmNuUnpMbVp2Y20xaGRDNWhjSEJzZVNobGVIQnZjblJ6TENCaGNtZDFiV1Z1ZEhNcEtUdGNibjA3WEc1Y2JseHVMeW9xWEc0Z0tpQkpibWhsY21sMElIUm9aU0J3Y205MGIzUjVjR1VnYldWMGFHOWtjeUJtY205dElHOXVaU0JqYjI1emRISjFZM1J2Y2lCcGJuUnZJR0Z1YjNSb1pYSXVYRzRnS2x4dUlDb2dWR2hsSUVaMWJtTjBhVzl1TG5CeWIzUnZkSGx3WlM1cGJtaGxjbWwwY3lCbWNtOXRJR3hoYm1jdWFuTWdjbVYzY21sMGRHVnVJR0Z6SUdFZ2MzUmhibVJoYkc5dVpWeHVJQ29nWm5WdVkzUnBiMjRnS0c1dmRDQnZiaUJHZFc1amRHbHZiaTV3Y205MGIzUjVjR1VwTGlCT1QxUkZPaUJKWmlCMGFHbHpJR1pwYkdVZ2FYTWdkRzhnWW1VZ2JHOWhaR1ZrWEc0Z0tpQmtkWEpwYm1jZ1ltOXZkSE4wY21Gd2NHbHVaeUIwYUdseklHWjFibU4wYVc5dUlHNWxaV1J6SUhSdklHSmxJSEpsZDNKcGRIUmxiaUIxYzJsdVp5QnpiMjFsSUc1aGRHbDJaVnh1SUNvZ1puVnVZM1JwYjI1eklHRnpJSEJ5YjNSdmRIbHdaU0J6WlhSMWNDQjFjMmx1WnlCdWIzSnRZV3dnU21GMllWTmpjbWx3ZENCa2IyVnpJRzV2ZENCM2IzSnJJR0Z6WEc0Z0tpQmxlSEJsWTNSbFpDQmtkWEpwYm1jZ1ltOXZkSE4wY21Gd2NHbHVaeUFvYzJWbElHMXBjbkp2Y2k1cWN5QnBiaUJ5TVRFME9UQXpLUzVjYmlBcVhHNGdLaUJBY0dGeVlXMGdlMloxYm1OMGFXOXVmU0JqZEc5eUlFTnZibk4wY25WamRHOXlJR1oxYm1OMGFXOXVJSGRvYVdOb0lHNWxaV1J6SUhSdklHbHVhR1Z5YVhRZ2RHaGxYRzRnS2lBZ0lDQWdjSEp2ZEc5MGVYQmxMbHh1SUNvZ1FIQmhjbUZ0SUh0bWRXNWpkR2x2Ym4wZ2MzVndaWEpEZEc5eUlFTnZibk4wY25WamRHOXlJR1oxYm1OMGFXOXVJSFJ2SUdsdWFHVnlhWFFnY0hKdmRHOTBlWEJsSUdaeWIyMHVYRzRnS2k5Y2JtVjRjRzl5ZEhNdWFXNW9aWEpwZEhNZ1BTQnlaWEYxYVhKbEtDZHBibWhsY21sMGN5Y3BPMXh1WEc1bGVIQnZjblJ6TGw5bGVIUmxibVFnUFNCbWRXNWpkR2x2YmlodmNtbG5hVzRzSUdGa1pDa2dlMXh1SUNBdkx5QkViMjRuZENCa2J5QmhibmwwYUdsdVp5QnBaaUJoWkdRZ2FYTnVKM1FnWVc0Z2IySnFaV04wWEc0Z0lHbG1JQ2doWVdSa0lIeDhJQ0ZwYzA5aWFtVmpkQ2hoWkdRcEtTQnlaWFIxY200Z2IzSnBaMmx1TzF4dVhHNGdJSFpoY2lCclpYbHpJRDBnVDJKcVpXTjBMbXRsZVhNb1lXUmtLVHRjYmlBZ2RtRnlJR2tnUFNCclpYbHpMbXhsYm1kMGFEdGNiaUFnZDJocGJHVWdLR2t0TFNrZ2UxeHVJQ0FnSUc5eWFXZHBibHRyWlhselcybGRYU0E5SUdGa1pGdHJaWGx6VzJsZFhUdGNiaUFnZlZ4dUlDQnlaWFIxY200Z2IzSnBaMmx1TzF4dWZUdGNibHh1Wm5WdVkzUnBiMjRnYUdGelQzZHVVSEp2Y0dWeWRIa29iMkpxTENCd2NtOXdLU0I3WEc0Z0lISmxkSFZ5YmlCUFltcGxZM1F1Y0hKdmRHOTBlWEJsTG1oaGMwOTNibEJ5YjNCbGNuUjVMbU5oYkd3b2IySnFMQ0J3Y205d0tUdGNibjFjYmlKZGZRPT0iXX0=
